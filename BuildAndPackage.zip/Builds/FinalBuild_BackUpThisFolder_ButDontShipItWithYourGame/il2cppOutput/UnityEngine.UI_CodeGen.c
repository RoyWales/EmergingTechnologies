﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.String UnityEngine.UI.AnimationTriggers::get_normalTrigger()
extern void AnimationTriggers_get_normalTrigger_mDB8A7C5C4B69515C514BB138724E25F16FCED43F (void);
// 0x00000002 System.Void UnityEngine.UI.AnimationTriggers::set_normalTrigger(System.String)
extern void AnimationTriggers_set_normalTrigger_m43C30CD216A826221653CF8648B1C1823EBBA8E6 (void);
// 0x00000003 System.String UnityEngine.UI.AnimationTriggers::get_highlightedTrigger()
extern void AnimationTriggers_get_highlightedTrigger_m492093112EC52907A3B5ED518BAD366B0052EDCA (void);
// 0x00000004 System.Void UnityEngine.UI.AnimationTriggers::set_highlightedTrigger(System.String)
extern void AnimationTriggers_set_highlightedTrigger_mCAD700865DD27254AFCA56FE85E2457ECF4CE6B7 (void);
// 0x00000005 System.String UnityEngine.UI.AnimationTriggers::get_pressedTrigger()
extern void AnimationTriggers_get_pressedTrigger_mFB9A652E90CCCB38FCF47EE464D20FACE41399B9 (void);
// 0x00000006 System.Void UnityEngine.UI.AnimationTriggers::set_pressedTrigger(System.String)
extern void AnimationTriggers_set_pressedTrigger_m1AEC4AC3C6CF43AE7EFE2B8E9A7561A5C2F7A5A0 (void);
// 0x00000007 System.String UnityEngine.UI.AnimationTriggers::get_selectedTrigger()
extern void AnimationTriggers_get_selectedTrigger_m631840BD0D4ED252C62E11405B29826F9BC419E8 (void);
// 0x00000008 System.Void UnityEngine.UI.AnimationTriggers::set_selectedTrigger(System.String)
extern void AnimationTriggers_set_selectedTrigger_m3AC876A19515E1901E0986781756F339A13E45A9 (void);
// 0x00000009 System.String UnityEngine.UI.AnimationTriggers::get_disabledTrigger()
extern void AnimationTriggers_get_disabledTrigger_mC91BD8165E64C82F9DCB7E0549ACB2D0537CE376 (void);
// 0x0000000A System.Void UnityEngine.UI.AnimationTriggers::set_disabledTrigger(System.String)
extern void AnimationTriggers_set_disabledTrigger_m20289A9FDAF524362F32320D57EF4E5A323299C1 (void);
// 0x0000000B System.Void UnityEngine.UI.AnimationTriggers::.ctor()
extern void AnimationTriggers__ctor_mDF3C8571BACB06DACEE75D9E5899B53C1D429A02 (void);
// 0x0000000C System.Void UnityEngine.UI.Button::.ctor()
extern void Button__ctor_m0A1FC265F589989085C1909BC8D93E33A698D8E5 (void);
// 0x0000000D UnityEngine.UI.Button/ButtonClickedEvent UnityEngine.UI.Button::get_onClick()
extern void Button_get_onClick_m701712A7F7F000CC80D517C4510697E15722C35C (void);
// 0x0000000E System.Void UnityEngine.UI.Button::set_onClick(UnityEngine.UI.Button/ButtonClickedEvent)
extern void Button_set_onClick_m4CD77BD99635400BA18692D591BEA79A7ECC66C3 (void);
// 0x0000000F System.Void UnityEngine.UI.Button::Press()
extern void Button_Press_mEF76F32CD5C01C1D8B00B80BDFC0C6CEEEF2C993 (void);
// 0x00000010 System.Void UnityEngine.UI.Button::OnPointerClick(UnityEngine.EventSystems.PointerEventData)
extern void Button_OnPointerClick_mB76B80D7374811C7BBE11DA188E2656904AE5422 (void);
// 0x00000011 System.Void UnityEngine.UI.Button::OnSubmit(UnityEngine.EventSystems.BaseEventData)
extern void Button_OnSubmit_m700E3D529DEE2FB6214BD698C61A3C7CDA08F0A8 (void);
// 0x00000012 System.Collections.IEnumerator UnityEngine.UI.Button::OnFinishSubmit()
extern void Button_OnFinishSubmit_m72771C6FF84DA31AE09E936D2D7FB6771FE5A7D9 (void);
// 0x00000013 System.Void UnityEngine.UI.Button/ButtonClickedEvent::.ctor()
extern void ButtonClickedEvent__ctor_m2B38CD66BDA4E63A19DB233BFA32C828A3D5290D (void);
// 0x00000014 System.Void UnityEngine.UI.Button/<OnFinishSubmit>d__9::.ctor(System.Int32)
extern void U3COnFinishSubmitU3Ed__9__ctor_m52988E24A7D4CE00B0F8A0F60A6EC20166027553 (void);
// 0x00000015 System.Void UnityEngine.UI.Button/<OnFinishSubmit>d__9::System.IDisposable.Dispose()
extern void U3COnFinishSubmitU3Ed__9_System_IDisposable_Dispose_m15AFD67ECC7FD7739798F4F063F3978AA19D41EA (void);
// 0x00000016 System.Boolean UnityEngine.UI.Button/<OnFinishSubmit>d__9::MoveNext()
extern void U3COnFinishSubmitU3Ed__9_MoveNext_m1D344B644399C92B28851F8630337135752BDE2A (void);
// 0x00000017 System.Object UnityEngine.UI.Button/<OnFinishSubmit>d__9::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3COnFinishSubmitU3Ed__9_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m82819377766A051FA756675E7EDB47088418FD96 (void);
// 0x00000018 System.Void UnityEngine.UI.Button/<OnFinishSubmit>d__9::System.Collections.IEnumerator.Reset()
extern void U3COnFinishSubmitU3Ed__9_System_Collections_IEnumerator_Reset_m3C1D75C11B17DE106053B97EC52822B74591061F (void);
// 0x00000019 System.Object UnityEngine.UI.Button/<OnFinishSubmit>d__9::System.Collections.IEnumerator.get_Current()
extern void U3COnFinishSubmitU3Ed__9_System_Collections_IEnumerator_get_Current_m26114B1DB5CA45B24C00C1B5596D29F76A4AED57 (void);
// 0x0000001A System.Void UnityEngine.UI.ICanvasElement::Rebuild(UnityEngine.UI.CanvasUpdate)
// 0x0000001B UnityEngine.Transform UnityEngine.UI.ICanvasElement::get_transform()
// 0x0000001C System.Void UnityEngine.UI.ICanvasElement::LayoutComplete()
// 0x0000001D System.Void UnityEngine.UI.ICanvasElement::GraphicUpdateComplete()
// 0x0000001E System.Boolean UnityEngine.UI.ICanvasElement::IsDestroyed()
// 0x0000001F System.Void UnityEngine.UI.CanvasUpdateRegistry::.ctor()
extern void CanvasUpdateRegistry__ctor_m2265E2D6AE72DCF25E4A8E52A03A390012CDB01C (void);
// 0x00000020 UnityEngine.UI.CanvasUpdateRegistry UnityEngine.UI.CanvasUpdateRegistry::get_instance()
extern void CanvasUpdateRegistry_get_instance_m57BA2006B09FA35EA4CE228078E7EAF0E01509DE (void);
// 0x00000021 System.Boolean UnityEngine.UI.CanvasUpdateRegistry::ObjectValidForUpdate(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_ObjectValidForUpdate_mFF8ACAA818FA7F73C5A6447C8E1E61631690660A (void);
// 0x00000022 System.Void UnityEngine.UI.CanvasUpdateRegistry::CleanInvalidItems()
extern void CanvasUpdateRegistry_CleanInvalidItems_mFDBE5D212F6B9649B6EB619AA8860DB72F3AA80E (void);
// 0x00000023 System.Void UnityEngine.UI.CanvasUpdateRegistry::PerformUpdate()
extern void CanvasUpdateRegistry_PerformUpdate_mA5CAEDD4452E5C8B58B688C08BC491AC2DAFD51A (void);
// 0x00000024 System.Int32 UnityEngine.UI.CanvasUpdateRegistry::ParentCount(UnityEngine.Transform)
extern void CanvasUpdateRegistry_ParentCount_mA10504532DE021BBA642052EDB70F46BAD4A55D2 (void);
// 0x00000025 System.Int32 UnityEngine.UI.CanvasUpdateRegistry::SortLayoutList(UnityEngine.UI.ICanvasElement,UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_SortLayoutList_m28074D05490A0F8B9D4E5699BEB357F92212141F (void);
// 0x00000026 System.Void UnityEngine.UI.CanvasUpdateRegistry::RegisterCanvasElementForLayoutRebuild(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_RegisterCanvasElementForLayoutRebuild_mB9571A1C6F0E32E1A0B07C46A1E68366E2A598AB (void);
// 0x00000027 System.Boolean UnityEngine.UI.CanvasUpdateRegistry::TryRegisterCanvasElementForLayoutRebuild(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_TryRegisterCanvasElementForLayoutRebuild_mCF214BCE7C81643D9684D93C2CC40FEC599E72EB (void);
// 0x00000028 System.Boolean UnityEngine.UI.CanvasUpdateRegistry::InternalRegisterCanvasElementForLayoutRebuild(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_InternalRegisterCanvasElementForLayoutRebuild_m609303A2651E3AC6B866A9ACDEAE0773F4CCAAC0 (void);
// 0x00000029 System.Void UnityEngine.UI.CanvasUpdateRegistry::RegisterCanvasElementForGraphicRebuild(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_RegisterCanvasElementForGraphicRebuild_mEBBD04C3B001E80801966E3347E70A35FCEBE8B1 (void);
// 0x0000002A System.Boolean UnityEngine.UI.CanvasUpdateRegistry::TryRegisterCanvasElementForGraphicRebuild(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_TryRegisterCanvasElementForGraphicRebuild_mFA63F8841FECC69E9EC84B9F4D7EAF4B0EBFE375 (void);
// 0x0000002B System.Boolean UnityEngine.UI.CanvasUpdateRegistry::InternalRegisterCanvasElementForGraphicRebuild(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_InternalRegisterCanvasElementForGraphicRebuild_m6CA79E8E3D6217779BF91B50C8D4C9FCF7492B60 (void);
// 0x0000002C System.Void UnityEngine.UI.CanvasUpdateRegistry::UnRegisterCanvasElementForRebuild(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_UnRegisterCanvasElementForRebuild_m61F9979AB8AFBA924430757FE09967D7A335D916 (void);
// 0x0000002D System.Void UnityEngine.UI.CanvasUpdateRegistry::DisableCanvasElementForRebuild(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_DisableCanvasElementForRebuild_mC1A68AC220C3755789E3CB51E8DBAC81CC61D62F (void);
// 0x0000002E System.Void UnityEngine.UI.CanvasUpdateRegistry::InternalUnRegisterCanvasElementForLayoutRebuild(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_InternalUnRegisterCanvasElementForLayoutRebuild_m2DA109CB4DE672A779EB3531D2E727D683E3A00A (void);
// 0x0000002F System.Void UnityEngine.UI.CanvasUpdateRegistry::InternalUnRegisterCanvasElementForGraphicRebuild(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_InternalUnRegisterCanvasElementForGraphicRebuild_m2A2FAEE11B508953630961D186E379ED890DA589 (void);
// 0x00000030 System.Void UnityEngine.UI.CanvasUpdateRegistry::InternalDisableCanvasElementForLayoutRebuild(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_InternalDisableCanvasElementForLayoutRebuild_m64780D6E94F424BEF771EC84E3F2A8D328B9CB6C (void);
// 0x00000031 System.Void UnityEngine.UI.CanvasUpdateRegistry::InternalDisableCanvasElementForGraphicRebuild(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_InternalDisableCanvasElementForGraphicRebuild_m6AC0A40EDD8462EEA49F355BFA793AD565DB5D57 (void);
// 0x00000032 System.Boolean UnityEngine.UI.CanvasUpdateRegistry::IsRebuildingLayout()
extern void CanvasUpdateRegistry_IsRebuildingLayout_m3C037968252136E38CF1AF8716DC671CE13917EA (void);
// 0x00000033 System.Boolean UnityEngine.UI.CanvasUpdateRegistry::IsRebuildingGraphics()
extern void CanvasUpdateRegistry_IsRebuildingGraphics_m424672693DCCC18C324436EDD483753B8137A482 (void);
// 0x00000034 System.Void UnityEngine.UI.CanvasUpdateRegistry::.cctor()
extern void CanvasUpdateRegistry__cctor_m19922681B4E153B487D8E81BE3A583CACBF32858 (void);
// 0x00000035 UnityEngine.Color UnityEngine.UI.ColorBlock::get_normalColor()
extern void ColorBlock_get_normalColor_m08A07A74ED743B4B0C1B5A5C35774F2D78F1F20E (void);
// 0x00000036 System.Void UnityEngine.UI.ColorBlock::set_normalColor(UnityEngine.Color)
extern void ColorBlock_set_normalColor_m3EBF594F6FA2C6494ACA9FCB9B458807D85B96F8 (void);
// 0x00000037 UnityEngine.Color UnityEngine.UI.ColorBlock::get_highlightedColor()
extern void ColorBlock_get_highlightedColor_m4D1A3D268CB00B351F56934F7F244DBC68855301 (void);
// 0x00000038 System.Void UnityEngine.UI.ColorBlock::set_highlightedColor(UnityEngine.Color)
extern void ColorBlock_set_highlightedColor_m04E97DF2CCE7CAC47120D8F486E18BF62F16FF86 (void);
// 0x00000039 UnityEngine.Color UnityEngine.UI.ColorBlock::get_pressedColor()
extern void ColorBlock_get_pressedColor_m5EDADBA10824D08BFB67D02099A9FC6A4235AC62 (void);
// 0x0000003A System.Void UnityEngine.UI.ColorBlock::set_pressedColor(UnityEngine.Color)
extern void ColorBlock_set_pressedColor_m644C938090857AB07C57B25FE53F6DC2BB0DD5A8 (void);
// 0x0000003B UnityEngine.Color UnityEngine.UI.ColorBlock::get_selectedColor()
extern void ColorBlock_get_selectedColor_m41CD59090E997A5982EE5AB9D23811FEB35C82CF (void);
// 0x0000003C System.Void UnityEngine.UI.ColorBlock::set_selectedColor(UnityEngine.Color)
extern void ColorBlock_set_selectedColor_m76FEFB1148798B7A356C974CDEA3BA2E2E3C1D21 (void);
// 0x0000003D UnityEngine.Color UnityEngine.UI.ColorBlock::get_disabledColor()
extern void ColorBlock_get_disabledColor_m2E20FC772B592ADD71CE1336D29B3C3C1523669E (void);
// 0x0000003E System.Void UnityEngine.UI.ColorBlock::set_disabledColor(UnityEngine.Color)
extern void ColorBlock_set_disabledColor_m4D10D1F8525CCC7E8E200E3994AFB28ADABB1D8E (void);
// 0x0000003F System.Single UnityEngine.UI.ColorBlock::get_colorMultiplier()
extern void ColorBlock_get_colorMultiplier_m54C8F6B7E5ACF45D70F9EAAED78AB4606999C187 (void);
// 0x00000040 System.Void UnityEngine.UI.ColorBlock::set_colorMultiplier(System.Single)
extern void ColorBlock_set_colorMultiplier_m920A048B95541DB0E92AF4AF3894BE7CD2D37102 (void);
// 0x00000041 System.Single UnityEngine.UI.ColorBlock::get_fadeDuration()
extern void ColorBlock_get_fadeDuration_m506A0FCC2819DA313BE033640C8FEDC5331D1C39 (void);
// 0x00000042 System.Void UnityEngine.UI.ColorBlock::set_fadeDuration(System.Single)
extern void ColorBlock_set_fadeDuration_m8519A304808384CE873377EC104969A6B9FBB6C5 (void);
// 0x00000043 System.Void UnityEngine.UI.ColorBlock::.cctor()
extern void ColorBlock__cctor_mE6D6008EFBF7B20ECDFC69AD0FBAAF745BBFEB7A (void);
// 0x00000044 System.Boolean UnityEngine.UI.ColorBlock::Equals(System.Object)
extern void ColorBlock_Equals_m20D958BB28F6FDC12D612279AF6B50679C0C1E67 (void);
// 0x00000045 System.Boolean UnityEngine.UI.ColorBlock::Equals(UnityEngine.UI.ColorBlock)
extern void ColorBlock_Equals_m52DCE246EA23904A3EF0FCD3ADAB81BC20DC1BE5 (void);
// 0x00000046 System.Boolean UnityEngine.UI.ColorBlock::op_Equality(UnityEngine.UI.ColorBlock,UnityEngine.UI.ColorBlock)
extern void ColorBlock_op_Equality_m5925207B6FDD0CE013BEB0269B4407B9C3A54276 (void);
// 0x00000047 System.Boolean UnityEngine.UI.ColorBlock::op_Inequality(UnityEngine.UI.ColorBlock,UnityEngine.UI.ColorBlock)
extern void ColorBlock_op_Inequality_m73B2B54AA18CB45290F99B1A870BC43E08209AC7 (void);
// 0x00000048 System.Int32 UnityEngine.UI.ColorBlock::GetHashCode()
extern void ColorBlock_GetHashCode_m3CCB4E1E5EE93B905650E24BD4753096082270D7 (void);
// 0x00000049 System.Void UnityEngine.UI.ClipperRegistry::.ctor()
extern void ClipperRegistry__ctor_m664370B6F6A28646681B08A723C4EEE7737599A4 (void);
// 0x0000004A UnityEngine.UI.ClipperRegistry UnityEngine.UI.ClipperRegistry::get_instance()
extern void ClipperRegistry_get_instance_m709E4407231F3C616FCE693389AE2BC0121FCE40 (void);
// 0x0000004B System.Void UnityEngine.UI.ClipperRegistry::Cull()
extern void ClipperRegistry_Cull_mE2BBF0B75900B6780EDE22699476542FC5B62730 (void);
// 0x0000004C System.Void UnityEngine.UI.ClipperRegistry::Register(UnityEngine.UI.IClipper)
extern void ClipperRegistry_Register_m4C47388806CA8A75538144365809137FB61C965B (void);
// 0x0000004D System.Void UnityEngine.UI.ClipperRegistry::Unregister(UnityEngine.UI.IClipper)
extern void ClipperRegistry_Unregister_mEEF92721B30BDF97F454512C32D1DF8E24834F42 (void);
// 0x0000004E System.Void UnityEngine.UI.ClipperRegistry::Disable(UnityEngine.UI.IClipper)
extern void ClipperRegistry_Disable_m4541BB1A762E730709A65D7CDA917CF0D56CA687 (void);
// 0x0000004F UnityEngine.Rect UnityEngine.UI.Clipping::FindCullAndClipWorldRect(System.Collections.Generic.List`1<UnityEngine.UI.RectMask2D>,System.Boolean&)
extern void Clipping_FindCullAndClipWorldRect_mE367B99A2BEBA67F6B394B7E95346C9F6416C4B5 (void);
// 0x00000050 System.Void UnityEngine.UI.IClipper::PerformClipping()
// 0x00000051 UnityEngine.GameObject UnityEngine.UI.IClippable::get_gameObject()
// 0x00000052 System.Void UnityEngine.UI.IClippable::RecalculateClipping()
// 0x00000053 UnityEngine.RectTransform UnityEngine.UI.IClippable::get_rectTransform()
// 0x00000054 System.Void UnityEngine.UI.IClippable::Cull(UnityEngine.Rect,System.Boolean)
// 0x00000055 System.Void UnityEngine.UI.IClippable::SetClipRect(UnityEngine.Rect,System.Boolean)
// 0x00000056 System.Void UnityEngine.UI.IClippable::SetClipSoftness(UnityEngine.Vector2)
// 0x00000057 UnityEngine.Rect UnityEngine.UI.RectangularVertexClipper::GetCanvasRect(UnityEngine.RectTransform,UnityEngine.Canvas)
extern void RectangularVertexClipper_GetCanvasRect_m9C9A5CAF396D20925E1394FA188E71D3B825B383 (void);
// 0x00000058 System.Void UnityEngine.UI.RectangularVertexClipper::.ctor()
extern void RectangularVertexClipper__ctor_m159190C771C2A7F406769365B902A228DE585C7A (void);
// 0x00000059 UnityEngine.UI.DefaultControls/IFactoryControls UnityEngine.UI.DefaultControls::get_factory()
extern void DefaultControls_get_factory_m5E94C746BC7C05A928A9886519FC4FB32C2EB57D (void);
// 0x0000005A UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateUIElementRoot(System.String,UnityEngine.Vector2,System.Type[])
extern void DefaultControls_CreateUIElementRoot_m29E6F31D5BEA9AA602BFDFA423DB403DFE429683 (void);
// 0x0000005B UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateUIObject(System.String,UnityEngine.GameObject,System.Type[])
extern void DefaultControls_CreateUIObject_mBBA2C8A5C8BB80104251200395B2947A5CB45071 (void);
// 0x0000005C System.Void UnityEngine.UI.DefaultControls::SetDefaultTextValues(UnityEngine.UI.Text)
extern void DefaultControls_SetDefaultTextValues_mE667D7E0A8BB03B6EBA7E3A5917A5F0B5DF1D0BB (void);
// 0x0000005D System.Void UnityEngine.UI.DefaultControls::SetDefaultColorTransitionValues(UnityEngine.UI.Selectable)
extern void DefaultControls_SetDefaultColorTransitionValues_mA11DBF31257A877F2C3CFE2FC555F77DE4AB27B5 (void);
// 0x0000005E System.Void UnityEngine.UI.DefaultControls::SetParentAndAlign(UnityEngine.GameObject,UnityEngine.GameObject)
extern void DefaultControls_SetParentAndAlign_mA6632B61C5C5C33B4901129DC16919E8C5158952 (void);
// 0x0000005F System.Void UnityEngine.UI.DefaultControls::SetLayerRecursively(UnityEngine.GameObject,System.Int32)
extern void DefaultControls_SetLayerRecursively_mE0BFC051766E26BC0118555582A6579179281CBA (void);
// 0x00000060 UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreatePanel(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreatePanel_m69F2B388CE41646797A582D4AF52CC91B45BB7C0 (void);
// 0x00000061 UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateButton(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreateButton_m3551B134B8B79ADCE1DB85D5A77B4C9F32E43619 (void);
// 0x00000062 UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateText(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreateText_mA23D7B0D56561FA174752601AEFFEB04F26E7C3E (void);
// 0x00000063 UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateImage(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreateImage_m0D5C35201D8D12B1A42685CE23772F5C39864331 (void);
// 0x00000064 UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateRawImage(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreateRawImage_m1CF70C988DE4276C35037BB56479E805EAAB567F (void);
// 0x00000065 UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateSlider(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreateSlider_m46C7D78861271433489674E7B9A09D018E33911C (void);
// 0x00000066 UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateScrollbar(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreateScrollbar_m78FC29513D3DAF700CB9205882F58F59B3F5620E (void);
// 0x00000067 UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateToggle(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreateToggle_mE5D3F00385DD0F468F8218D520C0C0D300BE58F4 (void);
// 0x00000068 UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateInputField(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreateInputField_m0381BFDF0D84EC0A896C639EAB732F39A36B8ED2 (void);
// 0x00000069 UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateDropdown(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreateDropdown_m94CE7639D609D6341FBCF0D49D6494A5901FFDBD (void);
// 0x0000006A UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateScrollView(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreateScrollView_m091D81394C468627D85DDAB8236665E837C89AA7 (void);
// 0x0000006B System.Void UnityEngine.UI.DefaultControls::.cctor()
extern void DefaultControls__cctor_m712ED7CCB7CEEE815F424F553E03BC3BA4F6E80B (void);
// 0x0000006C UnityEngine.GameObject UnityEngine.UI.DefaultControls/IFactoryControls::CreateGameObject(System.String,System.Type[])
// 0x0000006D UnityEngine.GameObject UnityEngine.UI.DefaultControls/DefaultRuntimeFactory::CreateGameObject(System.String,System.Type[])
extern void DefaultRuntimeFactory_CreateGameObject_m0D5F91ACE140C39C3139BAF1437792D42CC0C389 (void);
// 0x0000006E System.Void UnityEngine.UI.DefaultControls/DefaultRuntimeFactory::.ctor()
extern void DefaultRuntimeFactory__ctor_m5467830A8AA017398C392E147A4582857EFD0710 (void);
// 0x0000006F System.Void UnityEngine.UI.DefaultControls/DefaultRuntimeFactory::.cctor()
extern void DefaultRuntimeFactory__cctor_m09225594AC1F1C4EE5EBF6E5FBC7C8760C34AF2D (void);
// 0x00000070 UnityEngine.RectTransform UnityEngine.UI.Dropdown::get_template()
extern void Dropdown_get_template_m6714116D7DA3F457F184B004785B4F017D50987A (void);
// 0x00000071 System.Void UnityEngine.UI.Dropdown::set_template(UnityEngine.RectTransform)
extern void Dropdown_set_template_m13FE93E0ED2414A5D8D4595D3123DDFD726DB619 (void);
// 0x00000072 UnityEngine.UI.Text UnityEngine.UI.Dropdown::get_captionText()
extern void Dropdown_get_captionText_m0A8DEACA15F0DDFEE339462E03DF511B87389EF4 (void);
// 0x00000073 System.Void UnityEngine.UI.Dropdown::set_captionText(UnityEngine.UI.Text)
extern void Dropdown_set_captionText_mD314CF798D1B85726553E124496A7EE226BB1830 (void);
// 0x00000074 UnityEngine.UI.Image UnityEngine.UI.Dropdown::get_captionImage()
extern void Dropdown_get_captionImage_mA4C6EF8312F06B6190FC4E78583975145274168B (void);
// 0x00000075 System.Void UnityEngine.UI.Dropdown::set_captionImage(UnityEngine.UI.Image)
extern void Dropdown_set_captionImage_mF6B9BCAF2C8C0018E2F94600F9C8DE2412F5F184 (void);
// 0x00000076 UnityEngine.UI.Text UnityEngine.UI.Dropdown::get_itemText()
extern void Dropdown_get_itemText_m8E98EB1B2B2F8D5C14F0D4A02E620E9240966681 (void);
// 0x00000077 System.Void UnityEngine.UI.Dropdown::set_itemText(UnityEngine.UI.Text)
extern void Dropdown_set_itemText_m901981335866C0A856E31D7D1C87C7D8E76FBFAA (void);
// 0x00000078 UnityEngine.UI.Image UnityEngine.UI.Dropdown::get_itemImage()
extern void Dropdown_get_itemImage_mA30A3B51B8C9B6E364B57A3FB277B364B6E0EF1B (void);
// 0x00000079 System.Void UnityEngine.UI.Dropdown::set_itemImage(UnityEngine.UI.Image)
extern void Dropdown_set_itemImage_m6F4BBC06449E2EAF073D495871BB29F4B35BD7FE (void);
// 0x0000007A System.Collections.Generic.List`1<UnityEngine.UI.Dropdown/OptionData> UnityEngine.UI.Dropdown::get_options()
extern void Dropdown_get_options_m30F757DBA22980CB77DADB8315207D5B87307816 (void);
// 0x0000007B System.Void UnityEngine.UI.Dropdown::set_options(System.Collections.Generic.List`1<UnityEngine.UI.Dropdown/OptionData>)
extern void Dropdown_set_options_mEC30A0E3E0819485B1EACF8624D0C1974857D368 (void);
// 0x0000007C UnityEngine.UI.Dropdown/DropdownEvent UnityEngine.UI.Dropdown::get_onValueChanged()
extern void Dropdown_get_onValueChanged_mAC49CE9A83E258FEC024662127057567275CAC12 (void);
// 0x0000007D System.Void UnityEngine.UI.Dropdown::set_onValueChanged(UnityEngine.UI.Dropdown/DropdownEvent)
extern void Dropdown_set_onValueChanged_m59337E2E2975F5F4338C5B03C50347A23343C0E0 (void);
// 0x0000007E System.Single UnityEngine.UI.Dropdown::get_alphaFadeSpeed()
extern void Dropdown_get_alphaFadeSpeed_m17C37664CEDBA2950ACDA7FCB1DFCBAD1A9C82E9 (void);
// 0x0000007F System.Void UnityEngine.UI.Dropdown::set_alphaFadeSpeed(System.Single)
extern void Dropdown_set_alphaFadeSpeed_m67E1A7B551D3592380C6EA34355B94C461790984 (void);
// 0x00000080 System.Int32 UnityEngine.UI.Dropdown::get_value()
extern void Dropdown_get_value_m386913162D5E273B762657FE5156DC567602BC3C (void);
// 0x00000081 System.Void UnityEngine.UI.Dropdown::set_value(System.Int32)
extern void Dropdown_set_value_m0764A5E2023E34705ADD422689BF6C0074449FEE (void);
// 0x00000082 System.Void UnityEngine.UI.Dropdown::SetValueWithoutNotify(System.Int32)
extern void Dropdown_SetValueWithoutNotify_m3D2B40BC16D305309D68D9FF093BF25FF66E4ABA (void);
// 0x00000083 System.Void UnityEngine.UI.Dropdown::Set(System.Int32,System.Boolean)
extern void Dropdown_Set_m2F7DFBF09261A4C4CB1AFCF939907716191D8F07 (void);
// 0x00000084 System.Void UnityEngine.UI.Dropdown::.ctor()
extern void Dropdown__ctor_m1AF791E4615DB8F00045A3713730CD45E66A7CD4 (void);
// 0x00000085 System.Void UnityEngine.UI.Dropdown::Awake()
extern void Dropdown_Awake_m1A9102FB62C5393F695E5A0FB44A0CFEC5B947FF (void);
// 0x00000086 System.Void UnityEngine.UI.Dropdown::Start()
extern void Dropdown_Start_m93BFFE8C88FF09265315FE8B145FE165467CBB35 (void);
// 0x00000087 System.Void UnityEngine.UI.Dropdown::OnDisable()
extern void Dropdown_OnDisable_mB9CBBE366F5F5EDA29C064DB5D7A6EA7C711C70E (void);
// 0x00000088 System.Void UnityEngine.UI.Dropdown::RefreshShownValue()
extern void Dropdown_RefreshShownValue_mA112A95E8653859FC2B6C2D0CC89660D36E8970E (void);
// 0x00000089 System.Void UnityEngine.UI.Dropdown::AddOptions(System.Collections.Generic.List`1<UnityEngine.UI.Dropdown/OptionData>)
extern void Dropdown_AddOptions_mE535B30A30D77024D10AB2AB71CE3FD280CD0327 (void);
// 0x0000008A System.Void UnityEngine.UI.Dropdown::AddOptions(System.Collections.Generic.List`1<System.String>)
extern void Dropdown_AddOptions_mCFB763400FA1BCA695C168E7FBCDE20C9B8E7839 (void);
// 0x0000008B System.Void UnityEngine.UI.Dropdown::AddOptions(System.Collections.Generic.List`1<UnityEngine.Sprite>)
extern void Dropdown_AddOptions_mD4460EE082AB7BE36CB54DBB67BFEB4BC172707E (void);
// 0x0000008C System.Void UnityEngine.UI.Dropdown::ClearOptions()
extern void Dropdown_ClearOptions_m3EE71BFE47AB96BC7F731C4EE6BC728ED0E6EE56 (void);
// 0x0000008D System.Void UnityEngine.UI.Dropdown::SetupTemplate(UnityEngine.Canvas)
extern void Dropdown_SetupTemplate_m6F68B1CAC7C39B2C3415B46FD2CF8F91DCF48901 (void);
// 0x0000008E T UnityEngine.UI.Dropdown::GetOrAddComponent(UnityEngine.GameObject)
// 0x0000008F System.Void UnityEngine.UI.Dropdown::OnPointerClick(UnityEngine.EventSystems.PointerEventData)
extern void Dropdown_OnPointerClick_m3AE64082F83B272B4880935125784442E107939C (void);
// 0x00000090 System.Void UnityEngine.UI.Dropdown::OnSubmit(UnityEngine.EventSystems.BaseEventData)
extern void Dropdown_OnSubmit_m3535A89BE2130B54653DB2A6BA850F2055DA7F6D (void);
// 0x00000091 System.Void UnityEngine.UI.Dropdown::OnCancel(UnityEngine.EventSystems.BaseEventData)
extern void Dropdown_OnCancel_m50A25AA76B6A92E72820E97C4C9DF2295B45FC2A (void);
// 0x00000092 System.Void UnityEngine.UI.Dropdown::Show()
extern void Dropdown_Show_m103EDF14CFC2B5284C92037B097F015DAB1340DC (void);
// 0x00000093 UnityEngine.GameObject UnityEngine.UI.Dropdown::CreateBlocker(UnityEngine.Canvas)
extern void Dropdown_CreateBlocker_mA27CE256509155DAC14FBB8549074ACFF5976DDB (void);
// 0x00000094 System.Void UnityEngine.UI.Dropdown::DestroyBlocker(UnityEngine.GameObject)
extern void Dropdown_DestroyBlocker_mE0B298F69E3343D0551E7B42B28312EEE28C553B (void);
// 0x00000095 UnityEngine.GameObject UnityEngine.UI.Dropdown::CreateDropdownList(UnityEngine.GameObject)
extern void Dropdown_CreateDropdownList_mD6A55CE0786F7A418C6FC001798F660D1D2CFF95 (void);
// 0x00000096 System.Void UnityEngine.UI.Dropdown::DestroyDropdownList(UnityEngine.GameObject)
extern void Dropdown_DestroyDropdownList_mB8F81B723F9C08AF3D303D8CDB395B4474B1846C (void);
// 0x00000097 UnityEngine.UI.Dropdown/DropdownItem UnityEngine.UI.Dropdown::CreateItem(UnityEngine.UI.Dropdown/DropdownItem)
extern void Dropdown_CreateItem_m2E8E7B65A324DF3CB783D219F7ADA70E28CD8FAA (void);
// 0x00000098 System.Void UnityEngine.UI.Dropdown::DestroyItem(UnityEngine.UI.Dropdown/DropdownItem)
extern void Dropdown_DestroyItem_mD48C6E656F3CE04FE1C26E1F92F599B1F0EAD778 (void);
// 0x00000099 UnityEngine.UI.Dropdown/DropdownItem UnityEngine.UI.Dropdown::AddItem(UnityEngine.UI.Dropdown/OptionData,System.Boolean,UnityEngine.UI.Dropdown/DropdownItem,System.Collections.Generic.List`1<UnityEngine.UI.Dropdown/DropdownItem>)
extern void Dropdown_AddItem_m16017A91D142FECFE69FB38FAA311636348B499C (void);
// 0x0000009A System.Void UnityEngine.UI.Dropdown::AlphaFadeList(System.Single,System.Single)
extern void Dropdown_AlphaFadeList_mF73F53EB84546666A4DB382173BEFEA23DFD9D64 (void);
// 0x0000009B System.Void UnityEngine.UI.Dropdown::AlphaFadeList(System.Single,System.Single,System.Single)
extern void Dropdown_AlphaFadeList_m5727C00B9A1FF385C5A4B65799E1CFAE49F29F86 (void);
// 0x0000009C System.Void UnityEngine.UI.Dropdown::SetAlpha(System.Single)
extern void Dropdown_SetAlpha_mE367D2B2798F4F7FC0281D772AB4DC7417A2077C (void);
// 0x0000009D System.Void UnityEngine.UI.Dropdown::Hide()
extern void Dropdown_Hide_m49F29E7BC614DB6E04512F762399A9AACCDAFCB7 (void);
// 0x0000009E System.Collections.IEnumerator UnityEngine.UI.Dropdown::DelayedDestroyDropdownList(System.Single)
extern void Dropdown_DelayedDestroyDropdownList_m5840A3EACBCDA1F7EB89E36A44EA502243E87F8F (void);
// 0x0000009F System.Void UnityEngine.UI.Dropdown::ImmediateDestroyDropdownList()
extern void Dropdown_ImmediateDestroyDropdownList_mAC289C54114CD256FE7F34B8D62EFDA947C00272 (void);
// 0x000000A0 System.Void UnityEngine.UI.Dropdown::OnSelectItem(UnityEngine.UI.Toggle)
extern void Dropdown_OnSelectItem_m17D380C68C04FE4125D32EA8494D8F98442150F9 (void);
// 0x000000A1 System.Void UnityEngine.UI.Dropdown::.cctor()
extern void Dropdown__cctor_m4A014C9379610C7598BED3E900FD22040E2F9C2C (void);
// 0x000000A2 UnityEngine.UI.Text UnityEngine.UI.Dropdown/DropdownItem::get_text()
extern void DropdownItem_get_text_m29C926466BC0BE39A7EA282A627E1F8459C53E0D (void);
// 0x000000A3 System.Void UnityEngine.UI.Dropdown/DropdownItem::set_text(UnityEngine.UI.Text)
extern void DropdownItem_set_text_mE5F27F83326429B6056B686682BBC9911546DAA0 (void);
// 0x000000A4 UnityEngine.UI.Image UnityEngine.UI.Dropdown/DropdownItem::get_image()
extern void DropdownItem_get_image_m415346A4FB0E83932E4043D41B0AE837F2C3EE75 (void);
// 0x000000A5 System.Void UnityEngine.UI.Dropdown/DropdownItem::set_image(UnityEngine.UI.Image)
extern void DropdownItem_set_image_mED01F92D19AA3B5C0CACBCE2D1C9A70AFC7049EA (void);
// 0x000000A6 UnityEngine.RectTransform UnityEngine.UI.Dropdown/DropdownItem::get_rectTransform()
extern void DropdownItem_get_rectTransform_mAFF594D5FE8280F8E4CF8D246654C1EC04C892EB (void);
// 0x000000A7 System.Void UnityEngine.UI.Dropdown/DropdownItem::set_rectTransform(UnityEngine.RectTransform)
extern void DropdownItem_set_rectTransform_m62744FF037D3E7044EDA139CA6BB6FBB11E1061E (void);
// 0x000000A8 UnityEngine.UI.Toggle UnityEngine.UI.Dropdown/DropdownItem::get_toggle()
extern void DropdownItem_get_toggle_m9E93C07903AF29C0D66C48B217575A65CD4CB471 (void);
// 0x000000A9 System.Void UnityEngine.UI.Dropdown/DropdownItem::set_toggle(UnityEngine.UI.Toggle)
extern void DropdownItem_set_toggle_mD58F68764A433037C8F42483BE4F95973EBA3535 (void);
// 0x000000AA System.Void UnityEngine.UI.Dropdown/DropdownItem::OnPointerEnter(UnityEngine.EventSystems.PointerEventData)
extern void DropdownItem_OnPointerEnter_mB9464C1CE0EBF0A4F3A7979B37AEF2283E738A34 (void);
// 0x000000AB System.Void UnityEngine.UI.Dropdown/DropdownItem::OnCancel(UnityEngine.EventSystems.BaseEventData)
extern void DropdownItem_OnCancel_mFEA3928E939D387662E21AD7496DD64FF40B9FC7 (void);
// 0x000000AC System.Void UnityEngine.UI.Dropdown/DropdownItem::.ctor()
extern void DropdownItem__ctor_mB55660FE9B66C2A5E7E8587450729BB691EDAC03 (void);
// 0x000000AD System.String UnityEngine.UI.Dropdown/OptionData::get_text()
extern void OptionData_get_text_m147C3EFE4B7D157914D2C6CF653B32CE2D987AF1 (void);
// 0x000000AE System.Void UnityEngine.UI.Dropdown/OptionData::set_text(System.String)
extern void OptionData_set_text_mA6022A455FC38025B0CA97B4E3629DA10FDE259E (void);
// 0x000000AF UnityEngine.Sprite UnityEngine.UI.Dropdown/OptionData::get_image()
extern void OptionData_get_image_m4E10E9C1338C69EF43C240AB6866AD99CA63451F (void);
// 0x000000B0 System.Void UnityEngine.UI.Dropdown/OptionData::set_image(UnityEngine.Sprite)
extern void OptionData_set_image_mE503B098325797C5AA91F3BD71A182CAFF878C9D (void);
// 0x000000B1 System.Void UnityEngine.UI.Dropdown/OptionData::.ctor()
extern void OptionData__ctor_m6321993E5D83F3A7E52ADC14C9276508D1129166 (void);
// 0x000000B2 System.Void UnityEngine.UI.Dropdown/OptionData::.ctor(System.String)
extern void OptionData__ctor_m0BB22D3B9A2443D8D51CE88AD6B4DAEAF11B59E6 (void);
// 0x000000B3 System.Void UnityEngine.UI.Dropdown/OptionData::.ctor(UnityEngine.Sprite)
extern void OptionData__ctor_m59495D34418035A84F4985F134B7557294689252 (void);
// 0x000000B4 System.Void UnityEngine.UI.Dropdown/OptionData::.ctor(System.String,UnityEngine.Sprite)
extern void OptionData__ctor_mFF7263F2503D3F2D1E395450A62CAAB48CA9AFDE (void);
// 0x000000B5 System.Collections.Generic.List`1<UnityEngine.UI.Dropdown/OptionData> UnityEngine.UI.Dropdown/OptionDataList::get_options()
extern void OptionDataList_get_options_m0400B4F545E0EF3D00D50B701720B5D2F732A00E (void);
// 0x000000B6 System.Void UnityEngine.UI.Dropdown/OptionDataList::set_options(System.Collections.Generic.List`1<UnityEngine.UI.Dropdown/OptionData>)
extern void OptionDataList_set_options_mE730DD2A6EB4DEE150450E52C0C2869CE4573E1C (void);
// 0x000000B7 System.Void UnityEngine.UI.Dropdown/OptionDataList::.ctor()
extern void OptionDataList__ctor_mEDE3FBBEC8C69BAB71DC8A4EEBA4DD92A19D2E6E (void);
// 0x000000B8 System.Void UnityEngine.UI.Dropdown/DropdownEvent::.ctor()
extern void DropdownEvent__ctor_m40067CAE88519F3B3B9991621A3EA5DC89682145 (void);
// 0x000000B9 System.Void UnityEngine.UI.Dropdown/<>c__DisplayClass63_0::.ctor()
extern void U3CU3Ec__DisplayClass63_0__ctor_mA6669AA99E56F2DEE6C1E1ECB173C7BE4DE1CD64 (void);
// 0x000000BA System.Void UnityEngine.UI.Dropdown/<>c__DisplayClass63_0::<Show>b__0(System.Boolean)
extern void U3CU3Ec__DisplayClass63_0_U3CShowU3Eb__0_m2D40C4419DA54F2340E2A0BE7E7E6BD57113B71C (void);
// 0x000000BB System.Void UnityEngine.UI.Dropdown/<DelayedDestroyDropdownList>d__75::.ctor(System.Int32)
extern void U3CDelayedDestroyDropdownListU3Ed__75__ctor_m80FA88C604962EB1BCF0453E39809E4AD856564F (void);
// 0x000000BC System.Void UnityEngine.UI.Dropdown/<DelayedDestroyDropdownList>d__75::System.IDisposable.Dispose()
extern void U3CDelayedDestroyDropdownListU3Ed__75_System_IDisposable_Dispose_m86610E303C691865AD8CA51A944E0DD22CD76646 (void);
// 0x000000BD System.Boolean UnityEngine.UI.Dropdown/<DelayedDestroyDropdownList>d__75::MoveNext()
extern void U3CDelayedDestroyDropdownListU3Ed__75_MoveNext_m4635FEBE76913C9F4A0D60DF2DEFBABE071481D4 (void);
// 0x000000BE System.Object UnityEngine.UI.Dropdown/<DelayedDestroyDropdownList>d__75::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CDelayedDestroyDropdownListU3Ed__75_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mD7843A1E586805C8BA4165718774F1579F775077 (void);
// 0x000000BF System.Void UnityEngine.UI.Dropdown/<DelayedDestroyDropdownList>d__75::System.Collections.IEnumerator.Reset()
extern void U3CDelayedDestroyDropdownListU3Ed__75_System_Collections_IEnumerator_Reset_mD5684D5117ECD0043294091F4CBB9EEC17957CC2 (void);
// 0x000000C0 System.Object UnityEngine.UI.Dropdown/<DelayedDestroyDropdownList>d__75::System.Collections.IEnumerator.get_Current()
extern void U3CDelayedDestroyDropdownListU3Ed__75_System_Collections_IEnumerator_get_Current_m746DC8D79704E5D1B78C1DC62CDECC7274409D13 (void);
// 0x000000C1 UnityEngine.UI.FontData UnityEngine.UI.FontData::get_defaultFontData()
extern void FontData_get_defaultFontData_mE91EA0AE923A4988ECEF06F608BA8DE764541B6F (void);
// 0x000000C2 UnityEngine.Font UnityEngine.UI.FontData::get_font()
extern void FontData_get_font_m449DE7A18F42B85D427608E88BC17B528D974D93 (void);
// 0x000000C3 System.Void UnityEngine.UI.FontData::set_font(UnityEngine.Font)
extern void FontData_set_font_mDF16F5058F749DA9A80B7203BE1E007A21258089 (void);
// 0x000000C4 System.Int32 UnityEngine.UI.FontData::get_fontSize()
extern void FontData_get_fontSize_m6695DDD7FECD4BAC1147A15D26B7F16B78E2B2D3 (void);
// 0x000000C5 System.Void UnityEngine.UI.FontData::set_fontSize(System.Int32)
extern void FontData_set_fontSize_m00594E7340206777E0CF1F038943724B8DA9FD53 (void);
// 0x000000C6 UnityEngine.FontStyle UnityEngine.UI.FontData::get_fontStyle()
extern void FontData_get_fontStyle_m7671598F11D5C2AE55AA46D28794C78D0D690EC3 (void);
// 0x000000C7 System.Void UnityEngine.UI.FontData::set_fontStyle(UnityEngine.FontStyle)
extern void FontData_set_fontStyle_m90E8DF52C663489F43FB185780D38A3E99A30C29 (void);
// 0x000000C8 System.Boolean UnityEngine.UI.FontData::get_bestFit()
extern void FontData_get_bestFit_m230FD8F27172E1A020BFDDC2D89932DFD01788FC (void);
// 0x000000C9 System.Void UnityEngine.UI.FontData::set_bestFit(System.Boolean)
extern void FontData_set_bestFit_m15B4E1EC2E3AA912718466F0C098BF0C22E7B46B (void);
// 0x000000CA System.Int32 UnityEngine.UI.FontData::get_minSize()
extern void FontData_get_minSize_mD8AD04F4CF85C79BEA14710F3AD85228E3DC2D97 (void);
// 0x000000CB System.Void UnityEngine.UI.FontData::set_minSize(System.Int32)
extern void FontData_set_minSize_mAAC06D3C29D5210054B3DC3FDE58358648460F91 (void);
// 0x000000CC System.Int32 UnityEngine.UI.FontData::get_maxSize()
extern void FontData_get_maxSize_mA8FDA877D8D459C0C97F1AE7FD8D5F7C27391872 (void);
// 0x000000CD System.Void UnityEngine.UI.FontData::set_maxSize(System.Int32)
extern void FontData_set_maxSize_m3EC43E7AB5A4C022DE729371D8AACFC7D702B527 (void);
// 0x000000CE UnityEngine.TextAnchor UnityEngine.UI.FontData::get_alignment()
extern void FontData_get_alignment_mC3C237BFE74D104BE4502D0D6BEF6D400AC509F4 (void);
// 0x000000CF System.Void UnityEngine.UI.FontData::set_alignment(UnityEngine.TextAnchor)
extern void FontData_set_alignment_m25795B35CBF298D966B5C9A73A4A58F075C17563 (void);
// 0x000000D0 System.Boolean UnityEngine.UI.FontData::get_alignByGeometry()
extern void FontData_get_alignByGeometry_m193ADE84986D74A91F46B31C1F961BC9D688CDFF (void);
// 0x000000D1 System.Void UnityEngine.UI.FontData::set_alignByGeometry(System.Boolean)
extern void FontData_set_alignByGeometry_m580D8D1B9D4396C648C9180BB891DAF561E37A2F (void);
// 0x000000D2 System.Boolean UnityEngine.UI.FontData::get_richText()
extern void FontData_get_richText_m76956F1C2063841C77172F1CB404F3C6C81052A1 (void);
// 0x000000D3 System.Void UnityEngine.UI.FontData::set_richText(System.Boolean)
extern void FontData_set_richText_mB37DCE83CBD25C93A3AA4AA9C0C3A7AE332753DC (void);
// 0x000000D4 UnityEngine.HorizontalWrapMode UnityEngine.UI.FontData::get_horizontalOverflow()
extern void FontData_get_horizontalOverflow_mEF56759973C6722FDE71032861BC0713628E5EA8 (void);
// 0x000000D5 System.Void UnityEngine.UI.FontData::set_horizontalOverflow(UnityEngine.HorizontalWrapMode)
extern void FontData_set_horizontalOverflow_m8B75EB2EB0241423F50E31C023729BDBAAA019E1 (void);
// 0x000000D6 UnityEngine.VerticalWrapMode UnityEngine.UI.FontData::get_verticalOverflow()
extern void FontData_get_verticalOverflow_m306AE42FED4B302C133CC899B55D92FB86C1ED8F (void);
// 0x000000D7 System.Void UnityEngine.UI.FontData::set_verticalOverflow(UnityEngine.VerticalWrapMode)
extern void FontData_set_verticalOverflow_m857D9882EC486696EE3898EB5BFFFE04053C9D17 (void);
// 0x000000D8 System.Single UnityEngine.UI.FontData::get_lineSpacing()
extern void FontData_get_lineSpacing_mE9627A4D01D54115F8AE42EC1F12CFBB86FAC5E0 (void);
// 0x000000D9 System.Void UnityEngine.UI.FontData::set_lineSpacing(System.Single)
extern void FontData_set_lineSpacing_m034F2A307093DCAACE71D610550C3306C1389FB5 (void);
// 0x000000DA System.Void UnityEngine.UI.FontData::UnityEngine.ISerializationCallbackReceiver.OnBeforeSerialize()
extern void FontData_UnityEngine_ISerializationCallbackReceiver_OnBeforeSerialize_mCA5C2ADF6B05942D58C400752E8D175DAC008399 (void);
// 0x000000DB System.Void UnityEngine.UI.FontData::UnityEngine.ISerializationCallbackReceiver.OnAfterDeserialize()
extern void FontData_UnityEngine_ISerializationCallbackReceiver_OnAfterDeserialize_mAB5158604FD53556402CD7297F9797747088EC6F (void);
// 0x000000DC System.Void UnityEngine.UI.FontData::.ctor()
extern void FontData__ctor_m90225BC9FF97C82F911B775CD3EB54B0C95839C8 (void);
// 0x000000DD System.Void UnityEngine.UI.FontUpdateTracker::TrackText(UnityEngine.UI.Text)
extern void FontUpdateTracker_TrackText_mE52366E2C5DF0BA4E24F35D7DA246FBF32332007 (void);
// 0x000000DE System.Void UnityEngine.UI.FontUpdateTracker::RebuildForFont(UnityEngine.Font)
extern void FontUpdateTracker_RebuildForFont_mC9A828F534DBBCE1E70BFF4A5034C7B37F7D65EE (void);
// 0x000000DF System.Void UnityEngine.UI.FontUpdateTracker::UntrackText(UnityEngine.UI.Text)
extern void FontUpdateTracker_UntrackText_m813D712F66E05727FE0CEFAB4438EE7DF5483738 (void);
// 0x000000E0 System.Void UnityEngine.UI.FontUpdateTracker::.cctor()
extern void FontUpdateTracker__cctor_m82550106869CBCE1C5D8D7AC9F211AD71DBEE5C7 (void);
// 0x000000E1 UnityEngine.Material UnityEngine.UI.Graphic::get_defaultGraphicMaterial()
extern void Graphic_get_defaultGraphicMaterial_mC3D98DC8F6E8826633B17BB4AC6E38DF20A74E78 (void);
// 0x000000E2 UnityEngine.Color UnityEngine.UI.Graphic::get_color()
extern void Graphic_get_color_mA6639AC2B77A8F1B7F27656B69320E7A0FD4F315 (void);
// 0x000000E3 System.Void UnityEngine.UI.Graphic::set_color(UnityEngine.Color)
extern void Graphic_set_color_mC9B90A387A37946AF295D7BCDA1FBC1DBD2D4865 (void);
// 0x000000E4 System.Boolean UnityEngine.UI.Graphic::get_raycastTarget()
extern void Graphic_get_raycastTarget_mA3E3A3A0C7A12EB550D0BCD5DC68F5A40C6D7844 (void);
// 0x000000E5 System.Void UnityEngine.UI.Graphic::set_raycastTarget(System.Boolean)
extern void Graphic_set_raycastTarget_mE3D3CBB94E605C13362A592F17420AEAAC771448 (void);
// 0x000000E6 UnityEngine.Vector4 UnityEngine.UI.Graphic::get_raycastPadding()
extern void Graphic_get_raycastPadding_m44CC4DC7030C46D15519AAFA7523E9AD4DC462B7 (void);
// 0x000000E7 System.Void UnityEngine.UI.Graphic::set_raycastPadding(UnityEngine.Vector4)
extern void Graphic_set_raycastPadding_m5EBFEDD522BD4E1EC0202FEA1D7A0273E25FD5E5 (void);
// 0x000000E8 System.Boolean UnityEngine.UI.Graphic::get_useLegacyMeshGeneration()
extern void Graphic_get_useLegacyMeshGeneration_m2057231F53432FC95BA40EA485E85F5DAF21F423 (void);
// 0x000000E9 System.Void UnityEngine.UI.Graphic::set_useLegacyMeshGeneration(System.Boolean)
extern void Graphic_set_useLegacyMeshGeneration_m8069890AE2F389C73D944941BB8462C44EB32EC9 (void);
// 0x000000EA System.Void UnityEngine.UI.Graphic::.ctor()
extern void Graphic__ctor_m61FAEBEC21F22FE00B8CF39A8498AD31F62C0D6D (void);
// 0x000000EB System.Void UnityEngine.UI.Graphic::SetAllDirty()
extern void Graphic_SetAllDirty_mE93D6326AF09CED62858980A38F571F01A567E17 (void);
// 0x000000EC System.Void UnityEngine.UI.Graphic::SetLayoutDirty()
extern void Graphic_SetLayoutDirty_m707188E6F05B8977FBA14C6269420EAE045A728B (void);
// 0x000000ED System.Void UnityEngine.UI.Graphic::SetVerticesDirty()
extern void Graphic_SetVerticesDirty_m8DBAF14DE97CB50DC54E768A2C120F8F4B3C647E (void);
// 0x000000EE System.Void UnityEngine.UI.Graphic::SetMaterialDirty()
extern void Graphic_SetMaterialDirty_m19E23BAD2FAF23CEF776F467AA8A453C3320473E (void);
// 0x000000EF System.Void UnityEngine.UI.Graphic::SetRaycastDirty()
extern void Graphic_SetRaycastDirty_m07F00097DD9C6278923A1CC204770A4141F4B400 (void);
// 0x000000F0 System.Void UnityEngine.UI.Graphic::OnRectTransformDimensionsChange()
extern void Graphic_OnRectTransformDimensionsChange_m2A42F124936B2F377BE4A07BC9586C38CF15EB74 (void);
// 0x000000F1 System.Void UnityEngine.UI.Graphic::OnBeforeTransformParentChanged()
extern void Graphic_OnBeforeTransformParentChanged_mFEE7DB7653CD70C7279F397DFF1A5C9B702B36BE (void);
// 0x000000F2 System.Void UnityEngine.UI.Graphic::OnTransformParentChanged()
extern void Graphic_OnTransformParentChanged_m5FAC5BEDE05D6969B7F7AD15C0A8C5715129EED7 (void);
// 0x000000F3 System.Int32 UnityEngine.UI.Graphic::get_depth()
extern void Graphic_get_depth_m16A82C751AE0497941048A3715D48A1066939460 (void);
// 0x000000F4 UnityEngine.RectTransform UnityEngine.UI.Graphic::get_rectTransform()
extern void Graphic_get_rectTransform_mF4752E8934267D630810E84CE02CDFB81EB1FD6D (void);
// 0x000000F5 UnityEngine.Canvas UnityEngine.UI.Graphic::get_canvas()
extern void Graphic_get_canvas_mEA2161DF3BD736541DE41F9B814C4860FEB76419 (void);
// 0x000000F6 System.Void UnityEngine.UI.Graphic::CacheCanvas()
extern void Graphic_CacheCanvas_m3F8A1EE9BE3F17297B5E5B9EA02CCA8AF53E34DD (void);
// 0x000000F7 UnityEngine.CanvasRenderer UnityEngine.UI.Graphic::get_canvasRenderer()
extern void Graphic_get_canvasRenderer_m62AB727277A28728264860232642DA6EC20DEAB1 (void);
// 0x000000F8 UnityEngine.Material UnityEngine.UI.Graphic::get_defaultMaterial()
extern void Graphic_get_defaultMaterial_m1F258214F9C1F431922BAA0028374FF6F3F81661 (void);
// 0x000000F9 UnityEngine.Material UnityEngine.UI.Graphic::get_material()
extern void Graphic_get_material_m7E92B4A77B5454BCC2507952561F12EA88AB9240 (void);
// 0x000000FA System.Void UnityEngine.UI.Graphic::set_material(UnityEngine.Material)
extern void Graphic_set_material_m49252B02E3CB2C0A17C1A74783F615E50C8801B5 (void);
// 0x000000FB UnityEngine.Material UnityEngine.UI.Graphic::get_materialForRendering()
extern void Graphic_get_materialForRendering_m4B0017B2B59D2EF578D32ABFCF84A97A835B6B22 (void);
// 0x000000FC UnityEngine.Texture UnityEngine.UI.Graphic::get_mainTexture()
extern void Graphic_get_mainTexture_mC38AAAD7BB2E9ED5CD1606FB0BB076CCB5F4B70D (void);
// 0x000000FD System.Void UnityEngine.UI.Graphic::OnEnable()
extern void Graphic_OnEnable_mD7544FBC0068D0C74181E6E66C7EC167B7C6309E (void);
// 0x000000FE System.Void UnityEngine.UI.Graphic::OnDisable()
extern void Graphic_OnDisable_m2DF81EFCEA05C2E6605C027DA3ABD79945C94F16 (void);
// 0x000000FF System.Void UnityEngine.UI.Graphic::OnDestroy()
extern void Graphic_OnDestroy_mDA1CEBC665EEC946C60519596C396477F2E348D9 (void);
// 0x00000100 System.Void UnityEngine.UI.Graphic::OnCanvasHierarchyChanged()
extern void Graphic_OnCanvasHierarchyChanged_m7062158DC1477AF8A5BC2B07755314ED7A184C5C (void);
// 0x00000101 System.Void UnityEngine.UI.Graphic::OnCullingChanged()
extern void Graphic_OnCullingChanged_m50D153DBBF9C9F17AE177E6ED6D157D847120621 (void);
// 0x00000102 System.Void UnityEngine.UI.Graphic::Rebuild(UnityEngine.UI.CanvasUpdate)
extern void Graphic_Rebuild_mEA8B7052D925874A5C8A3F3733F5027CA946EFAD (void);
// 0x00000103 System.Void UnityEngine.UI.Graphic::LayoutComplete()
extern void Graphic_LayoutComplete_m42E63C813BCE631365012B856473439ABD49A726 (void);
// 0x00000104 System.Void UnityEngine.UI.Graphic::GraphicUpdateComplete()
extern void Graphic_GraphicUpdateComplete_m02387ED9D65BF3C90D58BD5D2A9614736ABD7D5F (void);
// 0x00000105 System.Void UnityEngine.UI.Graphic::UpdateMaterial()
extern void Graphic_UpdateMaterial_m0FE63FE57725F78FA05D9C85F8457B6CA06EF665 (void);
// 0x00000106 System.Void UnityEngine.UI.Graphic::UpdateGeometry()
extern void Graphic_UpdateGeometry_m29DD64EA8C3600E9B5A50DAAA8A79D63B9FC1BE5 (void);
// 0x00000107 System.Void UnityEngine.UI.Graphic::DoMeshGeneration()
extern void Graphic_DoMeshGeneration_m9A226AB1660C68B8C2ED56845686600741CF7BB9 (void);
// 0x00000108 System.Void UnityEngine.UI.Graphic::DoLegacyMeshGeneration()
extern void Graphic_DoLegacyMeshGeneration_m6B3FFD836E8904FE9ED48633DED556CB8CEC0156 (void);
// 0x00000109 UnityEngine.Mesh UnityEngine.UI.Graphic::get_workerMesh()
extern void Graphic_get_workerMesh_m31789D0370C0CCCFC9A160714835CAD44CEEB877 (void);
// 0x0000010A System.Void UnityEngine.UI.Graphic::OnFillVBO(System.Collections.Generic.List`1<UnityEngine.UIVertex>)
extern void Graphic_OnFillVBO_m327876DCE662B10A36B5DD71A891F75599186FE4 (void);
// 0x0000010B System.Void UnityEngine.UI.Graphic::OnPopulateMesh(UnityEngine.Mesh)
extern void Graphic_OnPopulateMesh_mA35BBAE4555A20A302AABD4EF1AB4F4C9D565160 (void);
// 0x0000010C System.Void UnityEngine.UI.Graphic::OnPopulateMesh(UnityEngine.UI.VertexHelper)
extern void Graphic_OnPopulateMesh_mDD8F1B97C1AB94FB2C61D82080DE06DBAE2C0EEF (void);
// 0x0000010D System.Void UnityEngine.UI.Graphic::OnDidApplyAnimationProperties()
extern void Graphic_OnDidApplyAnimationProperties_m75AB831FC70C61BF140CFA69D337C48E8762B1CF (void);
// 0x0000010E System.Void UnityEngine.UI.Graphic::SetNativeSize()
extern void Graphic_SetNativeSize_m9D5D0610B602745DA5BED808B20A07214CC18991 (void);
// 0x0000010F System.Boolean UnityEngine.UI.Graphic::Raycast(UnityEngine.Vector2,UnityEngine.Camera)
extern void Graphic_Raycast_mEEE1690786A5894545C42BF6143936237BFE61A0 (void);
// 0x00000110 UnityEngine.Vector2 UnityEngine.UI.Graphic::PixelAdjustPoint(UnityEngine.Vector2)
extern void Graphic_PixelAdjustPoint_mBC4AFC26628D498B9872314726561D72F6DD2F28 (void);
// 0x00000111 UnityEngine.Rect UnityEngine.UI.Graphic::GetPixelAdjustedRect()
extern void Graphic_GetPixelAdjustedRect_m70D7B527D04C0B88C23E7C6661A8FF1ECC4B4BA1 (void);
// 0x00000112 System.Void UnityEngine.UI.Graphic::CrossFadeColor(UnityEngine.Color,System.Single,System.Boolean,System.Boolean)
extern void Graphic_CrossFadeColor_m6BF11EA2B9F62DF8D9421292EF974D7D548829C5 (void);
// 0x00000113 System.Void UnityEngine.UI.Graphic::CrossFadeColor(UnityEngine.Color,System.Single,System.Boolean,System.Boolean,System.Boolean)
extern void Graphic_CrossFadeColor_m0D1181CC2BF5CE521C14C85BE9CEB22EC0129D43 (void);
// 0x00000114 UnityEngine.Color UnityEngine.UI.Graphic::CreateColorFromAlpha(System.Single)
extern void Graphic_CreateColorFromAlpha_mFFAB1C85CFC981F357FCBFE84DDCFC623E2C804A (void);
// 0x00000115 System.Void UnityEngine.UI.Graphic::CrossFadeAlpha(System.Single,System.Single,System.Boolean)
extern void Graphic_CrossFadeAlpha_mB3D045B48E9DDE6CE23F4368B875F1307765B192 (void);
// 0x00000116 System.Void UnityEngine.UI.Graphic::RegisterDirtyLayoutCallback(UnityEngine.Events.UnityAction)
extern void Graphic_RegisterDirtyLayoutCallback_m870D9C225888AF117EAB7DCFBC5E629797D22B7E (void);
// 0x00000117 System.Void UnityEngine.UI.Graphic::UnregisterDirtyLayoutCallback(UnityEngine.Events.UnityAction)
extern void Graphic_UnregisterDirtyLayoutCallback_m2284BC352FE69018BB15978CB3218C673F29AD9B (void);
// 0x00000118 System.Void UnityEngine.UI.Graphic::RegisterDirtyVerticesCallback(UnityEngine.Events.UnityAction)
extern void Graphic_RegisterDirtyVerticesCallback_m46034B2100B5D28BDBCCB34C1283B1B9B2DB9A9E (void);
// 0x00000119 System.Void UnityEngine.UI.Graphic::UnregisterDirtyVerticesCallback(UnityEngine.Events.UnityAction)
extern void Graphic_UnregisterDirtyVerticesCallback_mA36A388BF7DDB2D71596D6F13CEFCA79B4199B5C (void);
// 0x0000011A System.Void UnityEngine.UI.Graphic::RegisterDirtyMaterialCallback(UnityEngine.Events.UnityAction)
extern void Graphic_RegisterDirtyMaterialCallback_m5EDBA1E08656A49997538A1C7DE29201FDE0A013 (void);
// 0x0000011B System.Void UnityEngine.UI.Graphic::UnregisterDirtyMaterialCallback(UnityEngine.Events.UnityAction)
extern void Graphic_UnregisterDirtyMaterialCallback_m62B9DB9B9021EC647E1B3D5122FE3693F8FC9BD2 (void);
// 0x0000011C System.Void UnityEngine.UI.Graphic::.cctor()
extern void Graphic__cctor_mF2A854B88E328E94B0091B2E9ACC67559BFD3514 (void);
// 0x0000011D UnityEngine.Transform UnityEngine.UI.Graphic::UnityEngine.UI.ICanvasElement.get_transform()
extern void Graphic_UnityEngine_UI_ICanvasElement_get_transform_m171A3F16EAE82D42EF768C3B091DC87174D5E768 (void);
// 0x0000011E System.Int32 UnityEngine.UI.GraphicRaycaster::get_sortOrderPriority()
extern void GraphicRaycaster_get_sortOrderPriority_m0F064AFD3551ABC89DE649D406B032AFA6E3D83F (void);
// 0x0000011F System.Int32 UnityEngine.UI.GraphicRaycaster::get_renderOrderPriority()
extern void GraphicRaycaster_get_renderOrderPriority_m1E6278AF3B98742F9F5A293DAF89F75B06E7441D (void);
// 0x00000120 System.Boolean UnityEngine.UI.GraphicRaycaster::get_ignoreReversedGraphics()
extern void GraphicRaycaster_get_ignoreReversedGraphics_mC501DBD2D4BD9594F4A5591AFD76AE307EA6BACE (void);
// 0x00000121 System.Void UnityEngine.UI.GraphicRaycaster::set_ignoreReversedGraphics(System.Boolean)
extern void GraphicRaycaster_set_ignoreReversedGraphics_m5CFA68408D296EDCC9230AF7CFB53589BE9F1CCB (void);
// 0x00000122 UnityEngine.UI.GraphicRaycaster/BlockingObjects UnityEngine.UI.GraphicRaycaster::get_blockingObjects()
extern void GraphicRaycaster_get_blockingObjects_m54343002F72E2C27919DDF5F4088934891AC13FF (void);
// 0x00000123 System.Void UnityEngine.UI.GraphicRaycaster::set_blockingObjects(UnityEngine.UI.GraphicRaycaster/BlockingObjects)
extern void GraphicRaycaster_set_blockingObjects_m0CB3F62ABC27BDB348B09B6CF0E6AB4D42A6FBC7 (void);
// 0x00000124 UnityEngine.LayerMask UnityEngine.UI.GraphicRaycaster::get_blockingMask()
extern void GraphicRaycaster_get_blockingMask_mDD3BC80288E6B12D2480B40788BA3B69D6F863C5 (void);
// 0x00000125 System.Void UnityEngine.UI.GraphicRaycaster::set_blockingMask(UnityEngine.LayerMask)
extern void GraphicRaycaster_set_blockingMask_mCE08DF88D4D4BFD17358C75DE9F0A8F68DB3BB00 (void);
// 0x00000126 System.Void UnityEngine.UI.GraphicRaycaster::.ctor()
extern void GraphicRaycaster__ctor_m863917ADCD9732623EBDF53A0CEDDEEB6EA4C42A (void);
// 0x00000127 UnityEngine.Canvas UnityEngine.UI.GraphicRaycaster::get_canvas()
extern void GraphicRaycaster_get_canvas_mD4D82F397DA3E82EBA7052E93A20562C2263339F (void);
// 0x00000128 System.Void UnityEngine.UI.GraphicRaycaster::Raycast(UnityEngine.EventSystems.PointerEventData,System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
extern void GraphicRaycaster_Raycast_mCBF5513CAA3AB70569DA3BE50DCF8980819A6D7F (void);
// 0x00000129 UnityEngine.Camera UnityEngine.UI.GraphicRaycaster::get_eventCamera()
extern void GraphicRaycaster_get_eventCamera_m2EF53324CF216839FA622884418FA77EFB9B3879 (void);
// 0x0000012A System.Void UnityEngine.UI.GraphicRaycaster::Raycast(UnityEngine.Canvas,UnityEngine.Camera,UnityEngine.Vector2,System.Collections.Generic.IList`1<UnityEngine.UI.Graphic>,System.Collections.Generic.List`1<UnityEngine.UI.Graphic>)
extern void GraphicRaycaster_Raycast_m06B8EF9AC17F7B4FBDB687E3A2C748EF575CCFCC (void);
// 0x0000012B System.Void UnityEngine.UI.GraphicRaycaster::.cctor()
extern void GraphicRaycaster__cctor_mCE7CB78EE668443FB78303E46D3D62EE92814FBD (void);
// 0x0000012C System.Void UnityEngine.UI.GraphicRaycaster/<>c::.cctor()
extern void U3CU3Ec__cctor_m6A476FFBD4558E7BA60882D6696252685DD826F5 (void);
// 0x0000012D System.Void UnityEngine.UI.GraphicRaycaster/<>c::.ctor()
extern void U3CU3Ec__ctor_mA1FCF997C2A1BC3278AFD9072B0CA4C4273F8F39 (void);
// 0x0000012E System.Int32 UnityEngine.UI.GraphicRaycaster/<>c::<Raycast>b__27_0(UnityEngine.UI.Graphic,UnityEngine.UI.Graphic)
extern void U3CU3Ec_U3CRaycastU3Eb__27_0_m81E2CE6D45AE93300AF014EA75EF4A4B2E4C059A (void);
// 0x0000012F System.Void UnityEngine.UI.GraphicRegistry::.ctor()
extern void GraphicRegistry__ctor_m26893FC7AC6ED439CDD999168C66667E27C0B48F (void);
// 0x00000130 UnityEngine.UI.GraphicRegistry UnityEngine.UI.GraphicRegistry::get_instance()
extern void GraphicRegistry_get_instance_mB6879C75347DA916BAECEF49280C8A32375BAC60 (void);
// 0x00000131 System.Void UnityEngine.UI.GraphicRegistry::RegisterGraphicForCanvas(UnityEngine.Canvas,UnityEngine.UI.Graphic)
extern void GraphicRegistry_RegisterGraphicForCanvas_m0C0DEF1D00EE4D074927B2592AA0E39EBBC5C935 (void);
// 0x00000132 System.Void UnityEngine.UI.GraphicRegistry::RegisterRaycastGraphicForCanvas(UnityEngine.Canvas,UnityEngine.UI.Graphic)
extern void GraphicRegistry_RegisterRaycastGraphicForCanvas_m10218EBBB9EBD098CB0E4954902E94C1862222A9 (void);
// 0x00000133 System.Void UnityEngine.UI.GraphicRegistry::UnregisterGraphicForCanvas(UnityEngine.Canvas,UnityEngine.UI.Graphic)
extern void GraphicRegistry_UnregisterGraphicForCanvas_m31671D141DBAF5B11D8F005E90D6E826362FDC3B (void);
// 0x00000134 System.Void UnityEngine.UI.GraphicRegistry::UnregisterRaycastGraphicForCanvas(UnityEngine.Canvas,UnityEngine.UI.Graphic)
extern void GraphicRegistry_UnregisterRaycastGraphicForCanvas_mAB5A50A86219AE4AE5DD135C93AADC22989B5CD4 (void);
// 0x00000135 System.Void UnityEngine.UI.GraphicRegistry::DisableGraphicForCanvas(UnityEngine.Canvas,UnityEngine.UI.Graphic)
extern void GraphicRegistry_DisableGraphicForCanvas_m9AFAD2245A25194017FDDF31DE9D6F6DD9B7A506 (void);
// 0x00000136 System.Void UnityEngine.UI.GraphicRegistry::DisableRaycastGraphicForCanvas(UnityEngine.Canvas,UnityEngine.UI.Graphic)
extern void GraphicRegistry_DisableRaycastGraphicForCanvas_mA4F6606E0E337C952C61773DD6C6109BE27D2115 (void);
// 0x00000137 System.Collections.Generic.IList`1<UnityEngine.UI.Graphic> UnityEngine.UI.GraphicRegistry::GetGraphicsForCanvas(UnityEngine.Canvas)
extern void GraphicRegistry_GetGraphicsForCanvas_m72A429EAD15F1CFA7F84BE394A3ECA1A00BE7087 (void);
// 0x00000138 System.Collections.Generic.IList`1<UnityEngine.UI.Graphic> UnityEngine.UI.GraphicRegistry::GetRaycastableGraphicsForCanvas(UnityEngine.Canvas)
extern void GraphicRegistry_GetRaycastableGraphicsForCanvas_mF0EABC1F1DDCAB05BA144A1C37F1EC0EB606E668 (void);
// 0x00000139 System.Void UnityEngine.UI.GraphicRegistry::.cctor()
extern void GraphicRegistry__cctor_m63428B4F697EE7B38C6A4F6C6C724E3A2B4FEC45 (void);
// 0x0000013A System.Void UnityEngine.UI.IGraphicEnabledDisabled::OnSiblingGraphicEnabledDisabled()
// 0x0000013B UnityEngine.Sprite UnityEngine.UI.Image::get_sprite()
extern void Image_get_sprite_mB2AA377708722E100574F6F75BC102513BB3BCB1 (void);
// 0x0000013C System.Void UnityEngine.UI.Image::set_sprite(UnityEngine.Sprite)
extern void Image_set_sprite_mC0C248340BA27AAEE56855A3FAFA0D8CA12956DE (void);
// 0x0000013D System.Void UnityEngine.UI.Image::DisableSpriteOptimizations()
extern void Image_DisableSpriteOptimizations_m94966D77FEEF830B1B97C44EAF74843EB94E7C25 (void);
// 0x0000013E UnityEngine.Sprite UnityEngine.UI.Image::get_overrideSprite()
extern void Image_get_overrideSprite_mE3FDFDD768A99DA4F19356E1D3F158A29E7A3C65 (void);
// 0x0000013F System.Void UnityEngine.UI.Image::set_overrideSprite(UnityEngine.Sprite)
extern void Image_set_overrideSprite_m05036DA9D0E7A173E3A5D2A2156E8E0A50A7983E (void);
// 0x00000140 UnityEngine.Sprite UnityEngine.UI.Image::get_activeSprite()
extern void Image_get_activeSprite_m0F639A03B26FD25CA1D8EEA006D0B0C322037034 (void);
// 0x00000141 UnityEngine.UI.Image/Type UnityEngine.UI.Image::get_type()
extern void Image_get_type_m7CE3AA14B38E1C50AC8362176AE842992DA8C639 (void);
// 0x00000142 System.Void UnityEngine.UI.Image::set_type(UnityEngine.UI.Image/Type)
extern void Image_set_type_mECB8D34772AA393FFBC867B03D18EA0F1A8546BF (void);
// 0x00000143 System.Boolean UnityEngine.UI.Image::get_preserveAspect()
extern void Image_get_preserveAspect_mCF10199F127659628F58CDC7C91E686816B34B5F (void);
// 0x00000144 System.Void UnityEngine.UI.Image::set_preserveAspect(System.Boolean)
extern void Image_set_preserveAspect_mF465AFD1313C0F002B37C8B86C75F98CB72A4098 (void);
// 0x00000145 System.Boolean UnityEngine.UI.Image::get_fillCenter()
extern void Image_get_fillCenter_m4951647922C5C7B1A0243C9536F8CF5A8FDDDC6E (void);
// 0x00000146 System.Void UnityEngine.UI.Image::set_fillCenter(System.Boolean)
extern void Image_set_fillCenter_m3A5E856A3F877649590F678ED6DDE38B64B14FE4 (void);
// 0x00000147 UnityEngine.UI.Image/FillMethod UnityEngine.UI.Image::get_fillMethod()
extern void Image_get_fillMethod_mAFB1FAAFA913DB0EE050C4053DBBA6FAAD68A5F1 (void);
// 0x00000148 System.Void UnityEngine.UI.Image::set_fillMethod(UnityEngine.UI.Image/FillMethod)
extern void Image_set_fillMethod_m5361D29BA950BEFE72E7270AC3BFA0B00AE7E294 (void);
// 0x00000149 System.Single UnityEngine.UI.Image::get_fillAmount()
extern void Image_get_fillAmount_mDEE52490D07124E21E7CB36718A5E3714D8B9788 (void);
// 0x0000014A System.Void UnityEngine.UI.Image::set_fillAmount(System.Single)
extern void Image_set_fillAmount_m8A9B55F47F966A3214EAC4ACBFE198776A98FAA7 (void);
// 0x0000014B System.Boolean UnityEngine.UI.Image::get_fillClockwise()
extern void Image_get_fillClockwise_mD18612EBF815BC5C238D1591039BF9F1D28DF2C0 (void);
// 0x0000014C System.Void UnityEngine.UI.Image::set_fillClockwise(System.Boolean)
extern void Image_set_fillClockwise_mB5DBAFC66370F906EA2CC1D49D49FCC366B64646 (void);
// 0x0000014D System.Int32 UnityEngine.UI.Image::get_fillOrigin()
extern void Image_get_fillOrigin_mC9778E141C67C15EC865F6648E5B2545BCC30389 (void);
// 0x0000014E System.Void UnityEngine.UI.Image::set_fillOrigin(System.Int32)
extern void Image_set_fillOrigin_m2D89BA820DABB26123A33059CA266212E7970B4E (void);
// 0x0000014F System.Single UnityEngine.UI.Image::get_eventAlphaThreshold()
extern void Image_get_eventAlphaThreshold_m19B026C80DB547E702E22A1053FBD0A1BFF2F51A (void);
// 0x00000150 System.Void UnityEngine.UI.Image::set_eventAlphaThreshold(System.Single)
extern void Image_set_eventAlphaThreshold_m999376263E8A9914F5D69E71B4650D76F283AB6D (void);
// 0x00000151 System.Single UnityEngine.UI.Image::get_alphaHitTestMinimumThreshold()
extern void Image_get_alphaHitTestMinimumThreshold_m5F6F90EEC3D06F719E9C360A6813A49CDD7EC4BA (void);
// 0x00000152 System.Void UnityEngine.UI.Image::set_alphaHitTestMinimumThreshold(System.Single)
extern void Image_set_alphaHitTestMinimumThreshold_m007F9F1C5FD0331E1EDADF4EEE3CB16F6B43F843 (void);
// 0x00000153 System.Boolean UnityEngine.UI.Image::get_useSpriteMesh()
extern void Image_get_useSpriteMesh_m3157E0D7DB2F54EA7B13284F53FA9013F316F7F8 (void);
// 0x00000154 System.Void UnityEngine.UI.Image::set_useSpriteMesh(System.Boolean)
extern void Image_set_useSpriteMesh_mFA81C2E108CEB33E5F92A9142B2C83B871C3A81B (void);
// 0x00000155 System.Void UnityEngine.UI.Image::.ctor()
extern void Image__ctor_m8F922348981CDB74700D89D833FE39611FA4BC37 (void);
// 0x00000156 UnityEngine.Material UnityEngine.UI.Image::get_defaultETC1GraphicMaterial()
extern void Image_get_defaultETC1GraphicMaterial_mCEFD3237CA0090EBED29A81983DC3FE78BAFBAB3 (void);
// 0x00000157 UnityEngine.Texture UnityEngine.UI.Image::get_mainTexture()
extern void Image_get_mainTexture_m16CAAF3A2CBF5B3BBB19AC8BD99CE9187C47D3FD (void);
// 0x00000158 System.Boolean UnityEngine.UI.Image::get_hasBorder()
extern void Image_get_hasBorder_m9B09E5452FE8CF13958D7301B01A3A8124ADDDC0 (void);
// 0x00000159 System.Single UnityEngine.UI.Image::get_pixelsPerUnitMultiplier()
extern void Image_get_pixelsPerUnitMultiplier_m2B008CF7C16C195A24FDBC5CC7B34531E18F1A18 (void);
// 0x0000015A System.Void UnityEngine.UI.Image::set_pixelsPerUnitMultiplier(System.Single)
extern void Image_set_pixelsPerUnitMultiplier_m05DA43C7FD5B7B162FCB1ED6FCA850FD41AF7DC1 (void);
// 0x0000015B System.Single UnityEngine.UI.Image::get_pixelsPerUnit()
extern void Image_get_pixelsPerUnit_m319197FFB69E9E8661F46B0DF652F3B3F25D16D5 (void);
// 0x0000015C System.Single UnityEngine.UI.Image::get_multipliedPixelsPerUnit()
extern void Image_get_multipliedPixelsPerUnit_m6F99237811BE288035A4133833611A446BEE6A8A (void);
// 0x0000015D UnityEngine.Material UnityEngine.UI.Image::get_material()
extern void Image_get_material_m62CEA51BA237569FDB47573CDC125CC3E643A3E7 (void);
// 0x0000015E System.Void UnityEngine.UI.Image::set_material(UnityEngine.Material)
extern void Image_set_material_mC1B5D07666D4CF7C4531F2E8424EB2B62A445D19 (void);
// 0x0000015F System.Void UnityEngine.UI.Image::OnBeforeSerialize()
extern void Image_OnBeforeSerialize_mF6D870DBB1C6826A6AFBD2F23D5181A2BE47994A (void);
// 0x00000160 System.Void UnityEngine.UI.Image::OnAfterDeserialize()
extern void Image_OnAfterDeserialize_mAD5F5C236B40A266EED00C838164502E253957DD (void);
// 0x00000161 System.Void UnityEngine.UI.Image::PreserveSpriteAspectRatio(UnityEngine.Rect&,UnityEngine.Vector2)
extern void Image_PreserveSpriteAspectRatio_mF56B000B224C2EF11A2EAB4BF465EEA158C5BE1D (void);
// 0x00000162 UnityEngine.Vector4 UnityEngine.UI.Image::GetDrawingDimensions(System.Boolean)
extern void Image_GetDrawingDimensions_mE33EF5C86703080A13063FAD318B6C114B80CB1B (void);
// 0x00000163 System.Void UnityEngine.UI.Image::SetNativeSize()
extern void Image_SetNativeSize_mC769A2A62A1F5ED648FC64918182CA40D5518817 (void);
// 0x00000164 System.Void UnityEngine.UI.Image::OnPopulateMesh(UnityEngine.UI.VertexHelper)
extern void Image_OnPopulateMesh_m5B662B655BB6DD663AFBF9DF440DF6C6C2EEF9EB (void);
// 0x00000165 System.Void UnityEngine.UI.Image::TrackSprite()
extern void Image_TrackSprite_m77BFAC0425F494ED236E393B60E6BD26D5B6A5AA (void);
// 0x00000166 System.Void UnityEngine.UI.Image::OnEnable()
extern void Image_OnEnable_m35B953599A5E65EFEA059E93772D73ACA91BD073 (void);
// 0x00000167 System.Void UnityEngine.UI.Image::OnDisable()
extern void Image_OnDisable_m453B2333D529FD5359E1F687BFE2D949207AA58C (void);
// 0x00000168 System.Void UnityEngine.UI.Image::UpdateMaterial()
extern void Image_UpdateMaterial_m3EF2E1AA8D38FAA067FB5AF887B88855EBF1AE9C (void);
// 0x00000169 System.Void UnityEngine.UI.Image::OnCanvasHierarchyChanged()
extern void Image_OnCanvasHierarchyChanged_m3B34FE2B1BDEE8A04854E9C1ADAC49934FC7EDA8 (void);
// 0x0000016A System.Void UnityEngine.UI.Image::GenerateSimpleSprite(UnityEngine.UI.VertexHelper,System.Boolean)
extern void Image_GenerateSimpleSprite_m32C9150574E952AE9F5B846AD11A5F0BC8521CC9 (void);
// 0x0000016B System.Void UnityEngine.UI.Image::GenerateSprite(UnityEngine.UI.VertexHelper,System.Boolean)
extern void Image_GenerateSprite_mE58FCD6A8B78A30794664E9DEA81A51C5CF6FD03 (void);
// 0x0000016C System.Void UnityEngine.UI.Image::GenerateSlicedSprite(UnityEngine.UI.VertexHelper)
extern void Image_GenerateSlicedSprite_mE27E793AAF0D0E30BD1B02A12C7FF08566132EF1 (void);
// 0x0000016D System.Void UnityEngine.UI.Image::GenerateTiledSprite(UnityEngine.UI.VertexHelper)
extern void Image_GenerateTiledSprite_mD6AD2832573EB7AFDDDAC9D31C243AABEA7489B5 (void);
// 0x0000016E System.Void UnityEngine.UI.Image::AddQuad(UnityEngine.UI.VertexHelper,UnityEngine.Vector3[],UnityEngine.Color32,UnityEngine.Vector3[])
extern void Image_AddQuad_m53D28C1CA949F7C8B1214D15298BDA5E21AFFD21 (void);
// 0x0000016F System.Void UnityEngine.UI.Image::AddQuad(UnityEngine.UI.VertexHelper,UnityEngine.Vector2,UnityEngine.Vector2,UnityEngine.Color32,UnityEngine.Vector2,UnityEngine.Vector2)
extern void Image_AddQuad_m39CF7AAE0605E563F3D0C6CE62639E44BCAACA42 (void);
// 0x00000170 UnityEngine.Vector4 UnityEngine.UI.Image::GetAdjustedBorders(UnityEngine.Vector4,UnityEngine.Rect)
extern void Image_GetAdjustedBorders_mF3AEDCD9810B2DE6038FF269245899F325366CF6 (void);
// 0x00000171 System.Void UnityEngine.UI.Image::GenerateFilledSprite(UnityEngine.UI.VertexHelper,System.Boolean)
extern void Image_GenerateFilledSprite_m3C13BE8BEBBF021D40B2A6AF6A4170055E621915 (void);
// 0x00000172 System.Boolean UnityEngine.UI.Image::RadialCut(UnityEngine.Vector3[],UnityEngine.Vector3[],System.Single,System.Boolean,System.Int32)
extern void Image_RadialCut_m0D5FED1F2A3FFE1985A19E8C8AE990EDFA42C2E4 (void);
// 0x00000173 System.Void UnityEngine.UI.Image::RadialCut(UnityEngine.Vector3[],System.Single,System.Single,System.Boolean,System.Int32)
extern void Image_RadialCut_m9F8E2FE769EE906D4327A856B6DE9ED73B1AE338 (void);
// 0x00000174 System.Void UnityEngine.UI.Image::CalculateLayoutInputHorizontal()
extern void Image_CalculateLayoutInputHorizontal_m2B3C913A12F299D2ADBC79DCBC2FD533B24E1EC8 (void);
// 0x00000175 System.Void UnityEngine.UI.Image::CalculateLayoutInputVertical()
extern void Image_CalculateLayoutInputVertical_mA3259ED5830198EF68B2FE1490491D6761C9CAF4 (void);
// 0x00000176 System.Single UnityEngine.UI.Image::get_minWidth()
extern void Image_get_minWidth_m55A550B01D2E2AA928D77B836B6DDD159EF8B9EA (void);
// 0x00000177 System.Single UnityEngine.UI.Image::get_preferredWidth()
extern void Image_get_preferredWidth_m8AB595CC948924C3C0014873E4C32FC60CA7F27E (void);
// 0x00000178 System.Single UnityEngine.UI.Image::get_flexibleWidth()
extern void Image_get_flexibleWidth_m76B50FB439854C2E3850E4D1988029BFCD85EEB5 (void);
// 0x00000179 System.Single UnityEngine.UI.Image::get_minHeight()
extern void Image_get_minHeight_m40CDD49A5304B1E96FBA3325A9865F16C782CA4F (void);
// 0x0000017A System.Single UnityEngine.UI.Image::get_preferredHeight()
extern void Image_get_preferredHeight_m3A6C0CA2FF3F09FD072ABA13D0553783DD5B0A5E (void);
// 0x0000017B System.Single UnityEngine.UI.Image::get_flexibleHeight()
extern void Image_get_flexibleHeight_mF47948629BAA50EC3FC818AD668411A0061EEE6C (void);
// 0x0000017C System.Int32 UnityEngine.UI.Image::get_layoutPriority()
extern void Image_get_layoutPriority_m1D4FFA04DF71939657E16CDFFC81A5453ECE0C67 (void);
// 0x0000017D System.Boolean UnityEngine.UI.Image::IsRaycastLocationValid(UnityEngine.Vector2,UnityEngine.Camera)
extern void Image_IsRaycastLocationValid_mB71CF2A446BE3F4C6CF896E8BCA9A36BDF676D21 (void);
// 0x0000017E UnityEngine.Vector2 UnityEngine.UI.Image::MapCoordinate(UnityEngine.Vector2,UnityEngine.Rect)
extern void Image_MapCoordinate_m11D428E63DF2AEB1A5866A0AE778E5287F4776FF (void);
// 0x0000017F System.Void UnityEngine.UI.Image::RebuildImage(UnityEngine.U2D.SpriteAtlas)
extern void Image_RebuildImage_m5BDCACEE109C4EF96B8F783BCB71FEA9A72E0E45 (void);
// 0x00000180 System.Void UnityEngine.UI.Image::TrackImage(UnityEngine.UI.Image)
extern void Image_TrackImage_m24AE9D703DB406780DA6975F648C587CA1F62EDC (void);
// 0x00000181 System.Void UnityEngine.UI.Image::UnTrackImage(UnityEngine.UI.Image)
extern void Image_UnTrackImage_m59DCA4A9F6ABE55046D24006FCC7373FC0717A0C (void);
// 0x00000182 System.Void UnityEngine.UI.Image::OnDidApplyAnimationProperties()
extern void Image_OnDidApplyAnimationProperties_mA079140EDEA8341023066DC950E94F38C61EEE27 (void);
// 0x00000183 System.Void UnityEngine.UI.Image::.cctor()
extern void Image__cctor_m67595BC3057DCFD5A6593929CA673CE415F5803C (void);
// 0x00000184 System.Boolean UnityEngine.UI.IMask::Enabled()
// 0x00000185 UnityEngine.RectTransform UnityEngine.UI.IMask::get_rectTransform()
// 0x00000186 System.Void UnityEngine.UI.IMaskable::RecalculateMasking()
// 0x00000187 UnityEngine.EventSystems.BaseInput UnityEngine.UI.InputField::get_input()
extern void InputField_get_input_m23129FACBD4CDCEA3FC9A977D7DA5BBD4BBB0B2B (void);
// 0x00000188 System.String UnityEngine.UI.InputField::get_compositionString()
extern void InputField_get_compositionString_m5E9F323DE7B62EBB69AFC569C05ABC00F619FC4A (void);
// 0x00000189 System.Void UnityEngine.UI.InputField::.ctor()
extern void InputField__ctor_m06B9629E3C878D578A8B43C1A8835B526629D6E5 (void);
// 0x0000018A UnityEngine.Mesh UnityEngine.UI.InputField::get_mesh()
extern void InputField_get_mesh_m89CB1A4155FF8E7C42D5D97178DD00A3A7D8888E (void);
// 0x0000018B UnityEngine.TextGenerator UnityEngine.UI.InputField::get_cachedInputTextGenerator()
extern void InputField_get_cachedInputTextGenerator_m42F16837E9BC49BB43F58163B827C4260303E48E (void);
// 0x0000018C System.Void UnityEngine.UI.InputField::set_shouldHideMobileInput(System.Boolean)
extern void InputField_set_shouldHideMobileInput_mC3759A3E3DED19B9EC01E30CB810922772894C76 (void);
// 0x0000018D System.Boolean UnityEngine.UI.InputField::get_shouldHideMobileInput()
extern void InputField_get_shouldHideMobileInput_mA752B065435F4062EFB931119C34FDB5B35157E2 (void);
// 0x0000018E System.Void UnityEngine.UI.InputField::set_shouldActivateOnSelect(System.Boolean)
extern void InputField_set_shouldActivateOnSelect_m5F21C9511D040820CFF661E56145C25D147D17A5 (void);
// 0x0000018F System.Boolean UnityEngine.UI.InputField::get_shouldActivateOnSelect()
extern void InputField_get_shouldActivateOnSelect_m4DA84FAEB2FFB6F036A3821675730842FF86245F (void);
// 0x00000190 System.String UnityEngine.UI.InputField::get_text()
extern void InputField_get_text_m6E0796350FF559505E4DF17311803962699D6704 (void);
// 0x00000191 System.Void UnityEngine.UI.InputField::set_text(System.String)
extern void InputField_set_text_m28B1C806BBCAC44F3ACCDC3B550509CA0C7D257F (void);
// 0x00000192 System.Void UnityEngine.UI.InputField::SetTextWithoutNotify(System.String)
extern void InputField_SetTextWithoutNotify_m2CD8DAC2A298CBABFCEC654A17294427DDD238A3 (void);
// 0x00000193 System.Void UnityEngine.UI.InputField::SetText(System.String,System.Boolean)
extern void InputField_SetText_m66574324D7550D728E41F71DD704CDCDEADF9E66 (void);
// 0x00000194 System.Boolean UnityEngine.UI.InputField::get_isFocused()
extern void InputField_get_isFocused_m19BD51E842077CA087824025F294C4078B2DAC50 (void);
// 0x00000195 System.Single UnityEngine.UI.InputField::get_caretBlinkRate()
extern void InputField_get_caretBlinkRate_m5D6172BA3B84F25897444A1A469AA53FC5CE5613 (void);
// 0x00000196 System.Void UnityEngine.UI.InputField::set_caretBlinkRate(System.Single)
extern void InputField_set_caretBlinkRate_mCE440AA4049C7A1EDEDB63E5B0AE4005563C5226 (void);
// 0x00000197 System.Int32 UnityEngine.UI.InputField::get_caretWidth()
extern void InputField_get_caretWidth_m6D85BF105006F28ABF2940033BEED2E595C89E55 (void);
// 0x00000198 System.Void UnityEngine.UI.InputField::set_caretWidth(System.Int32)
extern void InputField_set_caretWidth_mD71B00146099D90D920F4F63A7032E8AEDD39915 (void);
// 0x00000199 UnityEngine.UI.Text UnityEngine.UI.InputField::get_textComponent()
extern void InputField_get_textComponent_m319EF4B9B24056AF25327874A2455362FF7B7A85 (void);
// 0x0000019A System.Void UnityEngine.UI.InputField::set_textComponent(UnityEngine.UI.Text)
extern void InputField_set_textComponent_m09DF6BBF8544028D98D68D3F905AAAE17486D272 (void);
// 0x0000019B UnityEngine.UI.Graphic UnityEngine.UI.InputField::get_placeholder()
extern void InputField_get_placeholder_m84C2F2E414B8A03B372C7CEB3C97A2AE72F3A39F (void);
// 0x0000019C System.Void UnityEngine.UI.InputField::set_placeholder(UnityEngine.UI.Graphic)
extern void InputField_set_placeholder_m64F47B180F584EB1049CF8B501DAC3FCA9029F25 (void);
// 0x0000019D UnityEngine.Color UnityEngine.UI.InputField::get_caretColor()
extern void InputField_get_caretColor_m92C8BB7D9BD4B4DAE361494F85418F834EE87832 (void);
// 0x0000019E System.Void UnityEngine.UI.InputField::set_caretColor(UnityEngine.Color)
extern void InputField_set_caretColor_mF9C606AA2F9F123CB6AD078DF616DE35061FF830 (void);
// 0x0000019F System.Boolean UnityEngine.UI.InputField::get_customCaretColor()
extern void InputField_get_customCaretColor_mB1D8A9DE8CD1787B3614BAF3E50E27B2428C7215 (void);
// 0x000001A0 System.Void UnityEngine.UI.InputField::set_customCaretColor(System.Boolean)
extern void InputField_set_customCaretColor_m7CA0470187246247EEC354FEB7053E4B4911DC13 (void);
// 0x000001A1 UnityEngine.Color UnityEngine.UI.InputField::get_selectionColor()
extern void InputField_get_selectionColor_m988C5ACE38195B9B6397352B5A226FF3867A6E54 (void);
// 0x000001A2 System.Void UnityEngine.UI.InputField::set_selectionColor(UnityEngine.Color)
extern void InputField_set_selectionColor_m2B7800A90FCE0840800CC01EC2C17059634B015E (void);
// 0x000001A3 UnityEngine.UI.InputField/EndEditEvent UnityEngine.UI.InputField::get_onEndEdit()
extern void InputField_get_onEndEdit_m92C86FF7CA6108C4B14392CED20C9ED9D39AD9A3 (void);
// 0x000001A4 System.Void UnityEngine.UI.InputField::set_onEndEdit(UnityEngine.UI.InputField/EndEditEvent)
extern void InputField_set_onEndEdit_m0AA121171524CB10C4BE4692117839A97E6AAD08 (void);
// 0x000001A5 UnityEngine.UI.InputField/SubmitEvent UnityEngine.UI.InputField::get_onSubmit()
extern void InputField_get_onSubmit_m66A3BFEC3D3D5C261558043FD606D4FBCC7D478D (void);
// 0x000001A6 System.Void UnityEngine.UI.InputField::set_onSubmit(UnityEngine.UI.InputField/SubmitEvent)
extern void InputField_set_onSubmit_m1763F344243E5E3CF28F07872A80AAF809FC1988 (void);
// 0x000001A7 UnityEngine.UI.InputField/OnChangeEvent UnityEngine.UI.InputField::get_onValueChange()
extern void InputField_get_onValueChange_mF6915B4F33F4B24A91D8E56DE20EFFAE25C59756 (void);
// 0x000001A8 System.Void UnityEngine.UI.InputField::set_onValueChange(UnityEngine.UI.InputField/OnChangeEvent)
extern void InputField_set_onValueChange_mA1AEDDDB12CEC499949DB0605A83D8F383212CEA (void);
// 0x000001A9 UnityEngine.UI.InputField/OnChangeEvent UnityEngine.UI.InputField::get_onValueChanged()
extern void InputField_get_onValueChanged_mA9ABE178FE3EB05AEF3DC20C11349427C59916AE (void);
// 0x000001AA System.Void UnityEngine.UI.InputField::set_onValueChanged(UnityEngine.UI.InputField/OnChangeEvent)
extern void InputField_set_onValueChanged_m2B2F8D1E8F5FE418CE0797F2534B61A1A45B8A85 (void);
// 0x000001AB UnityEngine.UI.InputField/OnValidateInput UnityEngine.UI.InputField::get_onValidateInput()
extern void InputField_get_onValidateInput_m370D93274B6040422092981DD3A34E4B88E96EBC (void);
// 0x000001AC System.Void UnityEngine.UI.InputField::set_onValidateInput(UnityEngine.UI.InputField/OnValidateInput)
extern void InputField_set_onValidateInput_m3A3FA74285B9BBA68325A91AA862201AF3A18CE4 (void);
// 0x000001AD System.Int32 UnityEngine.UI.InputField::get_characterLimit()
extern void InputField_get_characterLimit_m7FE26FC66741545B89BFFDCAD8E8B34EB1274403 (void);
// 0x000001AE System.Void UnityEngine.UI.InputField::set_characterLimit(System.Int32)
extern void InputField_set_characterLimit_m98A2187FF493DB170821C39A6D069731F3AFFF2B (void);
// 0x000001AF UnityEngine.UI.InputField/ContentType UnityEngine.UI.InputField::get_contentType()
extern void InputField_get_contentType_m8C589B15987EB8852D5F4948A79084186935B19B (void);
// 0x000001B0 System.Void UnityEngine.UI.InputField::set_contentType(UnityEngine.UI.InputField/ContentType)
extern void InputField_set_contentType_m5C3DDD7C14781E963BFFC88F7A8A537919F34C59 (void);
// 0x000001B1 UnityEngine.UI.InputField/LineType UnityEngine.UI.InputField::get_lineType()
extern void InputField_get_lineType_m6CEA63D8FCACAEC05D3499577ED0771EFFF33377 (void);
// 0x000001B2 System.Void UnityEngine.UI.InputField::set_lineType(UnityEngine.UI.InputField/LineType)
extern void InputField_set_lineType_m06BE148366DF8F17E0F91C3CF094628C201B5FD8 (void);
// 0x000001B3 UnityEngine.UI.InputField/InputType UnityEngine.UI.InputField::get_inputType()
extern void InputField_get_inputType_mC324081499638BC8AAA45CC110536C016C707BD0 (void);
// 0x000001B4 System.Void UnityEngine.UI.InputField::set_inputType(UnityEngine.UI.InputField/InputType)
extern void InputField_set_inputType_mB2A3B667DC710AD1F9E1C046659AC35720AB0313 (void);
// 0x000001B5 UnityEngine.TouchScreenKeyboard UnityEngine.UI.InputField::get_touchScreenKeyboard()
extern void InputField_get_touchScreenKeyboard_m99338FA7655276193EE1BA8FCB821C7F1928B3D8 (void);
// 0x000001B6 UnityEngine.TouchScreenKeyboardType UnityEngine.UI.InputField::get_keyboardType()
extern void InputField_get_keyboardType_mCF9432AC88C35E77546235909346C5689682E620 (void);
// 0x000001B7 System.Void UnityEngine.UI.InputField::set_keyboardType(UnityEngine.TouchScreenKeyboardType)
extern void InputField_set_keyboardType_m9DD165B20CF12F93BD85140D8D1F54371FF4E9F3 (void);
// 0x000001B8 UnityEngine.UI.InputField/CharacterValidation UnityEngine.UI.InputField::get_characterValidation()
extern void InputField_get_characterValidation_m02AD706E70817147BAADD487DAC73D79547BCBBF (void);
// 0x000001B9 System.Void UnityEngine.UI.InputField::set_characterValidation(UnityEngine.UI.InputField/CharacterValidation)
extern void InputField_set_characterValidation_m9DE08B33714B9D97F570853ADB56C070C2DD4072 (void);
// 0x000001BA System.Boolean UnityEngine.UI.InputField::get_readOnly()
extern void InputField_get_readOnly_m37800B8623CB744D99E5F5607C80AEBE6C7043B3 (void);
// 0x000001BB System.Void UnityEngine.UI.InputField::set_readOnly(System.Boolean)
extern void InputField_set_readOnly_mD70582D7F885929AD7CF28BF083623991C5F543F (void);
// 0x000001BC System.Boolean UnityEngine.UI.InputField::get_multiLine()
extern void InputField_get_multiLine_m4AF37C1E2560778A214C50E91C472430D8F777B6 (void);
// 0x000001BD System.Char UnityEngine.UI.InputField::get_asteriskChar()
extern void InputField_get_asteriskChar_m2556CE9FA8ABF5C00552BA665299F71EAC7D55C5 (void);
// 0x000001BE System.Void UnityEngine.UI.InputField::set_asteriskChar(System.Char)
extern void InputField_set_asteriskChar_m26FC4CE6C8637E49ADE854769F6C777A6BEF5CB6 (void);
// 0x000001BF System.Boolean UnityEngine.UI.InputField::get_wasCanceled()
extern void InputField_get_wasCanceled_m75E09A773352839E08B04B33F966ED3E849436E9 (void);
// 0x000001C0 System.Void UnityEngine.UI.InputField::ClampPos(System.Int32&)
extern void InputField_ClampPos_m8939841884C3CD51A6169F5DA05A85CC3C16A371 (void);
// 0x000001C1 System.Int32 UnityEngine.UI.InputField::get_caretPositionInternal()
extern void InputField_get_caretPositionInternal_mF01180C72008CCDD2A5371EE45B84D7745CB6BC0 (void);
// 0x000001C2 System.Void UnityEngine.UI.InputField::set_caretPositionInternal(System.Int32)
extern void InputField_set_caretPositionInternal_mA35B05D5FF035A060967C6E456610D659367C3EA (void);
// 0x000001C3 System.Int32 UnityEngine.UI.InputField::get_caretSelectPositionInternal()
extern void InputField_get_caretSelectPositionInternal_mBAE2F71F18603A0C4A6AA08F0BFE5831CBBBA461 (void);
// 0x000001C4 System.Void UnityEngine.UI.InputField::set_caretSelectPositionInternal(System.Int32)
extern void InputField_set_caretSelectPositionInternal_mCA096AAD610587421E739BDD195A1680FD93A75A (void);
// 0x000001C5 System.Boolean UnityEngine.UI.InputField::get_hasSelection()
extern void InputField_get_hasSelection_m3E8EF152E7A7238C8F0631FFC16727800CF16B24 (void);
// 0x000001C6 System.Int32 UnityEngine.UI.InputField::get_caretPosition()
extern void InputField_get_caretPosition_mC43674CCFF5BF7D047C2D4682B2CD7DE8A179EA7 (void);
// 0x000001C7 System.Void UnityEngine.UI.InputField::set_caretPosition(System.Int32)
extern void InputField_set_caretPosition_mF502AA3301C39D4397C7BF809D1F3A18D0603BD7 (void);
// 0x000001C8 System.Int32 UnityEngine.UI.InputField::get_selectionAnchorPosition()
extern void InputField_get_selectionAnchorPosition_mF5CB19025C29DECEA0EBA8C6EC3D6D5687A1D65E (void);
// 0x000001C9 System.Void UnityEngine.UI.InputField::set_selectionAnchorPosition(System.Int32)
extern void InputField_set_selectionAnchorPosition_mE57B85DBF03991E694729ED36283B44A8D7D1E68 (void);
// 0x000001CA System.Int32 UnityEngine.UI.InputField::get_selectionFocusPosition()
extern void InputField_get_selectionFocusPosition_m14D662A0A20FF6952E73CFAB7C1F21FD7CF4298A (void);
// 0x000001CB System.Void UnityEngine.UI.InputField::set_selectionFocusPosition(System.Int32)
extern void InputField_set_selectionFocusPosition_mE9E0E491C5AC1B89B4F9272EC3B67617A4F7DFEB (void);
// 0x000001CC System.Void UnityEngine.UI.InputField::Awake()
extern void InputField_Awake_m7253E5687FD0D44982BA34EA523894C0CBE927A6 (void);
// 0x000001CD System.Void UnityEngine.UI.InputField::OnEnable()
extern void InputField_OnEnable_m00FE61194E553F736B0C1AABC73A79EEDE81D9AF (void);
// 0x000001CE System.Void UnityEngine.UI.InputField::OnDisable()
extern void InputField_OnDisable_mA79B9B02E48BE7F1AA6C94C6CECB7A6AB323AB8B (void);
// 0x000001CF System.Void UnityEngine.UI.InputField::OnDestroy()
extern void InputField_OnDestroy_m551000531722FAD0D2DEB4CA9A76EF25A7067EAA (void);
// 0x000001D0 System.Collections.IEnumerator UnityEngine.UI.InputField::CaretBlink()
extern void InputField_CaretBlink_m030EE72571B48D2CD7E346D68B0F236C9BB25CB5 (void);
// 0x000001D1 System.Void UnityEngine.UI.InputField::SetCaretVisible()
extern void InputField_SetCaretVisible_m9DB05703AF6B427F53FB4948BB592CF061AA37AB (void);
// 0x000001D2 System.Void UnityEngine.UI.InputField::SetCaretActive()
extern void InputField_SetCaretActive_mC91972AACD936D757447E3F7967CE2DAD4B46D0E (void);
// 0x000001D3 System.Void UnityEngine.UI.InputField::UpdateCaretMaterial()
extern void InputField_UpdateCaretMaterial_mA2C86C0AFC38D35509A3BD66A10411AF7D13FFD4 (void);
// 0x000001D4 System.Void UnityEngine.UI.InputField::OnFocus()
extern void InputField_OnFocus_m5EC2CB19FBDAA84FB317F5ADA86548D78B550F37 (void);
// 0x000001D5 System.Void UnityEngine.UI.InputField::SelectAll()
extern void InputField_SelectAll_mC3A2CAB32B290BC43782A61452760BD127E729EA (void);
// 0x000001D6 System.Void UnityEngine.UI.InputField::MoveTextEnd(System.Boolean)
extern void InputField_MoveTextEnd_m1C20AF9DB90F79CD85C4DAB179DA4EDB4D971810 (void);
// 0x000001D7 System.Void UnityEngine.UI.InputField::MoveTextStart(System.Boolean)
extern void InputField_MoveTextStart_mE56A94C2D4AE751A3BE1035250880D9B592BF130 (void);
// 0x000001D8 System.String UnityEngine.UI.InputField::get_clipboard()
extern void InputField_get_clipboard_m4ACB240747BB6AF77A3FEF28A63A5C2B2A049543 (void);
// 0x000001D9 System.Void UnityEngine.UI.InputField::set_clipboard(System.String)
extern void InputField_set_clipboard_mA8C4BC1DA5B1C12F8A7E7880E0F74185E2D8BCDB (void);
// 0x000001DA System.Boolean UnityEngine.UI.InputField::TouchScreenKeyboardShouldBeUsed()
extern void InputField_TouchScreenKeyboardShouldBeUsed_m56104E5B7C58A89C552D4CF8FD7A1B1D93D7340A (void);
// 0x000001DB System.Boolean UnityEngine.UI.InputField::InPlaceEditing()
extern void InputField_InPlaceEditing_m1F71173373CC2A21034D23ECA0060FA4E5A89F11 (void);
// 0x000001DC System.Boolean UnityEngine.UI.InputField::InPlaceEditingChanged()
extern void InputField_InPlaceEditingChanged_mE02AC706260B93670AF1380BE4060F3AA4063C47 (void);
// 0x000001DD System.Void UnityEngine.UI.InputField::UpdateCaretFromKeyboard()
extern void InputField_UpdateCaretFromKeyboard_mCFB186696BE23B347D7AA94DF50A13555C31F8B4 (void);
// 0x000001DE System.Void UnityEngine.UI.InputField::LateUpdate()
extern void InputField_LateUpdate_mA1C1B81011E3D2F3D6F0769C0FE0D4B0A8E71020 (void);
// 0x000001DF UnityEngine.Vector2 UnityEngine.UI.InputField::ScreenToLocal(UnityEngine.Vector2)
extern void InputField_ScreenToLocal_m3ABFAAAC443370A1621926D80EA665CF421CAF9E (void);
// 0x000001E0 System.Int32 UnityEngine.UI.InputField::GetUnclampedCharacterLineFromPosition(UnityEngine.Vector2,UnityEngine.TextGenerator)
extern void InputField_GetUnclampedCharacterLineFromPosition_mDD25BDEA1097899537A5D7E8881F23D3D49327DC (void);
// 0x000001E1 System.Int32 UnityEngine.UI.InputField::GetCharacterIndexFromPosition(UnityEngine.Vector2)
extern void InputField_GetCharacterIndexFromPosition_m9C0D9CBB43A1CCC47F7B4234379668E46AE3EB32 (void);
// 0x000001E2 System.Boolean UnityEngine.UI.InputField::MayDrag(UnityEngine.EventSystems.PointerEventData)
extern void InputField_MayDrag_m72ED9A80A46F59B07697E415E1D691084BC133E6 (void);
// 0x000001E3 System.Void UnityEngine.UI.InputField::OnBeginDrag(UnityEngine.EventSystems.PointerEventData)
extern void InputField_OnBeginDrag_m3A945C4E07937EDA5E99447572F5F167F1143691 (void);
// 0x000001E4 System.Void UnityEngine.UI.InputField::OnDrag(UnityEngine.EventSystems.PointerEventData)
extern void InputField_OnDrag_mEF28C06EFB5024C1E236C5A21E715B62CA87BE84 (void);
// 0x000001E5 System.Collections.IEnumerator UnityEngine.UI.InputField::MouseDragOutsideRect(UnityEngine.EventSystems.PointerEventData)
extern void InputField_MouseDragOutsideRect_m464392D721204B540DC92E449B48BCB04BCFDABC (void);
// 0x000001E6 System.Void UnityEngine.UI.InputField::OnEndDrag(UnityEngine.EventSystems.PointerEventData)
extern void InputField_OnEndDrag_m0BAA34E5BDBC9A3E241F8BC7DBA8172DD5D9651B (void);
// 0x000001E7 System.Void UnityEngine.UI.InputField::OnPointerDown(UnityEngine.EventSystems.PointerEventData)
extern void InputField_OnPointerDown_m4A3A77DDBA95CB4E50A4BFDF0EDD59B5A9191BF2 (void);
// 0x000001E8 UnityEngine.UI.InputField/EditState UnityEngine.UI.InputField::KeyPressed(UnityEngine.Event)
extern void InputField_KeyPressed_mD6FAC314D8211F43C4C041AE87B3290665A05D28 (void);
// 0x000001E9 System.Boolean UnityEngine.UI.InputField::IsValidChar(System.Char)
extern void InputField_IsValidChar_mDFF88F1042D52286FDCD5D7302706C837265876D (void);
// 0x000001EA System.Void UnityEngine.UI.InputField::ProcessEvent(UnityEngine.Event)
extern void InputField_ProcessEvent_mF905BEF5A4CFF9144159FA40DE2F9DFD4A967358 (void);
// 0x000001EB System.Void UnityEngine.UI.InputField::OnUpdateSelected(UnityEngine.EventSystems.BaseEventData)
extern void InputField_OnUpdateSelected_m36FFEE16138CDDCA30643962A4C5A41763FE2E55 (void);
// 0x000001EC System.String UnityEngine.UI.InputField::GetSelectedString()
extern void InputField_GetSelectedString_mDF15471A4398D6D7B391105A8549F09DC03DA283 (void);
// 0x000001ED System.Int32 UnityEngine.UI.InputField::FindtNextWordBegin()
extern void InputField_FindtNextWordBegin_m1152E725F12932E30E304F4F10A42B0733201A18 (void);
// 0x000001EE System.Void UnityEngine.UI.InputField::MoveRight(System.Boolean,System.Boolean)
extern void InputField_MoveRight_m0D51E23BE4EF55EA54DED277573263BB2A5B1D38 (void);
// 0x000001EF System.Int32 UnityEngine.UI.InputField::FindtPrevWordBegin()
extern void InputField_FindtPrevWordBegin_m54E76FA4BF8AE95109D2F78EA0814751837F5AF7 (void);
// 0x000001F0 System.Void UnityEngine.UI.InputField::MoveLeft(System.Boolean,System.Boolean)
extern void InputField_MoveLeft_mD7E3870F7E54009522CF9412764FD5FD9212BBAA (void);
// 0x000001F1 System.Int32 UnityEngine.UI.InputField::DetermineCharacterLine(System.Int32,UnityEngine.TextGenerator)
extern void InputField_DetermineCharacterLine_mD80BD8A0F49EE45FA6E512796D3A4A15462D97BC (void);
// 0x000001F2 System.Int32 UnityEngine.UI.InputField::LineUpCharacterPosition(System.Int32,System.Boolean)
extern void InputField_LineUpCharacterPosition_m6E5C0F57795B5CF3D588EFF099A65D90E60848A0 (void);
// 0x000001F3 System.Int32 UnityEngine.UI.InputField::LineDownCharacterPosition(System.Int32,System.Boolean)
extern void InputField_LineDownCharacterPosition_m3212B8EC92092E97AC60D072EFBD385FE72CA829 (void);
// 0x000001F4 System.Void UnityEngine.UI.InputField::MoveDown(System.Boolean)
extern void InputField_MoveDown_m365DDF603B2D68FD98B0240F3302886FF7CFF16E (void);
// 0x000001F5 System.Void UnityEngine.UI.InputField::MoveDown(System.Boolean,System.Boolean)
extern void InputField_MoveDown_m13622D37FC022939623A9DBC447E49F5D9F43C80 (void);
// 0x000001F6 System.Void UnityEngine.UI.InputField::MoveUp(System.Boolean)
extern void InputField_MoveUp_m4703516BEB5B1A3C4020895BABD0558427BE7895 (void);
// 0x000001F7 System.Void UnityEngine.UI.InputField::MoveUp(System.Boolean,System.Boolean)
extern void InputField_MoveUp_m7F41FF9D5EA2BF64B36C1ACABB67169722C668DD (void);
// 0x000001F8 System.Void UnityEngine.UI.InputField::Delete()
extern void InputField_Delete_m12AD40195316F01879910401E6E0DCEC7F5A8132 (void);
// 0x000001F9 System.Void UnityEngine.UI.InputField::ForwardSpace()
extern void InputField_ForwardSpace_m4CF251F5CE00CF4918EA0C2D322770A4B556D4E7 (void);
// 0x000001FA System.Void UnityEngine.UI.InputField::Backspace()
extern void InputField_Backspace_m4BDCF533ECD04258884076830CB4F0907FCED3E6 (void);
// 0x000001FB System.Void UnityEngine.UI.InputField::Insert(System.Char)
extern void InputField_Insert_m925B9FADD75785B8FDD886477F0B0CC1E0B4C718 (void);
// 0x000001FC System.Void UnityEngine.UI.InputField::UpdateTouchKeyboardFromEditChanges()
extern void InputField_UpdateTouchKeyboardFromEditChanges_m68C429349526101B885D038FFD0C2935151E0772 (void);
// 0x000001FD System.Void UnityEngine.UI.InputField::SendOnValueChangedAndUpdateLabel()
extern void InputField_SendOnValueChangedAndUpdateLabel_mEB064D57921681BB49F55AA796E046A951DAA7BA (void);
// 0x000001FE System.Void UnityEngine.UI.InputField::SendOnValueChanged()
extern void InputField_SendOnValueChanged_m52131907987E99A872F6007B599345A2ADD244AC (void);
// 0x000001FF System.Void UnityEngine.UI.InputField::SendOnEndEdit()
extern void InputField_SendOnEndEdit_m79E2689DD75F72FDA8157EECD3F17391D187094B (void);
// 0x00000200 System.Void UnityEngine.UI.InputField::SendOnSubmit()
extern void InputField_SendOnSubmit_m933C160291FD9118A9EC7FD7AED5E805B998BA27 (void);
// 0x00000201 System.Void UnityEngine.UI.InputField::Append(System.String)
extern void InputField_Append_m78F45E67DDB94E034940730969D199A971C7D1F1 (void);
// 0x00000202 System.Void UnityEngine.UI.InputField::Append(System.Char)
extern void InputField_Append_m22A6348E74FB83932286AC1CDD73322C05BBC63F (void);
// 0x00000203 System.Void UnityEngine.UI.InputField::UpdateLabel()
extern void InputField_UpdateLabel_mDBE25D21A1021AE4563539586438B5EA89511D58 (void);
// 0x00000204 System.Boolean UnityEngine.UI.InputField::IsSelectionVisible()
extern void InputField_IsSelectionVisible_m2A7FD156812466D2D2397B57959BF91BACC52EB0 (void);
// 0x00000205 System.Int32 UnityEngine.UI.InputField::GetLineStartPosition(UnityEngine.TextGenerator,System.Int32)
extern void InputField_GetLineStartPosition_m6ABF6AFB8A9495D7A5446B577EB2ECA8770A9660 (void);
// 0x00000206 System.Int32 UnityEngine.UI.InputField::GetLineEndPosition(UnityEngine.TextGenerator,System.Int32)
extern void InputField_GetLineEndPosition_m690864C08F9250D76D718D5D54611C886AAA0A79 (void);
// 0x00000207 System.Void UnityEngine.UI.InputField::SetDrawRangeToContainCaretPosition(System.Int32)
extern void InputField_SetDrawRangeToContainCaretPosition_m0F3F4E0179627915136B2B2927CD234304E8432C (void);
// 0x00000208 System.Void UnityEngine.UI.InputField::ForceLabelUpdate()
extern void InputField_ForceLabelUpdate_m49441594294B33C5DC10D717198A476B523EE1C8 (void);
// 0x00000209 System.Void UnityEngine.UI.InputField::MarkGeometryAsDirty()
extern void InputField_MarkGeometryAsDirty_m71DCE40033F96C4A842885A7601E3882FF0BD4F4 (void);
// 0x0000020A System.Void UnityEngine.UI.InputField::Rebuild(UnityEngine.UI.CanvasUpdate)
extern void InputField_Rebuild_m4974AB56B494186177AB4BA6C2626BCB0EF93304 (void);
// 0x0000020B System.Void UnityEngine.UI.InputField::LayoutComplete()
extern void InputField_LayoutComplete_m7953946E63BF48E14CE1FF13D76FCAA832735C7F (void);
// 0x0000020C System.Void UnityEngine.UI.InputField::GraphicUpdateComplete()
extern void InputField_GraphicUpdateComplete_m25B7375B32DC3384EF8684ADDAB6996359668DBF (void);
// 0x0000020D System.Void UnityEngine.UI.InputField::UpdateGeometry()
extern void InputField_UpdateGeometry_mABF2E288AF71AF5C8E608F30745D6BAE40A9CB4D (void);
// 0x0000020E System.Void UnityEngine.UI.InputField::AssignPositioningIfNeeded()
extern void InputField_AssignPositioningIfNeeded_m114957547C208AD107279D1B6E8A855D18915E36 (void);
// 0x0000020F System.Void UnityEngine.UI.InputField::OnFillVBO(UnityEngine.Mesh)
extern void InputField_OnFillVBO_m84E1576406EFFC37D6EFDDD4604B393E281C5BA2 (void);
// 0x00000210 System.Void UnityEngine.UI.InputField::GenerateCaret(UnityEngine.UI.VertexHelper,UnityEngine.Vector2)
extern void InputField_GenerateCaret_m401461627986E86804E31BE16332003BDCD9EF98 (void);
// 0x00000211 System.Void UnityEngine.UI.InputField::CreateCursorVerts()
extern void InputField_CreateCursorVerts_m2170881250E5F316805946E87EA1F1A794E6AB23 (void);
// 0x00000212 System.Void UnityEngine.UI.InputField::GenerateHighlight(UnityEngine.UI.VertexHelper,UnityEngine.Vector2)
extern void InputField_GenerateHighlight_mD1A67441901D78AE29E17A655791754A92EEC072 (void);
// 0x00000213 System.Char UnityEngine.UI.InputField::Validate(System.String,System.Int32,System.Char)
extern void InputField_Validate_mBB63D4E37F8CD96C0F57270259DDE69E3BCB7656 (void);
// 0x00000214 System.Void UnityEngine.UI.InputField::ActivateInputField()
extern void InputField_ActivateInputField_m4986DE5488FE44D93DE1D906C140D6500134DF05 (void);
// 0x00000215 System.Void UnityEngine.UI.InputField::ActivateInputFieldInternal()
extern void InputField_ActivateInputFieldInternal_m5B89A6BBCE9D7DD6F0A3DF4B6296533507170119 (void);
// 0x00000216 System.Void UnityEngine.UI.InputField::OnSelect(UnityEngine.EventSystems.BaseEventData)
extern void InputField_OnSelect_m723C2F0E81FAFF8264CFE4596CA2AF30B7D9E307 (void);
// 0x00000217 System.Void UnityEngine.UI.InputField::OnPointerClick(UnityEngine.EventSystems.PointerEventData)
extern void InputField_OnPointerClick_mCADA1FE2E0B6EA1F6A9B69DB3790E752243BA4F3 (void);
// 0x00000218 System.Void UnityEngine.UI.InputField::DeactivateInputField()
extern void InputField_DeactivateInputField_m58D0B3BF095094A0963A9CE8BABF1979F7D1254D (void);
// 0x00000219 System.Void UnityEngine.UI.InputField::OnDeselect(UnityEngine.EventSystems.BaseEventData)
extern void InputField_OnDeselect_mA31D1383106BAF91CB638C04E508322FBEB2EFDC (void);
// 0x0000021A System.Void UnityEngine.UI.InputField::OnSubmit(UnityEngine.EventSystems.BaseEventData)
extern void InputField_OnSubmit_mFEBD3EF3B76741F19E84A12FBBF9B5BB60E5952C (void);
// 0x0000021B System.Void UnityEngine.UI.InputField::EnforceContentType()
extern void InputField_EnforceContentType_mB8A7743C77E3EAE952426EF14BB5BE5B80E7488A (void);
// 0x0000021C System.Void UnityEngine.UI.InputField::EnforceTextHOverflow()
extern void InputField_EnforceTextHOverflow_m7F0E61391D942F47B4AD128C0C8B9B204BBE14B8 (void);
// 0x0000021D System.Void UnityEngine.UI.InputField::SetToCustomIfContentTypeIsNot(UnityEngine.UI.InputField/ContentType[])
extern void InputField_SetToCustomIfContentTypeIsNot_m8E1B8AF7133B6B42F9E6BA3951AE2AA4D2AF1071 (void);
// 0x0000021E System.Void UnityEngine.UI.InputField::SetToCustom()
extern void InputField_SetToCustom_m1D8B546B458993E86A24A05B868C57286E8C6BF4 (void);
// 0x0000021F System.Void UnityEngine.UI.InputField::DoStateTransition(UnityEngine.UI.Selectable/SelectionState,System.Boolean)
extern void InputField_DoStateTransition_m51CFACBDB11404C6F10D0BA3AACB394036CB35A8 (void);
// 0x00000220 System.Void UnityEngine.UI.InputField::CalculateLayoutInputHorizontal()
extern void InputField_CalculateLayoutInputHorizontal_m291256FA87BF5E7F0D7CD64205B58E6B7E88809B (void);
// 0x00000221 System.Void UnityEngine.UI.InputField::CalculateLayoutInputVertical()
extern void InputField_CalculateLayoutInputVertical_m4102477D8FA249BA49FDF9C0CE5F45A42752B083 (void);
// 0x00000222 System.Single UnityEngine.UI.InputField::get_minWidth()
extern void InputField_get_minWidth_mE316201A4474E22FA455CFD381C0A73B76CF5B06 (void);
// 0x00000223 System.Single UnityEngine.UI.InputField::get_preferredWidth()
extern void InputField_get_preferredWidth_m13ACB831ECB400033C936A46342FF10E8A96D05B (void);
// 0x00000224 System.Single UnityEngine.UI.InputField::get_flexibleWidth()
extern void InputField_get_flexibleWidth_mCCBC75043CD2BF11B0E38D71A00A5CE790DD9E8C (void);
// 0x00000225 System.Single UnityEngine.UI.InputField::get_minHeight()
extern void InputField_get_minHeight_mC742ED6E8E46602EE8C085F724AD5442A24DB1D7 (void);
// 0x00000226 System.Single UnityEngine.UI.InputField::get_preferredHeight()
extern void InputField_get_preferredHeight_m7C3EAA7E8DC12397B9C83A72582C8FC219BA63DA (void);
// 0x00000227 System.Single UnityEngine.UI.InputField::get_flexibleHeight()
extern void InputField_get_flexibleHeight_mE4CA2B68F90E91C6B884D87FF98D3CA062332A6D (void);
// 0x00000228 System.Int32 UnityEngine.UI.InputField::get_layoutPriority()
extern void InputField_get_layoutPriority_m88277B59E761DA55E6DF1AA803B0DC629ECDFE3C (void);
// 0x00000229 System.Void UnityEngine.UI.InputField::.cctor()
extern void InputField__cctor_m963ABF5968D8C97B8286CD633B0B0B4691ACEBBD (void);
// 0x0000022A UnityEngine.Transform UnityEngine.UI.InputField::UnityEngine.UI.ICanvasElement.get_transform()
extern void InputField_UnityEngine_UI_ICanvasElement_get_transform_m68143981855D6B92BF815F3058EA2F063A63D59A (void);
// 0x0000022B System.Void UnityEngine.UI.InputField/OnValidateInput::.ctor(System.Object,System.IntPtr)
extern void OnValidateInput__ctor_mDC0454BF264F87154EF8694821905B5A6A587A29 (void);
// 0x0000022C System.Char UnityEngine.UI.InputField/OnValidateInput::Invoke(System.String,System.Int32,System.Char)
extern void OnValidateInput_Invoke_m6A7776E0E91552E39F207A90C7E33A4D4479F076 (void);
// 0x0000022D System.IAsyncResult UnityEngine.UI.InputField/OnValidateInput::BeginInvoke(System.String,System.Int32,System.Char,System.AsyncCallback,System.Object)
extern void OnValidateInput_BeginInvoke_m2A003B257BC355C137B83FB37B3D9DD34821F9D2 (void);
// 0x0000022E System.Char UnityEngine.UI.InputField/OnValidateInput::EndInvoke(System.IAsyncResult)
extern void OnValidateInput_EndInvoke_mE13A5F2C1260AD59F20BFBD7CCC9BE42F84EF6DA (void);
// 0x0000022F System.Void UnityEngine.UI.InputField/SubmitEvent::.ctor()
extern void SubmitEvent__ctor_mE8908589516FD77AA786BDACC7BEBC2182A87EE3 (void);
// 0x00000230 System.Void UnityEngine.UI.InputField/EndEditEvent::.ctor()
extern void EndEditEvent__ctor_mEAA90FD69A3F6F34EF977AF11A424CEEFF441953 (void);
// 0x00000231 System.Void UnityEngine.UI.InputField/OnChangeEvent::.ctor()
extern void OnChangeEvent__ctor_m3D387EF9F415EC6E177649A23DAA137AB98F3E05 (void);
// 0x00000232 System.Void UnityEngine.UI.InputField/<CaretBlink>d__172::.ctor(System.Int32)
extern void U3CCaretBlinkU3Ed__172__ctor_mD71554D61758324CCBD8F37F5CE8249169AA88F6 (void);
// 0x00000233 System.Void UnityEngine.UI.InputField/<CaretBlink>d__172::System.IDisposable.Dispose()
extern void U3CCaretBlinkU3Ed__172_System_IDisposable_Dispose_m4B3174F229D803FBEC9FE749FE1A76E0A17A7AF1 (void);
// 0x00000234 System.Boolean UnityEngine.UI.InputField/<CaretBlink>d__172::MoveNext()
extern void U3CCaretBlinkU3Ed__172_MoveNext_m725171803230FB9AB7A1FD06EA915CE483335D82 (void);
// 0x00000235 System.Object UnityEngine.UI.InputField/<CaretBlink>d__172::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CCaretBlinkU3Ed__172_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m6F0710FF54BBA7F57D031169B56C02C9D0503926 (void);
// 0x00000236 System.Void UnityEngine.UI.InputField/<CaretBlink>d__172::System.Collections.IEnumerator.Reset()
extern void U3CCaretBlinkU3Ed__172_System_Collections_IEnumerator_Reset_m880C7F0BD8A9138228E0D9C61A53D0C7FF616BCA (void);
// 0x00000237 System.Object UnityEngine.UI.InputField/<CaretBlink>d__172::System.Collections.IEnumerator.get_Current()
extern void U3CCaretBlinkU3Ed__172_System_Collections_IEnumerator_get_Current_m047B5A2A48DE0ADB8ADA21A1B9C70A81F7ADD9CE (void);
// 0x00000238 System.Void UnityEngine.UI.InputField/<MouseDragOutsideRect>d__194::.ctor(System.Int32)
extern void U3CMouseDragOutsideRectU3Ed__194__ctor_m561BCE12F8D3972DD2E157255C57E2E7EF5A3EF5 (void);
// 0x00000239 System.Void UnityEngine.UI.InputField/<MouseDragOutsideRect>d__194::System.IDisposable.Dispose()
extern void U3CMouseDragOutsideRectU3Ed__194_System_IDisposable_Dispose_mB18C1AC7228F57FAFCEE8B7D6015C8AA079418F2 (void);
// 0x0000023A System.Boolean UnityEngine.UI.InputField/<MouseDragOutsideRect>d__194::MoveNext()
extern void U3CMouseDragOutsideRectU3Ed__194_MoveNext_mBDBD60F4DA7ED5CD50DE5ED93C6ACA320B3AC444 (void);
// 0x0000023B System.Object UnityEngine.UI.InputField/<MouseDragOutsideRect>d__194::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CMouseDragOutsideRectU3Ed__194_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m97FAB502D17418D00041C80355446F3790E2027C (void);
// 0x0000023C System.Void UnityEngine.UI.InputField/<MouseDragOutsideRect>d__194::System.Collections.IEnumerator.Reset()
extern void U3CMouseDragOutsideRectU3Ed__194_System_Collections_IEnumerator_Reset_mA0942EBCCC575616D5D28D9879334C5D68ECBD34 (void);
// 0x0000023D System.Object UnityEngine.UI.InputField/<MouseDragOutsideRect>d__194::System.Collections.IEnumerator.get_Current()
extern void U3CMouseDragOutsideRectU3Ed__194_System_Collections_IEnumerator_get_Current_mCB19D1EFAE7DE8A8B81DF1B0C6CF552ED9E40BD3 (void);
// 0x0000023E UnityEngine.UI.AspectRatioFitter/AspectMode UnityEngine.UI.AspectRatioFitter::get_aspectMode()
extern void AspectRatioFitter_get_aspectMode_m530AE9878F26D7C1166C2AC3C2B2547CED122B27 (void);
// 0x0000023F System.Void UnityEngine.UI.AspectRatioFitter::set_aspectMode(UnityEngine.UI.AspectRatioFitter/AspectMode)
extern void AspectRatioFitter_set_aspectMode_m1CDA777FF728BD01AB939C074D03F9C18675FB65 (void);
// 0x00000240 System.Single UnityEngine.UI.AspectRatioFitter::get_aspectRatio()
extern void AspectRatioFitter_get_aspectRatio_m72A1972D15B7435EF895562EEF0AE8C689ED120E (void);
// 0x00000241 System.Void UnityEngine.UI.AspectRatioFitter::set_aspectRatio(System.Single)
extern void AspectRatioFitter_set_aspectRatio_m4192E203648BE0ACA39D9C0540C982331CEA91D9 (void);
// 0x00000242 UnityEngine.RectTransform UnityEngine.UI.AspectRatioFitter::get_rectTransform()
extern void AspectRatioFitter_get_rectTransform_m20FD6C51C01C8BBC2C8223C255F9C28E00689496 (void);
// 0x00000243 System.Void UnityEngine.UI.AspectRatioFitter::.ctor()
extern void AspectRatioFitter__ctor_m277805022C03480F2EDA97E7AA48D33839EBD102 (void);
// 0x00000244 System.Void UnityEngine.UI.AspectRatioFitter::OnEnable()
extern void AspectRatioFitter_OnEnable_m5B6FCCB531F87ABBAEFEB38AEDA1340E10EDEFDD (void);
// 0x00000245 System.Void UnityEngine.UI.AspectRatioFitter::Start()
extern void AspectRatioFitter_Start_mB88F08EC9C3453EAB41607D91825BD90C6391F64 (void);
// 0x00000246 System.Void UnityEngine.UI.AspectRatioFitter::OnDisable()
extern void AspectRatioFitter_OnDisable_m43DAB6B9ADAE9683A99395FCD7B769879A75477F (void);
// 0x00000247 System.Void UnityEngine.UI.AspectRatioFitter::OnTransformParentChanged()
extern void AspectRatioFitter_OnTransformParentChanged_mD5F9B727921A4416EB663B4152CCB499EFB8B111 (void);
// 0x00000248 System.Void UnityEngine.UI.AspectRatioFitter::Update()
extern void AspectRatioFitter_Update_mE1F6FB785AB83C3416B67EEC58CDB74144583230 (void);
// 0x00000249 System.Void UnityEngine.UI.AspectRatioFitter::OnRectTransformDimensionsChange()
extern void AspectRatioFitter_OnRectTransformDimensionsChange_mE94570689C2A5CCB2C2EB33F9C5F240E780A2784 (void);
// 0x0000024A System.Void UnityEngine.UI.AspectRatioFitter::UpdateRect()
extern void AspectRatioFitter_UpdateRect_mFAB08DEB6F064E439934183C92038428ADA0F235 (void);
// 0x0000024B System.Single UnityEngine.UI.AspectRatioFitter::GetSizeDeltaToProduceSize(System.Single,System.Int32)
extern void AspectRatioFitter_GetSizeDeltaToProduceSize_m467FB832F233366AC4B795E932F05740E6429A4D (void);
// 0x0000024C UnityEngine.Vector2 UnityEngine.UI.AspectRatioFitter::GetParentSize()
extern void AspectRatioFitter_GetParentSize_mA3CFC47B4F43532BCA0267F99911DC2CA1FFE9B0 (void);
// 0x0000024D System.Void UnityEngine.UI.AspectRatioFitter::SetLayoutHorizontal()
extern void AspectRatioFitter_SetLayoutHorizontal_m49115A35A48158B48CD198028034214F95793FAE (void);
// 0x0000024E System.Void UnityEngine.UI.AspectRatioFitter::SetLayoutVertical()
extern void AspectRatioFitter_SetLayoutVertical_mAC5B9A89C0E8659BB590BD62608D22349B90D612 (void);
// 0x0000024F System.Void UnityEngine.UI.AspectRatioFitter::SetDirty()
extern void AspectRatioFitter_SetDirty_mCCB04E2ECBD43C874822C58BEEAC00AB7EA8A58A (void);
// 0x00000250 System.Boolean UnityEngine.UI.AspectRatioFitter::IsComponentValidOnObject()
extern void AspectRatioFitter_IsComponentValidOnObject_m163BC9DE4258B1C308B850BC259704A3D285A3B0 (void);
// 0x00000251 System.Boolean UnityEngine.UI.AspectRatioFitter::IsAspectModeValid()
extern void AspectRatioFitter_IsAspectModeValid_m0311FF067288EAD9D2A81ED3A4151C406F0A30B7 (void);
// 0x00000252 System.Boolean UnityEngine.UI.AspectRatioFitter::DoesParentExists()
extern void AspectRatioFitter_DoesParentExists_m9475339C8EE94000A65B9F39AFB08A867940D925 (void);
// 0x00000253 UnityEngine.UI.CanvasScaler/ScaleMode UnityEngine.UI.CanvasScaler::get_uiScaleMode()
extern void CanvasScaler_get_uiScaleMode_m8E92609E011796E8CC23B1739F95CE7BE2631525 (void);
// 0x00000254 System.Void UnityEngine.UI.CanvasScaler::set_uiScaleMode(UnityEngine.UI.CanvasScaler/ScaleMode)
extern void CanvasScaler_set_uiScaleMode_m064C83FFA35E2AED4E9FA7D5EC1AD19630D8FC2A (void);
// 0x00000255 System.Single UnityEngine.UI.CanvasScaler::get_referencePixelsPerUnit()
extern void CanvasScaler_get_referencePixelsPerUnit_mE0A7FECC27003A4A2BE6AE6E70747FAC8C19A008 (void);
// 0x00000256 System.Void UnityEngine.UI.CanvasScaler::set_referencePixelsPerUnit(System.Single)
extern void CanvasScaler_set_referencePixelsPerUnit_m8817BAEB73BE78DD7C87EAB7D2FE2983B2300628 (void);
// 0x00000257 System.Single UnityEngine.UI.CanvasScaler::get_scaleFactor()
extern void CanvasScaler_get_scaleFactor_mB2BFA22B99AEC96F09886F490DA9EE2F825D3431 (void);
// 0x00000258 System.Void UnityEngine.UI.CanvasScaler::set_scaleFactor(System.Single)
extern void CanvasScaler_set_scaleFactor_mD53E8CAE41E8C1B0DF53CCF14D5941FF8EA3488B (void);
// 0x00000259 UnityEngine.Vector2 UnityEngine.UI.CanvasScaler::get_referenceResolution()
extern void CanvasScaler_get_referenceResolution_m79C03DD8CE6759B045928C5339A3C5E6220276B5 (void);
// 0x0000025A System.Void UnityEngine.UI.CanvasScaler::set_referenceResolution(UnityEngine.Vector2)
extern void CanvasScaler_set_referenceResolution_m793679B8505AF9BBF64F45D80AFE39F3F99FAB8D (void);
// 0x0000025B UnityEngine.UI.CanvasScaler/ScreenMatchMode UnityEngine.UI.CanvasScaler::get_screenMatchMode()
extern void CanvasScaler_get_screenMatchMode_mA07ABCCF6AFE98C16651EBD5AB24BFF08B10F768 (void);
// 0x0000025C System.Void UnityEngine.UI.CanvasScaler::set_screenMatchMode(UnityEngine.UI.CanvasScaler/ScreenMatchMode)
extern void CanvasScaler_set_screenMatchMode_m926C437B408D2F2CA4900723BEEEE09504A6768F (void);
// 0x0000025D System.Single UnityEngine.UI.CanvasScaler::get_matchWidthOrHeight()
extern void CanvasScaler_get_matchWidthOrHeight_m9C40FBA943172874FD27F3F7B880E2D5D5862C9B (void);
// 0x0000025E System.Void UnityEngine.UI.CanvasScaler::set_matchWidthOrHeight(System.Single)
extern void CanvasScaler_set_matchWidthOrHeight_m44635DC3E4424255C312814C325A48E37E6B6E30 (void);
// 0x0000025F UnityEngine.UI.CanvasScaler/Unit UnityEngine.UI.CanvasScaler::get_physicalUnit()
extern void CanvasScaler_get_physicalUnit_mD4B04FD2D68F8C3CA39550C056A7AFC836DEB6EA (void);
// 0x00000260 System.Void UnityEngine.UI.CanvasScaler::set_physicalUnit(UnityEngine.UI.CanvasScaler/Unit)
extern void CanvasScaler_set_physicalUnit_m6A759A32FFBEBC43A51C98621A3F505289670C5C (void);
// 0x00000261 System.Single UnityEngine.UI.CanvasScaler::get_fallbackScreenDPI()
extern void CanvasScaler_get_fallbackScreenDPI_m966C603918C0420EAB4C3048591DE408190FFAA2 (void);
// 0x00000262 System.Void UnityEngine.UI.CanvasScaler::set_fallbackScreenDPI(System.Single)
extern void CanvasScaler_set_fallbackScreenDPI_m01E7CB32B519FBC9F5A77F060EE0B2DF7D6895AC (void);
// 0x00000263 System.Single UnityEngine.UI.CanvasScaler::get_defaultSpriteDPI()
extern void CanvasScaler_get_defaultSpriteDPI_m2F1CDF6DE4F2B2E3DED10D50D6E674699120C50A (void);
// 0x00000264 System.Void UnityEngine.UI.CanvasScaler::set_defaultSpriteDPI(System.Single)
extern void CanvasScaler_set_defaultSpriteDPI_m742DFE7A3315C0B33763D2E3FB2424BCFF35D3DE (void);
// 0x00000265 System.Single UnityEngine.UI.CanvasScaler::get_dynamicPixelsPerUnit()
extern void CanvasScaler_get_dynamicPixelsPerUnit_m6DFC581EFFD626F6815BA8C9579DD736514626AB (void);
// 0x00000266 System.Void UnityEngine.UI.CanvasScaler::set_dynamicPixelsPerUnit(System.Single)
extern void CanvasScaler_set_dynamicPixelsPerUnit_m7A081D5FD963F751140DCF1E5190ED4E51308CA2 (void);
// 0x00000267 System.Void UnityEngine.UI.CanvasScaler::.ctor()
extern void CanvasScaler__ctor_m0D60150B065E8CFBCB4BC324F364A0FF08762493 (void);
// 0x00000268 System.Void UnityEngine.UI.CanvasScaler::OnEnable()
extern void CanvasScaler_OnEnable_m9F50E6AF109CE6227FD9E523B0698925B89D29F8 (void);
// 0x00000269 System.Void UnityEngine.UI.CanvasScaler::Canvas_preWillRenderCanvases()
extern void CanvasScaler_Canvas_preWillRenderCanvases_mDBBF36EADD3DFBE62E1E5F14D0DC9BB86FC21E6A (void);
// 0x0000026A System.Void UnityEngine.UI.CanvasScaler::OnDisable()
extern void CanvasScaler_OnDisable_mE0CE97F651B806DD2B2565203A00E97A6A781B2E (void);
// 0x0000026B System.Void UnityEngine.UI.CanvasScaler::Handle()
extern void CanvasScaler_Handle_m0EF8A30C92B8A90A54D2B0BB06E7698E74AD5967 (void);
// 0x0000026C System.Void UnityEngine.UI.CanvasScaler::HandleWorldCanvas()
extern void CanvasScaler_HandleWorldCanvas_m3E325EB0AC3221EA44B3D81360DFE63C36C13190 (void);
// 0x0000026D System.Void UnityEngine.UI.CanvasScaler::HandleConstantPixelSize()
extern void CanvasScaler_HandleConstantPixelSize_m7C504A9281A98E3473F0113CD74A9305AE4C5CD0 (void);
// 0x0000026E System.Void UnityEngine.UI.CanvasScaler::HandleScaleWithScreenSize()
extern void CanvasScaler_HandleScaleWithScreenSize_m3F436166B074013EDBEE38B7009C338650CF942C (void);
// 0x0000026F System.Void UnityEngine.UI.CanvasScaler::HandleConstantPhysicalSize()
extern void CanvasScaler_HandleConstantPhysicalSize_m44CEBEFEE2AAD54993DA3A43047E86AE07B32DD7 (void);
// 0x00000270 System.Void UnityEngine.UI.CanvasScaler::SetScaleFactor(System.Single)
extern void CanvasScaler_SetScaleFactor_m195FFD8019696523653CA6CB1B8531ECE4020636 (void);
// 0x00000271 System.Void UnityEngine.UI.CanvasScaler::SetReferencePixelsPerUnit(System.Single)
extern void CanvasScaler_SetReferencePixelsPerUnit_m77B9E51B468EC9750355687AA6E25564D60BE9B5 (void);
// 0x00000272 UnityEngine.UI.ContentSizeFitter/FitMode UnityEngine.UI.ContentSizeFitter::get_horizontalFit()
extern void ContentSizeFitter_get_horizontalFit_mA5FBF6AB42F551272B94A7B89A372B1AA1ADBC0D (void);
// 0x00000273 System.Void UnityEngine.UI.ContentSizeFitter::set_horizontalFit(UnityEngine.UI.ContentSizeFitter/FitMode)
extern void ContentSizeFitter_set_horizontalFit_m7B0DB223B08B8D578F749DEC381349E7D66DCDE4 (void);
// 0x00000274 UnityEngine.UI.ContentSizeFitter/FitMode UnityEngine.UI.ContentSizeFitter::get_verticalFit()
extern void ContentSizeFitter_get_verticalFit_m3F2848F19A5F8F30F55E0B5D930EFEF4E5EFAFF5 (void);
// 0x00000275 System.Void UnityEngine.UI.ContentSizeFitter::set_verticalFit(UnityEngine.UI.ContentSizeFitter/FitMode)
extern void ContentSizeFitter_set_verticalFit_m8F61CFD01D4C3D3DC253F30BA8FC2F44F8F927CF (void);
// 0x00000276 UnityEngine.RectTransform UnityEngine.UI.ContentSizeFitter::get_rectTransform()
extern void ContentSizeFitter_get_rectTransform_m757AAC9852D5C462C083FDA80390813E4FF06467 (void);
// 0x00000277 System.Void UnityEngine.UI.ContentSizeFitter::.ctor()
extern void ContentSizeFitter__ctor_m60693679801693DCDEC5BF0FD45590BD66F2434A (void);
// 0x00000278 System.Void UnityEngine.UI.ContentSizeFitter::OnEnable()
extern void ContentSizeFitter_OnEnable_m31DA9C05A1B5FAB9BD1BE05C43192B427C156CD3 (void);
// 0x00000279 System.Void UnityEngine.UI.ContentSizeFitter::OnDisable()
extern void ContentSizeFitter_OnDisable_mA11B1667210796F7DEE199F2B78844A6CA0C720F (void);
// 0x0000027A System.Void UnityEngine.UI.ContentSizeFitter::OnRectTransformDimensionsChange()
extern void ContentSizeFitter_OnRectTransformDimensionsChange_m427809780F5D59796CDB386A8CD5B4DB985D7691 (void);
// 0x0000027B System.Void UnityEngine.UI.ContentSizeFitter::HandleSelfFittingAlongAxis(System.Int32)
extern void ContentSizeFitter_HandleSelfFittingAlongAxis_mA050224EA492DF6C8B339DC36FC3BB8ED5D09A85 (void);
// 0x0000027C System.Void UnityEngine.UI.ContentSizeFitter::SetLayoutHorizontal()
extern void ContentSizeFitter_SetLayoutHorizontal_m694E40D536D88366735B3838FA040EB2D2144320 (void);
// 0x0000027D System.Void UnityEngine.UI.ContentSizeFitter::SetLayoutVertical()
extern void ContentSizeFitter_SetLayoutVertical_mB58DDF80917329DFAE202DA73472AD39BF37E561 (void);
// 0x0000027E System.Void UnityEngine.UI.ContentSizeFitter::SetDirty()
extern void ContentSizeFitter_SetDirty_m5A4C67937A3C77E467881648D5B9D7AB4E8C5C59 (void);
// 0x0000027F UnityEngine.UI.GridLayoutGroup/Corner UnityEngine.UI.GridLayoutGroup::get_startCorner()
extern void GridLayoutGroup_get_startCorner_m0796B782C9F3981B6E97F83A6815102A5176657D (void);
// 0x00000280 System.Void UnityEngine.UI.GridLayoutGroup::set_startCorner(UnityEngine.UI.GridLayoutGroup/Corner)
extern void GridLayoutGroup_set_startCorner_mCE5A1E957B06BF34173119A5C62B832E279DA78A (void);
// 0x00000281 UnityEngine.UI.GridLayoutGroup/Axis UnityEngine.UI.GridLayoutGroup::get_startAxis()
extern void GridLayoutGroup_get_startAxis_mADFB75A761550B3141256B0130655A6703FF3FF5 (void);
// 0x00000282 System.Void UnityEngine.UI.GridLayoutGroup::set_startAxis(UnityEngine.UI.GridLayoutGroup/Axis)
extern void GridLayoutGroup_set_startAxis_m2C9BCD2A1CD3ECFDDF3B0A8B7EE28C48179A7739 (void);
// 0x00000283 UnityEngine.Vector2 UnityEngine.UI.GridLayoutGroup::get_cellSize()
extern void GridLayoutGroup_get_cellSize_m30D8A051F44C8EE0C87B6D6CDDC00C2592A78B6D (void);
// 0x00000284 System.Void UnityEngine.UI.GridLayoutGroup::set_cellSize(UnityEngine.Vector2)
extern void GridLayoutGroup_set_cellSize_m0A3FF07694BDBF52D973597978FC87B0941BE5F9 (void);
// 0x00000285 UnityEngine.Vector2 UnityEngine.UI.GridLayoutGroup::get_spacing()
extern void GridLayoutGroup_get_spacing_m19BC15652BF18D051B0998C14F13DB83191F3E58 (void);
// 0x00000286 System.Void UnityEngine.UI.GridLayoutGroup::set_spacing(UnityEngine.Vector2)
extern void GridLayoutGroup_set_spacing_mA5550A683F7B4A7A1510B267B5D4CACEB8981306 (void);
// 0x00000287 UnityEngine.UI.GridLayoutGroup/Constraint UnityEngine.UI.GridLayoutGroup::get_constraint()
extern void GridLayoutGroup_get_constraint_mAEC0A95B4DF9F48E07B5403CC5F954AFDE503029 (void);
// 0x00000288 System.Void UnityEngine.UI.GridLayoutGroup::set_constraint(UnityEngine.UI.GridLayoutGroup/Constraint)
extern void GridLayoutGroup_set_constraint_m632CB37D0D79A12DE81372EE819348CD1226B84A (void);
// 0x00000289 System.Int32 UnityEngine.UI.GridLayoutGroup::get_constraintCount()
extern void GridLayoutGroup_get_constraintCount_m63AE4B7889A27D8CAA8EB04A40B1FE53D80CC318 (void);
// 0x0000028A System.Void UnityEngine.UI.GridLayoutGroup::set_constraintCount(System.Int32)
extern void GridLayoutGroup_set_constraintCount_m685F6D5254B6D77AF8BE070EF3DCA5F049B3D043 (void);
// 0x0000028B System.Void UnityEngine.UI.GridLayoutGroup::.ctor()
extern void GridLayoutGroup__ctor_mBC2ADB7B7F092C83138425C82DEDBB6701F73F7D (void);
// 0x0000028C System.Void UnityEngine.UI.GridLayoutGroup::CalculateLayoutInputHorizontal()
extern void GridLayoutGroup_CalculateLayoutInputHorizontal_mFDEDFB79ECF5C03713EE1C128362D3AC0D48ED8E (void);
// 0x0000028D System.Void UnityEngine.UI.GridLayoutGroup::CalculateLayoutInputVertical()
extern void GridLayoutGroup_CalculateLayoutInputVertical_m41E33CD0EBF75155C0B842E9EDA2C66EB68AA9EA (void);
// 0x0000028E System.Void UnityEngine.UI.GridLayoutGroup::SetLayoutHorizontal()
extern void GridLayoutGroup_SetLayoutHorizontal_m16F35F3DA5B7AED47787C0EBEC723723DC9034F0 (void);
// 0x0000028F System.Void UnityEngine.UI.GridLayoutGroup::SetLayoutVertical()
extern void GridLayoutGroup_SetLayoutVertical_mAF83C49C8BBA29EC4465B1BC2A8A39B0321FB038 (void);
// 0x00000290 System.Void UnityEngine.UI.GridLayoutGroup::SetCellsAlongAxis(System.Int32)
extern void GridLayoutGroup_SetCellsAlongAxis_m815D9BF1B794A46C96CFE3E069C49274FCB66739 (void);
// 0x00000291 System.Void UnityEngine.UI.HorizontalLayoutGroup::.ctor()
extern void HorizontalLayoutGroup__ctor_m811D870AB5F67030CD9A3C1FC02FFE69298131BC (void);
// 0x00000292 System.Void UnityEngine.UI.HorizontalLayoutGroup::CalculateLayoutInputHorizontal()
extern void HorizontalLayoutGroup_CalculateLayoutInputHorizontal_mB2C54B2F51CB18A490867DE302D6444C93ADC537 (void);
// 0x00000293 System.Void UnityEngine.UI.HorizontalLayoutGroup::CalculateLayoutInputVertical()
extern void HorizontalLayoutGroup_CalculateLayoutInputVertical_m8739924AF17AA7FD9061BBDEBECFC3E2C946D27E (void);
// 0x00000294 System.Void UnityEngine.UI.HorizontalLayoutGroup::SetLayoutHorizontal()
extern void HorizontalLayoutGroup_SetLayoutHorizontal_mA4203F549D73128EB605594C74DA47CA07278A25 (void);
// 0x00000295 System.Void UnityEngine.UI.HorizontalLayoutGroup::SetLayoutVertical()
extern void HorizontalLayoutGroup_SetLayoutVertical_m6B8A658837C88E6A29A9850725734F9C5CA67B82 (void);
// 0x00000296 System.Single UnityEngine.UI.HorizontalOrVerticalLayoutGroup::get_spacing()
extern void HorizontalOrVerticalLayoutGroup_get_spacing_m916C9BF57D4AB0EF76E6BC4EC5E1EA54B7918782 (void);
// 0x00000297 System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::set_spacing(System.Single)
extern void HorizontalOrVerticalLayoutGroup_set_spacing_m90373F54D37DA8DFA90E102DC60EC33E542FD859 (void);
// 0x00000298 System.Boolean UnityEngine.UI.HorizontalOrVerticalLayoutGroup::get_childForceExpandWidth()
extern void HorizontalOrVerticalLayoutGroup_get_childForceExpandWidth_m07A6B6378938DA69E365DCFB2794EEE7D71CC510 (void);
// 0x00000299 System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::set_childForceExpandWidth(System.Boolean)
extern void HorizontalOrVerticalLayoutGroup_set_childForceExpandWidth_m351827AA1A453ACD17C2EAC7B4DAB9C5DB1760E5 (void);
// 0x0000029A System.Boolean UnityEngine.UI.HorizontalOrVerticalLayoutGroup::get_childForceExpandHeight()
extern void HorizontalOrVerticalLayoutGroup_get_childForceExpandHeight_mFCBB20057EDC1E7B2DFD56FB6ABFE9A462560741 (void);
// 0x0000029B System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::set_childForceExpandHeight(System.Boolean)
extern void HorizontalOrVerticalLayoutGroup_set_childForceExpandHeight_mA144CF421614F41813DE346AA9D1C64621C6C2E5 (void);
// 0x0000029C System.Boolean UnityEngine.UI.HorizontalOrVerticalLayoutGroup::get_childControlWidth()
extern void HorizontalOrVerticalLayoutGroup_get_childControlWidth_mBA38BDC393C180CFC30DA02478B493D6CCD92AB1 (void);
// 0x0000029D System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::set_childControlWidth(System.Boolean)
extern void HorizontalOrVerticalLayoutGroup_set_childControlWidth_m0B9A78B8284E17C438645684984796AC0E2D1BD8 (void);
// 0x0000029E System.Boolean UnityEngine.UI.HorizontalOrVerticalLayoutGroup::get_childControlHeight()
extern void HorizontalOrVerticalLayoutGroup_get_childControlHeight_m867F7E1D52F29ED8F9E5F060089800295E186AA4 (void);
// 0x0000029F System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::set_childControlHeight(System.Boolean)
extern void HorizontalOrVerticalLayoutGroup_set_childControlHeight_m8DD189C9B1F926641F4A2FD41F41F2097E4D7751 (void);
// 0x000002A0 System.Boolean UnityEngine.UI.HorizontalOrVerticalLayoutGroup::get_childScaleWidth()
extern void HorizontalOrVerticalLayoutGroup_get_childScaleWidth_mF5057406C963AB6CB70DC1B2B213A1F5F7C97E91 (void);
// 0x000002A1 System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::set_childScaleWidth(System.Boolean)
extern void HorizontalOrVerticalLayoutGroup_set_childScaleWidth_m96A12D7E1C6BCDD510EC08FC470FA5F69B90922D (void);
// 0x000002A2 System.Boolean UnityEngine.UI.HorizontalOrVerticalLayoutGroup::get_childScaleHeight()
extern void HorizontalOrVerticalLayoutGroup_get_childScaleHeight_mA5AD05DFD31E25C5C014C24B5B11DC5492A2E893 (void);
// 0x000002A3 System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::set_childScaleHeight(System.Boolean)
extern void HorizontalOrVerticalLayoutGroup_set_childScaleHeight_m519A990CF97DE1C974DD1F48466763E4AEC648BC (void);
// 0x000002A4 System.Boolean UnityEngine.UI.HorizontalOrVerticalLayoutGroup::get_reverseArrangement()
extern void HorizontalOrVerticalLayoutGroup_get_reverseArrangement_m245D8EC788EDA70DCB831FE62DAB8DB806BE7EA3 (void);
// 0x000002A5 System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::set_reverseArrangement(System.Boolean)
extern void HorizontalOrVerticalLayoutGroup_set_reverseArrangement_m2AF5AC83D6FE8AE364C626C0518B2ECCEE9C0477 (void);
// 0x000002A6 System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::CalcAlongAxis(System.Int32,System.Boolean)
extern void HorizontalOrVerticalLayoutGroup_CalcAlongAxis_m12CA995AB887ED06762B07E97953D456B316647A (void);
// 0x000002A7 System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::SetChildrenAlongAxis(System.Int32,System.Boolean)
extern void HorizontalOrVerticalLayoutGroup_SetChildrenAlongAxis_m4D7B06435A66102659B2372B48D49B2117D57F09 (void);
// 0x000002A8 System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::GetChildSizes(UnityEngine.RectTransform,System.Int32,System.Boolean,System.Boolean,System.Single&,System.Single&,System.Single&)
extern void HorizontalOrVerticalLayoutGroup_GetChildSizes_mE555CFCDBD0CD9913829BB56457F939A166BA383 (void);
// 0x000002A9 System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::.ctor()
extern void HorizontalOrVerticalLayoutGroup__ctor_m778C23DD9F3973AFACD3C6CCEDABF81902665D3F (void);
// 0x000002AA System.Void UnityEngine.UI.ILayoutElement::CalculateLayoutInputHorizontal()
// 0x000002AB System.Void UnityEngine.UI.ILayoutElement::CalculateLayoutInputVertical()
// 0x000002AC System.Single UnityEngine.UI.ILayoutElement::get_minWidth()
// 0x000002AD System.Single UnityEngine.UI.ILayoutElement::get_preferredWidth()
// 0x000002AE System.Single UnityEngine.UI.ILayoutElement::get_flexibleWidth()
// 0x000002AF System.Single UnityEngine.UI.ILayoutElement::get_minHeight()
// 0x000002B0 System.Single UnityEngine.UI.ILayoutElement::get_preferredHeight()
// 0x000002B1 System.Single UnityEngine.UI.ILayoutElement::get_flexibleHeight()
// 0x000002B2 System.Int32 UnityEngine.UI.ILayoutElement::get_layoutPriority()
// 0x000002B3 System.Void UnityEngine.UI.ILayoutController::SetLayoutHorizontal()
// 0x000002B4 System.Void UnityEngine.UI.ILayoutController::SetLayoutVertical()
// 0x000002B5 System.Boolean UnityEngine.UI.ILayoutIgnorer::get_ignoreLayout()
// 0x000002B6 System.Boolean UnityEngine.UI.LayoutElement::get_ignoreLayout()
extern void LayoutElement_get_ignoreLayout_m32A9F0BACBC8E6BAE46F35E570DF71E937924412 (void);
// 0x000002B7 System.Void UnityEngine.UI.LayoutElement::set_ignoreLayout(System.Boolean)
extern void LayoutElement_set_ignoreLayout_mF3D4AF6214FD719979E4BA6A120494E7226FF18C (void);
// 0x000002B8 System.Void UnityEngine.UI.LayoutElement::CalculateLayoutInputHorizontal()
extern void LayoutElement_CalculateLayoutInputHorizontal_mD6645A83B5E234C1EA5C764E48CAD4F3C135C4D7 (void);
// 0x000002B9 System.Void UnityEngine.UI.LayoutElement::CalculateLayoutInputVertical()
extern void LayoutElement_CalculateLayoutInputVertical_m1D25D380F32BD322135C80C41D407BD81C5D88F6 (void);
// 0x000002BA System.Single UnityEngine.UI.LayoutElement::get_minWidth()
extern void LayoutElement_get_minWidth_m6943ECF36A67019A485C4A7AFFC0BF7FD94480CE (void);
// 0x000002BB System.Void UnityEngine.UI.LayoutElement::set_minWidth(System.Single)
extern void LayoutElement_set_minWidth_mC140AB11DDA8F8FD299A5A7E3A9674FB21E827E4 (void);
// 0x000002BC System.Single UnityEngine.UI.LayoutElement::get_minHeight()
extern void LayoutElement_get_minHeight_mC1951830B9F43C57AC4A287E9AF3A62A0871E9C3 (void);
// 0x000002BD System.Void UnityEngine.UI.LayoutElement::set_minHeight(System.Single)
extern void LayoutElement_set_minHeight_m8B794B9E92B440D9B88FEACD95492DC5257D628F (void);
// 0x000002BE System.Single UnityEngine.UI.LayoutElement::get_preferredWidth()
extern void LayoutElement_get_preferredWidth_m214B11641CBD652E174F42133EF7CDC413CF6CE0 (void);
// 0x000002BF System.Void UnityEngine.UI.LayoutElement::set_preferredWidth(System.Single)
extern void LayoutElement_set_preferredWidth_m9D8F8097227D2EBAC03BB0E2E6B0E0A6C8887BA6 (void);
// 0x000002C0 System.Single UnityEngine.UI.LayoutElement::get_preferredHeight()
extern void LayoutElement_get_preferredHeight_mE630312564CC2A3E459C9C3E5FFDC2138D35EC88 (void);
// 0x000002C1 System.Void UnityEngine.UI.LayoutElement::set_preferredHeight(System.Single)
extern void LayoutElement_set_preferredHeight_m0F5874AD74B74F2A8F1CE86ED0477FEA9555433F (void);
// 0x000002C2 System.Single UnityEngine.UI.LayoutElement::get_flexibleWidth()
extern void LayoutElement_get_flexibleWidth_m2E51EA4DC58A4740702314E253FCA8816A1B98A8 (void);
// 0x000002C3 System.Void UnityEngine.UI.LayoutElement::set_flexibleWidth(System.Single)
extern void LayoutElement_set_flexibleWidth_m29E6E303E19AE180FD805D6E5481A00FC49E2983 (void);
// 0x000002C4 System.Single UnityEngine.UI.LayoutElement::get_flexibleHeight()
extern void LayoutElement_get_flexibleHeight_m8A7B16E85F304CAA03BF6417BE1D0F6C0212E2E4 (void);
// 0x000002C5 System.Void UnityEngine.UI.LayoutElement::set_flexibleHeight(System.Single)
extern void LayoutElement_set_flexibleHeight_m39C426C07583BE074F9B71DA9ECA1216860A43D2 (void);
// 0x000002C6 System.Int32 UnityEngine.UI.LayoutElement::get_layoutPriority()
extern void LayoutElement_get_layoutPriority_m20D5C7FC2019146C2FFD09CF1A3D908703763510 (void);
// 0x000002C7 System.Void UnityEngine.UI.LayoutElement::set_layoutPriority(System.Int32)
extern void LayoutElement_set_layoutPriority_m8EAEC716134A0536F1E96F8C3AB0980D5416E2BD (void);
// 0x000002C8 System.Void UnityEngine.UI.LayoutElement::.ctor()
extern void LayoutElement__ctor_m31C173AFE1B1749B6957B578C9463044BA22624A (void);
// 0x000002C9 System.Void UnityEngine.UI.LayoutElement::OnEnable()
extern void LayoutElement_OnEnable_mCD4984C5E35B4658AAB3224795209A92DAD65C6B (void);
// 0x000002CA System.Void UnityEngine.UI.LayoutElement::OnTransformParentChanged()
extern void LayoutElement_OnTransformParentChanged_m7495A830D24B032BBCE6FC2F540CDCE8B713C330 (void);
// 0x000002CB System.Void UnityEngine.UI.LayoutElement::OnDisable()
extern void LayoutElement_OnDisable_m5DBCC5762DB101EA70B19A24F8A41BCDE450AB87 (void);
// 0x000002CC System.Void UnityEngine.UI.LayoutElement::OnDidApplyAnimationProperties()
extern void LayoutElement_OnDidApplyAnimationProperties_m3D225CF42A2339702431CEB9F43DC769567E1535 (void);
// 0x000002CD System.Void UnityEngine.UI.LayoutElement::OnBeforeTransformParentChanged()
extern void LayoutElement_OnBeforeTransformParentChanged_mC3BA3EA166CF4AE74B9A00799DE1C2869A9261D6 (void);
// 0x000002CE System.Void UnityEngine.UI.LayoutElement::SetDirty()
extern void LayoutElement_SetDirty_m9ECC494A5A6C3764AAB0D3E2C61C6050FC517879 (void);
// 0x000002CF UnityEngine.RectOffset UnityEngine.UI.LayoutGroup::get_padding()
extern void LayoutGroup_get_padding_m91ABA3C588704717EDC82E72BA6D1B82711FE83C (void);
// 0x000002D0 System.Void UnityEngine.UI.LayoutGroup::set_padding(UnityEngine.RectOffset)
extern void LayoutGroup_set_padding_m9F415F3402E5E4AE684FD153493CE3E8D64D3EB7 (void);
// 0x000002D1 UnityEngine.TextAnchor UnityEngine.UI.LayoutGroup::get_childAlignment()
extern void LayoutGroup_get_childAlignment_m45C0D32DB91FD92852CA50278904034A26ADEFC1 (void);
// 0x000002D2 System.Void UnityEngine.UI.LayoutGroup::set_childAlignment(UnityEngine.TextAnchor)
extern void LayoutGroup_set_childAlignment_mA97DF1F2CF43C0CD1B83CFE7883626AA86ABB0AF (void);
// 0x000002D3 UnityEngine.RectTransform UnityEngine.UI.LayoutGroup::get_rectTransform()
extern void LayoutGroup_get_rectTransform_mE9AD2CFD78229C631BF21260FDB40C2D0D895974 (void);
// 0x000002D4 System.Collections.Generic.List`1<UnityEngine.RectTransform> UnityEngine.UI.LayoutGroup::get_rectChildren()
extern void LayoutGroup_get_rectChildren_mEB00A4F0B86326AA9BE3D5E5DD7E4C9E3A032391 (void);
// 0x000002D5 System.Void UnityEngine.UI.LayoutGroup::CalculateLayoutInputHorizontal()
extern void LayoutGroup_CalculateLayoutInputHorizontal_mAB313A3646FC94E9FA98E5C4EA19DBAA7F3754FD (void);
// 0x000002D6 System.Void UnityEngine.UI.LayoutGroup::CalculateLayoutInputVertical()
// 0x000002D7 System.Single UnityEngine.UI.LayoutGroup::get_minWidth()
extern void LayoutGroup_get_minWidth_m3EFD1527249470CC4F71588466BFB17D4A632229 (void);
// 0x000002D8 System.Single UnityEngine.UI.LayoutGroup::get_preferredWidth()
extern void LayoutGroup_get_preferredWidth_mDE70B887487494986C9A5621C9F19488154EE2CA (void);
// 0x000002D9 System.Single UnityEngine.UI.LayoutGroup::get_flexibleWidth()
extern void LayoutGroup_get_flexibleWidth_mB4DCC3B208370CF2A2FE276A56D011922BC08609 (void);
// 0x000002DA System.Single UnityEngine.UI.LayoutGroup::get_minHeight()
extern void LayoutGroup_get_minHeight_mE2FA1D3B4B40AAD5CD4493087C5B63C7BCAE9B3C (void);
// 0x000002DB System.Single UnityEngine.UI.LayoutGroup::get_preferredHeight()
extern void LayoutGroup_get_preferredHeight_m055B2270ECB1C9C0FCCCA396FD7E9F8EFBDBDBA8 (void);
// 0x000002DC System.Single UnityEngine.UI.LayoutGroup::get_flexibleHeight()
extern void LayoutGroup_get_flexibleHeight_m5F911708AAE2DDEF9ABF8EC7894F2B7A7264EB0A (void);
// 0x000002DD System.Int32 UnityEngine.UI.LayoutGroup::get_layoutPriority()
extern void LayoutGroup_get_layoutPriority_mC86CB36BF49A18F09F6577A9B298CB639F1FEC4A (void);
// 0x000002DE System.Void UnityEngine.UI.LayoutGroup::SetLayoutHorizontal()
// 0x000002DF System.Void UnityEngine.UI.LayoutGroup::SetLayoutVertical()
// 0x000002E0 System.Void UnityEngine.UI.LayoutGroup::.ctor()
extern void LayoutGroup__ctor_m3F10CB94B64D503325A8EE097A94261C08AA2337 (void);
// 0x000002E1 System.Void UnityEngine.UI.LayoutGroup::OnEnable()
extern void LayoutGroup_OnEnable_m49EF8F43626DCBD10EB37D7F95BDEF2817DECC72 (void);
// 0x000002E2 System.Void UnityEngine.UI.LayoutGroup::OnDisable()
extern void LayoutGroup_OnDisable_mC10A4F2B949F44688E26D0F1499BE39B0655DB42 (void);
// 0x000002E3 System.Void UnityEngine.UI.LayoutGroup::OnDidApplyAnimationProperties()
extern void LayoutGroup_OnDidApplyAnimationProperties_m7E426AAB3C937005BF074ABCF5A1C9FB2D67BB95 (void);
// 0x000002E4 System.Single UnityEngine.UI.LayoutGroup::GetTotalMinSize(System.Int32)
extern void LayoutGroup_GetTotalMinSize_mFBD1A44880D3390EFC7AF2441D556C9FAD49059A (void);
// 0x000002E5 System.Single UnityEngine.UI.LayoutGroup::GetTotalPreferredSize(System.Int32)
extern void LayoutGroup_GetTotalPreferredSize_mEFFC79C79FC70A3BDD06E46C6188827E0F7EABC3 (void);
// 0x000002E6 System.Single UnityEngine.UI.LayoutGroup::GetTotalFlexibleSize(System.Int32)
extern void LayoutGroup_GetTotalFlexibleSize_m0750BE35A8B466C0CB82460B0A490139B8BE1E2A (void);
// 0x000002E7 System.Single UnityEngine.UI.LayoutGroup::GetStartOffset(System.Int32,System.Single)
extern void LayoutGroup_GetStartOffset_m3748EE96F01312488AD6B764B01171AB2F5E309B (void);
// 0x000002E8 System.Single UnityEngine.UI.LayoutGroup::GetAlignmentOnAxis(System.Int32)
extern void LayoutGroup_GetAlignmentOnAxis_m14E9D80D22AFAE88909D806F5439BCB9EF194A45 (void);
// 0x000002E9 System.Void UnityEngine.UI.LayoutGroup::SetLayoutInputForAxis(System.Single,System.Single,System.Single,System.Int32)
extern void LayoutGroup_SetLayoutInputForAxis_m3704D7673470CF7CF1F2B145F226C9C30C25E660 (void);
// 0x000002EA System.Void UnityEngine.UI.LayoutGroup::SetChildAlongAxis(UnityEngine.RectTransform,System.Int32,System.Single)
extern void LayoutGroup_SetChildAlongAxis_m25F11D4F93E0D31E68F7227D74000FFB067A8FDC (void);
// 0x000002EB System.Void UnityEngine.UI.LayoutGroup::SetChildAlongAxisWithScale(UnityEngine.RectTransform,System.Int32,System.Single,System.Single)
extern void LayoutGroup_SetChildAlongAxisWithScale_mDCF850DCCD115F9B2ED8AC9D5D7EF8EA0B42EA94 (void);
// 0x000002EC System.Void UnityEngine.UI.LayoutGroup::SetChildAlongAxis(UnityEngine.RectTransform,System.Int32,System.Single,System.Single)
extern void LayoutGroup_SetChildAlongAxis_mBE88585F9D066C2997499871D934C0A4E9AE871F (void);
// 0x000002ED System.Void UnityEngine.UI.LayoutGroup::SetChildAlongAxisWithScale(UnityEngine.RectTransform,System.Int32,System.Single,System.Single,System.Single)
extern void LayoutGroup_SetChildAlongAxisWithScale_mC1910181779269C2656D954DE36F384D19F11C22 (void);
// 0x000002EE System.Boolean UnityEngine.UI.LayoutGroup::get_isRootLayoutGroup()
extern void LayoutGroup_get_isRootLayoutGroup_mFB0EC6A489F3847C38599F1187755B6E04301B04 (void);
// 0x000002EF System.Void UnityEngine.UI.LayoutGroup::OnRectTransformDimensionsChange()
extern void LayoutGroup_OnRectTransformDimensionsChange_m32A8C9D736F6096B93235870A9623D63C2CBCA74 (void);
// 0x000002F0 System.Void UnityEngine.UI.LayoutGroup::OnTransformChildrenChanged()
extern void LayoutGroup_OnTransformChildrenChanged_mF55AB48380641070CF0F92AC633357266D14A04A (void);
// 0x000002F1 System.Void UnityEngine.UI.LayoutGroup::SetProperty(T&,T)
// 0x000002F2 System.Void UnityEngine.UI.LayoutGroup::SetDirty()
extern void LayoutGroup_SetDirty_m32F20D8BB5C4B4DF350AF5F35A5917660FF9CE60 (void);
// 0x000002F3 System.Collections.IEnumerator UnityEngine.UI.LayoutGroup::DelayedSetDirty(UnityEngine.RectTransform)
extern void LayoutGroup_DelayedSetDirty_m67C0D880E25888F274BE8AE9D3F4C28EA4A22D0C (void);
// 0x000002F4 System.Void UnityEngine.UI.LayoutGroup/<DelayedSetDirty>d__56::.ctor(System.Int32)
extern void U3CDelayedSetDirtyU3Ed__56__ctor_mF6AE811754CADB1402BABF82639E38DB56C9AFCB (void);
// 0x000002F5 System.Void UnityEngine.UI.LayoutGroup/<DelayedSetDirty>d__56::System.IDisposable.Dispose()
extern void U3CDelayedSetDirtyU3Ed__56_System_IDisposable_Dispose_m347957DDD38BB5EFEE268E592550D258E5189F75 (void);
// 0x000002F6 System.Boolean UnityEngine.UI.LayoutGroup/<DelayedSetDirty>d__56::MoveNext()
extern void U3CDelayedSetDirtyU3Ed__56_MoveNext_mE69F0D45357F390412D5833F35A0C4B4F3E47420 (void);
// 0x000002F7 System.Object UnityEngine.UI.LayoutGroup/<DelayedSetDirty>d__56::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CDelayedSetDirtyU3Ed__56_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m581E5D52D9508F8B755213FC2BFFC15412352F79 (void);
// 0x000002F8 System.Void UnityEngine.UI.LayoutGroup/<DelayedSetDirty>d__56::System.Collections.IEnumerator.Reset()
extern void U3CDelayedSetDirtyU3Ed__56_System_Collections_IEnumerator_Reset_m7C5E44C5235E8C18D0066EF7464A6165F6D4B1C0 (void);
// 0x000002F9 System.Object UnityEngine.UI.LayoutGroup/<DelayedSetDirty>d__56::System.Collections.IEnumerator.get_Current()
extern void U3CDelayedSetDirtyU3Ed__56_System_Collections_IEnumerator_get_Current_m83BB521EA7AF720756B95AA6D637557DFCDCA2A3 (void);
// 0x000002FA System.Void UnityEngine.UI.LayoutRebuilder::Initialize(UnityEngine.RectTransform)
extern void LayoutRebuilder_Initialize_m3186A381CF387FC04A9D52BF6ED9982B0150E562 (void);
// 0x000002FB System.Void UnityEngine.UI.LayoutRebuilder::Clear()
extern void LayoutRebuilder_Clear_m2BCF887531F7BA60FB962F7153564A055A136AA1 (void);
// 0x000002FC System.Void UnityEngine.UI.LayoutRebuilder::.cctor()
extern void LayoutRebuilder__cctor_m5AE721B6C2738FA3FD23CF5103CEF96E6AEA578B (void);
// 0x000002FD System.Void UnityEngine.UI.LayoutRebuilder::ReapplyDrivenProperties(UnityEngine.RectTransform)
extern void LayoutRebuilder_ReapplyDrivenProperties_m2FAE70C6B03F93BDF9484BC4674FA80D956BE45F (void);
// 0x000002FE UnityEngine.Transform UnityEngine.UI.LayoutRebuilder::get_transform()
extern void LayoutRebuilder_get_transform_m885E49969AFEF977B384D517212E68ABFDDB6555 (void);
// 0x000002FF System.Boolean UnityEngine.UI.LayoutRebuilder::IsDestroyed()
extern void LayoutRebuilder_IsDestroyed_mEB8D2E6A0E61BD035965F28D30FB5BB41AAB2149 (void);
// 0x00000300 System.Void UnityEngine.UI.LayoutRebuilder::StripDisabledBehavioursFromList(System.Collections.Generic.List`1<UnityEngine.Component>)
extern void LayoutRebuilder_StripDisabledBehavioursFromList_mB6E476924D6DDDA8050F40300A58696303F0753A (void);
// 0x00000301 System.Void UnityEngine.UI.LayoutRebuilder::ForceRebuildLayoutImmediate(UnityEngine.RectTransform)
extern void LayoutRebuilder_ForceRebuildLayoutImmediate_mCCA094579654469919EFA4B5AA5D9AF93CD67B4A (void);
// 0x00000302 System.Void UnityEngine.UI.LayoutRebuilder::Rebuild(UnityEngine.UI.CanvasUpdate)
extern void LayoutRebuilder_Rebuild_mE0477A991681D208BF504CCAABFE01D7FCD8E137 (void);
// 0x00000303 System.Void UnityEngine.UI.LayoutRebuilder::PerformLayoutControl(UnityEngine.RectTransform,UnityEngine.Events.UnityAction`1<UnityEngine.Component>)
extern void LayoutRebuilder_PerformLayoutControl_mA6EB813FBAC300966A6357D248FAADD947C92D4B (void);
// 0x00000304 System.Void UnityEngine.UI.LayoutRebuilder::PerformLayoutCalculation(UnityEngine.RectTransform,UnityEngine.Events.UnityAction`1<UnityEngine.Component>)
extern void LayoutRebuilder_PerformLayoutCalculation_m0733192A11C335EEF72298A2321937CDA97A1C34 (void);
// 0x00000305 System.Void UnityEngine.UI.LayoutRebuilder::MarkLayoutForRebuild(UnityEngine.RectTransform)
extern void LayoutRebuilder_MarkLayoutForRebuild_m37F415D59609E9D18D49423D9C33E7EA6D859EBD (void);
// 0x00000306 System.Boolean UnityEngine.UI.LayoutRebuilder::ValidController(UnityEngine.RectTransform,System.Collections.Generic.List`1<UnityEngine.Component>)
extern void LayoutRebuilder_ValidController_m28AC31CE8158B1D2D9656A99ACE3F259F5212C70 (void);
// 0x00000307 System.Void UnityEngine.UI.LayoutRebuilder::MarkLayoutRootForRebuild(UnityEngine.RectTransform)
extern void LayoutRebuilder_MarkLayoutRootForRebuild_m72542D06667BE02C021D13ADC4C77094614552FF (void);
// 0x00000308 System.Void UnityEngine.UI.LayoutRebuilder::LayoutComplete()
extern void LayoutRebuilder_LayoutComplete_mB93ADFB170DD29029D271710D946FE0B08665380 (void);
// 0x00000309 System.Void UnityEngine.UI.LayoutRebuilder::GraphicUpdateComplete()
extern void LayoutRebuilder_GraphicUpdateComplete_m177178144B034919E062EB9C205AB65CB437BC6D (void);
// 0x0000030A System.Int32 UnityEngine.UI.LayoutRebuilder::GetHashCode()
extern void LayoutRebuilder_GetHashCode_m408B8FD9884FA8F7F967F1E8C7015055B8F780D3 (void);
// 0x0000030B System.Boolean UnityEngine.UI.LayoutRebuilder::Equals(System.Object)
extern void LayoutRebuilder_Equals_mD6E988174B451D9E832E3FC8B1EBBA0DD1FFB92E (void);
// 0x0000030C System.String UnityEngine.UI.LayoutRebuilder::ToString()
extern void LayoutRebuilder_ToString_m7F8066428103BE4A1E0A71F45B1D0E725E377A58 (void);
// 0x0000030D System.Void UnityEngine.UI.LayoutRebuilder::.ctor()
extern void LayoutRebuilder__ctor_m685B1B7449046E3467525550996AFB6A4565219E (void);
// 0x0000030E System.Void UnityEngine.UI.LayoutRebuilder/<>c::.cctor()
extern void U3CU3Ec__cctor_m0D6AD1DB52B49A72650F253F02B465D02C18BE04 (void);
// 0x0000030F System.Void UnityEngine.UI.LayoutRebuilder/<>c::.ctor()
extern void U3CU3Ec__ctor_mD28F0F8B5399F1C60A8E4575F9DCDC847D2CAA23 (void);
// 0x00000310 UnityEngine.UI.LayoutRebuilder UnityEngine.UI.LayoutRebuilder/<>c::<.cctor>b__5_0()
extern void U3CU3Ec_U3C_cctorU3Eb__5_0_mD2D37BAA0BED9121AC22FDFC48D7CA35BF400E14 (void);
// 0x00000311 System.Void UnityEngine.UI.LayoutRebuilder/<>c::<.cctor>b__5_1(UnityEngine.UI.LayoutRebuilder)
extern void U3CU3Ec_U3C_cctorU3Eb__5_1_mE8F9670037E944B0EB22487F1640407057B8A290 (void);
// 0x00000312 System.Boolean UnityEngine.UI.LayoutRebuilder/<>c::<StripDisabledBehavioursFromList>b__10_0(UnityEngine.Component)
extern void U3CU3Ec_U3CStripDisabledBehavioursFromListU3Eb__10_0_m03CF501571C52837064AFBD196238DB52B64BC5E (void);
// 0x00000313 System.Void UnityEngine.UI.LayoutRebuilder/<>c::<Rebuild>b__12_0(UnityEngine.Component)
extern void U3CU3Ec_U3CRebuildU3Eb__12_0_mDB44431ACB66295B4B09C0132E9EF267DB0090F1 (void);
// 0x00000314 System.Void UnityEngine.UI.LayoutRebuilder/<>c::<Rebuild>b__12_1(UnityEngine.Component)
extern void U3CU3Ec_U3CRebuildU3Eb__12_1_m08B6A90656111D084CCF7AF3B07D50C03B95BF9F (void);
// 0x00000315 System.Void UnityEngine.UI.LayoutRebuilder/<>c::<Rebuild>b__12_2(UnityEngine.Component)
extern void U3CU3Ec_U3CRebuildU3Eb__12_2_m516829AF584D4F446B08587F777088C704548C40 (void);
// 0x00000316 System.Void UnityEngine.UI.LayoutRebuilder/<>c::<Rebuild>b__12_3(UnityEngine.Component)
extern void U3CU3Ec_U3CRebuildU3Eb__12_3_mDEE0C1EB02D33044B945FF479F81E7A3DD85684B (void);
// 0x00000317 System.Single UnityEngine.UI.LayoutUtility::GetMinSize(UnityEngine.RectTransform,System.Int32)
extern void LayoutUtility_GetMinSize_mE0421687F579243D5252F065A737268EF736374C (void);
// 0x00000318 System.Single UnityEngine.UI.LayoutUtility::GetPreferredSize(UnityEngine.RectTransform,System.Int32)
extern void LayoutUtility_GetPreferredSize_mCAFD360B8490CD02AF5F99E93E09D8625BD85F52 (void);
// 0x00000319 System.Single UnityEngine.UI.LayoutUtility::GetFlexibleSize(UnityEngine.RectTransform,System.Int32)
extern void LayoutUtility_GetFlexibleSize_m2D6400EB342AE2E811DAFFF0CD2AA2F8AA5DD655 (void);
// 0x0000031A System.Single UnityEngine.UI.LayoutUtility::GetMinWidth(UnityEngine.RectTransform)
extern void LayoutUtility_GetMinWidth_m920875D5D911EF3FAC615C045D9178630697A0F3 (void);
// 0x0000031B System.Single UnityEngine.UI.LayoutUtility::GetPreferredWidth(UnityEngine.RectTransform)
extern void LayoutUtility_GetPreferredWidth_mFF51E72881BE14E8C59521A71188E458475D4052 (void);
// 0x0000031C System.Single UnityEngine.UI.LayoutUtility::GetFlexibleWidth(UnityEngine.RectTransform)
extern void LayoutUtility_GetFlexibleWidth_mFE4684C5AC223E1D8E4369AA3460461A3964D9BE (void);
// 0x0000031D System.Single UnityEngine.UI.LayoutUtility::GetMinHeight(UnityEngine.RectTransform)
extern void LayoutUtility_GetMinHeight_mB428914EB41682FC709CDBB27A0CB42D42EC4D9E (void);
// 0x0000031E System.Single UnityEngine.UI.LayoutUtility::GetPreferredHeight(UnityEngine.RectTransform)
extern void LayoutUtility_GetPreferredHeight_m3E8CDE02CC980080BBD4BBA1D6BFDFD42F7CF706 (void);
// 0x0000031F System.Single UnityEngine.UI.LayoutUtility::GetFlexibleHeight(UnityEngine.RectTransform)
extern void LayoutUtility_GetFlexibleHeight_m13C0A91CEB1B4DE827C4B9E5230D4AA73FFC23DC (void);
// 0x00000320 System.Single UnityEngine.UI.LayoutUtility::GetLayoutProperty(UnityEngine.RectTransform,System.Func`2<UnityEngine.UI.ILayoutElement,System.Single>,System.Single)
extern void LayoutUtility_GetLayoutProperty_m3A5BD03879B0B223BE78DDD6AB7595BDF14CF7A7 (void);
// 0x00000321 System.Single UnityEngine.UI.LayoutUtility::GetLayoutProperty(UnityEngine.RectTransform,System.Func`2<UnityEngine.UI.ILayoutElement,System.Single>,System.Single,UnityEngine.UI.ILayoutElement&)
extern void LayoutUtility_GetLayoutProperty_mEE37FED419E8D6C3B799296DC6712D312AA5261F (void);
// 0x00000322 System.Void UnityEngine.UI.LayoutUtility/<>c::.cctor()
extern void U3CU3Ec__cctor_m0CA720C96E971F17E2E861D8AFE6982FD1F59F44 (void);
// 0x00000323 System.Void UnityEngine.UI.LayoutUtility/<>c::.ctor()
extern void U3CU3Ec__ctor_m5E4858F8F2E57AAC48D706CFDE697DB16DE163D3 (void);
// 0x00000324 System.Single UnityEngine.UI.LayoutUtility/<>c::<GetMinWidth>b__3_0(UnityEngine.UI.ILayoutElement)
extern void U3CU3Ec_U3CGetMinWidthU3Eb__3_0_mB230985725E48B130593DCE9618576ABD38544E9 (void);
// 0x00000325 System.Single UnityEngine.UI.LayoutUtility/<>c::<GetPreferredWidth>b__4_0(UnityEngine.UI.ILayoutElement)
extern void U3CU3Ec_U3CGetPreferredWidthU3Eb__4_0_mB8A573FB7B4D32CBC78F6AF30C42FDD204D18862 (void);
// 0x00000326 System.Single UnityEngine.UI.LayoutUtility/<>c::<GetPreferredWidth>b__4_1(UnityEngine.UI.ILayoutElement)
extern void U3CU3Ec_U3CGetPreferredWidthU3Eb__4_1_m21A4B6CC6110B2FE507ECD670D1C701BC9E1C9F9 (void);
// 0x00000327 System.Single UnityEngine.UI.LayoutUtility/<>c::<GetFlexibleWidth>b__5_0(UnityEngine.UI.ILayoutElement)
extern void U3CU3Ec_U3CGetFlexibleWidthU3Eb__5_0_mDAFF6CD37904716095CE8E674BB7D2586ED17A95 (void);
// 0x00000328 System.Single UnityEngine.UI.LayoutUtility/<>c::<GetMinHeight>b__6_0(UnityEngine.UI.ILayoutElement)
extern void U3CU3Ec_U3CGetMinHeightU3Eb__6_0_m92D133D332D83DAECA59B06DD94CE6390C617162 (void);
// 0x00000329 System.Single UnityEngine.UI.LayoutUtility/<>c::<GetPreferredHeight>b__7_0(UnityEngine.UI.ILayoutElement)
extern void U3CU3Ec_U3CGetPreferredHeightU3Eb__7_0_m869A0C6EBD3699CA96970C944D80A94779D58FEA (void);
// 0x0000032A System.Single UnityEngine.UI.LayoutUtility/<>c::<GetPreferredHeight>b__7_1(UnityEngine.UI.ILayoutElement)
extern void U3CU3Ec_U3CGetPreferredHeightU3Eb__7_1_m6851C73E5D55417BF6A9A29D3DD22EA033D40EEB (void);
// 0x0000032B System.Single UnityEngine.UI.LayoutUtility/<>c::<GetFlexibleHeight>b__8_0(UnityEngine.UI.ILayoutElement)
extern void U3CU3Ec_U3CGetFlexibleHeightU3Eb__8_0_m55A0D46B9D7CD1002AE7F803E496E6F1A98F3E24 (void);
// 0x0000032C System.Void UnityEngine.UI.VerticalLayoutGroup::.ctor()
extern void VerticalLayoutGroup__ctor_m2EF3851AD1D83E3ADBB5053D1FAEF84A773E1D5B (void);
// 0x0000032D System.Void UnityEngine.UI.VerticalLayoutGroup::CalculateLayoutInputHorizontal()
extern void VerticalLayoutGroup_CalculateLayoutInputHorizontal_mF9483E90B39BDCE71C90F9B27CBF76F2A10E4D28 (void);
// 0x0000032E System.Void UnityEngine.UI.VerticalLayoutGroup::CalculateLayoutInputVertical()
extern void VerticalLayoutGroup_CalculateLayoutInputVertical_m360446A9D17C1B798BBB0B777EA1BEEE297807BA (void);
// 0x0000032F System.Void UnityEngine.UI.VerticalLayoutGroup::SetLayoutHorizontal()
extern void VerticalLayoutGroup_SetLayoutHorizontal_mD074FE8C9B3187AA23AF6578E8C81B23404D58B2 (void);
// 0x00000330 System.Void UnityEngine.UI.VerticalLayoutGroup::SetLayoutVertical()
extern void VerticalLayoutGroup_SetLayoutVertical_m27D87A8FEBBBD9226B95F250A076B3AB7BAA155F (void);
// 0x00000331 UnityEngine.RectTransform UnityEngine.UI.Mask::get_rectTransform()
extern void Mask_get_rectTransform_m4D1933DACBE7B0F93B1B83F1B3B0A09F65B24209 (void);
// 0x00000332 System.Boolean UnityEngine.UI.Mask::get_showMaskGraphic()
extern void Mask_get_showMaskGraphic_m87FD20C72F514AB305E05A5B104B180D9B35601B (void);
// 0x00000333 System.Void UnityEngine.UI.Mask::set_showMaskGraphic(System.Boolean)
extern void Mask_set_showMaskGraphic_m9F288D22259CFD781D5A4D9B9747C2A2895E7D67 (void);
// 0x00000334 UnityEngine.UI.Graphic UnityEngine.UI.Mask::get_graphic()
extern void Mask_get_graphic_mDC288968F569C492F1E18F82229ECB7AA3804AD2 (void);
// 0x00000335 System.Void UnityEngine.UI.Mask::.ctor()
extern void Mask__ctor_mB4AF8A6FD9496A1E8EEB7631D43F8A0548134DB9 (void);
// 0x00000336 System.Boolean UnityEngine.UI.Mask::MaskEnabled()
extern void Mask_MaskEnabled_m330C9AE8B8A642ECF3C4E88687E9F297969B6351 (void);
// 0x00000337 System.Void UnityEngine.UI.Mask::OnSiblingGraphicEnabledDisabled()
extern void Mask_OnSiblingGraphicEnabledDisabled_m38D50E90213834C6E06D449F364C7A802964FC74 (void);
// 0x00000338 System.Void UnityEngine.UI.Mask::OnEnable()
extern void Mask_OnEnable_m928342074FD21B3A58E1370F681DC762BD64B095 (void);
// 0x00000339 System.Void UnityEngine.UI.Mask::OnDisable()
extern void Mask_OnDisable_m7B533EC440BB28CB80AB8AE914BFA501FAB3ADA5 (void);
// 0x0000033A System.Boolean UnityEngine.UI.Mask::IsRaycastLocationValid(UnityEngine.Vector2,UnityEngine.Camera)
extern void Mask_IsRaycastLocationValid_mE12C460DF4AF0C65082DBBA6F46A2259687A2534 (void);
// 0x0000033B UnityEngine.Material UnityEngine.UI.Mask::GetModifiedMaterial(UnityEngine.Material)
extern void Mask_GetModifiedMaterial_m5D7DE1884428D7EBC6A7AA6376650E4FB966B1F4 (void);
// 0x0000033C UnityEngine.UI.MaskableGraphic/CullStateChangedEvent UnityEngine.UI.MaskableGraphic::get_onCullStateChanged()
extern void MaskableGraphic_get_onCullStateChanged_m8452945E93AF20B975D85E61999B51039CAF6538 (void);
// 0x0000033D System.Void UnityEngine.UI.MaskableGraphic::set_onCullStateChanged(UnityEngine.UI.MaskableGraphic/CullStateChangedEvent)
extern void MaskableGraphic_set_onCullStateChanged_m4284F81D75D8F8293FE2FB5FC236FDF63579BBF7 (void);
// 0x0000033E System.Boolean UnityEngine.UI.MaskableGraphic::get_maskable()
extern void MaskableGraphic_get_maskable_m34B87CD87CFF73FF4E09D892ADB316E412F22660 (void);
// 0x0000033F System.Void UnityEngine.UI.MaskableGraphic::set_maskable(System.Boolean)
extern void MaskableGraphic_set_maskable_mC2486FDC0636C83AC3BDBFF11E6E85CC27F15689 (void);
// 0x00000340 System.Boolean UnityEngine.UI.MaskableGraphic::get_isMaskingGraphic()
extern void MaskableGraphic_get_isMaskingGraphic_m8C4270841AF6071FD5AC4EB7225AF259053DF55E (void);
// 0x00000341 System.Void UnityEngine.UI.MaskableGraphic::set_isMaskingGraphic(System.Boolean)
extern void MaskableGraphic_set_isMaskingGraphic_m350EDFCF390CF594B939BBEE3A0D634F2EA48A78 (void);
// 0x00000342 UnityEngine.Material UnityEngine.UI.MaskableGraphic::GetModifiedMaterial(UnityEngine.Material)
extern void MaskableGraphic_GetModifiedMaterial_mBE4C5B18ED4221E0A6C026C750B6A04E9B35312A (void);
// 0x00000343 System.Void UnityEngine.UI.MaskableGraphic::Cull(UnityEngine.Rect,System.Boolean)
extern void MaskableGraphic_Cull_mF6948476960E33BD174FD3723101650E3C344CC7 (void);
// 0x00000344 System.Void UnityEngine.UI.MaskableGraphic::UpdateCull(System.Boolean)
extern void MaskableGraphic_UpdateCull_mAC0798E6376F7B103BB36929AC4DD69729E30E86 (void);
// 0x00000345 System.Void UnityEngine.UI.MaskableGraphic::SetClipRect(UnityEngine.Rect,System.Boolean)
extern void MaskableGraphic_SetClipRect_m19317C49A4CC99A991A3F0135756DB94020930C2 (void);
// 0x00000346 System.Void UnityEngine.UI.MaskableGraphic::SetClipSoftness(UnityEngine.Vector2)
extern void MaskableGraphic_SetClipSoftness_mF11957AB91E1BA19B6008ACEF95C5F9AD930CAE4 (void);
// 0x00000347 System.Void UnityEngine.UI.MaskableGraphic::OnEnable()
extern void MaskableGraphic_OnEnable_m4BF46ECE5E57E2EE11ED4CE41AD50DADF141C9BC (void);
// 0x00000348 System.Void UnityEngine.UI.MaskableGraphic::OnDisable()
extern void MaskableGraphic_OnDisable_m9123E729FA7BE001037CDE14E8A75B69AD68E16C (void);
// 0x00000349 System.Void UnityEngine.UI.MaskableGraphic::OnTransformParentChanged()
extern void MaskableGraphic_OnTransformParentChanged_mE5ABE137F670FBA7E6FCD2A67616E4A8097AD876 (void);
// 0x0000034A System.Void UnityEngine.UI.MaskableGraphic::ParentMaskStateChanged()
extern void MaskableGraphic_ParentMaskStateChanged_m1353B87D25271925B6ED342FDC06B05F7EAD3992 (void);
// 0x0000034B System.Void UnityEngine.UI.MaskableGraphic::OnCanvasHierarchyChanged()
extern void MaskableGraphic_OnCanvasHierarchyChanged_mB30092A7276A921F711E466E9CE85C04ED982E77 (void);
// 0x0000034C UnityEngine.Rect UnityEngine.UI.MaskableGraphic::get_rootCanvasRect()
extern void MaskableGraphic_get_rootCanvasRect_mB7F5E772A53CBCCF920CD924E84634CD8155F6D8 (void);
// 0x0000034D System.Void UnityEngine.UI.MaskableGraphic::UpdateClipParent()
extern void MaskableGraphic_UpdateClipParent_mEFEEC27574B12503C1D8B694BA61C7166828F6A2 (void);
// 0x0000034E System.Void UnityEngine.UI.MaskableGraphic::RecalculateClipping()
extern void MaskableGraphic_RecalculateClipping_mFDD980F0A3AC1BEFF0BC9EDE95EF063AA9C282F7 (void);
// 0x0000034F System.Void UnityEngine.UI.MaskableGraphic::RecalculateMasking()
extern void MaskableGraphic_RecalculateMasking_m76F4A84B87AD4938F8A68B022A5A2BB4B5F343AF (void);
// 0x00000350 System.Void UnityEngine.UI.MaskableGraphic::.ctor()
extern void MaskableGraphic__ctor_mD2E256F950AAAE0E2445971361B5C54D2066E4C2 (void);
// 0x00000351 UnityEngine.GameObject UnityEngine.UI.MaskableGraphic::UnityEngine.UI.IClippable.get_gameObject()
extern void MaskableGraphic_UnityEngine_UI_IClippable_get_gameObject_m17FD7D774DA4D9D0F2E23240D9E17FF5C7DC4A44 (void);
// 0x00000352 System.Void UnityEngine.UI.MaskableGraphic/CullStateChangedEvent::.ctor()
extern void CullStateChangedEvent__ctor_m885AD59B4D0D6075AB6DFA71AD69A7BB48640CE4 (void);
// 0x00000353 System.Void UnityEngine.UI.MaskUtilities::Notify2DMaskStateChanged(UnityEngine.Component)
extern void MaskUtilities_Notify2DMaskStateChanged_mBD5C9FCE2AC1327C599BF0D7390BFD86FAE06937 (void);
// 0x00000354 System.Void UnityEngine.UI.MaskUtilities::NotifyStencilStateChanged(UnityEngine.Component)
extern void MaskUtilities_NotifyStencilStateChanged_m112CACEF914385BC2F96F4D66D4038AF1E0FCD6B (void);
// 0x00000355 UnityEngine.Transform UnityEngine.UI.MaskUtilities::FindRootSortOverrideCanvas(UnityEngine.Transform)
extern void MaskUtilities_FindRootSortOverrideCanvas_mCB7DABA799F6C5BDF659D4CA60BA2FE8141A65AA (void);
// 0x00000356 System.Int32 UnityEngine.UI.MaskUtilities::GetStencilDepth(UnityEngine.Transform,UnityEngine.Transform)
extern void MaskUtilities_GetStencilDepth_m782D2795F76F569F4FB261C5BFB6D9EF241C0EE9 (void);
// 0x00000357 System.Boolean UnityEngine.UI.MaskUtilities::IsDescendantOrSelf(UnityEngine.Transform,UnityEngine.Transform)
extern void MaskUtilities_IsDescendantOrSelf_mBCC8B1428F599BAF1EAFA16E9586639A11B87C23 (void);
// 0x00000358 UnityEngine.UI.RectMask2D UnityEngine.UI.MaskUtilities::GetRectMaskForClippable(UnityEngine.UI.IClippable)
extern void MaskUtilities_GetRectMaskForClippable_m7AEB8F89DFD994A487EED33DDD8C59E5A784245C (void);
// 0x00000359 System.Void UnityEngine.UI.MaskUtilities::GetRectMasksForClip(UnityEngine.UI.RectMask2D,System.Collections.Generic.List`1<UnityEngine.UI.RectMask2D>)
extern void MaskUtilities_GetRectMasksForClip_mDEC4D04BA24F5C4C5828A4E8A677BE4F3CC6FAAF (void);
// 0x0000035A System.Void UnityEngine.UI.MaskUtilities::.ctor()
extern void MaskUtilities__ctor_m32B6A8721369418CAA95A8EF5D65E0B8CD89DA82 (void);
// 0x0000035B UnityEngine.Material UnityEngine.UI.IMaterialModifier::GetModifiedMaterial(UnityEngine.Material)
// 0x0000035C System.Void UnityEngine.UI.Misc::Destroy(UnityEngine.Object)
extern void Misc_Destroy_mA812AD936D10BCABA81E04C6C4C190034995214F (void);
// 0x0000035D System.Void UnityEngine.UI.Misc::DestroyImmediate(UnityEngine.Object)
extern void Misc_DestroyImmediate_m7E53D180A6459C9577D115A345D59C26FC05F919 (void);
// 0x0000035E System.Boolean UnityEngine.UI.MultipleDisplayUtilities::GetRelativeMousePositionForDrag(UnityEngine.EventSystems.PointerEventData,UnityEngine.Vector2&)
extern void MultipleDisplayUtilities_GetRelativeMousePositionForDrag_m3C283E331437CB72CF86C5C98B9E61D2317B8F4A (void);
// 0x0000035F UnityEngine.Vector3 UnityEngine.UI.MultipleDisplayUtilities::RelativeMouseAtScaled(UnityEngine.Vector2)
extern void MultipleDisplayUtilities_RelativeMouseAtScaled_mE3B0EE3E697B4316CE8588D05F3A75E47A75A855 (void);
// 0x00000360 UnityEngine.UI.Navigation/Mode UnityEngine.UI.Navigation::get_mode()
extern void Navigation_get_mode_m3B574F1549B3806753EC33228EB3FF3031F4E809 (void);
// 0x00000361 System.Void UnityEngine.UI.Navigation::set_mode(UnityEngine.UI.Navigation/Mode)
extern void Navigation_set_mode_m0BEF999F733332AD994CF3CA4AC17B2A47531207 (void);
// 0x00000362 System.Boolean UnityEngine.UI.Navigation::get_wrapAround()
extern void Navigation_get_wrapAround_mA24021791B1C67F665065B5A415434837CEA86DD (void);
// 0x00000363 System.Void UnityEngine.UI.Navigation::set_wrapAround(System.Boolean)
extern void Navigation_set_wrapAround_m9D808EC49EE5F3AFA7F0D13E86FF9F72AA20A081 (void);
// 0x00000364 UnityEngine.UI.Selectable UnityEngine.UI.Navigation::get_selectOnUp()
extern void Navigation_get_selectOnUp_mD24FC0BAB97E5DBB28C9C7209BAC2ACC9419B183 (void);
// 0x00000365 System.Void UnityEngine.UI.Navigation::set_selectOnUp(UnityEngine.UI.Selectable)
extern void Navigation_set_selectOnUp_mCB04000FDFC05D3BAC497602E4BA346A536152E5 (void);
// 0x00000366 UnityEngine.UI.Selectable UnityEngine.UI.Navigation::get_selectOnDown()
extern void Navigation_get_selectOnDown_m1D36E990CDB38C4BB78745587668F94BBE8A1285 (void);
// 0x00000367 System.Void UnityEngine.UI.Navigation::set_selectOnDown(UnityEngine.UI.Selectable)
extern void Navigation_set_selectOnDown_m0EBBAB8C51107F75F63FFBC3DF88D9010E6A44BB (void);
// 0x00000368 UnityEngine.UI.Selectable UnityEngine.UI.Navigation::get_selectOnLeft()
extern void Navigation_get_selectOnLeft_mA4F7DA341D7C660A7E15520B34847B0757C65F81 (void);
// 0x00000369 System.Void UnityEngine.UI.Navigation::set_selectOnLeft(UnityEngine.UI.Selectable)
extern void Navigation_set_selectOnLeft_mA4E7480D7CBDA9A5ECA93BAFCD1CF1976A994FCB (void);
// 0x0000036A UnityEngine.UI.Selectable UnityEngine.UI.Navigation::get_selectOnRight()
extern void Navigation_get_selectOnRight_m7A781F4050AE064DC0473E68AA6D07CFFF0A8FF9 (void);
// 0x0000036B System.Void UnityEngine.UI.Navigation::set_selectOnRight(UnityEngine.UI.Selectable)
extern void Navigation_set_selectOnRight_mD0B38024BB628CDC801EA93E9FF7C438ECE2055B (void);
// 0x0000036C UnityEngine.UI.Navigation UnityEngine.UI.Navigation::get_defaultNavigation()
extern void Navigation_get_defaultNavigation_m142FA3A8F52EE3DD355FFE30061771FB9A86671E (void);
// 0x0000036D System.Boolean UnityEngine.UI.Navigation::Equals(UnityEngine.UI.Navigation)
extern void Navigation_Equals_mE25B4E3D0AB85C1469B99971E6AB16E2039E6B4D (void);
// 0x0000036E System.Void UnityEngine.UI.RawImage::.ctor()
extern void RawImage__ctor_mB9515043B2286A9012B98913D023EA0ACEF57401 (void);
// 0x0000036F UnityEngine.Texture UnityEngine.UI.RawImage::get_mainTexture()
extern void RawImage_get_mainTexture_mDA4701244E31799D8897FBB6E0A1FA41EF5B81E9 (void);
// 0x00000370 UnityEngine.Texture UnityEngine.UI.RawImage::get_texture()
extern void RawImage_get_texture_m84CCFDF78F6886F73EBE5A7C78D6E9C3CA903813 (void);
// 0x00000371 System.Void UnityEngine.UI.RawImage::set_texture(UnityEngine.Texture)
extern void RawImage_set_texture_mC016318C95CC17A826D57DD219DBCB6DFD295C02 (void);
// 0x00000372 UnityEngine.Rect UnityEngine.UI.RawImage::get_uvRect()
extern void RawImage_get_uvRect_m83D2C4632C6AE437D1DC775904AC2FA8CB83D823 (void);
// 0x00000373 System.Void UnityEngine.UI.RawImage::set_uvRect(UnityEngine.Rect)
extern void RawImage_set_uvRect_m9DF6BBBC6AC46F7F3290A220ED6F076CAB4BC52F (void);
// 0x00000374 System.Void UnityEngine.UI.RawImage::SetNativeSize()
extern void RawImage_SetNativeSize_m02ACAE096422EE2D5E17FCF89CC7BBB74A64FD6A (void);
// 0x00000375 System.Void UnityEngine.UI.RawImage::OnPopulateMesh(UnityEngine.UI.VertexHelper)
extern void RawImage_OnPopulateMesh_mA85FE8B6123F6B3D013E8DEFB9DE3CAAF0C08F6D (void);
// 0x00000376 System.Void UnityEngine.UI.RawImage::OnDidApplyAnimationProperties()
extern void RawImage_OnDidApplyAnimationProperties_m571F0CB106D9060554503E87FCA700A6B6C997A6 (void);
// 0x00000377 UnityEngine.Vector4 UnityEngine.UI.RectMask2D::get_padding()
extern void RectMask2D_get_padding_m37CA7BF6DA7386AB4D9A6449CAC48ED6BC4B7777 (void);
// 0x00000378 System.Void UnityEngine.UI.RectMask2D::set_padding(UnityEngine.Vector4)
extern void RectMask2D_set_padding_m2E8CADD2DC7A40E78586118453CFE2D8795C997A (void);
// 0x00000379 UnityEngine.Vector2Int UnityEngine.UI.RectMask2D::get_softness()
extern void RectMask2D_get_softness_m2638D596B2600278FF2D3225B14038624DA19E34 (void);
// 0x0000037A System.Void UnityEngine.UI.RectMask2D::set_softness(UnityEngine.Vector2Int)
extern void RectMask2D_set_softness_m2857F567959455CA644277BC644A2EE0984089D4 (void);
// 0x0000037B UnityEngine.Canvas UnityEngine.UI.RectMask2D::get_Canvas()
extern void RectMask2D_get_Canvas_m689A6760F58FD683B7A5EA6A92691AAA521D4634 (void);
// 0x0000037C UnityEngine.Rect UnityEngine.UI.RectMask2D::get_canvasRect()
extern void RectMask2D_get_canvasRect_m81DEFAC3250A9F3FE4B97981335E406B43CFF4F4 (void);
// 0x0000037D UnityEngine.RectTransform UnityEngine.UI.RectMask2D::get_rectTransform()
extern void RectMask2D_get_rectTransform_m6EF34408BB7A5763A590F36D65DE7974E6C996DD (void);
// 0x0000037E System.Void UnityEngine.UI.RectMask2D::.ctor()
extern void RectMask2D__ctor_mC7257CF022267C2E98E8F04CFC28CA37CF8C64FD (void);
// 0x0000037F System.Void UnityEngine.UI.RectMask2D::OnEnable()
extern void RectMask2D_OnEnable_m2C52D2F840A9E7462488AB028C21803D3BE14A51 (void);
// 0x00000380 System.Void UnityEngine.UI.RectMask2D::OnDisable()
extern void RectMask2D_OnDisable_m2CF7F93D68B6ADC28322024E7A9AD4102832F4CC (void);
// 0x00000381 System.Void UnityEngine.UI.RectMask2D::OnDestroy()
extern void RectMask2D_OnDestroy_m950120AD49BDAFF20E783C22AF863741897015BF (void);
// 0x00000382 System.Boolean UnityEngine.UI.RectMask2D::IsRaycastLocationValid(UnityEngine.Vector2,UnityEngine.Camera)
extern void RectMask2D_IsRaycastLocationValid_m9ADA1029D511D9A62CFC1B576F396EDD0A31E4FF (void);
// 0x00000383 UnityEngine.Rect UnityEngine.UI.RectMask2D::get_rootCanvasRect()
extern void RectMask2D_get_rootCanvasRect_mC644AE792D28558B8260E23A87C8E6645D33224A (void);
// 0x00000384 System.Void UnityEngine.UI.RectMask2D::PerformClipping()
extern void RectMask2D_PerformClipping_mD89C9AEAC139EA7AFBB189608D02ABB87F3D7AB0 (void);
// 0x00000385 System.Void UnityEngine.UI.RectMask2D::UpdateClipSoftness()
extern void RectMask2D_UpdateClipSoftness_m84A9BCB92DEB1654703D0084C5A3F0BCD2E1BFF2 (void);
// 0x00000386 System.Void UnityEngine.UI.RectMask2D::AddClippable(UnityEngine.UI.IClippable)
extern void RectMask2D_AddClippable_m90A9698CD91A2A08EBE86AB60B05E76AFA38EAA4 (void);
// 0x00000387 System.Void UnityEngine.UI.RectMask2D::RemoveClippable(UnityEngine.UI.IClippable)
extern void RectMask2D_RemoveClippable_m2247DBCAD9B09980191AB791A7CB83FF9C355C2D (void);
// 0x00000388 System.Void UnityEngine.UI.RectMask2D::OnTransformParentChanged()
extern void RectMask2D_OnTransformParentChanged_m593E595A4C1293CEFB17764B55C96E2EC41E4648 (void);
// 0x00000389 System.Void UnityEngine.UI.RectMask2D::OnCanvasHierarchyChanged()
extern void RectMask2D_OnCanvasHierarchyChanged_m232F0056ED310EAB18C3BA314A666ABF13B4353B (void);
// 0x0000038A UnityEngine.RectTransform UnityEngine.UI.Scrollbar::get_handleRect()
extern void Scrollbar_get_handleRect_mEC95A981B744C4DB961D8B5DF6D2B81132CBB238 (void);
// 0x0000038B System.Void UnityEngine.UI.Scrollbar::set_handleRect(UnityEngine.RectTransform)
extern void Scrollbar_set_handleRect_m2B621325A0EEA1EDCB71402FCBC7DBEB9C2BD4B0 (void);
// 0x0000038C UnityEngine.UI.Scrollbar/Direction UnityEngine.UI.Scrollbar::get_direction()
extern void Scrollbar_get_direction_m1950D7EE42DDD0E3DBEABCDD59DD7E0FEC164C4C (void);
// 0x0000038D System.Void UnityEngine.UI.Scrollbar::set_direction(UnityEngine.UI.Scrollbar/Direction)
extern void Scrollbar_set_direction_m1C307CE73857CD7D3FBB160FE66875CA6BA6A3C6 (void);
// 0x0000038E System.Void UnityEngine.UI.Scrollbar::.ctor()
extern void Scrollbar__ctor_m65C96C26AB7CBC074ACDC19557E1982155CA30A4 (void);
// 0x0000038F System.Single UnityEngine.UI.Scrollbar::get_value()
extern void Scrollbar_get_value_mC2F43475C89766DA596FFAA019CA59F94CC89A35 (void);
// 0x00000390 System.Void UnityEngine.UI.Scrollbar::set_value(System.Single)
extern void Scrollbar_set_value_m8F7815DB02D4A69B33B091FC5F674609F070D804 (void);
// 0x00000391 System.Void UnityEngine.UI.Scrollbar::SetValueWithoutNotify(System.Single)
extern void Scrollbar_SetValueWithoutNotify_m6E2A4BE4DA16EBA596D2E6E40E4AC2DAC8B6C162 (void);
// 0x00000392 System.Single UnityEngine.UI.Scrollbar::get_size()
extern void Scrollbar_get_size_mD88FDA836274F40EC8A97237C72B7E3C4906DB5F (void);
// 0x00000393 System.Void UnityEngine.UI.Scrollbar::set_size(System.Single)
extern void Scrollbar_set_size_m5376982465D6013425FAB0CA8EFC620C3E1458FB (void);
// 0x00000394 System.Int32 UnityEngine.UI.Scrollbar::get_numberOfSteps()
extern void Scrollbar_get_numberOfSteps_mC3CEFF66E82BEF0473A82581CA7ACE08AA93B999 (void);
// 0x00000395 System.Void UnityEngine.UI.Scrollbar::set_numberOfSteps(System.Int32)
extern void Scrollbar_set_numberOfSteps_m59EA2D1FDFB3D5E91CC5630254E319605B67E095 (void);
// 0x00000396 UnityEngine.UI.Scrollbar/ScrollEvent UnityEngine.UI.Scrollbar::get_onValueChanged()
extern void Scrollbar_get_onValueChanged_m14356CECC1A2BA96576EB73279AF2ECF28B26D6A (void);
// 0x00000397 System.Void UnityEngine.UI.Scrollbar::set_onValueChanged(UnityEngine.UI.Scrollbar/ScrollEvent)
extern void Scrollbar_set_onValueChanged_m4167C1B411C38C2BCF9967840102723367B35AAF (void);
// 0x00000398 System.Single UnityEngine.UI.Scrollbar::get_stepSize()
extern void Scrollbar_get_stepSize_m76926AD1E9F264A61B9BF098BC90F1E1335FA7A5 (void);
// 0x00000399 System.Void UnityEngine.UI.Scrollbar::Rebuild(UnityEngine.UI.CanvasUpdate)
extern void Scrollbar_Rebuild_mB6BEE134B0B018A07FD5DE27A353DC4F8834EE85 (void);
// 0x0000039A System.Void UnityEngine.UI.Scrollbar::LayoutComplete()
extern void Scrollbar_LayoutComplete_m62E02A6865F74A44F1301CC085D1D4CA4CC90797 (void);
// 0x0000039B System.Void UnityEngine.UI.Scrollbar::GraphicUpdateComplete()
extern void Scrollbar_GraphicUpdateComplete_mD1DB8FC7C34AC5454CDF41D39483122DA7118876 (void);
// 0x0000039C System.Void UnityEngine.UI.Scrollbar::OnEnable()
extern void Scrollbar_OnEnable_m80353998984F644C00DFC51861A9ACE4134D2C86 (void);
// 0x0000039D System.Void UnityEngine.UI.Scrollbar::OnDisable()
extern void Scrollbar_OnDisable_mB78DB94C4093312BBBE28F78FE21B16F8485D2B5 (void);
// 0x0000039E System.Void UnityEngine.UI.Scrollbar::Update()
extern void Scrollbar_Update_m758EF18E62B3A8D6F319D5CEC9ACDFB005CD1AC3 (void);
// 0x0000039F System.Void UnityEngine.UI.Scrollbar::UpdateCachedReferences()
extern void Scrollbar_UpdateCachedReferences_m63BD63A223E31DF89731186F8204993FE707F0AE (void);
// 0x000003A0 System.Void UnityEngine.UI.Scrollbar::Set(System.Single,System.Boolean)
extern void Scrollbar_Set_m9A15F05D06D200A038C20B1F1C6A4DFA5B17D0A4 (void);
// 0x000003A1 System.Void UnityEngine.UI.Scrollbar::OnRectTransformDimensionsChange()
extern void Scrollbar_OnRectTransformDimensionsChange_m06E846A58CBE1B1006AA3453784789F1A56B8CC6 (void);
// 0x000003A2 UnityEngine.UI.Scrollbar/Axis UnityEngine.UI.Scrollbar::get_axis()
extern void Scrollbar_get_axis_m7C529809A9A4246CAA1F7417AC3418270B7D7ADB (void);
// 0x000003A3 System.Boolean UnityEngine.UI.Scrollbar::get_reverseValue()
extern void Scrollbar_get_reverseValue_mDEEB7F6EC4FD16FD6B1F6806335463FDBC417571 (void);
// 0x000003A4 System.Void UnityEngine.UI.Scrollbar::UpdateVisuals()
extern void Scrollbar_UpdateVisuals_m262B64133E8C98F2B1FF1A075AEACF0F8CBFF72C (void);
// 0x000003A5 System.Void UnityEngine.UI.Scrollbar::UpdateDrag(UnityEngine.EventSystems.PointerEventData)
extern void Scrollbar_UpdateDrag_mD7B02B0A326AF4BB20B66423F3EAEC8FD4BCC787 (void);
// 0x000003A6 System.Void UnityEngine.UI.Scrollbar::DoUpdateDrag(UnityEngine.Vector2,System.Single)
extern void Scrollbar_DoUpdateDrag_mC0C9D56DA7F9AAF3E8941206448DEF1FF2E4BC3E (void);
// 0x000003A7 System.Boolean UnityEngine.UI.Scrollbar::MayDrag(UnityEngine.EventSystems.PointerEventData)
extern void Scrollbar_MayDrag_m19259CC2C45110C1951E59E7E0F8CB207DD69430 (void);
// 0x000003A8 System.Void UnityEngine.UI.Scrollbar::OnBeginDrag(UnityEngine.EventSystems.PointerEventData)
extern void Scrollbar_OnBeginDrag_m9B628433953BE38D64DB2AE5A3A14A82CDD789CE (void);
// 0x000003A9 System.Void UnityEngine.UI.Scrollbar::OnDrag(UnityEngine.EventSystems.PointerEventData)
extern void Scrollbar_OnDrag_m79EAA59922BB2ED61C042ACCCCF9EE14B0990675 (void);
// 0x000003AA System.Void UnityEngine.UI.Scrollbar::OnPointerDown(UnityEngine.EventSystems.PointerEventData)
extern void Scrollbar_OnPointerDown_m8A4C9EDFECF2503F92F57D70C8D71842A3165A27 (void);
// 0x000003AB System.Collections.IEnumerator UnityEngine.UI.Scrollbar::ClickRepeat(UnityEngine.EventSystems.PointerEventData)
extern void Scrollbar_ClickRepeat_mB3CD100CB06D4687F163B47B1BE806F5519FD8C8 (void);
// 0x000003AC System.Collections.IEnumerator UnityEngine.UI.Scrollbar::ClickRepeat(UnityEngine.Vector2,UnityEngine.Camera)
extern void Scrollbar_ClickRepeat_m9805A27D61BE928E0A8CC8B6CF6D7DD0A2256830 (void);
// 0x000003AD System.Void UnityEngine.UI.Scrollbar::OnPointerUp(UnityEngine.EventSystems.PointerEventData)
extern void Scrollbar_OnPointerUp_m957C480C8DE9E46E381A800B4B60B07FF12F64B7 (void);
// 0x000003AE System.Void UnityEngine.UI.Scrollbar::OnMove(UnityEngine.EventSystems.AxisEventData)
extern void Scrollbar_OnMove_m17725BD4A3BB30209D66B1938BDF15172F05AD51 (void);
// 0x000003AF UnityEngine.UI.Selectable UnityEngine.UI.Scrollbar::FindSelectableOnLeft()
extern void Scrollbar_FindSelectableOnLeft_m4D775883935EA4A06A67C452C47971BDA90FEFE9 (void);
// 0x000003B0 UnityEngine.UI.Selectable UnityEngine.UI.Scrollbar::FindSelectableOnRight()
extern void Scrollbar_FindSelectableOnRight_mD77EA6CD469357D8E014C5075301A5752A0CA052 (void);
// 0x000003B1 UnityEngine.UI.Selectable UnityEngine.UI.Scrollbar::FindSelectableOnUp()
extern void Scrollbar_FindSelectableOnUp_m44369416317D6AF92FC5CD29CF3B4D4CB44D247D (void);
// 0x000003B2 UnityEngine.UI.Selectable UnityEngine.UI.Scrollbar::FindSelectableOnDown()
extern void Scrollbar_FindSelectableOnDown_mA0C3C3970272025DE78D382CCDB96721B4EBDD6D (void);
// 0x000003B3 System.Void UnityEngine.UI.Scrollbar::OnInitializePotentialDrag(UnityEngine.EventSystems.PointerEventData)
extern void Scrollbar_OnInitializePotentialDrag_m7B2840ACB1D2A6D3DA0F03DF9677D2DCF790E065 (void);
// 0x000003B4 System.Void UnityEngine.UI.Scrollbar::SetDirection(UnityEngine.UI.Scrollbar/Direction,System.Boolean)
extern void Scrollbar_SetDirection_mA62DC964AA698D058BC84FA1DCAFA46BCA6A8182 (void);
// 0x000003B5 UnityEngine.Transform UnityEngine.UI.Scrollbar::UnityEngine.UI.ICanvasElement.get_transform()
extern void Scrollbar_UnityEngine_UI_ICanvasElement_get_transform_m402A9522ECD918080DBBE778E8BEF58415E41B44 (void);
// 0x000003B6 System.Void UnityEngine.UI.Scrollbar/ScrollEvent::.ctor()
extern void ScrollEvent__ctor_m8875FD9430D9657557F83634E0BDAC8A4C280C10 (void);
// 0x000003B7 System.Void UnityEngine.UI.Scrollbar/<ClickRepeat>d__58::.ctor(System.Int32)
extern void U3CClickRepeatU3Ed__58__ctor_mFE0A3748E0675C23476EE9B999A3DA9A648D07EB (void);
// 0x000003B8 System.Void UnityEngine.UI.Scrollbar/<ClickRepeat>d__58::System.IDisposable.Dispose()
extern void U3CClickRepeatU3Ed__58_System_IDisposable_Dispose_mF65B6B047023720C4031343ADBFBA21A23455068 (void);
// 0x000003B9 System.Boolean UnityEngine.UI.Scrollbar/<ClickRepeat>d__58::MoveNext()
extern void U3CClickRepeatU3Ed__58_MoveNext_mB17FA8F05D7A43F4D54188D618BE2C575FC51EFD (void);
// 0x000003BA System.Object UnityEngine.UI.Scrollbar/<ClickRepeat>d__58::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CClickRepeatU3Ed__58_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m72A0A35EF0BD3D37716605AD12258D2CEF3E283B (void);
// 0x000003BB System.Void UnityEngine.UI.Scrollbar/<ClickRepeat>d__58::System.Collections.IEnumerator.Reset()
extern void U3CClickRepeatU3Ed__58_System_Collections_IEnumerator_Reset_m5B78E0B6896A6F359FF829520E88FB0EF9E747C0 (void);
// 0x000003BC System.Object UnityEngine.UI.Scrollbar/<ClickRepeat>d__58::System.Collections.IEnumerator.get_Current()
extern void U3CClickRepeatU3Ed__58_System_Collections_IEnumerator_get_Current_m217C077410A6847D0936C68956158E8BE9925873 (void);
// 0x000003BD UnityEngine.RectTransform UnityEngine.UI.ScrollRect::get_content()
extern void ScrollRect_get_content_m7878BCA28A96B7FBA02DC466A1ED2C9E191C6996 (void);
// 0x000003BE System.Void UnityEngine.UI.ScrollRect::set_content(UnityEngine.RectTransform)
extern void ScrollRect_set_content_m01BF6FE0205985CBD16C6D3BB4B6F345B3AF484E (void);
// 0x000003BF System.Boolean UnityEngine.UI.ScrollRect::get_horizontal()
extern void ScrollRect_get_horizontal_mDA4358EF29CE64E6B346D6CC5D70E08F00D3D05B (void);
// 0x000003C0 System.Void UnityEngine.UI.ScrollRect::set_horizontal(System.Boolean)
extern void ScrollRect_set_horizontal_m99C076AF2B2B596C87435E1465EF0B104281B150 (void);
// 0x000003C1 System.Boolean UnityEngine.UI.ScrollRect::get_vertical()
extern void ScrollRect_get_vertical_m43F2C650302CB71D53A0A373934CA9F9921CC38B (void);
// 0x000003C2 System.Void UnityEngine.UI.ScrollRect::set_vertical(System.Boolean)
extern void ScrollRect_set_vertical_m972088E788E72690AAE139E7C0F8F634C325E7CE (void);
// 0x000003C3 UnityEngine.UI.ScrollRect/MovementType UnityEngine.UI.ScrollRect::get_movementType()
extern void ScrollRect_get_movementType_m0672A0BA382BC5479398DE95C551530FE5B38621 (void);
// 0x000003C4 System.Void UnityEngine.UI.ScrollRect::set_movementType(UnityEngine.UI.ScrollRect/MovementType)
extern void ScrollRect_set_movementType_m2A900C10E6C005FD6866EFF1DA2DF78AA957534A (void);
// 0x000003C5 System.Single UnityEngine.UI.ScrollRect::get_elasticity()
extern void ScrollRect_get_elasticity_mF0DE000D57AA94F2A5D9E1C48EC6F6514C1F4565 (void);
// 0x000003C6 System.Void UnityEngine.UI.ScrollRect::set_elasticity(System.Single)
extern void ScrollRect_set_elasticity_mCA1500D31E9A8DE62FA03EA3E1276BFFB7F6094B (void);
// 0x000003C7 System.Boolean UnityEngine.UI.ScrollRect::get_inertia()
extern void ScrollRect_get_inertia_m10C8837B3E43787E1FA94C71683D19638FCEFFBF (void);
// 0x000003C8 System.Void UnityEngine.UI.ScrollRect::set_inertia(System.Boolean)
extern void ScrollRect_set_inertia_m8A17589561A5E7A2F5F543B8F2F6149458C68AC2 (void);
// 0x000003C9 System.Single UnityEngine.UI.ScrollRect::get_decelerationRate()
extern void ScrollRect_get_decelerationRate_mDE7178B7D5AEA48B258A328ED352C7A8AF9065AF (void);
// 0x000003CA System.Void UnityEngine.UI.ScrollRect::set_decelerationRate(System.Single)
extern void ScrollRect_set_decelerationRate_m7DB02F71AC6E7C519ADB3FA88F9B46EF187FCD61 (void);
// 0x000003CB System.Single UnityEngine.UI.ScrollRect::get_scrollSensitivity()
extern void ScrollRect_get_scrollSensitivity_m36A71A35CCAE99F83DE336A51520BB2657686E4C (void);
// 0x000003CC System.Void UnityEngine.UI.ScrollRect::set_scrollSensitivity(System.Single)
extern void ScrollRect_set_scrollSensitivity_m07A6D8B94625BC52775BED72633CCBEA41E27E1D (void);
// 0x000003CD UnityEngine.RectTransform UnityEngine.UI.ScrollRect::get_viewport()
extern void ScrollRect_get_viewport_m85092216DD476F77E78F5CE50F9C4E70063ECCF9 (void);
// 0x000003CE System.Void UnityEngine.UI.ScrollRect::set_viewport(UnityEngine.RectTransform)
extern void ScrollRect_set_viewport_m53D91C0869950B18953E163E9A3CE5E7AFB0A262 (void);
// 0x000003CF UnityEngine.UI.Scrollbar UnityEngine.UI.ScrollRect::get_horizontalScrollbar()
extern void ScrollRect_get_horizontalScrollbar_mDE0EC3FD5C1AC8FDB4D8E8EF4B093A77218DF534 (void);
// 0x000003D0 System.Void UnityEngine.UI.ScrollRect::set_horizontalScrollbar(UnityEngine.UI.Scrollbar)
extern void ScrollRect_set_horizontalScrollbar_m38777B9083CABE5B05EE674DF59867247613F6CA (void);
// 0x000003D1 UnityEngine.UI.Scrollbar UnityEngine.UI.ScrollRect::get_verticalScrollbar()
extern void ScrollRect_get_verticalScrollbar_mCEB62CC858B43CE7FB07D287CAFC1363668E78C6 (void);
// 0x000003D2 System.Void UnityEngine.UI.ScrollRect::set_verticalScrollbar(UnityEngine.UI.Scrollbar)
extern void ScrollRect_set_verticalScrollbar_m3A3503567D1ED44E21A452FE51B12691E084426C (void);
// 0x000003D3 UnityEngine.UI.ScrollRect/ScrollbarVisibility UnityEngine.UI.ScrollRect::get_horizontalScrollbarVisibility()
extern void ScrollRect_get_horizontalScrollbarVisibility_m3BB3586EBE511EEB0946353153D4818D5207A91C (void);
// 0x000003D4 System.Void UnityEngine.UI.ScrollRect::set_horizontalScrollbarVisibility(UnityEngine.UI.ScrollRect/ScrollbarVisibility)
extern void ScrollRect_set_horizontalScrollbarVisibility_mA00C9BDAC3704BEEE76986BCD1D2DFB7F2E2D818 (void);
// 0x000003D5 UnityEngine.UI.ScrollRect/ScrollbarVisibility UnityEngine.UI.ScrollRect::get_verticalScrollbarVisibility()
extern void ScrollRect_get_verticalScrollbarVisibility_m8F8691067DFB8070BDB2A15D40C6E98E858B1E77 (void);
// 0x000003D6 System.Void UnityEngine.UI.ScrollRect::set_verticalScrollbarVisibility(UnityEngine.UI.ScrollRect/ScrollbarVisibility)
extern void ScrollRect_set_verticalScrollbarVisibility_m40A791E57B3FD37CEB97D2FD29639C4EC5B49ABF (void);
// 0x000003D7 System.Single UnityEngine.UI.ScrollRect::get_horizontalScrollbarSpacing()
extern void ScrollRect_get_horizontalScrollbarSpacing_mA61BE48D8F60FA41696D3854501BD6931297DFB6 (void);
// 0x000003D8 System.Void UnityEngine.UI.ScrollRect::set_horizontalScrollbarSpacing(System.Single)
extern void ScrollRect_set_horizontalScrollbarSpacing_mF3FDBF169F96C109BCC75EE62AAC265D23E30D63 (void);
// 0x000003D9 System.Single UnityEngine.UI.ScrollRect::get_verticalScrollbarSpacing()
extern void ScrollRect_get_verticalScrollbarSpacing_mB3FB9008708D488CCC4EE2753B4EE74953CBEB7C (void);
// 0x000003DA System.Void UnityEngine.UI.ScrollRect::set_verticalScrollbarSpacing(System.Single)
extern void ScrollRect_set_verticalScrollbarSpacing_m27BECB09BC4EE6BC91EAABEF50657182A637C1E7 (void);
// 0x000003DB UnityEngine.UI.ScrollRect/ScrollRectEvent UnityEngine.UI.ScrollRect::get_onValueChanged()
extern void ScrollRect_get_onValueChanged_mA6AF3832A97E82D31BB8C20BCD6E87A300E56C05 (void);
// 0x000003DC System.Void UnityEngine.UI.ScrollRect::set_onValueChanged(UnityEngine.UI.ScrollRect/ScrollRectEvent)
extern void ScrollRect_set_onValueChanged_mB3D669EB2351EDDEBEF2D0F85FBE6279BE905288 (void);
// 0x000003DD UnityEngine.RectTransform UnityEngine.UI.ScrollRect::get_viewRect()
extern void ScrollRect_get_viewRect_m3E97A12D75F8D1CBE409EFD5D550141B0DA326C3 (void);
// 0x000003DE UnityEngine.Vector2 UnityEngine.UI.ScrollRect::get_velocity()
extern void ScrollRect_get_velocity_m8F7DDB02F52BFF2503F079C216FC5C89AA4875DC (void);
// 0x000003DF System.Void UnityEngine.UI.ScrollRect::set_velocity(UnityEngine.Vector2)
extern void ScrollRect_set_velocity_mBC8D4BC0A0184FCC3AEB359AE68E9130E811AFC2 (void);
// 0x000003E0 UnityEngine.RectTransform UnityEngine.UI.ScrollRect::get_rectTransform()
extern void ScrollRect_get_rectTransform_mB34A69B7E6E21FFF066786508974D89B5A6D4E4C (void);
// 0x000003E1 System.Void UnityEngine.UI.ScrollRect::.ctor()
extern void ScrollRect__ctor_m71A7660A30496E9D4937AE250FBAB722BF0747C7 (void);
// 0x000003E2 System.Void UnityEngine.UI.ScrollRect::Rebuild(UnityEngine.UI.CanvasUpdate)
extern void ScrollRect_Rebuild_mC15C5A090517F09F981F12DFD46BCCAE96FF9660 (void);
// 0x000003E3 System.Void UnityEngine.UI.ScrollRect::LayoutComplete()
extern void ScrollRect_LayoutComplete_mA3AB518DD92641DF7F01CE8108EBFC4C0424A115 (void);
// 0x000003E4 System.Void UnityEngine.UI.ScrollRect::GraphicUpdateComplete()
extern void ScrollRect_GraphicUpdateComplete_mF50A0A85D39C499126C7305CCCF055360091EE22 (void);
// 0x000003E5 System.Void UnityEngine.UI.ScrollRect::UpdateCachedData()
extern void ScrollRect_UpdateCachedData_m5E25EF1E36AB04D01FEE66C8E0CD30C0E6CCA933 (void);
// 0x000003E6 System.Void UnityEngine.UI.ScrollRect::OnEnable()
extern void ScrollRect_OnEnable_m5A4AE9FF349A1F5C9780F2DC17CEF3304B795AE9 (void);
// 0x000003E7 System.Void UnityEngine.UI.ScrollRect::OnDisable()
extern void ScrollRect_OnDisable_m0C287FAF83174051A941BA2F90F4D0E38B3ECFDC (void);
// 0x000003E8 System.Boolean UnityEngine.UI.ScrollRect::IsActive()
extern void ScrollRect_IsActive_mBACF2D3F35080C325C5D6A54CF86D17C19FF9A70 (void);
// 0x000003E9 System.Void UnityEngine.UI.ScrollRect::EnsureLayoutHasRebuilt()
extern void ScrollRect_EnsureLayoutHasRebuilt_mDEA99980960C5429B17B200EFB3B2EB13B01956A (void);
// 0x000003EA System.Void UnityEngine.UI.ScrollRect::StopMovement()
extern void ScrollRect_StopMovement_mA278F4EBDE715F61F9D38F88E71E364E82870851 (void);
// 0x000003EB System.Void UnityEngine.UI.ScrollRect::OnScroll(UnityEngine.EventSystems.PointerEventData)
extern void ScrollRect_OnScroll_m86BA4041DE7B1B13101BCC01D90752143A5A28F6 (void);
// 0x000003EC System.Void UnityEngine.UI.ScrollRect::OnInitializePotentialDrag(UnityEngine.EventSystems.PointerEventData)
extern void ScrollRect_OnInitializePotentialDrag_m35BB18E5EB6B50B7CC4B44171433E1493A5F8A10 (void);
// 0x000003ED System.Void UnityEngine.UI.ScrollRect::OnBeginDrag(UnityEngine.EventSystems.PointerEventData)
extern void ScrollRect_OnBeginDrag_m6B0948CCD12A89B43E4F2596E3C7220A6D426868 (void);
// 0x000003EE System.Void UnityEngine.UI.ScrollRect::OnEndDrag(UnityEngine.EventSystems.PointerEventData)
extern void ScrollRect_OnEndDrag_m7CB3145874E1930FEBD50874DF31280FC35B480B (void);
// 0x000003EF System.Void UnityEngine.UI.ScrollRect::OnDrag(UnityEngine.EventSystems.PointerEventData)
extern void ScrollRect_OnDrag_m1BA80F29441E3761A294E32C7CCE52C35F1B6E5C (void);
// 0x000003F0 System.Void UnityEngine.UI.ScrollRect::SetContentAnchoredPosition(UnityEngine.Vector2)
extern void ScrollRect_SetContentAnchoredPosition_m4C8EC3F85A2B1011985E7583AFDC15A69FF90ACE (void);
// 0x000003F1 System.Void UnityEngine.UI.ScrollRect::LateUpdate()
extern void ScrollRect_LateUpdate_m7E003F1E2C34057F6B802003E77AABF54526C0EE (void);
// 0x000003F2 System.Void UnityEngine.UI.ScrollRect::UpdatePrevData()
extern void ScrollRect_UpdatePrevData_m4BF4AF6ACB7DC3E4A3F7DA8F468B784D1320ED8D (void);
// 0x000003F3 System.Void UnityEngine.UI.ScrollRect::UpdateScrollbars(UnityEngine.Vector2)
extern void ScrollRect_UpdateScrollbars_m9D6268FD19434213F7BCE166722A9B36346C755B (void);
// 0x000003F4 UnityEngine.Vector2 UnityEngine.UI.ScrollRect::get_normalizedPosition()
extern void ScrollRect_get_normalizedPosition_m4B05A9E790891D503C2B65953728278C7FF8CB58 (void);
// 0x000003F5 System.Void UnityEngine.UI.ScrollRect::set_normalizedPosition(UnityEngine.Vector2)
extern void ScrollRect_set_normalizedPosition_m8CFC50007450856E3B1FEB9E61A6311FBC0E709E (void);
// 0x000003F6 System.Single UnityEngine.UI.ScrollRect::get_horizontalNormalizedPosition()
extern void ScrollRect_get_horizontalNormalizedPosition_mC2C3A7F67E27AA7470A81042AD2B0AD0B5F1AF93 (void);
// 0x000003F7 System.Void UnityEngine.UI.ScrollRect::set_horizontalNormalizedPosition(System.Single)
extern void ScrollRect_set_horizontalNormalizedPosition_m9B268C9AE7891FC73623DC7BE6B9900640C029B6 (void);
// 0x000003F8 System.Single UnityEngine.UI.ScrollRect::get_verticalNormalizedPosition()
extern void ScrollRect_get_verticalNormalizedPosition_m4FE766F04272C1805FDE2A4B72D80F6190841FA1 (void);
// 0x000003F9 System.Void UnityEngine.UI.ScrollRect::set_verticalNormalizedPosition(System.Single)
extern void ScrollRect_set_verticalNormalizedPosition_m4AF461113925E6710BF04F46A49CF1F856F7738C (void);
// 0x000003FA System.Void UnityEngine.UI.ScrollRect::SetHorizontalNormalizedPosition(System.Single)
extern void ScrollRect_SetHorizontalNormalizedPosition_m3F43FC307A146E534DC3F73F4DE38386AAC10405 (void);
// 0x000003FB System.Void UnityEngine.UI.ScrollRect::SetVerticalNormalizedPosition(System.Single)
extern void ScrollRect_SetVerticalNormalizedPosition_m4E9F3559FA6369389C1B70D3E94AA35AEC7903E5 (void);
// 0x000003FC System.Void UnityEngine.UI.ScrollRect::SetNormalizedPosition(System.Single,System.Int32)
extern void ScrollRect_SetNormalizedPosition_m99C3731F06EEEF281E68D5D448914B1A3C5636FB (void);
// 0x000003FD System.Single UnityEngine.UI.ScrollRect::RubberDelta(System.Single,System.Single)
extern void ScrollRect_RubberDelta_m5A4BE5FAAA0C39B318A422F236C898D1008AE248 (void);
// 0x000003FE System.Void UnityEngine.UI.ScrollRect::OnRectTransformDimensionsChange()
extern void ScrollRect_OnRectTransformDimensionsChange_mD41D649A067BFD8DC067FC612C04E48518D691BF (void);
// 0x000003FF System.Boolean UnityEngine.UI.ScrollRect::get_hScrollingNeeded()
extern void ScrollRect_get_hScrollingNeeded_m426A4490F146A56FF76349CBBA4B587EDA5F78DB (void);
// 0x00000400 System.Boolean UnityEngine.UI.ScrollRect::get_vScrollingNeeded()
extern void ScrollRect_get_vScrollingNeeded_m96BA5B252797DF209A1784D1DE3C09AAFEFB25B2 (void);
// 0x00000401 System.Void UnityEngine.UI.ScrollRect::CalculateLayoutInputHorizontal()
extern void ScrollRect_CalculateLayoutInputHorizontal_mEC706200EAB973A2333279BA6C2EE7F6DAA884A6 (void);
// 0x00000402 System.Void UnityEngine.UI.ScrollRect::CalculateLayoutInputVertical()
extern void ScrollRect_CalculateLayoutInputVertical_mF708C890C569C942921A2ED809FC0294E13CC9A4 (void);
// 0x00000403 System.Single UnityEngine.UI.ScrollRect::get_minWidth()
extern void ScrollRect_get_minWidth_m3824272990612610DDDCA8D35C23EDC0E97A6751 (void);
// 0x00000404 System.Single UnityEngine.UI.ScrollRect::get_preferredWidth()
extern void ScrollRect_get_preferredWidth_m16914F16D3F8F1102428267D62CCBF5E8B1EF131 (void);
// 0x00000405 System.Single UnityEngine.UI.ScrollRect::get_flexibleWidth()
extern void ScrollRect_get_flexibleWidth_m6C7F8AC0595D6B5179BF02EAFEF3126731B162D6 (void);
// 0x00000406 System.Single UnityEngine.UI.ScrollRect::get_minHeight()
extern void ScrollRect_get_minHeight_m3D973E3759C8D35899E2F62CFA7677834E6050B4 (void);
// 0x00000407 System.Single UnityEngine.UI.ScrollRect::get_preferredHeight()
extern void ScrollRect_get_preferredHeight_m90993A52773D1214E648E8DC937D89317F6D4F72 (void);
// 0x00000408 System.Single UnityEngine.UI.ScrollRect::get_flexibleHeight()
extern void ScrollRect_get_flexibleHeight_m91767E81456CA1069B6BBEFCD140BE65962C421F (void);
// 0x00000409 System.Int32 UnityEngine.UI.ScrollRect::get_layoutPriority()
extern void ScrollRect_get_layoutPriority_m19C83DF0ACE68769627C6FB8E09F92FDF63E80E9 (void);
// 0x0000040A System.Void UnityEngine.UI.ScrollRect::SetLayoutHorizontal()
extern void ScrollRect_SetLayoutHorizontal_m26167C6091ECF4AFB6A4747575592C2923CA4EE5 (void);
// 0x0000040B System.Void UnityEngine.UI.ScrollRect::SetLayoutVertical()
extern void ScrollRect_SetLayoutVertical_mAC8DF5F2CEB21C69D993846A3AF307C6217B83C8 (void);
// 0x0000040C System.Void UnityEngine.UI.ScrollRect::UpdateScrollbarVisibility()
extern void ScrollRect_UpdateScrollbarVisibility_mC4E22621A76C4FED36EFA5421BA4006DCB4E5140 (void);
// 0x0000040D System.Void UnityEngine.UI.ScrollRect::UpdateOneScrollbarVisibility(System.Boolean,System.Boolean,UnityEngine.UI.ScrollRect/ScrollbarVisibility,UnityEngine.UI.Scrollbar)
extern void ScrollRect_UpdateOneScrollbarVisibility_mB2A129E7AE74E39D6080389679DFDB99D1A65FD7 (void);
// 0x0000040E System.Void UnityEngine.UI.ScrollRect::UpdateScrollbarLayout()
extern void ScrollRect_UpdateScrollbarLayout_m41BFD2C6E126A96E99A6892EB88249D2F44530D2 (void);
// 0x0000040F System.Void UnityEngine.UI.ScrollRect::UpdateBounds()
extern void ScrollRect_UpdateBounds_m71C0450FC4E45F3A60CAEC0D3ABE21702364BA92 (void);
// 0x00000410 System.Void UnityEngine.UI.ScrollRect::AdjustBounds(UnityEngine.Bounds&,UnityEngine.Vector2&,UnityEngine.Vector3&,UnityEngine.Vector3&)
extern void ScrollRect_AdjustBounds_mF4ADDB84F572E72668E1FA1E699F84A4A89E9F96 (void);
// 0x00000411 UnityEngine.Bounds UnityEngine.UI.ScrollRect::GetBounds()
extern void ScrollRect_GetBounds_m867D453097CBE1F32BF2F9D74F88255542F692A2 (void);
// 0x00000412 UnityEngine.Bounds UnityEngine.UI.ScrollRect::InternalGetBounds(UnityEngine.Vector3[],UnityEngine.Matrix4x4&)
extern void ScrollRect_InternalGetBounds_m678E51D17A614402FEA0D24741A37EBE45B31817 (void);
// 0x00000413 UnityEngine.Vector2 UnityEngine.UI.ScrollRect::CalculateOffset(UnityEngine.Vector2)
extern void ScrollRect_CalculateOffset_mAFCC1C71DF0F848130BBF11C914E2333B8E5155D (void);
// 0x00000414 UnityEngine.Vector2 UnityEngine.UI.ScrollRect::InternalCalculateOffset(UnityEngine.Bounds&,UnityEngine.Bounds&,System.Boolean,System.Boolean,UnityEngine.UI.ScrollRect/MovementType,UnityEngine.Vector2&)
extern void ScrollRect_InternalCalculateOffset_m47D8A586D3069AA701718AB516A5F2FECC8AE1C0 (void);
// 0x00000415 System.Void UnityEngine.UI.ScrollRect::SetDirty()
extern void ScrollRect_SetDirty_mAE263F4AB8A126B60FECCB4A20A6DE1C0A7EB8FE (void);
// 0x00000416 System.Void UnityEngine.UI.ScrollRect::SetDirtyCaching()
extern void ScrollRect_SetDirtyCaching_m8E5F2F8A20AE671802C2ABA400E9125CF60FF19F (void);
// 0x00000417 UnityEngine.Transform UnityEngine.UI.ScrollRect::UnityEngine.UI.ICanvasElement.get_transform()
extern void ScrollRect_UnityEngine_UI_ICanvasElement_get_transform_m92CB3091979234EDC51D449A75CC22C2F9223AD8 (void);
// 0x00000418 System.Void UnityEngine.UI.ScrollRect/ScrollRectEvent::.ctor()
extern void ScrollRectEvent__ctor_m1A1148AF5CFAEA289C3F017565F6B1261CDB95AC (void);
// 0x00000419 UnityEngine.UI.Selectable[] UnityEngine.UI.Selectable::get_allSelectablesArray()
extern void Selectable_get_allSelectablesArray_m1071647E8ED4DDE7162EE56B3D730468D09454B3 (void);
// 0x0000041A System.Int32 UnityEngine.UI.Selectable::get_allSelectableCount()
extern void Selectable_get_allSelectableCount_m2C8D64447141260C734038679940C8D9DB39A6CA (void);
// 0x0000041B System.Collections.Generic.List`1<UnityEngine.UI.Selectable> UnityEngine.UI.Selectable::get_allSelectables()
extern void Selectable_get_allSelectables_m0B3507A121322D32AC9E8EE45424F84B3653D8AF (void);
// 0x0000041C System.Int32 UnityEngine.UI.Selectable::AllSelectablesNoAlloc(UnityEngine.UI.Selectable[])
extern void Selectable_AllSelectablesNoAlloc_m1583EDE9D566FA98A92F1AFC543519E3A8BE56BC (void);
// 0x0000041D UnityEngine.UI.Navigation UnityEngine.UI.Selectable::get_navigation()
extern void Selectable_get_navigation_mA0E5FC6B1D19C2DCABA5C82EC33C49CF7F17103E (void);
// 0x0000041E System.Void UnityEngine.UI.Selectable::set_navigation(UnityEngine.UI.Navigation)
extern void Selectable_set_navigation_m706D254813B084B60F07980607D7AE43AC44AFEF (void);
// 0x0000041F UnityEngine.UI.Selectable/Transition UnityEngine.UI.Selectable::get_transition()
extern void Selectable_get_transition_mBDC7F9FCA36E707B6D77E2F33FCEFA344A3E5005 (void);
// 0x00000420 System.Void UnityEngine.UI.Selectable::set_transition(UnityEngine.UI.Selectable/Transition)
extern void Selectable_set_transition_m67F9584736EB6891A314C9804489368C430F0F59 (void);
// 0x00000421 UnityEngine.UI.ColorBlock UnityEngine.UI.Selectable::get_colors()
extern void Selectable_get_colors_mB53E365D02351D4B64084295C4B2A7AF2DEC4750 (void);
// 0x00000422 System.Void UnityEngine.UI.Selectable::set_colors(UnityEngine.UI.ColorBlock)
extern void Selectable_set_colors_m0A49ED3ACD6647B7E5A2DA10B3D417E8FE1BE55A (void);
// 0x00000423 UnityEngine.UI.SpriteState UnityEngine.UI.Selectable::get_spriteState()
extern void Selectable_get_spriteState_m7388F8F08AB8A03CB56516A7C9713733A737629A (void);
// 0x00000424 System.Void UnityEngine.UI.Selectable::set_spriteState(UnityEngine.UI.SpriteState)
extern void Selectable_set_spriteState_mE0E2CDA8757045FE0D35BC4D9E827857F64E19ED (void);
// 0x00000425 UnityEngine.UI.AnimationTriggers UnityEngine.UI.Selectable::get_animationTriggers()
extern void Selectable_get_animationTriggers_m58213BBD3E4D5B7C8A25F1DAC51F2B06176A08DA (void);
// 0x00000426 System.Void UnityEngine.UI.Selectable::set_animationTriggers(UnityEngine.UI.AnimationTriggers)
extern void Selectable_set_animationTriggers_m564A90FBE85D0F3A5055AEA255E753EF58C2B1D8 (void);
// 0x00000427 UnityEngine.UI.Graphic UnityEngine.UI.Selectable::get_targetGraphic()
extern void Selectable_get_targetGraphic_m659A2940226EC644AAFC2D5CCC326ABEE6384388 (void);
// 0x00000428 System.Void UnityEngine.UI.Selectable::set_targetGraphic(UnityEngine.UI.Graphic)
extern void Selectable_set_targetGraphic_m23DB0DF4E5F2DABD50C662C708B4555162171FB9 (void);
// 0x00000429 System.Boolean UnityEngine.UI.Selectable::get_interactable()
extern void Selectable_get_interactable_m17DD0484DC62DCB4467109488D7A599BC85EC112 (void);
// 0x0000042A System.Void UnityEngine.UI.Selectable::set_interactable(System.Boolean)
extern void Selectable_set_interactable_m8DD581C1AD99B2EFA8B3EE9AF69EDDF26688B492 (void);
// 0x0000042B System.Boolean UnityEngine.UI.Selectable::get_isPointerInside()
extern void Selectable_get_isPointerInside_mB31AB05760CDC4A72B7E5D7B86061C9829BE5DF0 (void);
// 0x0000042C System.Void UnityEngine.UI.Selectable::set_isPointerInside(System.Boolean)
extern void Selectable_set_isPointerInside_mF82515A016E440225E31092AC6CB63EA09D71D4D (void);
// 0x0000042D System.Boolean UnityEngine.UI.Selectable::get_isPointerDown()
extern void Selectable_get_isPointerDown_m61C9ECC7F52547B6638CD046CD7FF61A7FA1F778 (void);
// 0x0000042E System.Void UnityEngine.UI.Selectable::set_isPointerDown(System.Boolean)
extern void Selectable_set_isPointerDown_m02FB181F4C59A8477243C9971AA17CD77A86A70C (void);
// 0x0000042F System.Boolean UnityEngine.UI.Selectable::get_hasSelection()
extern void Selectable_get_hasSelection_m7F81F2A77E32862AE18BB0459A0732275EFFA11A (void);
// 0x00000430 System.Void UnityEngine.UI.Selectable::set_hasSelection(System.Boolean)
extern void Selectable_set_hasSelection_m9EBB907C29E5BB0DAB3066EFCC728595B125D235 (void);
// 0x00000431 System.Void UnityEngine.UI.Selectable::.ctor()
extern void Selectable__ctor_m340EDFEA07F025166175C3ECB1BD2EEDD81C8638 (void);
// 0x00000432 UnityEngine.UI.Image UnityEngine.UI.Selectable::get_image()
extern void Selectable_get_image_m88664022F6BC90E7B8D4BFCBA7FE24B48E90C639 (void);
// 0x00000433 System.Void UnityEngine.UI.Selectable::set_image(UnityEngine.UI.Image)
extern void Selectable_set_image_mE9DDDBE46C5A435F9788E88EEF0187B5E09A30A8 (void);
// 0x00000434 UnityEngine.Animator UnityEngine.UI.Selectable::get_animator()
extern void Selectable_get_animator_mE0AB180AF3936F681535220F4344FF3016C96C34 (void);
// 0x00000435 System.Void UnityEngine.UI.Selectable::Awake()
extern void Selectable_Awake_m55439376D9E09A622C61C4BD7DA413E1E0EFD469 (void);
// 0x00000436 System.Void UnityEngine.UI.Selectable::OnCanvasGroupChanged()
extern void Selectable_OnCanvasGroupChanged_mC30124BB26D8462F8E163F33A57388B443A1BBA0 (void);
// 0x00000437 System.Boolean UnityEngine.UI.Selectable::IsInteractable()
extern void Selectable_IsInteractable_mEF8BE44216120C4200B619E9BEE7ABF608D5246D (void);
// 0x00000438 System.Void UnityEngine.UI.Selectable::OnDidApplyAnimationProperties()
extern void Selectable_OnDidApplyAnimationProperties_m62471EC7970DF938373D7E63BB1D4DFB74EA7330 (void);
// 0x00000439 System.Void UnityEngine.UI.Selectable::OnEnable()
extern void Selectable_OnEnable_mBE48F9440061AFFCEA53B103F7C7A059AC115FA7 (void);
// 0x0000043A System.Void UnityEngine.UI.Selectable::OnTransformParentChanged()
extern void Selectable_OnTransformParentChanged_mC802FD6123F88D70845E1FDE93FD38D38315EB27 (void);
// 0x0000043B System.Void UnityEngine.UI.Selectable::OnSetProperty()
extern void Selectable_OnSetProperty_m9070CBEB5C95931EFC0DA7BCA038461CDF835010 (void);
// 0x0000043C System.Void UnityEngine.UI.Selectable::OnDisable()
extern void Selectable_OnDisable_m293DB718E1101FC77E655E4A2C4F2DE1DBD4663C (void);
// 0x0000043D System.Void UnityEngine.UI.Selectable::OnApplicationFocus(System.Boolean)
extern void Selectable_OnApplicationFocus_mE3ADCB53E6FD825F59B51BD0390F0C81AAD8E8F4 (void);
// 0x0000043E UnityEngine.UI.Selectable/SelectionState UnityEngine.UI.Selectable::get_currentSelectionState()
extern void Selectable_get_currentSelectionState_mD8AC0B7BF3C5AFB574C57BDC81274F621978FABC (void);
// 0x0000043F System.Void UnityEngine.UI.Selectable::InstantClearState()
extern void Selectable_InstantClearState_m8D5BD204B502945CC1AB73A0C45CF8DE199A041B (void);
// 0x00000440 System.Void UnityEngine.UI.Selectable::DoStateTransition(UnityEngine.UI.Selectable/SelectionState,System.Boolean)
extern void Selectable_DoStateTransition_mE74A03CC2A2DBCA9C07559B168FA6A77FFE57942 (void);
// 0x00000441 UnityEngine.UI.Selectable UnityEngine.UI.Selectable::FindSelectable(UnityEngine.Vector3)
extern void Selectable_FindSelectable_m332211FC94618A05817C0C62A9C36C60F787179E (void);
// 0x00000442 UnityEngine.Vector3 UnityEngine.UI.Selectable::GetPointOnRectEdge(UnityEngine.RectTransform,UnityEngine.Vector2)
extern void Selectable_GetPointOnRectEdge_m3E2D149816CB643503988036FEA4E25F914788C2 (void);
// 0x00000443 System.Void UnityEngine.UI.Selectable::Navigate(UnityEngine.EventSystems.AxisEventData,UnityEngine.UI.Selectable)
extern void Selectable_Navigate_mF67643CAEFF8AFFB80A1EC743CF6B2C1121556C5 (void);
// 0x00000444 UnityEngine.UI.Selectable UnityEngine.UI.Selectable::FindSelectableOnLeft()
extern void Selectable_FindSelectableOnLeft_m1DB05BA9AB4FBED7AAD646526926BCC9BC99E134 (void);
// 0x00000445 UnityEngine.UI.Selectable UnityEngine.UI.Selectable::FindSelectableOnRight()
extern void Selectable_FindSelectableOnRight_m9F76D3B04DD85E9A2C6DC3F1041DE0C9200F307E (void);
// 0x00000446 UnityEngine.UI.Selectable UnityEngine.UI.Selectable::FindSelectableOnUp()
extern void Selectable_FindSelectableOnUp_m3B25FCB3C7EBEA5A777325A7ECB7985A4B7345CC (void);
// 0x00000447 UnityEngine.UI.Selectable UnityEngine.UI.Selectable::FindSelectableOnDown()
extern void Selectable_FindSelectableOnDown_mF1715CEA701C504DA775E4A22373881031F851B3 (void);
// 0x00000448 System.Void UnityEngine.UI.Selectable::OnMove(UnityEngine.EventSystems.AxisEventData)
extern void Selectable_OnMove_m0801D5433615BD3163659A17B1DB2B23886AF05A (void);
// 0x00000449 System.Void UnityEngine.UI.Selectable::StartColorTween(UnityEngine.Color,System.Boolean)
extern void Selectable_StartColorTween_m13B3BCF55A09B8C4CD56C25018C93E97F2B51097 (void);
// 0x0000044A System.Void UnityEngine.UI.Selectable::DoSpriteSwap(UnityEngine.Sprite)
extern void Selectable_DoSpriteSwap_mDE447BE74A0240AE366AA9C0D9701B2E4689ECD5 (void);
// 0x0000044B System.Void UnityEngine.UI.Selectable::TriggerAnimation(System.String)
extern void Selectable_TriggerAnimation_mDA4462FAF2B2DE28945F4AD30E9F8904F4AC4D8E (void);
// 0x0000044C System.Boolean UnityEngine.UI.Selectable::IsHighlighted()
extern void Selectable_IsHighlighted_m889908FCD27411E02267021F8A1B0C72525EF96F (void);
// 0x0000044D System.Boolean UnityEngine.UI.Selectable::IsPressed()
extern void Selectable_IsPressed_m2B38EC61FF57A3C4161EDAA8DB4CA5757A3196FA (void);
// 0x0000044E System.Void UnityEngine.UI.Selectable::EvaluateAndTransitionToSelectionState()
extern void Selectable_EvaluateAndTransitionToSelectionState_mD0648A10DDF70A60B8B707507CC1DBF6A148F9B2 (void);
// 0x0000044F System.Void UnityEngine.UI.Selectable::OnPointerDown(UnityEngine.EventSystems.PointerEventData)
extern void Selectable_OnPointerDown_m4425D3C7641AAD2430A7E666F35047E2F3B623D3 (void);
// 0x00000450 System.Void UnityEngine.UI.Selectable::OnPointerUp(UnityEngine.EventSystems.PointerEventData)
extern void Selectable_OnPointerUp_mF7B6987EE86DD7079DDA835339A17BCFC6E7A4C9 (void);
// 0x00000451 System.Void UnityEngine.UI.Selectable::OnPointerEnter(UnityEngine.EventSystems.PointerEventData)
extern void Selectable_OnPointerEnter_m4AEEEAFB92045B8D8794C65890965E9CC8870860 (void);
// 0x00000452 System.Void UnityEngine.UI.Selectable::OnPointerExit(UnityEngine.EventSystems.PointerEventData)
extern void Selectable_OnPointerExit_mA288BF802AD6844F51CE19C120DF5CCEBF487929 (void);
// 0x00000453 System.Void UnityEngine.UI.Selectable::OnSelect(UnityEngine.EventSystems.BaseEventData)
extern void Selectable_OnSelect_m50BA6D8F185CEA3211F9DEFE68AB6439AF685242 (void);
// 0x00000454 System.Void UnityEngine.UI.Selectable::OnDeselect(UnityEngine.EventSystems.BaseEventData)
extern void Selectable_OnDeselect_m43A2F451FC100ACAFA88D67331CD4537994B8262 (void);
// 0x00000455 System.Void UnityEngine.UI.Selectable::Select()
extern void Selectable_Select_mE52B485BB3714E96666F913358BAB9D57588F9A7 (void);
// 0x00000456 System.Void UnityEngine.UI.Selectable::.cctor()
extern void Selectable__cctor_m6D5E8673B9C3F2CE492ECCF88960CBC03C9D8E51 (void);
// 0x00000457 System.Boolean UnityEngine.UI.SetPropertyUtility::SetColor(UnityEngine.Color&,UnityEngine.Color)
extern void SetPropertyUtility_SetColor_m05C71F5D62DDB2E51E35EDACC0060205B2BA7237 (void);
// 0x00000458 System.Boolean UnityEngine.UI.SetPropertyUtility::SetStruct(T&,T)
// 0x00000459 System.Boolean UnityEngine.UI.SetPropertyUtility::SetClass(T&,T)
// 0x0000045A UnityEngine.RectTransform UnityEngine.UI.Slider::get_fillRect()
extern void Slider_get_fillRect_m35EE2868F52084F9543158A2EAD99476E5C13D9A (void);
// 0x0000045B System.Void UnityEngine.UI.Slider::set_fillRect(UnityEngine.RectTransform)
extern void Slider_set_fillRect_m2CB86D7C94EA17486DACA010B643F9FE308B6AA3 (void);
// 0x0000045C UnityEngine.RectTransform UnityEngine.UI.Slider::get_handleRect()
extern void Slider_get_handleRect_mF6564572F3D7074E01D17661BD012F5987D328D9 (void);
// 0x0000045D System.Void UnityEngine.UI.Slider::set_handleRect(UnityEngine.RectTransform)
extern void Slider_set_handleRect_m572400ADF8F03B8931302F709BB638745CAD5111 (void);
// 0x0000045E UnityEngine.UI.Slider/Direction UnityEngine.UI.Slider::get_direction()
extern void Slider_get_direction_mEB650B873607C3D4E49EC4AB25EE9CE2554B33D5 (void);
// 0x0000045F System.Void UnityEngine.UI.Slider::set_direction(UnityEngine.UI.Slider/Direction)
extern void Slider_set_direction_mD219E6B22DA729C74E1594C8571B926C4A96871D (void);
// 0x00000460 System.Single UnityEngine.UI.Slider::get_minValue()
extern void Slider_get_minValue_m4443221B443E357866F07B062CE39944134C794C (void);
// 0x00000461 System.Void UnityEngine.UI.Slider::set_minValue(System.Single)
extern void Slider_set_minValue_mC4D1F7709276A9A418F9284A04799FF767DEDC4F (void);
// 0x00000462 System.Single UnityEngine.UI.Slider::get_maxValue()
extern void Slider_get_maxValue_mB34C0C9337F5D00ECB2915E8008BCAEB8E7C5FB6 (void);
// 0x00000463 System.Void UnityEngine.UI.Slider::set_maxValue(System.Single)
extern void Slider_set_maxValue_m43F3BF47C6D7063D80C578FD9B95AD88494203BE (void);
// 0x00000464 System.Boolean UnityEngine.UI.Slider::get_wholeNumbers()
extern void Slider_get_wholeNumbers_mF1A52AF2845985E1FC462236783B3E5BE83F9928 (void);
// 0x00000465 System.Void UnityEngine.UI.Slider::set_wholeNumbers(System.Boolean)
extern void Slider_set_wholeNumbers_m8A76CC011B30B0281F47F8ED085DDE62EACA0EC5 (void);
// 0x00000466 System.Single UnityEngine.UI.Slider::get_value()
extern void Slider_get_value_m92843A0FEE9FBF1FC5228C7F677E74642D860010 (void);
// 0x00000467 System.Void UnityEngine.UI.Slider::set_value(System.Single)
extern void Slider_set_value_mA6DC34301E7F76E7FD9C964D61A7B06C95A05D0C (void);
// 0x00000468 System.Void UnityEngine.UI.Slider::SetValueWithoutNotify(System.Single)
extern void Slider_SetValueWithoutNotify_mD60D03926D6D1CBA6F162DE01296B239CF9A03BA (void);
// 0x00000469 System.Single UnityEngine.UI.Slider::get_normalizedValue()
extern void Slider_get_normalizedValue_mC839197322275EF1318B6E49B7573FDB30F74D83 (void);
// 0x0000046A System.Void UnityEngine.UI.Slider::set_normalizedValue(System.Single)
extern void Slider_set_normalizedValue_mD8E0F3B3EC5CA862BCD1B2AB42DC1CDFCC381A1C (void);
// 0x0000046B UnityEngine.UI.Slider/SliderEvent UnityEngine.UI.Slider::get_onValueChanged()
extern void Slider_get_onValueChanged_m4DA3FD0F8D7BB838F442C07F7796EEE584D0D4F6 (void);
// 0x0000046C System.Void UnityEngine.UI.Slider::set_onValueChanged(UnityEngine.UI.Slider/SliderEvent)
extern void Slider_set_onValueChanged_mBFB4D238D7D0B4C686BF47E944A4F873A82939C9 (void);
// 0x0000046D System.Single UnityEngine.UI.Slider::get_stepSize()
extern void Slider_get_stepSize_m55FF421B05B5995454F93AF1D3A5313A6C58977D (void);
// 0x0000046E System.Void UnityEngine.UI.Slider::.ctor()
extern void Slider__ctor_m205FDE3F1A59F98FE8E0E138FA96C107F79BDDB0 (void);
// 0x0000046F System.Void UnityEngine.UI.Slider::Rebuild(UnityEngine.UI.CanvasUpdate)
extern void Slider_Rebuild_mD7FD3AE545912A90D82A84164779FAD30448BDE0 (void);
// 0x00000470 System.Void UnityEngine.UI.Slider::LayoutComplete()
extern void Slider_LayoutComplete_mD2E60699C63B82C9164232EA8A2669B5436A2DA5 (void);
// 0x00000471 System.Void UnityEngine.UI.Slider::GraphicUpdateComplete()
extern void Slider_GraphicUpdateComplete_m2BFE85324EE12F00974D6034CCEBD058911DBC6D (void);
// 0x00000472 System.Void UnityEngine.UI.Slider::OnEnable()
extern void Slider_OnEnable_m7B8D2AD29196D07E85830E4D17E01EB7D2151E8A (void);
// 0x00000473 System.Void UnityEngine.UI.Slider::OnDisable()
extern void Slider_OnDisable_m3FCB26AAD286DAC967219251AF81A676436A3D39 (void);
// 0x00000474 System.Void UnityEngine.UI.Slider::Update()
extern void Slider_Update_m522C74C2E16CB8923FFBB2F67A39DC92812A2283 (void);
// 0x00000475 System.Void UnityEngine.UI.Slider::OnDidApplyAnimationProperties()
extern void Slider_OnDidApplyAnimationProperties_m09393E7CF5C36A5C28AFDF3B767BB8F7B8B75FBC (void);
// 0x00000476 System.Void UnityEngine.UI.Slider::UpdateCachedReferences()
extern void Slider_UpdateCachedReferences_m377F41A1442EBDA6661A3E7E40E92B6D4CD4F5AE (void);
// 0x00000477 System.Single UnityEngine.UI.Slider::ClampValue(System.Single)
extern void Slider_ClampValue_m78647872AACF7C1DADF80CE1355C4FA72E17F91E (void);
// 0x00000478 System.Void UnityEngine.UI.Slider::Set(System.Single,System.Boolean)
extern void Slider_Set_m8407F7245321EAA46ED3E5F6CC9B2F04B9A2FDD5 (void);
// 0x00000479 System.Void UnityEngine.UI.Slider::OnRectTransformDimensionsChange()
extern void Slider_OnRectTransformDimensionsChange_mAD826A7F943BB26DA36F11310D286422ADA5E69A (void);
// 0x0000047A UnityEngine.UI.Slider/Axis UnityEngine.UI.Slider::get_axis()
extern void Slider_get_axis_m1EBD05C9A3C34B1859FEA0192B4569AD45EC7DED (void);
// 0x0000047B System.Boolean UnityEngine.UI.Slider::get_reverseValue()
extern void Slider_get_reverseValue_mE0B463C7174C203F870866456E0EF2AD39D8E834 (void);
// 0x0000047C System.Void UnityEngine.UI.Slider::UpdateVisuals()
extern void Slider_UpdateVisuals_mF0D5A86EE4352DBFE092CA49479F1AAD9212B00E (void);
// 0x0000047D System.Void UnityEngine.UI.Slider::UpdateDrag(UnityEngine.EventSystems.PointerEventData,UnityEngine.Camera)
extern void Slider_UpdateDrag_m704D10BF17D39858193BDD4E946558C520DAB304 (void);
// 0x0000047E System.Boolean UnityEngine.UI.Slider::MayDrag(UnityEngine.EventSystems.PointerEventData)
extern void Slider_MayDrag_mBC1025F6079EF65A36594E8BC2C0647A7F809576 (void);
// 0x0000047F System.Void UnityEngine.UI.Slider::OnPointerDown(UnityEngine.EventSystems.PointerEventData)
extern void Slider_OnPointerDown_m37122B2271F5C26BA2A36ABB70D07B8620A0961F (void);
// 0x00000480 System.Void UnityEngine.UI.Slider::OnDrag(UnityEngine.EventSystems.PointerEventData)
extern void Slider_OnDrag_mC19612CC7EA3D02F3D338ECD6C534B7E402A3856 (void);
// 0x00000481 System.Void UnityEngine.UI.Slider::OnMove(UnityEngine.EventSystems.AxisEventData)
extern void Slider_OnMove_m3FAB8435346C2D8DBA59AB5CC59D569B06CC1500 (void);
// 0x00000482 UnityEngine.UI.Selectable UnityEngine.UI.Slider::FindSelectableOnLeft()
extern void Slider_FindSelectableOnLeft_mB3F6A127C5B758ED1CB9E850FEE3BBE0D4CF3F85 (void);
// 0x00000483 UnityEngine.UI.Selectable UnityEngine.UI.Slider::FindSelectableOnRight()
extern void Slider_FindSelectableOnRight_m109193687A0ADDDF1BA1AEA2E6B49A1399AF18D4 (void);
// 0x00000484 UnityEngine.UI.Selectable UnityEngine.UI.Slider::FindSelectableOnUp()
extern void Slider_FindSelectableOnUp_m3523976BA934C07123A7E28CCE8302CAF321115A (void);
// 0x00000485 UnityEngine.UI.Selectable UnityEngine.UI.Slider::FindSelectableOnDown()
extern void Slider_FindSelectableOnDown_mC50638D5F0EE1A5D2E9322F0C7F88ED33F6161F1 (void);
// 0x00000486 System.Void UnityEngine.UI.Slider::OnInitializePotentialDrag(UnityEngine.EventSystems.PointerEventData)
extern void Slider_OnInitializePotentialDrag_m509A0273020AF65D2DA0DB25EC35FDB748F75DC9 (void);
// 0x00000487 System.Void UnityEngine.UI.Slider::SetDirection(UnityEngine.UI.Slider/Direction,System.Boolean)
extern void Slider_SetDirection_m84FCDE9EB319203D0C5C4069A1BFC40447760101 (void);
// 0x00000488 UnityEngine.Transform UnityEngine.UI.Slider::UnityEngine.UI.ICanvasElement.get_transform()
extern void Slider_UnityEngine_UI_ICanvasElement_get_transform_mA7875ACE1B6F89DDBF76529E25C1E122F027C33E (void);
// 0x00000489 System.Void UnityEngine.UI.Slider/SliderEvent::.ctor()
extern void SliderEvent__ctor_m5FD31BB6BB3FAF583C0A555FCF3733EAD6A6C319 (void);
// 0x0000048A UnityEngine.Sprite UnityEngine.UI.SpriteState::get_highlightedSprite()
extern void SpriteState_get_highlightedSprite_m5D24B628AB2E4DEBF67E094CCA059BDADAB952BB (void);
// 0x0000048B System.Void UnityEngine.UI.SpriteState::set_highlightedSprite(UnityEngine.Sprite)
extern void SpriteState_set_highlightedSprite_mEECDB7C62DE0C6A0B2A7D5D7ADF54EB8CDDB20B0 (void);
// 0x0000048C UnityEngine.Sprite UnityEngine.UI.SpriteState::get_pressedSprite()
extern void SpriteState_get_pressedSprite_m89052B1818D1659DA7E594F218485F1DEB8128BD (void);
// 0x0000048D System.Void UnityEngine.UI.SpriteState::set_pressedSprite(UnityEngine.Sprite)
extern void SpriteState_set_pressedSprite_mD01568B87B1BC1374CCFB5CD190D7CD62A6FDAA3 (void);
// 0x0000048E UnityEngine.Sprite UnityEngine.UI.SpriteState::get_selectedSprite()
extern void SpriteState_get_selectedSprite_m5316836E91F7EB454E953CADD439FF69AA198BA5 (void);
// 0x0000048F System.Void UnityEngine.UI.SpriteState::set_selectedSprite(UnityEngine.Sprite)
extern void SpriteState_set_selectedSprite_m902ACABEC203C0A2408B4ECD7B74C10DFE7BB340 (void);
// 0x00000490 UnityEngine.Sprite UnityEngine.UI.SpriteState::get_disabledSprite()
extern void SpriteState_get_disabledSprite_m6BE5A2231E20BE1600328082B4EFE53EE7F3E12C (void);
// 0x00000491 System.Void UnityEngine.UI.SpriteState::set_disabledSprite(UnityEngine.Sprite)
extern void SpriteState_set_disabledSprite_m624499C245DC34D314FF0326FE5ADCF35DA28E27 (void);
// 0x00000492 System.Boolean UnityEngine.UI.SpriteState::Equals(UnityEngine.UI.SpriteState)
extern void SpriteState_Equals_mAF58D9F36662F5A8196071690175AAFCC4506653 (void);
// 0x00000493 UnityEngine.Material UnityEngine.UI.StencilMaterial::Add(UnityEngine.Material,System.Int32)
extern void StencilMaterial_Add_m84AA68A912ABDADC5187B9E9BC0E4FE6DB4E2220 (void);
// 0x00000494 UnityEngine.Material UnityEngine.UI.StencilMaterial::Add(UnityEngine.Material,System.Int32,UnityEngine.Rendering.StencilOp,UnityEngine.Rendering.CompareFunction,UnityEngine.Rendering.ColorWriteMask)
extern void StencilMaterial_Add_m4FBC1C2732C3B161EE38767ABE2020105E0BF7F4 (void);
// 0x00000495 System.Void UnityEngine.UI.StencilMaterial::LogWarningWhenNotInBatchmode(System.String,UnityEngine.Object)
extern void StencilMaterial_LogWarningWhenNotInBatchmode_mDA6F8CA72D4AAD9C9B480AD2AB4FEFE0C73CD8E3 (void);
// 0x00000496 UnityEngine.Material UnityEngine.UI.StencilMaterial::Add(UnityEngine.Material,System.Int32,UnityEngine.Rendering.StencilOp,UnityEngine.Rendering.CompareFunction,UnityEngine.Rendering.ColorWriteMask,System.Int32,System.Int32)
extern void StencilMaterial_Add_m7BF719F0507970D16D11F47019761391ACE55766 (void);
// 0x00000497 System.Void UnityEngine.UI.StencilMaterial::Remove(UnityEngine.Material)
extern void StencilMaterial_Remove_m828D3D85F213AD5B3E4FE6A230981E9115007412 (void);
// 0x00000498 System.Void UnityEngine.UI.StencilMaterial::ClearAll()
extern void StencilMaterial_ClearAll_mB1977688C5675CB7C32AD21537795223742B7084 (void);
// 0x00000499 System.Void UnityEngine.UI.StencilMaterial::.cctor()
extern void StencilMaterial__cctor_m18A5D42EF758C1549A3DA3C6871A47042E5E547B (void);
// 0x0000049A System.Void UnityEngine.UI.StencilMaterial/MatEntry::.ctor()
extern void MatEntry__ctor_mEB63E7AA0A179AF5EE93EE6DCAC4E91BFAEF2CBA (void);
// 0x0000049B System.Void UnityEngine.UI.Text::.ctor()
extern void Text__ctor_mE28BC6E42B4715F23401A9379C9681867A0631C1 (void);
// 0x0000049C UnityEngine.TextGenerator UnityEngine.UI.Text::get_cachedTextGenerator()
extern void Text_get_cachedTextGenerator_mFC242539F7380F54696D431B126B69DC4EFC821E (void);
// 0x0000049D UnityEngine.TextGenerator UnityEngine.UI.Text::get_cachedTextGeneratorForLayout()
extern void Text_get_cachedTextGeneratorForLayout_m409B96DB358F900C531F543CE351B02B0974A077 (void);
// 0x0000049E UnityEngine.Texture UnityEngine.UI.Text::get_mainTexture()
extern void Text_get_mainTexture_m8EF8E897193467EF8B839C99B5F388AA3241315D (void);
// 0x0000049F System.Void UnityEngine.UI.Text::FontTextureChanged()
extern void Text_FontTextureChanged_mD716EBECCAFA43F8D01D90FF9F869C69E484A763 (void);
// 0x000004A0 UnityEngine.Font UnityEngine.UI.Text::get_font()
extern void Text_get_font_mBF98ED39D5C5081AF14A64170EC3391D206CCAFD (void);
// 0x000004A1 System.Void UnityEngine.UI.Text::set_font(UnityEngine.Font)
extern void Text_set_font_mA0D2999281A72029A5BC7294A886C5674F07DC5F (void);
// 0x000004A2 System.String UnityEngine.UI.Text::get_text()
extern void Text_get_text_mE71474D219ECCE472FD9A08679168E859577A3D1 (void);
// 0x000004A3 System.Void UnityEngine.UI.Text::set_text(System.String)
extern void Text_set_text_m6872BDD62D0904C075F06A19CF5AD96A2B2FE23F (void);
// 0x000004A4 System.Boolean UnityEngine.UI.Text::get_supportRichText()
extern void Text_get_supportRichText_mE5B61670099BB2611BB60D84ADB72C9A54BAC68B (void);
// 0x000004A5 System.Void UnityEngine.UI.Text::set_supportRichText(System.Boolean)
extern void Text_set_supportRichText_mB4DB141150AEBCCADEFFF4EC7A799F85FD075265 (void);
// 0x000004A6 System.Boolean UnityEngine.UI.Text::get_resizeTextForBestFit()
extern void Text_get_resizeTextForBestFit_mA4EEC57C4C188C1598187D1E11A83B950883B011 (void);
// 0x000004A7 System.Void UnityEngine.UI.Text::set_resizeTextForBestFit(System.Boolean)
extern void Text_set_resizeTextForBestFit_m1376BB9FDBAC5571E0F24564E22391AC8EB89A35 (void);
// 0x000004A8 System.Int32 UnityEngine.UI.Text::get_resizeTextMinSize()
extern void Text_get_resizeTextMinSize_mAB17F2DA673C7A3860E6EA0746BFC0C919D5A659 (void);
// 0x000004A9 System.Void UnityEngine.UI.Text::set_resizeTextMinSize(System.Int32)
extern void Text_set_resizeTextMinSize_m1DC5160514ED872A8C572024A94D7EA9D6357655 (void);
// 0x000004AA System.Int32 UnityEngine.UI.Text::get_resizeTextMaxSize()
extern void Text_get_resizeTextMaxSize_m7B61DCEEA4D801C4B8149674B27DBE99098A38E3 (void);
// 0x000004AB System.Void UnityEngine.UI.Text::set_resizeTextMaxSize(System.Int32)
extern void Text_set_resizeTextMaxSize_m25EB2C9302AA9354237A2F56BB3E019192C6015B (void);
// 0x000004AC UnityEngine.TextAnchor UnityEngine.UI.Text::get_alignment()
extern void Text_get_alignment_m01C4D0437DF8A2E05BE4489779A8BEF231A2F2CC (void);
// 0x000004AD System.Void UnityEngine.UI.Text::set_alignment(UnityEngine.TextAnchor)
extern void Text_set_alignment_m9FAD6C1C270FA28C610AB1E07414FBF96403157A (void);
// 0x000004AE System.Boolean UnityEngine.UI.Text::get_alignByGeometry()
extern void Text_get_alignByGeometry_m68F41E942D6BC7AF8F134B3CCDF039A8D3D49DC3 (void);
// 0x000004AF System.Void UnityEngine.UI.Text::set_alignByGeometry(System.Boolean)
extern void Text_set_alignByGeometry_mB427C41097943370E11579A3DA822A3295836CE2 (void);
// 0x000004B0 System.Int32 UnityEngine.UI.Text::get_fontSize()
extern void Text_get_fontSize_m837C0618E78D0FDA972D11DDE3015DC888E93993 (void);
// 0x000004B1 System.Void UnityEngine.UI.Text::set_fontSize(System.Int32)
extern void Text_set_fontSize_m426338B0A2CDA58609028FFD471EF5F2C9F364D4 (void);
// 0x000004B2 UnityEngine.HorizontalWrapMode UnityEngine.UI.Text::get_horizontalOverflow()
extern void Text_get_horizontalOverflow_mC909085F76EF49D62A70A8E503C5BC14C30176F1 (void);
// 0x000004B3 System.Void UnityEngine.UI.Text::set_horizontalOverflow(UnityEngine.HorizontalWrapMode)
extern void Text_set_horizontalOverflow_m10AAFBA65FD7F4B1934B5D628B3E70D75D02FFD6 (void);
// 0x000004B4 UnityEngine.VerticalWrapMode UnityEngine.UI.Text::get_verticalOverflow()
extern void Text_get_verticalOverflow_mEC72BD123A8B12278F6F7B89D29EB9D93D0A97FD (void);
// 0x000004B5 System.Void UnityEngine.UI.Text::set_verticalOverflow(UnityEngine.VerticalWrapMode)
extern void Text_set_verticalOverflow_m72A544DEAE0EBFCCBDE8174DF4C10C903DA8444F (void);
// 0x000004B6 System.Single UnityEngine.UI.Text::get_lineSpacing()
extern void Text_get_lineSpacing_m124405CE023E0E23D9040BAA84318408248DF9CF (void);
// 0x000004B7 System.Void UnityEngine.UI.Text::set_lineSpacing(System.Single)
extern void Text_set_lineSpacing_m36CE565189BAF89DB1DA1E0DE5786521D4763D0E (void);
// 0x000004B8 UnityEngine.FontStyle UnityEngine.UI.Text::get_fontStyle()
extern void Text_get_fontStyle_m7684B5FFE1DC8237FB573A012B482DDB04E3BA47 (void);
// 0x000004B9 System.Void UnityEngine.UI.Text::set_fontStyle(UnityEngine.FontStyle)
extern void Text_set_fontStyle_m5ABEF66BFC88E7E0A950E2817E4978FF472F6C1D (void);
// 0x000004BA System.Single UnityEngine.UI.Text::get_pixelsPerUnit()
extern void Text_get_pixelsPerUnit_mC48AE94D40662DE114A72B870DF77BF7B418925E (void);
// 0x000004BB System.Void UnityEngine.UI.Text::OnEnable()
extern void Text_OnEnable_m183EE6D534BE840F16D23DD36A0C1619AFC905F8 (void);
// 0x000004BC System.Void UnityEngine.UI.Text::OnDisable()
extern void Text_OnDisable_m94F10EBC54572DCD1D3DB7B6C7CBEC8CBE8AF60E (void);
// 0x000004BD System.Void UnityEngine.UI.Text::UpdateGeometry()
extern void Text_UpdateGeometry_mEAEFCA5F05F983DC984FA1497A905A4B2DCF132F (void);
// 0x000004BE System.Void UnityEngine.UI.Text::AssignDefaultFont()
extern void Text_AssignDefaultFont_m475A3C848C9F8ADFBD5438E936E81B618FB4B398 (void);
// 0x000004BF System.Void UnityEngine.UI.Text::AssignDefaultFontIfNecessary()
extern void Text_AssignDefaultFontIfNecessary_mF5167C211C87E6DD62978C938F6521B287F371CF (void);
// 0x000004C0 UnityEngine.TextGenerationSettings UnityEngine.UI.Text::GetGenerationSettings(UnityEngine.Vector2)
extern void Text_GetGenerationSettings_m620E0E5AFB30E3331A0371EB2361F587BB0A1E0F (void);
// 0x000004C1 UnityEngine.Vector2 UnityEngine.UI.Text::GetTextAnchorPivot(UnityEngine.TextAnchor)
extern void Text_GetTextAnchorPivot_mD0734509B028EC6E42800FD73A6CB8476EDF0150 (void);
// 0x000004C2 System.Void UnityEngine.UI.Text::OnPopulateMesh(UnityEngine.UI.VertexHelper)
extern void Text_OnPopulateMesh_m6505569424B120C338EAF6840893E38530185ECE (void);
// 0x000004C3 System.Void UnityEngine.UI.Text::CalculateLayoutInputHorizontal()
extern void Text_CalculateLayoutInputHorizontal_m42B464C2F7C1AE5A0B1311FC5E6BECE1C6EEAC5C (void);
// 0x000004C4 System.Void UnityEngine.UI.Text::CalculateLayoutInputVertical()
extern void Text_CalculateLayoutInputVertical_m7A76D597BFFF1C68C3FEA03E26EE440B9A67E532 (void);
// 0x000004C5 System.Single UnityEngine.UI.Text::get_minWidth()
extern void Text_get_minWidth_m8C6D60E991BAABD25859D3C04AAB6107BAD4F139 (void);
// 0x000004C6 System.Single UnityEngine.UI.Text::get_preferredWidth()
extern void Text_get_preferredWidth_m1624ADC4EB2193885E4EA35D44E6A80C12A436BC (void);
// 0x000004C7 System.Single UnityEngine.UI.Text::get_flexibleWidth()
extern void Text_get_flexibleWidth_m97C2D396445B82CD45260F21CD15CF6F6B279A4A (void);
// 0x000004C8 System.Single UnityEngine.UI.Text::get_minHeight()
extern void Text_get_minHeight_mB6B7E5A4426313C18A7F2CD28F3A7B5CE2DAA6F9 (void);
// 0x000004C9 System.Single UnityEngine.UI.Text::get_preferredHeight()
extern void Text_get_preferredHeight_mF95F444557BFB576AB0E1E876146E03174DA058C (void);
// 0x000004CA System.Single UnityEngine.UI.Text::get_flexibleHeight()
extern void Text_get_flexibleHeight_mC82DCE442BB670E3AC683BA1C660810FB4936FC8 (void);
// 0x000004CB System.Int32 UnityEngine.UI.Text::get_layoutPriority()
extern void Text_get_layoutPriority_m99DD053FCD9F30FFCA40937B2DFBF796B67CBD12 (void);
// 0x000004CC UnityEngine.UI.ToggleGroup UnityEngine.UI.Toggle::get_group()
extern void Toggle_get_group_mE182279EECC97BECAFFA919AA08E4D5B6E9C83FF (void);
// 0x000004CD System.Void UnityEngine.UI.Toggle::set_group(UnityEngine.UI.ToggleGroup)
extern void Toggle_set_group_mEE85FE3AB2ACFF9056DA613239DBACECA588507B (void);
// 0x000004CE System.Void UnityEngine.UI.Toggle::.ctor()
extern void Toggle__ctor_mA84E212B567F21B617B480F90BC335B602523400 (void);
// 0x000004CF System.Void UnityEngine.UI.Toggle::Rebuild(UnityEngine.UI.CanvasUpdate)
extern void Toggle_Rebuild_m101F36A2CD0C4ABD7BAF41262493A0D6ED0B0D3E (void);
// 0x000004D0 System.Void UnityEngine.UI.Toggle::LayoutComplete()
extern void Toggle_LayoutComplete_mD0D33BD5078F2E190A61E306A4CF88E45F80C473 (void);
// 0x000004D1 System.Void UnityEngine.UI.Toggle::GraphicUpdateComplete()
extern void Toggle_GraphicUpdateComplete_mE1636C76DF59E2B1483BB62FF0982EAAEE1185EA (void);
// 0x000004D2 System.Void UnityEngine.UI.Toggle::OnDestroy()
extern void Toggle_OnDestroy_mCC155BA7A5FE311B49536F9C904AC74EC6282E68 (void);
// 0x000004D3 System.Void UnityEngine.UI.Toggle::OnEnable()
extern void Toggle_OnEnable_mA9EF315CBA63011213BBB13A9CA1EB84147DAF0D (void);
// 0x000004D4 System.Void UnityEngine.UI.Toggle::OnDisable()
extern void Toggle_OnDisable_mB32FFD1AAE48A56205E782BC041A5EC86B66B536 (void);
// 0x000004D5 System.Void UnityEngine.UI.Toggle::OnDidApplyAnimationProperties()
extern void Toggle_OnDidApplyAnimationProperties_m1D3922CE86EA2AFB38F3204935BC15DCD534BFB3 (void);
// 0x000004D6 System.Void UnityEngine.UI.Toggle::SetToggleGroup(UnityEngine.UI.ToggleGroup,System.Boolean)
extern void Toggle_SetToggleGroup_mDD819C46310559ADC2346EAEE7BE3BEEF51BB1B1 (void);
// 0x000004D7 System.Boolean UnityEngine.UI.Toggle::get_isOn()
extern void Toggle_get_isOn_m89A609E936CD67F460E336CA8E03C4047BFB6619 (void);
// 0x000004D8 System.Void UnityEngine.UI.Toggle::set_isOn(System.Boolean)
extern void Toggle_set_isOn_m61D6AB073668E87530A9F49D990A3B3631D2061F (void);
// 0x000004D9 System.Void UnityEngine.UI.Toggle::SetIsOnWithoutNotify(System.Boolean)
extern void Toggle_SetIsOnWithoutNotify_mF5B19F1767B9EFF02335E41D3D2DC678642170C2 (void);
// 0x000004DA System.Void UnityEngine.UI.Toggle::Set(System.Boolean,System.Boolean)
extern void Toggle_Set_mA2CCB1FBC23519004E2F47CA0F53CA6E1B368DDE (void);
// 0x000004DB System.Void UnityEngine.UI.Toggle::PlayEffect(System.Boolean)
extern void Toggle_PlayEffect_m728310FF62E7251958CC8D4016C2435AAC9DF0A2 (void);
// 0x000004DC System.Void UnityEngine.UI.Toggle::Start()
extern void Toggle_Start_m3E085820286E51F69BD848C1EA1FCA7DFD07E3E7 (void);
// 0x000004DD System.Void UnityEngine.UI.Toggle::InternalToggle()
extern void Toggle_InternalToggle_mD36F2575F4B2E26641C0E24A73B277E0C8BF25A1 (void);
// 0x000004DE System.Void UnityEngine.UI.Toggle::OnPointerClick(UnityEngine.EventSystems.PointerEventData)
extern void Toggle_OnPointerClick_m2D0D693EE40BDC56482DA6982C3CB42DBACD98E3 (void);
// 0x000004DF System.Void UnityEngine.UI.Toggle::OnSubmit(UnityEngine.EventSystems.BaseEventData)
extern void Toggle_OnSubmit_mCD303693EDD107D676D55CABA07BA43F9328C9B2 (void);
// 0x000004E0 UnityEngine.Transform UnityEngine.UI.Toggle::UnityEngine.UI.ICanvasElement.get_transform()
extern void Toggle_UnityEngine_UI_ICanvasElement_get_transform_mD7C00596C9A48C3A7C40E285DFFF9C2B255221C2 (void);
// 0x000004E1 System.Void UnityEngine.UI.Toggle/ToggleEvent::.ctor()
extern void ToggleEvent__ctor_m8983544B67193810F8BAA820B2C408251CBEF145 (void);
// 0x000004E2 System.Boolean UnityEngine.UI.ToggleGroup::get_allowSwitchOff()
extern void ToggleGroup_get_allowSwitchOff_mA6724BF0B3965330FE892FB9E144D761ACFA7364 (void);
// 0x000004E3 System.Void UnityEngine.UI.ToggleGroup::set_allowSwitchOff(System.Boolean)
extern void ToggleGroup_set_allowSwitchOff_m30C71C353E740F9B3F9641689A4ABA4AB8BAC9C3 (void);
// 0x000004E4 System.Void UnityEngine.UI.ToggleGroup::.ctor()
extern void ToggleGroup__ctor_mED87CABB1682380A925DCC8FA41C739ED6ADF3EE (void);
// 0x000004E5 System.Void UnityEngine.UI.ToggleGroup::Start()
extern void ToggleGroup_Start_mA5D0C8F6437723E98C53149716EA28C7984BDDA7 (void);
// 0x000004E6 System.Void UnityEngine.UI.ToggleGroup::OnEnable()
extern void ToggleGroup_OnEnable_m5679531D85D1CAC371A71AC5B1E980248A01F038 (void);
// 0x000004E7 System.Void UnityEngine.UI.ToggleGroup::ValidateToggleIsInGroup(UnityEngine.UI.Toggle)
extern void ToggleGroup_ValidateToggleIsInGroup_mA9CAD4C4345BE7AE18351AB4F31D1574A900280C (void);
// 0x000004E8 System.Void UnityEngine.UI.ToggleGroup::NotifyToggleOn(UnityEngine.UI.Toggle,System.Boolean)
extern void ToggleGroup_NotifyToggleOn_m0676292BE46CBE477DAF139D9DABCE5DB72F7F45 (void);
// 0x000004E9 System.Void UnityEngine.UI.ToggleGroup::UnregisterToggle(UnityEngine.UI.Toggle)
extern void ToggleGroup_UnregisterToggle_m6A07803166E901CCDE4F23FCED1BD76CBB002307 (void);
// 0x000004EA System.Void UnityEngine.UI.ToggleGroup::RegisterToggle(UnityEngine.UI.Toggle)
extern void ToggleGroup_RegisterToggle_mADE82548BE13A13E9FDD00F488471D3416A97214 (void);
// 0x000004EB System.Void UnityEngine.UI.ToggleGroup::EnsureValidState()
extern void ToggleGroup_EnsureValidState_m5A8B88CF91EEB8F7E7DECB87261EAFF5A556778B (void);
// 0x000004EC System.Boolean UnityEngine.UI.ToggleGroup::AnyTogglesOn()
extern void ToggleGroup_AnyTogglesOn_mCE714D4DBDD9CF56D41C830719FCFC24008C1700 (void);
// 0x000004ED System.Collections.Generic.IEnumerable`1<UnityEngine.UI.Toggle> UnityEngine.UI.ToggleGroup::ActiveToggles()
extern void ToggleGroup_ActiveToggles_m04CAF25D2C9DE5F310090D63B9841963954BF2BF (void);
// 0x000004EE UnityEngine.UI.Toggle UnityEngine.UI.ToggleGroup::GetFirstActiveToggle()
extern void ToggleGroup_GetFirstActiveToggle_m07251AA447A7F06B082B685CD44F5C0465A323BA (void);
// 0x000004EF System.Void UnityEngine.UI.ToggleGroup::SetAllTogglesOff(System.Boolean)
extern void ToggleGroup_SetAllTogglesOff_m770745001C6B4553805F3E333084F5DFCB08B78F (void);
// 0x000004F0 System.Void UnityEngine.UI.ToggleGroup/<>c::.cctor()
extern void U3CU3Ec__cctor_m878A0225FF0D038AD88F4E89CB4DACC057132A26 (void);
// 0x000004F1 System.Void UnityEngine.UI.ToggleGroup/<>c::.ctor()
extern void U3CU3Ec__ctor_m71A650578043739A4182051BA48B2792FA8C287F (void);
// 0x000004F2 System.Boolean UnityEngine.UI.ToggleGroup/<>c::<AnyTogglesOn>b__13_0(UnityEngine.UI.Toggle)
extern void U3CU3Ec_U3CAnyTogglesOnU3Eb__13_0_m060E207CF61E772B8A8C9B5262EA8867E086B397 (void);
// 0x000004F3 System.Boolean UnityEngine.UI.ToggleGroup/<>c::<ActiveToggles>b__14_0(UnityEngine.UI.Toggle)
extern void U3CU3Ec_U3CActiveTogglesU3Eb__14_0_m9567251B779C881881B16EB6ADEF9D7E71CD3B0D (void);
// 0x000004F4 System.Void UnityEngine.UI.ReflectionMethodsCache::.ctor()
extern void ReflectionMethodsCache__ctor_m2BBCC7AC457DD7CB3836B01B5307F8B6285CADB3 (void);
// 0x000004F5 UnityEngine.UI.ReflectionMethodsCache UnityEngine.UI.ReflectionMethodsCache::get_Singleton()
extern void ReflectionMethodsCache_get_Singleton_m77EFD7AC0043333E09987BD601113B810453C42B (void);
// 0x000004F6 System.Void UnityEngine.UI.ReflectionMethodsCache/Raycast3DCallback::.ctor(System.Object,System.IntPtr)
extern void Raycast3DCallback__ctor_m8F06E2216CD1CCB88B9B94197226CE3F1EC67310 (void);
// 0x000004F7 System.Boolean UnityEngine.UI.ReflectionMethodsCache/Raycast3DCallback::Invoke(UnityEngine.Ray,UnityEngine.RaycastHit&,System.Single,System.Int32)
extern void Raycast3DCallback_Invoke_m9CDA4EB17B5A46853DEBC894E610B5C8FCE23415 (void);
// 0x000004F8 System.IAsyncResult UnityEngine.UI.ReflectionMethodsCache/Raycast3DCallback::BeginInvoke(UnityEngine.Ray,UnityEngine.RaycastHit&,System.Single,System.Int32,System.AsyncCallback,System.Object)
extern void Raycast3DCallback_BeginInvoke_m2FED0375CEC6BC3E6545ED6A19E88D7913AB2E6F (void);
// 0x000004F9 System.Boolean UnityEngine.UI.ReflectionMethodsCache/Raycast3DCallback::EndInvoke(UnityEngine.RaycastHit&,System.IAsyncResult)
extern void Raycast3DCallback_EndInvoke_m4DB350E572F75C4D0C92DE38EC9B8B0368464871 (void);
// 0x000004FA System.Void UnityEngine.UI.ReflectionMethodsCache/RaycastAllCallback::.ctor(System.Object,System.IntPtr)
extern void RaycastAllCallback__ctor_m971EC206409480AB580913F8E1E7E9850DC0DB03 (void);
// 0x000004FB UnityEngine.RaycastHit[] UnityEngine.UI.ReflectionMethodsCache/RaycastAllCallback::Invoke(UnityEngine.Ray,System.Single,System.Int32)
extern void RaycastAllCallback_Invoke_mB30319766AF5F0D5145A6C0AFFEA829A31A5D4B7 (void);
// 0x000004FC System.IAsyncResult UnityEngine.UI.ReflectionMethodsCache/RaycastAllCallback::BeginInvoke(UnityEngine.Ray,System.Single,System.Int32,System.AsyncCallback,System.Object)
extern void RaycastAllCallback_BeginInvoke_mFD486859C455F0E5198BC58E3505CD12ACDAC0AA (void);
// 0x000004FD UnityEngine.RaycastHit[] UnityEngine.UI.ReflectionMethodsCache/RaycastAllCallback::EndInvoke(System.IAsyncResult)
extern void RaycastAllCallback_EndInvoke_mBF07366FEF9002D0A44A4E8982BA201699C864CE (void);
// 0x000004FE System.Void UnityEngine.UI.ReflectionMethodsCache/GetRaycastNonAllocCallback::.ctor(System.Object,System.IntPtr)
extern void GetRaycastNonAllocCallback__ctor_mBF3B05A56B530A13FFE0C8F66A12A94230598787 (void);
// 0x000004FF System.Int32 UnityEngine.UI.ReflectionMethodsCache/GetRaycastNonAllocCallback::Invoke(UnityEngine.Ray,UnityEngine.RaycastHit[],System.Single,System.Int32)
extern void GetRaycastNonAllocCallback_Invoke_m36411365E9622819DAB93D0BB0F169FEE99F07D9 (void);
// 0x00000500 System.IAsyncResult UnityEngine.UI.ReflectionMethodsCache/GetRaycastNonAllocCallback::BeginInvoke(UnityEngine.Ray,UnityEngine.RaycastHit[],System.Single,System.Int32,System.AsyncCallback,System.Object)
extern void GetRaycastNonAllocCallback_BeginInvoke_m381F75A2BBE062F5DFB3B910D3B3066CA512D024 (void);
// 0x00000501 System.Int32 UnityEngine.UI.ReflectionMethodsCache/GetRaycastNonAllocCallback::EndInvoke(System.IAsyncResult)
extern void GetRaycastNonAllocCallback_EndInvoke_m0A8CB6C1DBFAD95A2E3AC7686E161E1D6057F52D (void);
// 0x00000502 System.Void UnityEngine.UI.ReflectionMethodsCache/Raycast2DCallback::.ctor(System.Object,System.IntPtr)
extern void Raycast2DCallback__ctor_m4C15F69C429322DFC4BDA9A9E99A500D4C9718BB (void);
// 0x00000503 UnityEngine.RaycastHit2D UnityEngine.UI.ReflectionMethodsCache/Raycast2DCallback::Invoke(UnityEngine.Vector2,UnityEngine.Vector2,System.Single,System.Int32)
extern void Raycast2DCallback_Invoke_m36A82ED39B674FC0D8D80D62948B729CC244C366 (void);
// 0x00000504 System.IAsyncResult UnityEngine.UI.ReflectionMethodsCache/Raycast2DCallback::BeginInvoke(UnityEngine.Vector2,UnityEngine.Vector2,System.Single,System.Int32,System.AsyncCallback,System.Object)
extern void Raycast2DCallback_BeginInvoke_m2135AC8F9004783AB5F6E92DFA11B187CBBC3DE8 (void);
// 0x00000505 UnityEngine.RaycastHit2D UnityEngine.UI.ReflectionMethodsCache/Raycast2DCallback::EndInvoke(System.IAsyncResult)
extern void Raycast2DCallback_EndInvoke_mC51CF38067DEC9BBB94782FF1BB129A19EC602C4 (void);
// 0x00000506 System.Void UnityEngine.UI.ReflectionMethodsCache/GetRayIntersectionAllCallback::.ctor(System.Object,System.IntPtr)
extern void GetRayIntersectionAllCallback__ctor_mF6F153CE75C4728D934A766700346C408088ECFF (void);
// 0x00000507 UnityEngine.RaycastHit2D[] UnityEngine.UI.ReflectionMethodsCache/GetRayIntersectionAllCallback::Invoke(UnityEngine.Ray,System.Single,System.Int32)
extern void GetRayIntersectionAllCallback_Invoke_m917AA4108EBDC724AFEF39BFD06A586B7461F497 (void);
// 0x00000508 System.IAsyncResult UnityEngine.UI.ReflectionMethodsCache/GetRayIntersectionAllCallback::BeginInvoke(UnityEngine.Ray,System.Single,System.Int32,System.AsyncCallback,System.Object)
extern void GetRayIntersectionAllCallback_BeginInvoke_m9C824E08C6261803AAE7A1B39D7525A4B748679E (void);
// 0x00000509 UnityEngine.RaycastHit2D[] UnityEngine.UI.ReflectionMethodsCache/GetRayIntersectionAllCallback::EndInvoke(System.IAsyncResult)
extern void GetRayIntersectionAllCallback_EndInvoke_mE9CE6394D3F2C7C56DE578882666ADBFFC729965 (void);
// 0x0000050A System.Void UnityEngine.UI.ReflectionMethodsCache/GetRayIntersectionAllNonAllocCallback::.ctor(System.Object,System.IntPtr)
extern void GetRayIntersectionAllNonAllocCallback__ctor_mAF9F997ABE4C3EECD5A402BAB7CB30B19CC50F9C (void);
// 0x0000050B System.Int32 UnityEngine.UI.ReflectionMethodsCache/GetRayIntersectionAllNonAllocCallback::Invoke(UnityEngine.Ray,UnityEngine.RaycastHit2D[],System.Single,System.Int32)
extern void GetRayIntersectionAllNonAllocCallback_Invoke_mFAA36E9AF362DC72204EEF53B28DBFC3367D09A7 (void);
// 0x0000050C System.IAsyncResult UnityEngine.UI.ReflectionMethodsCache/GetRayIntersectionAllNonAllocCallback::BeginInvoke(UnityEngine.Ray,UnityEngine.RaycastHit2D[],System.Single,System.Int32,System.AsyncCallback,System.Object)
extern void GetRayIntersectionAllNonAllocCallback_BeginInvoke_mE93D1099CC919A75041D25C692B4BA8FB1F66061 (void);
// 0x0000050D System.Int32 UnityEngine.UI.ReflectionMethodsCache/GetRayIntersectionAllNonAllocCallback::EndInvoke(System.IAsyncResult)
extern void GetRayIntersectionAllNonAllocCallback_EndInvoke_m0C4A807380DA32E16F797AF910C2A69C06D1352C (void);
// 0x0000050E System.Void UnityEngine.UI.VertexHelper::.ctor()
extern void VertexHelper__ctor_mE8DE438637116EA7AF8180E10E7641FD00DB64A5 (void);
// 0x0000050F System.Void UnityEngine.UI.VertexHelper::.ctor(UnityEngine.Mesh)
extern void VertexHelper__ctor_mE42FAE63F4A3200C38ACFDD9C3F601FDC7E258F8 (void);
// 0x00000510 System.Void UnityEngine.UI.VertexHelper::InitializeListIfRequired()
extern void VertexHelper_InitializeListIfRequired_mC7180B010A6DCC7C1115A33D29B8E00B92DB2542 (void);
// 0x00000511 System.Void UnityEngine.UI.VertexHelper::Dispose()
extern void VertexHelper_Dispose_mAA41704ED960A368DA8BFB8D1506A3969A033653 (void);
// 0x00000512 System.Void UnityEngine.UI.VertexHelper::Clear()
extern void VertexHelper_Clear_mB19E51AD5AF1C04CB2C6E6A272D032D651EC40F5 (void);
// 0x00000513 System.Int32 UnityEngine.UI.VertexHelper::get_currentVertCount()
extern void VertexHelper_get_currentVertCount_m45BFEBD6FCB7DF3BF9F76946D6002BDC58B173A4 (void);
// 0x00000514 System.Int32 UnityEngine.UI.VertexHelper::get_currentIndexCount()
extern void VertexHelper_get_currentIndexCount_mF409C3D4A6786E64AC4E8EC0D6D97E27597A900C (void);
// 0x00000515 System.Void UnityEngine.UI.VertexHelper::PopulateUIVertex(UnityEngine.UIVertex&,System.Int32)
extern void VertexHelper_PopulateUIVertex_m48FF05C38D56529E18A360D629F4842BE5D050BE (void);
// 0x00000516 System.Void UnityEngine.UI.VertexHelper::SetUIVertex(UnityEngine.UIVertex,System.Int32)
extern void VertexHelper_SetUIVertex_m539A518867E7872E0893715AD372DC9A06334FD9 (void);
// 0x00000517 System.Void UnityEngine.UI.VertexHelper::FillMesh(UnityEngine.Mesh)
extern void VertexHelper_FillMesh_m524F00287F0A0C7683E2CC7768A77B5755544A0E (void);
// 0x00000518 System.Void UnityEngine.UI.VertexHelper::AddVert(UnityEngine.Vector3,UnityEngine.Color32,UnityEngine.Vector4,UnityEngine.Vector4,UnityEngine.Vector4,UnityEngine.Vector4,UnityEngine.Vector3,UnityEngine.Vector4)
extern void VertexHelper_AddVert_mC7596EEC59384AB7BFD12CA6F8350ACDC5BF5E56 (void);
// 0x00000519 System.Void UnityEngine.UI.VertexHelper::AddVert(UnityEngine.Vector3,UnityEngine.Color32,UnityEngine.Vector4,UnityEngine.Vector4,UnityEngine.Vector3,UnityEngine.Vector4)
extern void VertexHelper_AddVert_m5765AC8F13C86709B2EFEC613D492963BE1E1198 (void);
// 0x0000051A System.Void UnityEngine.UI.VertexHelper::AddVert(UnityEngine.Vector3,UnityEngine.Color32,UnityEngine.Vector4)
extern void VertexHelper_AddVert_m2187D76DC2CE7E9AF69280424660739858901287 (void);
// 0x0000051B System.Void UnityEngine.UI.VertexHelper::AddVert(UnityEngine.UIVertex)
extern void VertexHelper_AddVert_mB65D778E8E3C6916CDFF5382208890882C3031BA (void);
// 0x0000051C System.Void UnityEngine.UI.VertexHelper::AddTriangle(System.Int32,System.Int32,System.Int32)
extern void VertexHelper_AddTriangle_mBA2504734E550C672A33168BE119D76D92C788A4 (void);
// 0x0000051D System.Void UnityEngine.UI.VertexHelper::AddUIVertexQuad(UnityEngine.UIVertex[])
extern void VertexHelper_AddUIVertexQuad_m6AC21081F2A5A48D22BC3497E527D0A9AB8278B0 (void);
// 0x0000051E System.Void UnityEngine.UI.VertexHelper::AddUIVertexStream(System.Collections.Generic.List`1<UnityEngine.UIVertex>,System.Collections.Generic.List`1<System.Int32>)
extern void VertexHelper_AddUIVertexStream_m213E27491ADDA2C603D40730E34F3AA6C5E7757D (void);
// 0x0000051F System.Void UnityEngine.UI.VertexHelper::AddUIVertexTriangleStream(System.Collections.Generic.List`1<UnityEngine.UIVertex>)
extern void VertexHelper_AddUIVertexTriangleStream_m29A217271BF2B3D3D60B7CBDA4114C7BB40C2841 (void);
// 0x00000520 System.Void UnityEngine.UI.VertexHelper::GetUIVertexStream(System.Collections.Generic.List`1<UnityEngine.UIVertex>)
extern void VertexHelper_GetUIVertexStream_m87D56EB5559CCCA150F68B1DD660FF4154CACBCE (void);
// 0x00000521 System.Void UnityEngine.UI.VertexHelper::.cctor()
extern void VertexHelper__cctor_mEED5FDE0E235482F4F4A551E114358266128E0CC (void);
// 0x00000522 System.Void UnityEngine.UI.BaseVertexEffect::ModifyVertices(System.Collections.Generic.List`1<UnityEngine.UIVertex>)
// 0x00000523 System.Void UnityEngine.UI.BaseVertexEffect::.ctor()
extern void BaseVertexEffect__ctor_m9458015A3EDD3D42F821F8608D0E595B85A70B6C (void);
// 0x00000524 UnityEngine.UI.Graphic UnityEngine.UI.BaseMeshEffect::get_graphic()
extern void BaseMeshEffect_get_graphic_mE8226BAC46FDB49681BEAD2DE8A4EE3CEC18FF04 (void);
// 0x00000525 System.Void UnityEngine.UI.BaseMeshEffect::OnEnable()
extern void BaseMeshEffect_OnEnable_m74592558CD0F70DC35EEFCBC1E23F84493CD77F7 (void);
// 0x00000526 System.Void UnityEngine.UI.BaseMeshEffect::OnDisable()
extern void BaseMeshEffect_OnDisable_mE005F7A15BFE7127D274717C3C482561481D3603 (void);
// 0x00000527 System.Void UnityEngine.UI.BaseMeshEffect::OnDidApplyAnimationProperties()
extern void BaseMeshEffect_OnDidApplyAnimationProperties_m981407A626B008820D9554F3778DAA8E7959451E (void);
// 0x00000528 System.Void UnityEngine.UI.BaseMeshEffect::ModifyMesh(UnityEngine.Mesh)
extern void BaseMeshEffect_ModifyMesh_mD98C4CF227E0EF63BD031824AABC5F3C1AB7BDEC (void);
// 0x00000529 System.Void UnityEngine.UI.BaseMeshEffect::ModifyMesh(UnityEngine.UI.VertexHelper)
// 0x0000052A System.Void UnityEngine.UI.BaseMeshEffect::.ctor()
extern void BaseMeshEffect__ctor_mFFF23FD89B32150DAC512C556A1CCF563D062427 (void);
// 0x0000052B System.Void UnityEngine.UI.IVertexModifier::ModifyVertices(System.Collections.Generic.List`1<UnityEngine.UIVertex>)
// 0x0000052C System.Void UnityEngine.UI.IMeshModifier::ModifyMesh(UnityEngine.Mesh)
// 0x0000052D System.Void UnityEngine.UI.IMeshModifier::ModifyMesh(UnityEngine.UI.VertexHelper)
// 0x0000052E System.Void UnityEngine.UI.Outline::.ctor()
extern void Outline__ctor_m1E8EF7C85B52E0DE3D67506C8F7C118A1E2B3552 (void);
// 0x0000052F System.Void UnityEngine.UI.Outline::ModifyMesh(UnityEngine.UI.VertexHelper)
extern void Outline_ModifyMesh_mC6D402BD2D65E27A163B68676F3102AF03BFC4C9 (void);
// 0x00000530 System.Void UnityEngine.UI.PositionAsUV1::.ctor()
extern void PositionAsUV1__ctor_mE24D2DE5032BCAE8B065B8D4CAA90BA3256EB382 (void);
// 0x00000531 System.Void UnityEngine.UI.PositionAsUV1::ModifyMesh(UnityEngine.UI.VertexHelper)
extern void PositionAsUV1_ModifyMesh_mFE5C4211D991E7A292A29DB85BFBAF3C31282F90 (void);
// 0x00000532 System.Void UnityEngine.UI.Shadow::.ctor()
extern void Shadow__ctor_mDE7F89B477692F7FF0CCE6B8CE01A63D9942291E (void);
// 0x00000533 UnityEngine.Color UnityEngine.UI.Shadow::get_effectColor()
extern void Shadow_get_effectColor_m6E7751BB8792C85BE9DAD0D133D787317D9CF59B (void);
// 0x00000534 System.Void UnityEngine.UI.Shadow::set_effectColor(UnityEngine.Color)
extern void Shadow_set_effectColor_mCCC5DB6B7D09C5DEE0C677DEB3B9B0C578F05AF1 (void);
// 0x00000535 UnityEngine.Vector2 UnityEngine.UI.Shadow::get_effectDistance()
extern void Shadow_get_effectDistance_mA87EB50066AFEBC13C69D27376E50033930FA58F (void);
// 0x00000536 System.Void UnityEngine.UI.Shadow::set_effectDistance(UnityEngine.Vector2)
extern void Shadow_set_effectDistance_m5E7B565C41CF2A8C84EC98319ACBF5C8E1FE47DA (void);
// 0x00000537 System.Boolean UnityEngine.UI.Shadow::get_useGraphicAlpha()
extern void Shadow_get_useGraphicAlpha_mD2A88F78B7B2E25905D1750788B0DFA3082AC616 (void);
// 0x00000538 System.Void UnityEngine.UI.Shadow::set_useGraphicAlpha(System.Boolean)
extern void Shadow_set_useGraphicAlpha_m70CCAE5D643B2373A5ADC8BD04031D3CBF0AF722 (void);
// 0x00000539 System.Void UnityEngine.UI.Shadow::ApplyShadowZeroAlloc(System.Collections.Generic.List`1<UnityEngine.UIVertex>,UnityEngine.Color32,System.Int32,System.Int32,System.Single,System.Single)
extern void Shadow_ApplyShadowZeroAlloc_m010AE345D731FC53595A62CF8D0B401C2D6F4B58 (void);
// 0x0000053A System.Void UnityEngine.UI.Shadow::ApplyShadow(System.Collections.Generic.List`1<UnityEngine.UIVertex>,UnityEngine.Color32,System.Int32,System.Int32,System.Single,System.Single)
extern void Shadow_ApplyShadow_mB615BBD368431C63B1407CAFD7DD32BE023E543E (void);
// 0x0000053B System.Void UnityEngine.UI.Shadow::ModifyMesh(UnityEngine.UI.VertexHelper)
extern void Shadow_ModifyMesh_m7201FBFE56F97B440215E92064BFC59F00ACA9C6 (void);
// 0x0000053C System.Void UnityEngine.UI.Collections.IndexedSet`1::Add(T)
// 0x0000053D System.Void UnityEngine.UI.Collections.IndexedSet`1::Add(T,System.Boolean)
// 0x0000053E System.Boolean UnityEngine.UI.Collections.IndexedSet`1::AddUnique(T,System.Boolean)
// 0x0000053F System.Boolean UnityEngine.UI.Collections.IndexedSet`1::EnableItem(T)
// 0x00000540 System.Boolean UnityEngine.UI.Collections.IndexedSet`1::DisableItem(T)
// 0x00000541 System.Boolean UnityEngine.UI.Collections.IndexedSet`1::Remove(T)
// 0x00000542 System.Collections.Generic.IEnumerator`1<T> UnityEngine.UI.Collections.IndexedSet`1::GetEnumerator()
// 0x00000543 System.Collections.IEnumerator UnityEngine.UI.Collections.IndexedSet`1::System.Collections.IEnumerable.GetEnumerator()
// 0x00000544 System.Void UnityEngine.UI.Collections.IndexedSet`1::Clear()
// 0x00000545 System.Boolean UnityEngine.UI.Collections.IndexedSet`1::Contains(T)
// 0x00000546 System.Void UnityEngine.UI.Collections.IndexedSet`1::CopyTo(T[],System.Int32)
// 0x00000547 System.Int32 UnityEngine.UI.Collections.IndexedSet`1::get_Count()
// 0x00000548 System.Int32 UnityEngine.UI.Collections.IndexedSet`1::get_Capacity()
// 0x00000549 System.Boolean UnityEngine.UI.Collections.IndexedSet`1::get_IsReadOnly()
// 0x0000054A System.Int32 UnityEngine.UI.Collections.IndexedSet`1::IndexOf(T)
// 0x0000054B System.Void UnityEngine.UI.Collections.IndexedSet`1::Insert(System.Int32,T)
// 0x0000054C System.Void UnityEngine.UI.Collections.IndexedSet`1::RemoveAt(System.Int32)
// 0x0000054D System.Void UnityEngine.UI.Collections.IndexedSet`1::Swap(System.Int32,System.Int32)
// 0x0000054E T UnityEngine.UI.Collections.IndexedSet`1::get_Item(System.Int32)
// 0x0000054F System.Void UnityEngine.UI.Collections.IndexedSet`1::set_Item(System.Int32,T)
// 0x00000550 System.Void UnityEngine.UI.Collections.IndexedSet`1::RemoveAll(System.Predicate`1<T>)
// 0x00000551 System.Void UnityEngine.UI.Collections.IndexedSet`1::Sort(System.Comparison`1<T>)
// 0x00000552 System.Void UnityEngine.UI.Collections.IndexedSet`1::.ctor()
// 0x00000553 System.Void UnityEngine.UI.CoroutineTween.ITweenValue::TweenValue(System.Single)
// 0x00000554 System.Boolean UnityEngine.UI.CoroutineTween.ITweenValue::get_ignoreTimeScale()
// 0x00000555 System.Single UnityEngine.UI.CoroutineTween.ITweenValue::get_duration()
// 0x00000556 System.Boolean UnityEngine.UI.CoroutineTween.ITweenValue::ValidTarget()
// 0x00000557 UnityEngine.Color UnityEngine.UI.CoroutineTween.ColorTween::get_startColor()
extern void ColorTween_get_startColor_m9E33FB5C5F76BCF49A3B20201CD8006DBFB46012 (void);
// 0x00000558 System.Void UnityEngine.UI.CoroutineTween.ColorTween::set_startColor(UnityEngine.Color)
extern void ColorTween_set_startColor_mD22349343421BD44F0C31E537718ED53BE4850DA (void);
// 0x00000559 UnityEngine.Color UnityEngine.UI.CoroutineTween.ColorTween::get_targetColor()
extern void ColorTween_get_targetColor_m240A7018BDC3B44AB44BA674AA16C39960BC23FF (void);
// 0x0000055A System.Void UnityEngine.UI.CoroutineTween.ColorTween::set_targetColor(UnityEngine.Color)
extern void ColorTween_set_targetColor_m7D8E74B32AC3A9C17C3192096003B12A1500D749 (void);
// 0x0000055B UnityEngine.UI.CoroutineTween.ColorTween/ColorTweenMode UnityEngine.UI.CoroutineTween.ColorTween::get_tweenMode()
extern void ColorTween_get_tweenMode_m06B83FB6E45A807F83FDD762A8241D478FD13F8B (void);
// 0x0000055C System.Void UnityEngine.UI.CoroutineTween.ColorTween::set_tweenMode(UnityEngine.UI.CoroutineTween.ColorTween/ColorTweenMode)
extern void ColorTween_set_tweenMode_m105EEB49F6632D6D105C63DA9919385233A5D4DE (void);
// 0x0000055D System.Single UnityEngine.UI.CoroutineTween.ColorTween::get_duration()
extern void ColorTween_get_duration_m40D8F08C13FF2FE7583746934C6A017A93398548 (void);
// 0x0000055E System.Void UnityEngine.UI.CoroutineTween.ColorTween::set_duration(System.Single)
extern void ColorTween_set_duration_m1C278AB5A90B5C108CEB4870CAC90A9A9EAC19CB (void);
// 0x0000055F System.Boolean UnityEngine.UI.CoroutineTween.ColorTween::get_ignoreTimeScale()
extern void ColorTween_get_ignoreTimeScale_mEDB15A4ADE3A0B9487D240964A7571247F974708 (void);
// 0x00000560 System.Void UnityEngine.UI.CoroutineTween.ColorTween::set_ignoreTimeScale(System.Boolean)
extern void ColorTween_set_ignoreTimeScale_m060FF3CED06F73EA1F555A37999D61DC58F99927 (void);
// 0x00000561 System.Void UnityEngine.UI.CoroutineTween.ColorTween::TweenValue(System.Single)
extern void ColorTween_TweenValue_mF5CBA9BDE7F73E47F9CF26DC4EC2419694049860 (void);
// 0x00000562 System.Void UnityEngine.UI.CoroutineTween.ColorTween::AddOnChangedCallback(UnityEngine.Events.UnityAction`1<UnityEngine.Color>)
extern void ColorTween_AddOnChangedCallback_mAC2856A154604B4B6721DAC185B819A98D6F7438 (void);
// 0x00000563 System.Boolean UnityEngine.UI.CoroutineTween.ColorTween::GetIgnoreTimescale()
extern void ColorTween_GetIgnoreTimescale_m679C83012235779A37DCCD0AA75CD6B0DAE5BCFA (void);
// 0x00000564 System.Single UnityEngine.UI.CoroutineTween.ColorTween::GetDuration()
extern void ColorTween_GetDuration_mC40D6776769FDB79C7ADC42D59F059A2A9AE2F66 (void);
// 0x00000565 System.Boolean UnityEngine.UI.CoroutineTween.ColorTween::ValidTarget()
extern void ColorTween_ValidTarget_m1D7A682CE00048FAF1A3BDD55EB76F44C9122B4D (void);
// 0x00000566 System.Void UnityEngine.UI.CoroutineTween.ColorTween/ColorTweenCallback::.ctor()
extern void ColorTweenCallback__ctor_mFEB49A6A1ABACFE2351A63060F786B762E2DC6B9 (void);
// 0x00000567 System.Single UnityEngine.UI.CoroutineTween.FloatTween::get_startValue()
extern void FloatTween_get_startValue_mCA121483CCF4C8F10991BB3306E3F2769EBB3A3C (void);
// 0x00000568 System.Void UnityEngine.UI.CoroutineTween.FloatTween::set_startValue(System.Single)
extern void FloatTween_set_startValue_m43B55D74B7B34D9C32439D6004F306BFA18E4A1A (void);
// 0x00000569 System.Single UnityEngine.UI.CoroutineTween.FloatTween::get_targetValue()
extern void FloatTween_get_targetValue_m6EFBD9EAB206F145959832269DC24C4B68FEE6B1 (void);
// 0x0000056A System.Void UnityEngine.UI.CoroutineTween.FloatTween::set_targetValue(System.Single)
extern void FloatTween_set_targetValue_m4AE44CE862797E898CDE00A1B7D6A33CE0AFDCFB (void);
// 0x0000056B System.Single UnityEngine.UI.CoroutineTween.FloatTween::get_duration()
extern void FloatTween_get_duration_mB1496D38A618FF8282205FD3AA14CA9C6D76454D (void);
// 0x0000056C System.Void UnityEngine.UI.CoroutineTween.FloatTween::set_duration(System.Single)
extern void FloatTween_set_duration_m40E10A7B796B4B54FFB8DA3889B09557BEC98456 (void);
// 0x0000056D System.Boolean UnityEngine.UI.CoroutineTween.FloatTween::get_ignoreTimeScale()
extern void FloatTween_get_ignoreTimeScale_m6F6BDCBD59C19E68572370F9FE3D7373B4212B3B (void);
// 0x0000056E System.Void UnityEngine.UI.CoroutineTween.FloatTween::set_ignoreTimeScale(System.Boolean)
extern void FloatTween_set_ignoreTimeScale_m09041A4110040F9C86D24E1B4DED6E6B7FB206A8 (void);
// 0x0000056F System.Void UnityEngine.UI.CoroutineTween.FloatTween::TweenValue(System.Single)
extern void FloatTween_TweenValue_mE51344369BDDA58E9C3AEC62E1B1C1AC0349278E (void);
// 0x00000570 System.Void UnityEngine.UI.CoroutineTween.FloatTween::AddOnChangedCallback(UnityEngine.Events.UnityAction`1<System.Single>)
extern void FloatTween_AddOnChangedCallback_m13B1FFCAD78C7E690E70704311B20D5BB67D8224 (void);
// 0x00000571 System.Boolean UnityEngine.UI.CoroutineTween.FloatTween::GetIgnoreTimescale()
extern void FloatTween_GetIgnoreTimescale_mA2463285D4524B70A46776FC60C4F939B3BCD045 (void);
// 0x00000572 System.Single UnityEngine.UI.CoroutineTween.FloatTween::GetDuration()
extern void FloatTween_GetDuration_m3E981D91F15C36ED6F241117665E703F2BD2A6D4 (void);
// 0x00000573 System.Boolean UnityEngine.UI.CoroutineTween.FloatTween::ValidTarget()
extern void FloatTween_ValidTarget_m36EABC84C8FEFF79EBAC8E9C3C7A394F1377E311 (void);
// 0x00000574 System.Void UnityEngine.UI.CoroutineTween.FloatTween/FloatTweenCallback::.ctor()
extern void FloatTweenCallback__ctor_m3BD06E1999E88B4BAC7627A04B37300331CA210A (void);
// 0x00000575 System.Collections.IEnumerator UnityEngine.UI.CoroutineTween.TweenRunner`1::Start(T)
// 0x00000576 System.Void UnityEngine.UI.CoroutineTween.TweenRunner`1::Init(UnityEngine.MonoBehaviour)
// 0x00000577 System.Void UnityEngine.UI.CoroutineTween.TweenRunner`1::StartTween(T)
// 0x00000578 System.Void UnityEngine.UI.CoroutineTween.TweenRunner`1::StopTween()
// 0x00000579 System.Void UnityEngine.UI.CoroutineTween.TweenRunner`1::.ctor()
// 0x0000057A System.Void UnityEngine.UI.CoroutineTween.TweenRunner`1/<Start>d__2::.ctor(System.Int32)
// 0x0000057B System.Void UnityEngine.UI.CoroutineTween.TweenRunner`1/<Start>d__2::System.IDisposable.Dispose()
// 0x0000057C System.Boolean UnityEngine.UI.CoroutineTween.TweenRunner`1/<Start>d__2::MoveNext()
// 0x0000057D System.Object UnityEngine.UI.CoroutineTween.TweenRunner`1/<Start>d__2::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
// 0x0000057E System.Void UnityEngine.UI.CoroutineTween.TweenRunner`1/<Start>d__2::System.Collections.IEnumerator.Reset()
// 0x0000057F System.Object UnityEngine.UI.CoroutineTween.TweenRunner`1/<Start>d__2::System.Collections.IEnumerator.get_Current()
// 0x00000580 UnityEngine.UIElements.IPanel UnityEngine.UIElements.PanelEventHandler::get_panel()
extern void PanelEventHandler_get_panel_mA34094B6004584B051A7E9554DCF7CE3C18E2642 (void);
// 0x00000581 System.Void UnityEngine.UIElements.PanelEventHandler::set_panel(UnityEngine.UIElements.IPanel)
extern void PanelEventHandler_set_panel_m30302AED739E083827B25651029CB2F1563D2988 (void);
// 0x00000582 UnityEngine.GameObject UnityEngine.UIElements.PanelEventHandler::get_selectableGameObject()
extern void PanelEventHandler_get_selectableGameObject_m327CAA6DDDE5191CF001B5FED18EC8857E6915FC (void);
// 0x00000583 UnityEngine.EventSystems.EventSystem UnityEngine.UIElements.PanelEventHandler::get_eventSystem()
extern void PanelEventHandler_get_eventSystem_m4AC951AFE51C13E82DF39BD27DDD6BE9258535A2 (void);
// 0x00000584 System.Void UnityEngine.UIElements.PanelEventHandler::OnEnable()
extern void PanelEventHandler_OnEnable_m75610BA601D59B6BCB212DB140580859B2C7B777 (void);
// 0x00000585 System.Void UnityEngine.UIElements.PanelEventHandler::OnDisable()
extern void PanelEventHandler_OnDisable_m7174BFEA2A756C36F810433F9D285D9D0B464CE4 (void);
// 0x00000586 System.Void UnityEngine.UIElements.PanelEventHandler::RegisterCallbacks()
extern void PanelEventHandler_RegisterCallbacks_mDA52FF8A14161DC03A7B09826079F60AEDBAC565 (void);
// 0x00000587 System.Void UnityEngine.UIElements.PanelEventHandler::UnregisterCallbacks()
extern void PanelEventHandler_UnregisterCallbacks_m93894C7D3D238507B771066CC0025C98816D309C (void);
// 0x00000588 System.Void UnityEngine.UIElements.PanelEventHandler::OnPanelDestroyed()
extern void PanelEventHandler_OnPanelDestroyed_m1E7871C24E171C75D64BA6F6FB8F70EF7B345366 (void);
// 0x00000589 System.Void UnityEngine.UIElements.PanelEventHandler::OnElementFocus(UnityEngine.UIElements.FocusEvent)
extern void PanelEventHandler_OnElementFocus_m5EF528DB20E06FC6EBECE22E71F90B47660041F1 (void);
// 0x0000058A System.Void UnityEngine.UIElements.PanelEventHandler::OnElementBlur(UnityEngine.UIElements.BlurEvent)
extern void PanelEventHandler_OnElementBlur_m7FB60FF1D38D571180F0FB9B740DE531E9F43A24 (void);
// 0x0000058B System.Void UnityEngine.UIElements.PanelEventHandler::OnSelect(UnityEngine.EventSystems.BaseEventData)
extern void PanelEventHandler_OnSelect_m01E0EBF7AF99013F9D7B0EE96F52CEA3B2C6FB68 (void);
// 0x0000058C System.Void UnityEngine.UIElements.PanelEventHandler::OnDeselect(UnityEngine.EventSystems.BaseEventData)
extern void PanelEventHandler_OnDeselect_m6AF499D5E0F1F162B5BCEA063D4D285E086AF663 (void);
// 0x0000058D System.Void UnityEngine.UIElements.PanelEventHandler::OnPointerMove(UnityEngine.EventSystems.PointerEventData)
extern void PanelEventHandler_OnPointerMove_m753962E17CA7F9176FF96F765527BB093ED1F058 (void);
// 0x0000058E System.Void UnityEngine.UIElements.PanelEventHandler::OnPointerUp(UnityEngine.EventSystems.PointerEventData)
extern void PanelEventHandler_OnPointerUp_mC03E88905E10E8730E8211810EC98927A3B89F96 (void);
// 0x0000058F System.Void UnityEngine.UIElements.PanelEventHandler::OnPointerDown(UnityEngine.EventSystems.PointerEventData)
extern void PanelEventHandler_OnPointerDown_mB46E8626C4F1D143AA495ABAF6B5D57301D3C303 (void);
// 0x00000590 System.Void UnityEngine.UIElements.PanelEventHandler::OnPointerExit(UnityEngine.EventSystems.PointerEventData)
extern void PanelEventHandler_OnPointerExit_m2A57890B6822CBB0D51D61FEBA91B32FE269B1B4 (void);
// 0x00000591 System.Void UnityEngine.UIElements.PanelEventHandler::OnPointerEnter(UnityEngine.EventSystems.PointerEventData)
extern void PanelEventHandler_OnPointerEnter_m0627B36F32B2C7D59783CF07C7781AA66F202C70 (void);
// 0x00000592 System.Void UnityEngine.UIElements.PanelEventHandler::OnSubmit(UnityEngine.EventSystems.BaseEventData)
extern void PanelEventHandler_OnSubmit_m56C7D96593E7DC7B561AE24B741647431C75E84D (void);
// 0x00000593 System.Void UnityEngine.UIElements.PanelEventHandler::OnCancel(UnityEngine.EventSystems.BaseEventData)
extern void PanelEventHandler_OnCancel_mAC960731F19FB4522FD960CD51790361A9F26C8A (void);
// 0x00000594 System.Void UnityEngine.UIElements.PanelEventHandler::OnMove(UnityEngine.EventSystems.AxisEventData)
extern void PanelEventHandler_OnMove_m3103CB2983C10B1E721004FDE9EAAF9E8C598DF4 (void);
// 0x00000595 System.Void UnityEngine.UIElements.PanelEventHandler::OnScroll(UnityEngine.EventSystems.PointerEventData)
extern void PanelEventHandler_OnScroll_mE4812293B72E54A268D49C31845DF17687E68DA4 (void);
// 0x00000596 System.Void UnityEngine.UIElements.PanelEventHandler::SendEvent(UnityEngine.UIElements.EventBase,UnityEngine.EventSystems.BaseEventData)
extern void PanelEventHandler_SendEvent_m380CCD38E3E7949B65EE3001067AA9548B19B9F5 (void);
// 0x00000597 System.Void UnityEngine.UIElements.PanelEventHandler::SendEvent(UnityEngine.UIElements.EventBase,UnityEngine.Event)
extern void PanelEventHandler_SendEvent_m8A731185591EB81DC398B72D4C081970A89D421B (void);
// 0x00000598 System.Void UnityEngine.UIElements.PanelEventHandler::Update()
extern void PanelEventHandler_Update_mB47B3B1C74E2FE6EC56B7A6861D71DACD2FFC733 (void);
// 0x00000599 System.Void UnityEngine.UIElements.PanelEventHandler::LateUpdate()
extern void PanelEventHandler_LateUpdate_mF537C32BA3237501B31627DEFCED28C934DDAF14 (void);
// 0x0000059A System.Void UnityEngine.UIElements.PanelEventHandler::ProcessImguiEvents(System.Boolean)
extern void PanelEventHandler_ProcessImguiEvents_mFD6515767C5083020530A3F81371BFC94029A31F (void);
// 0x0000059B System.Void UnityEngine.UIElements.PanelEventHandler::ProcessKeyboardEvent(UnityEngine.Event)
extern void PanelEventHandler_ProcessKeyboardEvent_m16DDFA49BD3081FEDA4FB3B22AA6DB78A19086F1 (void);
// 0x0000059C System.Void UnityEngine.UIElements.PanelEventHandler::ProcessTabEvent(UnityEngine.Event)
extern void PanelEventHandler_ProcessTabEvent_m53F9BFFBF8D1E45FE3CD57EC3815C7130C1363AE (void);
// 0x0000059D System.Void UnityEngine.UIElements.PanelEventHandler::SendTabEvent(UnityEngine.Event,System.Int32)
extern void PanelEventHandler_SendTabEvent_mA2058FFF2B3B3C64CD86EC20B30A9C753DE4AEA7 (void);
// 0x0000059E System.Void UnityEngine.UIElements.PanelEventHandler::SendKeyUpEvent(UnityEngine.Event)
extern void PanelEventHandler_SendKeyUpEvent_mF261A0CE2897E82529220A72DBE069DE97EC601D (void);
// 0x0000059F System.Void UnityEngine.UIElements.PanelEventHandler::SendKeyDownEvent(UnityEngine.Event)
extern void PanelEventHandler_SendKeyDownEvent_mB5DA98F3B07ED56ABF2E694744BE6EAE3ED81452 (void);
// 0x000005A0 System.Boolean UnityEngine.UIElements.PanelEventHandler::ReadPointerData(UnityEngine.UIElements.PanelEventHandler/PointerEvent,UnityEngine.EventSystems.PointerEventData,UnityEngine.UIElements.PanelEventHandler/PointerEventType)
extern void PanelEventHandler_ReadPointerData_m655D52851C00124DBA14106CDBE322B7AE2F9372 (void);
// 0x000005A1 System.Void UnityEngine.UIElements.PanelEventHandler::.ctor()
extern void PanelEventHandler__ctor_mF90AF37F849E48687B1A1D3730E952A379A62C5B (void);
// 0x000005A2 System.Int32 UnityEngine.UIElements.PanelEventHandler/PointerEvent::get_pointerId()
extern void PointerEvent_get_pointerId_mD4E22379BC076C3D75E103BC55ACFBA81BEF59BE (void);
// 0x000005A3 System.Void UnityEngine.UIElements.PanelEventHandler/PointerEvent::set_pointerId(System.Int32)
extern void PointerEvent_set_pointerId_m1BFCE40A5AF978254069B94292CADC4B39CB4E6B (void);
// 0x000005A4 System.String UnityEngine.UIElements.PanelEventHandler/PointerEvent::get_pointerType()
extern void PointerEvent_get_pointerType_m6AB451260BF46DEFEFF3607498093DE56F8CF537 (void);
// 0x000005A5 System.Void UnityEngine.UIElements.PanelEventHandler/PointerEvent::set_pointerType(System.String)
extern void PointerEvent_set_pointerType_m1BD8CE6C878A3FFB6441A60302634515525E1050 (void);
// 0x000005A6 System.Boolean UnityEngine.UIElements.PanelEventHandler/PointerEvent::get_isPrimary()
extern void PointerEvent_get_isPrimary_m5AF6EA62872F5E02DF4E88BCB078CAEDDB0813A6 (void);
// 0x000005A7 System.Void UnityEngine.UIElements.PanelEventHandler/PointerEvent::set_isPrimary(System.Boolean)
extern void PointerEvent_set_isPrimary_m90DD30E4F4B1641C8F800C4EF04DF078F7F37D2E (void);
// 0x000005A8 System.Int32 UnityEngine.UIElements.PanelEventHandler/PointerEvent::get_button()
extern void PointerEvent_get_button_m72275A3B433F9433FAAC939B5776E908CBAC488C (void);
// 0x000005A9 System.Void UnityEngine.UIElements.PanelEventHandler/PointerEvent::set_button(System.Int32)
extern void PointerEvent_set_button_mBD5A4ADBC9FB28B3D78019091D0279C18AC5F248 (void);
// 0x000005AA System.Int32 UnityEngine.UIElements.PanelEventHandler/PointerEvent::get_pressedButtons()
extern void PointerEvent_get_pressedButtons_m809CC87D0F8B424423079C5DA3E4EFC87E829F02 (void);
// 0x000005AB System.Void UnityEngine.UIElements.PanelEventHandler/PointerEvent::set_pressedButtons(System.Int32)
extern void PointerEvent_set_pressedButtons_m0B5199481431978AC07CFEAE090907BA5E70FA68 (void);
// 0x000005AC UnityEngine.Vector3 UnityEngine.UIElements.PanelEventHandler/PointerEvent::get_position()
extern void PointerEvent_get_position_m6CAC16F2273B6222BB18583B11B85BE3ECA8BB45 (void);
// 0x000005AD System.Void UnityEngine.UIElements.PanelEventHandler/PointerEvent::set_position(UnityEngine.Vector3)
extern void PointerEvent_set_position_m24E0958379E88BDD173E563CC00B2523E77EE051 (void);
// 0x000005AE UnityEngine.Vector3 UnityEngine.UIElements.PanelEventHandler/PointerEvent::get_localPosition()
extern void PointerEvent_get_localPosition_m06C5B58432C1E806B885F67BA0FB8C90EAD71793 (void);
// 0x000005AF System.Void UnityEngine.UIElements.PanelEventHandler/PointerEvent::set_localPosition(UnityEngine.Vector3)
extern void PointerEvent_set_localPosition_m759E75018F6729AA6744C93A57907ACEB390727C (void);
// 0x000005B0 UnityEngine.Vector3 UnityEngine.UIElements.PanelEventHandler/PointerEvent::get_deltaPosition()
extern void PointerEvent_get_deltaPosition_m185F5E48BD0879D48BADC520D64DDD68183B83D2 (void);
// 0x000005B1 System.Void UnityEngine.UIElements.PanelEventHandler/PointerEvent::set_deltaPosition(UnityEngine.Vector3)
extern void PointerEvent_set_deltaPosition_m12E7B298A9EEDC1D623E72EA99758204F16B4A11 (void);
// 0x000005B2 System.Single UnityEngine.UIElements.PanelEventHandler/PointerEvent::get_deltaTime()
extern void PointerEvent_get_deltaTime_mD95C5D61E308ACD9D91FD202D274C2DF94780940 (void);
// 0x000005B3 System.Void UnityEngine.UIElements.PanelEventHandler/PointerEvent::set_deltaTime(System.Single)
extern void PointerEvent_set_deltaTime_mEECBC843D749F429B1F72559BB488BE17BBFC3E0 (void);
// 0x000005B4 System.Int32 UnityEngine.UIElements.PanelEventHandler/PointerEvent::get_clickCount()
extern void PointerEvent_get_clickCount_m1E9AE0EF81D8BC131012E0DEE2C4E169C8B1EE06 (void);
// 0x000005B5 System.Void UnityEngine.UIElements.PanelEventHandler/PointerEvent::set_clickCount(System.Int32)
extern void PointerEvent_set_clickCount_m87C44B61E5E2154178CD4D4CD931C2C463971B89 (void);
// 0x000005B6 System.Single UnityEngine.UIElements.PanelEventHandler/PointerEvent::get_pressure()
extern void PointerEvent_get_pressure_mA7FA9AFBE607289D1A785889E0E2C8CEB705EDB2 (void);
// 0x000005B7 System.Void UnityEngine.UIElements.PanelEventHandler/PointerEvent::set_pressure(System.Single)
extern void PointerEvent_set_pressure_m1D036CF601B6EEB97DBDB8DB75F0923D39303FD9 (void);
// 0x000005B8 System.Single UnityEngine.UIElements.PanelEventHandler/PointerEvent::get_tangentialPressure()
extern void PointerEvent_get_tangentialPressure_m585887790F2A05742888E412B19E0331C4402320 (void);
// 0x000005B9 System.Void UnityEngine.UIElements.PanelEventHandler/PointerEvent::set_tangentialPressure(System.Single)
extern void PointerEvent_set_tangentialPressure_m7ADB233CDA686FCB10A995F2A6826EE5F54AB36D (void);
// 0x000005BA System.Single UnityEngine.UIElements.PanelEventHandler/PointerEvent::get_altitudeAngle()
extern void PointerEvent_get_altitudeAngle_mFDE6773840B002EC90E34041817D96BB8F27A3C4 (void);
// 0x000005BB System.Void UnityEngine.UIElements.PanelEventHandler/PointerEvent::set_altitudeAngle(System.Single)
extern void PointerEvent_set_altitudeAngle_m8B963C51BB5DB8A14A943F4B1BEC39B175ABABEB (void);
// 0x000005BC System.Single UnityEngine.UIElements.PanelEventHandler/PointerEvent::get_azimuthAngle()
extern void PointerEvent_get_azimuthAngle_mDB91EA27BE4126C4582A66DF75CB8012DE16254B (void);
// 0x000005BD System.Void UnityEngine.UIElements.PanelEventHandler/PointerEvent::set_azimuthAngle(System.Single)
extern void PointerEvent_set_azimuthAngle_m404D73D4BAF6C658A52B29DD2C1D5FBEDC174139 (void);
// 0x000005BE System.Single UnityEngine.UIElements.PanelEventHandler/PointerEvent::get_twist()
extern void PointerEvent_get_twist_mDE5D41083F1E9237B3B852B4E8EA778E2C5D2AE7 (void);
// 0x000005BF System.Void UnityEngine.UIElements.PanelEventHandler/PointerEvent::set_twist(System.Single)
extern void PointerEvent_set_twist_mCA0ECFFE48E1771A1540212CABB34326C7AD6B5D (void);
// 0x000005C0 UnityEngine.Vector2 UnityEngine.UIElements.PanelEventHandler/PointerEvent::get_radius()
extern void PointerEvent_get_radius_m2C6907BE1B20DE289E3C166F45FBBCEEAB095F32 (void);
// 0x000005C1 System.Void UnityEngine.UIElements.PanelEventHandler/PointerEvent::set_radius(UnityEngine.Vector2)
extern void PointerEvent_set_radius_m387840E4830548F1B1DA865A5A062062D86590EC (void);
// 0x000005C2 UnityEngine.Vector2 UnityEngine.UIElements.PanelEventHandler/PointerEvent::get_radiusVariance()
extern void PointerEvent_get_radiusVariance_mFED4A22BC0C0667DDC74F6046046A5DA315F4CA2 (void);
// 0x000005C3 System.Void UnityEngine.UIElements.PanelEventHandler/PointerEvent::set_radiusVariance(UnityEngine.Vector2)
extern void PointerEvent_set_radiusVariance_m2627A414E6EFAE8132E2B4FBAC008D830CF0458D (void);
// 0x000005C4 UnityEngine.EventModifiers UnityEngine.UIElements.PanelEventHandler/PointerEvent::get_modifiers()
extern void PointerEvent_get_modifiers_m31E21D875E7EF1A47DB29878AA76698B0047BD6D (void);
// 0x000005C5 System.Void UnityEngine.UIElements.PanelEventHandler/PointerEvent::set_modifiers(UnityEngine.EventModifiers)
extern void PointerEvent_set_modifiers_mB339D7800998DB09F5D8B47B7DDD365897FD61C5 (void);
// 0x000005C6 System.Boolean UnityEngine.UIElements.PanelEventHandler/PointerEvent::get_shiftKey()
extern void PointerEvent_get_shiftKey_mB459C1F6FA17DA9FF904A67473A19A1B22970631 (void);
// 0x000005C7 System.Boolean UnityEngine.UIElements.PanelEventHandler/PointerEvent::get_ctrlKey()
extern void PointerEvent_get_ctrlKey_m6EEB9C3A61C998C00946B424121C7BB32CDA6BED (void);
// 0x000005C8 System.Boolean UnityEngine.UIElements.PanelEventHandler/PointerEvent::get_commandKey()
extern void PointerEvent_get_commandKey_m750005DB9507733FAEE22D4DE58F28C11FD15DB3 (void);
// 0x000005C9 System.Boolean UnityEngine.UIElements.PanelEventHandler/PointerEvent::get_altKey()
extern void PointerEvent_get_altKey_m6306F34C315A6BF2B2B95448657A812817AE2B4E (void);
// 0x000005CA System.Boolean UnityEngine.UIElements.PanelEventHandler/PointerEvent::get_actionKey()
extern void PointerEvent_get_actionKey_mED4C6D96CBEE2F84F52354EFB3540A5759A47CA0 (void);
// 0x000005CB System.Void UnityEngine.UIElements.PanelEventHandler/PointerEvent::Read(UnityEngine.UIElements.PanelEventHandler,UnityEngine.EventSystems.PointerEventData,UnityEngine.UIElements.PanelEventHandler/PointerEventType)
extern void PointerEvent_Read_mE5A2B332E857E3264562FF872625FB5ACE2E3248 (void);
// 0x000005CC System.Void UnityEngine.UIElements.PanelEventHandler/PointerEvent::SetPosition(UnityEngine.Vector3,UnityEngine.Vector3)
extern void PointerEvent_SetPosition_mBFFE588EBFBDB353A634B4D6D544291073916B88 (void);
// 0x000005CD System.Void UnityEngine.UIElements.PanelEventHandler/PointerEvent::.ctor()
extern void PointerEvent__ctor_mE689E41BEA012A2914C799FECBCE48F7A58FCF73 (void);
// 0x000005CE System.Boolean UnityEngine.UIElements.PanelEventHandler/PointerEvent::<Read>g__InRange|82_0(System.Int32,System.Int32,System.Int32)
extern void PointerEvent_U3CReadU3Eg__InRangeU7C82_0_mC8BFB779E097CC745E370BFF83CDC1296C0DB045 (void);
// 0x000005CF UnityEngine.UIElements.IPanel UnityEngine.UIElements.PanelRaycaster::get_panel()
extern void PanelRaycaster_get_panel_m9D8D3E52B0D7A2E4F71B997CC95FB8C808395B85 (void);
// 0x000005D0 System.Void UnityEngine.UIElements.PanelRaycaster::set_panel(UnityEngine.UIElements.IPanel)
extern void PanelRaycaster_set_panel_m840C66DD38B96603B01E8FAA09C74CA1A67E602C (void);
// 0x000005D1 System.Void UnityEngine.UIElements.PanelRaycaster::RegisterCallbacks()
extern void PanelRaycaster_RegisterCallbacks_m840C71BFC5351078CB6BE82C8510F596DC55616D (void);
// 0x000005D2 System.Void UnityEngine.UIElements.PanelRaycaster::UnregisterCallbacks()
extern void PanelRaycaster_UnregisterCallbacks_mD26ACD360F0C27CFB33A824ADE371742853D66F6 (void);
// 0x000005D3 System.Void UnityEngine.UIElements.PanelRaycaster::OnPanelDestroyed()
extern void PanelRaycaster_OnPanelDestroyed_mF761BC7FD349DB95EBBD8C8D55B404300E5D8AF2 (void);
// 0x000005D4 UnityEngine.GameObject UnityEngine.UIElements.PanelRaycaster::get_selectableGameObject()
extern void PanelRaycaster_get_selectableGameObject_m26B496BDA7A92AD0C66B4209171B56321308A628 (void);
// 0x000005D5 System.Int32 UnityEngine.UIElements.PanelRaycaster::get_sortOrderPriority()
extern void PanelRaycaster_get_sortOrderPriority_mBFB2EAC6C4F13CAA1E1723216A0B624B7652EA54 (void);
// 0x000005D6 System.Int32 UnityEngine.UIElements.PanelRaycaster::get_renderOrderPriority()
extern void PanelRaycaster_get_renderOrderPriority_m5E21F65FA1954268DBE3862EB754B20A8B48BE8F (void);
// 0x000005D7 System.Void UnityEngine.UIElements.PanelRaycaster::Raycast(UnityEngine.EventSystems.PointerEventData,System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
extern void PanelRaycaster_Raycast_mFD63FF3E65B14E412D6CD21A3A9455416CE5F895 (void);
// 0x000005D8 UnityEngine.Camera UnityEngine.UIElements.PanelRaycaster::get_eventCamera()
extern void PanelRaycaster_get_eventCamera_m5CDBA1FA81F8BB62020925C81617830897793A2B (void);
// 0x000005D9 System.Int32 UnityEngine.UIElements.PanelRaycaster::ConvertFloatBitsToInt(System.Single)
extern void PanelRaycaster_ConvertFloatBitsToInt_m1B874D1D187BFEE0E217A8D74D21FF4A2F13D717 (void);
// 0x000005DA System.Void UnityEngine.UIElements.PanelRaycaster::.ctor()
extern void PanelRaycaster__ctor_m1F8C36B6C6A4A92394FFB160E6A084F8FA833F6C (void);
// 0x000005DB UnityEngine.Vector2 UnityEngine.EventSystems.AxisEventData::get_moveVector()
extern void AxisEventData_get_moveVector_m7979B5CF62B6B3B0C5F2DA8B328C499ED80ECC41 (void);
// 0x000005DC System.Void UnityEngine.EventSystems.AxisEventData::set_moveVector(UnityEngine.Vector2)
extern void AxisEventData_set_moveVector_mC744F8B3519A6EE5E60482E8FB39641181C62914 (void);
// 0x000005DD UnityEngine.EventSystems.MoveDirection UnityEngine.EventSystems.AxisEventData::get_moveDir()
extern void AxisEventData_get_moveDir_mC8E219BB19708AC67C202C860DF2E6D08C29B8B9 (void);
// 0x000005DE System.Void UnityEngine.EventSystems.AxisEventData::set_moveDir(UnityEngine.EventSystems.MoveDirection)
extern void AxisEventData_set_moveDir_mD82A8AEB52FEFAC48CA064BB77A381B9A3E1B24B (void);
// 0x000005DF System.Void UnityEngine.EventSystems.AxisEventData::.ctor(UnityEngine.EventSystems.EventSystem)
extern void AxisEventData__ctor_mD9AFBD293F84F7032BAC2BDCB47FF5A780418CC5 (void);
// 0x000005E0 System.Void UnityEngine.EventSystems.AbstractEventData::Reset()
extern void AbstractEventData_Reset_mC3FF13B6FB1012E8FAB00250AE8CD2E1975EF6AC (void);
// 0x000005E1 System.Void UnityEngine.EventSystems.AbstractEventData::Use()
extern void AbstractEventData_Use_m5DBA1B649A757E09ACB14C3632998231C03795B8 (void);
// 0x000005E2 System.Boolean UnityEngine.EventSystems.AbstractEventData::get_used()
extern void AbstractEventData_get_used_m0C95B1F392BD74E99F3AD87963647AA060EE5DDF (void);
// 0x000005E3 System.Void UnityEngine.EventSystems.AbstractEventData::.ctor()
extern void AbstractEventData__ctor_m3D5B26D1C8BC7ACDDF16F505CF7AE273B54584FC (void);
// 0x000005E4 System.Void UnityEngine.EventSystems.BaseEventData::.ctor(UnityEngine.EventSystems.EventSystem)
extern void BaseEventData__ctor_mE51C4DB618D8661AB2527EC5DE4D563D2284F558 (void);
// 0x000005E5 UnityEngine.EventSystems.BaseInputModule UnityEngine.EventSystems.BaseEventData::get_currentInputModule()
extern void BaseEventData_get_currentInputModule_mA46B583FC6DAA697F2DAA91A73D14B3E914AF1A5 (void);
// 0x000005E6 UnityEngine.GameObject UnityEngine.EventSystems.BaseEventData::get_selectedObject()
extern void BaseEventData_get_selectedObject_m0642DE5E08D7CCC49C67D66B296EEE060E357CE1 (void);
// 0x000005E7 System.Void UnityEngine.EventSystems.BaseEventData::set_selectedObject(UnityEngine.GameObject)
extern void BaseEventData_set_selectedObject_mF3EE53D700B0EA9444D1D7FAF0FB234B4D88A884 (void);
// 0x000005E8 UnityEngine.GameObject UnityEngine.EventSystems.PointerEventData::get_pointerEnter()
extern void PointerEventData_get_pointerEnter_m6CE76D5C0C36C4666CDDE348B57885C52D495A4B (void);
// 0x000005E9 System.Void UnityEngine.EventSystems.PointerEventData::set_pointerEnter(UnityEngine.GameObject)
extern void PointerEventData_set_pointerEnter_m2DA660C24CBDE9B83DF2B2D09D9AF0E94A770D17 (void);
// 0x000005EA UnityEngine.GameObject UnityEngine.EventSystems.PointerEventData::get_lastPress()
extern void PointerEventData_get_lastPress_m46720C62503214A44EE947679A8BA307BC2AEEDC (void);
// 0x000005EB System.Void UnityEngine.EventSystems.PointerEventData::set_lastPress(UnityEngine.GameObject)
extern void PointerEventData_set_lastPress_m0B9EDFBA95B410FBD8CA2A82306ED3EA6696AE64 (void);
// 0x000005EC UnityEngine.GameObject UnityEngine.EventSystems.PointerEventData::get_rawPointerPress()
extern void PointerEventData_get_rawPointerPress_m8B7A6235A116E26EDDBBDB24473BE0F9634C7B71 (void);
// 0x000005ED System.Void UnityEngine.EventSystems.PointerEventData::set_rawPointerPress(UnityEngine.GameObject)
extern void PointerEventData_set_rawPointerPress_mEEC4E3C7CD00F1DDCD3DA98DA5837E71BB8455E3 (void);
// 0x000005EE UnityEngine.GameObject UnityEngine.EventSystems.PointerEventData::get_pointerDrag()
extern void PointerEventData_get_pointerDrag_m36BF08A32216845A8095C5F74DFE6C9959A11E96 (void);
// 0x000005EF System.Void UnityEngine.EventSystems.PointerEventData::set_pointerDrag(UnityEngine.GameObject)
extern void PointerEventData_set_pointerDrag_m0E8D72362B07962843671C39ADC8F4D5E4915010 (void);
// 0x000005F0 UnityEngine.GameObject UnityEngine.EventSystems.PointerEventData::get_pointerClick()
extern void PointerEventData_get_pointerClick_m2AFE23543BC381EC734E85ADB16DD63BA2017FEB (void);
// 0x000005F1 System.Void UnityEngine.EventSystems.PointerEventData::set_pointerClick(UnityEngine.GameObject)
extern void PointerEventData_set_pointerClick_m8FA5D91C9556A722BAE8ADBBB5353C79854D74C0 (void);
// 0x000005F2 UnityEngine.EventSystems.RaycastResult UnityEngine.EventSystems.PointerEventData::get_pointerCurrentRaycast()
extern void PointerEventData_get_pointerCurrentRaycast_m1C6B7D707CEE9C6574DD443289D90102EDC7A2C4 (void);
// 0x000005F3 System.Void UnityEngine.EventSystems.PointerEventData::set_pointerCurrentRaycast(UnityEngine.EventSystems.RaycastResult)
extern void PointerEventData_set_pointerCurrentRaycast_m52E1E9E89BACACFA6E8F105191654C7E24A98667 (void);
// 0x000005F4 UnityEngine.EventSystems.RaycastResult UnityEngine.EventSystems.PointerEventData::get_pointerPressRaycast()
extern void PointerEventData_get_pointerPressRaycast_mEB1B974F5543F78162984E2924EF908E18CE3B5D (void);
// 0x000005F5 System.Void UnityEngine.EventSystems.PointerEventData::set_pointerPressRaycast(UnityEngine.EventSystems.RaycastResult)
extern void PointerEventData_set_pointerPressRaycast_m55CA127474B4CBCA795A9C872B7630AAF766F852 (void);
// 0x000005F6 System.Boolean UnityEngine.EventSystems.PointerEventData::get_eligibleForClick()
extern void PointerEventData_get_eligibleForClick_m4B01A1640C694FD7421BDFB19CF763BC85672C8E (void);
// 0x000005F7 System.Void UnityEngine.EventSystems.PointerEventData::set_eligibleForClick(System.Boolean)
extern void PointerEventData_set_eligibleForClick_m360125CB3E348F3CF64C39F163467A842E479C21 (void);
// 0x000005F8 System.Int32 UnityEngine.EventSystems.PointerEventData::get_pointerId()
extern void PointerEventData_get_pointerId_m81DDB468147FE75C1474C9C6C35753BB53A21275 (void);
// 0x000005F9 System.Void UnityEngine.EventSystems.PointerEventData::set_pointerId(System.Int32)
extern void PointerEventData_set_pointerId_m5B5FF54AB1DE7BD4454022A7C0535C618049BD9B (void);
// 0x000005FA UnityEngine.Vector2 UnityEngine.EventSystems.PointerEventData::get_position()
extern void PointerEventData_get_position_m5BE71C28EB72EFB8435749E4E6E839213AEF458C (void);
// 0x000005FB System.Void UnityEngine.EventSystems.PointerEventData::set_position(UnityEngine.Vector2)
extern void PointerEventData_set_position_m66E8DFE693F550372E6B085C6E2F887FDB092FAA (void);
// 0x000005FC UnityEngine.Vector2 UnityEngine.EventSystems.PointerEventData::get_delta()
extern void PointerEventData_get_delta_m7DC87C01EAE1D10282C37842ED215FDBFE2C1C5B (void);
// 0x000005FD System.Void UnityEngine.EventSystems.PointerEventData::set_delta(UnityEngine.Vector2)
extern void PointerEventData_set_delta_mD200AF7CCAEAD92D947091902AF864CB4ACE0F1D (void);
// 0x000005FE UnityEngine.Vector2 UnityEngine.EventSystems.PointerEventData::get_pressPosition()
extern void PointerEventData_get_pressPosition_m8A6788DA6BF81481E4EBCBA2ED1838F786EBAE63 (void);
// 0x000005FF System.Void UnityEngine.EventSystems.PointerEventData::set_pressPosition(UnityEngine.Vector2)
extern void PointerEventData_set_pressPosition_m85544FBAB798DABE70067508294A6C4841A95379 (void);
// 0x00000600 UnityEngine.Vector3 UnityEngine.EventSystems.PointerEventData::get_worldPosition()
extern void PointerEventData_get_worldPosition_m296F53ACF7665D00DE12A18E1A91E3FFDEB42101 (void);
// 0x00000601 System.Void UnityEngine.EventSystems.PointerEventData::set_worldPosition(UnityEngine.Vector3)
extern void PointerEventData_set_worldPosition_m917BBBF297B2D89BB6836985D466A93B863899FA (void);
// 0x00000602 UnityEngine.Vector3 UnityEngine.EventSystems.PointerEventData::get_worldNormal()
extern void PointerEventData_get_worldNormal_m5C5939C06E4AAC48C134A59A9C8F03A6D6CD8884 (void);
// 0x00000603 System.Void UnityEngine.EventSystems.PointerEventData::set_worldNormal(UnityEngine.Vector3)
extern void PointerEventData_set_worldNormal_mA342C6737631C9C902EFDF1F816AF5C6BE6B0EC7 (void);
// 0x00000604 System.Single UnityEngine.EventSystems.PointerEventData::get_clickTime()
extern void PointerEventData_get_clickTime_m5ABE0298E8CEF28B6BD7E750E940756CD78AB96E (void);
// 0x00000605 System.Void UnityEngine.EventSystems.PointerEventData::set_clickTime(System.Single)
extern void PointerEventData_set_clickTime_m93D27EB35F490AC9100369A23002F09148F85996 (void);
// 0x00000606 System.Int32 UnityEngine.EventSystems.PointerEventData::get_clickCount()
extern void PointerEventData_get_clickCount_m3977011C09DB9F904B1AAC3708B821B8D6AC0F9F (void);
// 0x00000607 System.Void UnityEngine.EventSystems.PointerEventData::set_clickCount(System.Int32)
extern void PointerEventData_set_clickCount_m0A87C2C367987492F310786DC9C3DF1616EA4D49 (void);
// 0x00000608 UnityEngine.Vector2 UnityEngine.EventSystems.PointerEventData::get_scrollDelta()
extern void PointerEventData_get_scrollDelta_m38C419C3E84811D17D1A42973AF7B3A457B316EA (void);
// 0x00000609 System.Void UnityEngine.EventSystems.PointerEventData::set_scrollDelta(UnityEngine.Vector2)
extern void PointerEventData_set_scrollDelta_m58007CAE9A9B333B82C36B9E5431FBD926CB556C (void);
// 0x0000060A System.Boolean UnityEngine.EventSystems.PointerEventData::get_useDragThreshold()
extern void PointerEventData_get_useDragThreshold_m3ED1F39E71630C9AB1F340C92F8FA39AA489E1C5 (void);
// 0x0000060B System.Void UnityEngine.EventSystems.PointerEventData::set_useDragThreshold(System.Boolean)
extern void PointerEventData_set_useDragThreshold_m63FE2034E4B240F1A0A902B1EB893B3DBA2D848B (void);
// 0x0000060C System.Boolean UnityEngine.EventSystems.PointerEventData::get_dragging()
extern void PointerEventData_get_dragging_mE0AD837F228E3830D4A74657AD3D47F53F6C87E9 (void);
// 0x0000060D System.Void UnityEngine.EventSystems.PointerEventData::set_dragging(System.Boolean)
extern void PointerEventData_set_dragging_m43982B3F95F05986F40A736914CFBC45D2A9BB8E (void);
// 0x0000060E UnityEngine.EventSystems.PointerEventData/InputButton UnityEngine.EventSystems.PointerEventData::get_button()
extern void PointerEventData_get_button_mA8CBDAF2E16927E6952BC60040D56630BCC95B0B (void);
// 0x0000060F System.Void UnityEngine.EventSystems.PointerEventData::set_button(UnityEngine.EventSystems.PointerEventData/InputButton)
extern void PointerEventData_set_button_m77DA0291BA43CB813FE83752D826AF3982C81601 (void);
// 0x00000610 System.Single UnityEngine.EventSystems.PointerEventData::get_pressure()
extern void PointerEventData_get_pressure_m0745482FB0BD942F9615009C647765E3000F12C3 (void);
// 0x00000611 System.Void UnityEngine.EventSystems.PointerEventData::set_pressure(System.Single)
extern void PointerEventData_set_pressure_m4471D0EEC22789490EA12FE6521A620CF60A37CA (void);
// 0x00000612 System.Single UnityEngine.EventSystems.PointerEventData::get_tangentialPressure()
extern void PointerEventData_get_tangentialPressure_m76ED73E8545F01660D6196DCEBAA6C63DDDE374C (void);
// 0x00000613 System.Void UnityEngine.EventSystems.PointerEventData::set_tangentialPressure(System.Single)
extern void PointerEventData_set_tangentialPressure_m66792087B044033F0FF0FA4B2BA316233755EEF4 (void);
// 0x00000614 System.Single UnityEngine.EventSystems.PointerEventData::get_altitudeAngle()
extern void PointerEventData_get_altitudeAngle_m3D72F9EF9FF2238B1FE2E6B5870F8B0DD14B90FE (void);
// 0x00000615 System.Void UnityEngine.EventSystems.PointerEventData::set_altitudeAngle(System.Single)
extern void PointerEventData_set_altitudeAngle_m20F2AF2ADB0A20BF20C4B9A6AFE2566A0F4C8BD1 (void);
// 0x00000616 System.Single UnityEngine.EventSystems.PointerEventData::get_azimuthAngle()
extern void PointerEventData_get_azimuthAngle_mBFF5F23355EEAB911D8FF55965CCFF9CB3DD3F42 (void);
// 0x00000617 System.Void UnityEngine.EventSystems.PointerEventData::set_azimuthAngle(System.Single)
extern void PointerEventData_set_azimuthAngle_mBE64BAD91A9A47E9D9163E25E9E0D1E677B0FC1B (void);
// 0x00000618 System.Single UnityEngine.EventSystems.PointerEventData::get_twist()
extern void PointerEventData_get_twist_m15A76D34614115A290B8FA90799752FBE00580B7 (void);
// 0x00000619 System.Void UnityEngine.EventSystems.PointerEventData::set_twist(System.Single)
extern void PointerEventData_set_twist_mE49469F4F730BA43906F2167E7ADDB9CB2F946E4 (void);
// 0x0000061A UnityEngine.Vector2 UnityEngine.EventSystems.PointerEventData::get_radius()
extern void PointerEventData_get_radius_mA89C671E5F8CA0D0684113CF05E7FAF2961BF7D0 (void);
// 0x0000061B System.Void UnityEngine.EventSystems.PointerEventData::set_radius(UnityEngine.Vector2)
extern void PointerEventData_set_radius_mB2F29A6E8A14D1DE1162ECAB3398B539FEF83ABE (void);
// 0x0000061C UnityEngine.Vector2 UnityEngine.EventSystems.PointerEventData::get_radiusVariance()
extern void PointerEventData_get_radiusVariance_m5A3BC7FD6B455570A6535911E0F72F88B0F598BB (void);
// 0x0000061D System.Void UnityEngine.EventSystems.PointerEventData::set_radiusVariance(UnityEngine.Vector2)
extern void PointerEventData_set_radiusVariance_m62367BD7EE689AFF5BB5394D984E4AF026A2D15E (void);
// 0x0000061E System.Boolean UnityEngine.EventSystems.PointerEventData::get_fullyExited()
extern void PointerEventData_get_fullyExited_m8A648782FBCC4F948B2D6DEC3B35AFF59A7C794C (void);
// 0x0000061F System.Void UnityEngine.EventSystems.PointerEventData::set_fullyExited(System.Boolean)
extern void PointerEventData_set_fullyExited_mDC23BED1E8A933E25E955A25109494A5D9F25C74 (void);
// 0x00000620 System.Boolean UnityEngine.EventSystems.PointerEventData::get_reentered()
extern void PointerEventData_get_reentered_m8B88B2F3A8C9FBBE878B458560F5BFF2D7DD142B (void);
// 0x00000621 System.Void UnityEngine.EventSystems.PointerEventData::set_reentered(System.Boolean)
extern void PointerEventData_set_reentered_mE363C3D307806C3FF87DF730C14E82AF68A96D8A (void);
// 0x00000622 System.Void UnityEngine.EventSystems.PointerEventData::.ctor(UnityEngine.EventSystems.EventSystem)
extern void PointerEventData__ctor_m63837790B68893F0022CCEFEF26ADD55A975F71C (void);
// 0x00000623 System.Boolean UnityEngine.EventSystems.PointerEventData::IsPointerMoving()
extern void PointerEventData_IsPointerMoving_m281B3698E618D116F3D1E7473BADFAE5B67C834E (void);
// 0x00000624 System.Boolean UnityEngine.EventSystems.PointerEventData::IsScrolling()
extern void PointerEventData_IsScrolling_mFB78E050A248CDF5221482334808B82500D0A564 (void);
// 0x00000625 UnityEngine.Camera UnityEngine.EventSystems.PointerEventData::get_enterEventCamera()
extern void PointerEventData_get_enterEventCamera_m2EBF9CB2E5C1B169F6B6BB066C9CF5B99A7476CF (void);
// 0x00000626 UnityEngine.Camera UnityEngine.EventSystems.PointerEventData::get_pressEventCamera()
extern void PointerEventData_get_pressEventCamera_m8D6A377D5CA730307D9F8ABB8656FFB8FCD56AE3 (void);
// 0x00000627 UnityEngine.GameObject UnityEngine.EventSystems.PointerEventData::get_pointerPress()
extern void PointerEventData_get_pointerPress_mEE815DDB67E40AA587090BCCE0E3CABA6405C50A (void);
// 0x00000628 System.Void UnityEngine.EventSystems.PointerEventData::set_pointerPress(UnityEngine.GameObject)
extern void PointerEventData_set_pointerPress_m51241AAA6E5F87ADEBBB8DB7D4452CE45200BEE8 (void);
// 0x00000629 System.String UnityEngine.EventSystems.PointerEventData::ToString()
extern void PointerEventData_ToString_m49B5681669B6866A981884B774BC48E87D64B48D (void);
// 0x0000062A System.Void UnityEngine.EventSystems.IPointerMoveHandler::OnPointerMove(UnityEngine.EventSystems.PointerEventData)
// 0x0000062B System.Void UnityEngine.EventSystems.IPointerEnterHandler::OnPointerEnter(UnityEngine.EventSystems.PointerEventData)
// 0x0000062C System.Void UnityEngine.EventSystems.IPointerExitHandler::OnPointerExit(UnityEngine.EventSystems.PointerEventData)
// 0x0000062D System.Void UnityEngine.EventSystems.IPointerDownHandler::OnPointerDown(UnityEngine.EventSystems.PointerEventData)
// 0x0000062E System.Void UnityEngine.EventSystems.IPointerUpHandler::OnPointerUp(UnityEngine.EventSystems.PointerEventData)
// 0x0000062F System.Void UnityEngine.EventSystems.IPointerClickHandler::OnPointerClick(UnityEngine.EventSystems.PointerEventData)
// 0x00000630 System.Void UnityEngine.EventSystems.IBeginDragHandler::OnBeginDrag(UnityEngine.EventSystems.PointerEventData)
// 0x00000631 System.Void UnityEngine.EventSystems.IInitializePotentialDragHandler::OnInitializePotentialDrag(UnityEngine.EventSystems.PointerEventData)
// 0x00000632 System.Void UnityEngine.EventSystems.IDragHandler::OnDrag(UnityEngine.EventSystems.PointerEventData)
// 0x00000633 System.Void UnityEngine.EventSystems.IEndDragHandler::OnEndDrag(UnityEngine.EventSystems.PointerEventData)
// 0x00000634 System.Void UnityEngine.EventSystems.IDropHandler::OnDrop(UnityEngine.EventSystems.PointerEventData)
// 0x00000635 System.Void UnityEngine.EventSystems.IScrollHandler::OnScroll(UnityEngine.EventSystems.PointerEventData)
// 0x00000636 System.Void UnityEngine.EventSystems.IUpdateSelectedHandler::OnUpdateSelected(UnityEngine.EventSystems.BaseEventData)
// 0x00000637 System.Void UnityEngine.EventSystems.ISelectHandler::OnSelect(UnityEngine.EventSystems.BaseEventData)
// 0x00000638 System.Void UnityEngine.EventSystems.IDeselectHandler::OnDeselect(UnityEngine.EventSystems.BaseEventData)
// 0x00000639 System.Void UnityEngine.EventSystems.IMoveHandler::OnMove(UnityEngine.EventSystems.AxisEventData)
// 0x0000063A System.Void UnityEngine.EventSystems.ISubmitHandler::OnSubmit(UnityEngine.EventSystems.BaseEventData)
// 0x0000063B System.Void UnityEngine.EventSystems.ICancelHandler::OnCancel(UnityEngine.EventSystems.BaseEventData)
// 0x0000063C UnityEngine.EventSystems.EventSystem UnityEngine.EventSystems.EventSystem::get_current()
extern void EventSystem_get_current_mC87C69FB418563DC2A571A10E2F9DB59A6785016 (void);
// 0x0000063D System.Void UnityEngine.EventSystems.EventSystem::set_current(UnityEngine.EventSystems.EventSystem)
extern void EventSystem_set_current_mCAAA4D0C90542AF31D363CC4ACE4D615D5D28233 (void);
// 0x0000063E System.Boolean UnityEngine.EventSystems.EventSystem::get_sendNavigationEvents()
extern void EventSystem_get_sendNavigationEvents_m8BA21E58E633B2C5B477E49DAABAD3C97A8158AF (void);
// 0x0000063F System.Void UnityEngine.EventSystems.EventSystem::set_sendNavigationEvents(System.Boolean)
extern void EventSystem_set_sendNavigationEvents_m9309FBEDCBAA85162A202AADF3FDBB7A47D52D30 (void);
// 0x00000640 System.Int32 UnityEngine.EventSystems.EventSystem::get_pixelDragThreshold()
extern void EventSystem_get_pixelDragThreshold_m2F7B0D1B5ACC63EB507FD7CCFE74F2B2804FF2E3 (void);
// 0x00000641 System.Void UnityEngine.EventSystems.EventSystem::set_pixelDragThreshold(System.Int32)
extern void EventSystem_set_pixelDragThreshold_m2D2A087B9A9992D7B624CDB98A6E30BE9D10EF63 (void);
// 0x00000642 UnityEngine.EventSystems.BaseInputModule UnityEngine.EventSystems.EventSystem::get_currentInputModule()
extern void EventSystem_get_currentInputModule_m30559FCECCCE1AAD97D801968B8BD1C483FBF7AC (void);
// 0x00000643 UnityEngine.GameObject UnityEngine.EventSystems.EventSystem::get_firstSelectedGameObject()
extern void EventSystem_get_firstSelectedGameObject_m15FB056EE7A99D8DD5891D40A6E3EF18719F0553 (void);
// 0x00000644 System.Void UnityEngine.EventSystems.EventSystem::set_firstSelectedGameObject(UnityEngine.GameObject)
extern void EventSystem_set_firstSelectedGameObject_m626D151EC4AC93DE63E18689FDC13A03DCFB5AAE (void);
// 0x00000645 UnityEngine.GameObject UnityEngine.EventSystems.EventSystem::get_currentSelectedGameObject()
extern void EventSystem_get_currentSelectedGameObject_mD606FFACF3E72755298A523CBB709535CF08C98A (void);
// 0x00000646 UnityEngine.GameObject UnityEngine.EventSystems.EventSystem::get_lastSelectedGameObject()
extern void EventSystem_get_lastSelectedGameObject_m494BAB623DA90318F7B37C2FFEAD1D8E17FBE735 (void);
// 0x00000647 System.Boolean UnityEngine.EventSystems.EventSystem::get_isFocused()
extern void EventSystem_get_isFocused_mB0BB5BE03F7203A06D2F351ACD28BA177079104A (void);
// 0x00000648 System.Void UnityEngine.EventSystems.EventSystem::.ctor()
extern void EventSystem__ctor_mEEF6F5A0BCA90CC9AD827AA3F2522783B71C6E50 (void);
// 0x00000649 System.Void UnityEngine.EventSystems.EventSystem::UpdateModules()
extern void EventSystem_UpdateModules_m2D91F02D546D50094DDB25BF0228A987E2EAFF91 (void);
// 0x0000064A System.Boolean UnityEngine.EventSystems.EventSystem::get_alreadySelecting()
extern void EventSystem_get_alreadySelecting_m3DB9F620A5E2976EBF1362F95C05C12031BACCC4 (void);
// 0x0000064B System.Void UnityEngine.EventSystems.EventSystem::SetSelectedGameObject(UnityEngine.GameObject,UnityEngine.EventSystems.BaseEventData)
extern void EventSystem_SetSelectedGameObject_m9675415B7B3FE13B35E2CCB220F0C8AF04ECA173 (void);
// 0x0000064C UnityEngine.EventSystems.BaseEventData UnityEngine.EventSystems.EventSystem::get_baseEventDataCache()
extern void EventSystem_get_baseEventDataCache_mF9AFC01C9D2B055F0816F6EEA2CC0011F1D82B7F (void);
// 0x0000064D System.Void UnityEngine.EventSystems.EventSystem::SetSelectedGameObject(UnityEngine.GameObject)
extern void EventSystem_SetSelectedGameObject_m91382EAC4D552C672CC07BE7EB1481F156045280 (void);
// 0x0000064E System.Int32 UnityEngine.EventSystems.EventSystem::RaycastComparer(UnityEngine.EventSystems.RaycastResult,UnityEngine.EventSystems.RaycastResult)
extern void EventSystem_RaycastComparer_mBF2582FBEDA9A1B604EE4281C61CB5E3DF676795 (void);
// 0x0000064F System.Void UnityEngine.EventSystems.EventSystem::RaycastAll(UnityEngine.EventSystems.PointerEventData,System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
extern void EventSystem_RaycastAll_mE93CC75909438D20D17A0EF98348A064FBFEA528 (void);
// 0x00000650 System.Boolean UnityEngine.EventSystems.EventSystem::IsPointerOverGameObject()
extern void EventSystem_IsPointerOverGameObject_mC89BFEA46B0DA67F914B9B90356E63BFBE11EB38 (void);
// 0x00000651 System.Boolean UnityEngine.EventSystems.EventSystem::IsPointerOverGameObject(System.Int32)
extern void EventSystem_IsPointerOverGameObject_m238732B4FDEA343976D798FF04DB34C3221243C2 (void);
// 0x00000652 System.Boolean UnityEngine.EventSystems.EventSystem::get_isUIToolkitActiveEventSystem()
extern void EventSystem_get_isUIToolkitActiveEventSystem_m6FF1DA7E38D73742C5AEBF93C611723B9CC93FDE (void);
// 0x00000653 System.Boolean UnityEngine.EventSystems.EventSystem::get_sendUIToolkitEvents()
extern void EventSystem_get_sendUIToolkitEvents_m7E11CCC27DFE797BC4DFAEAE2D1C94BF845B08C9 (void);
// 0x00000654 System.Boolean UnityEngine.EventSystems.EventSystem::get_createUIToolkitPanelGameObjectsOnStart()
extern void EventSystem_get_createUIToolkitPanelGameObjectsOnStart_mD617E1B0EA52D750421DE03A8F131CF2F5831712 (void);
// 0x00000655 System.Void UnityEngine.EventSystems.EventSystem::SetUITookitEventSystemOverride(UnityEngine.EventSystems.EventSystem,System.Boolean,System.Boolean)
extern void EventSystem_SetUITookitEventSystemOverride_m31B7776BD35EFB75371E2B860CF6E34FCDCD6A59 (void);
// 0x00000656 System.Void UnityEngine.EventSystems.EventSystem::CreateUIToolkitPanelGameObject(UnityEngine.UIElements.BaseRuntimePanel)
extern void EventSystem_CreateUIToolkitPanelGameObject_mFE582264FE41E29CA6BBCCA384E1B238671D3B4B (void);
// 0x00000657 System.Void UnityEngine.EventSystems.EventSystem::Start()
extern void EventSystem_Start_m392BF40F247855AA4D87C74F2CB5F9AC175F5556 (void);
// 0x00000658 System.Void UnityEngine.EventSystems.EventSystem::OnDestroy()
extern void EventSystem_OnDestroy_m2DDC6C240ED981710CB6D91F143A9FF6A3230D14 (void);
// 0x00000659 System.Void UnityEngine.EventSystems.EventSystem::OnEnable()
extern void EventSystem_OnEnable_m4A1E4BD3E26E6DD1150AF17B8A4E14DA9FDA2D9C (void);
// 0x0000065A System.Void UnityEngine.EventSystems.EventSystem::OnDisable()
extern void EventSystem_OnDisable_m7667186DBAD79874E4B7CE04A5F0291C35FBE240 (void);
// 0x0000065B System.Void UnityEngine.EventSystems.EventSystem::TickModules()
extern void EventSystem_TickModules_mD3F159C0C33396BEB5789B633065005DE771028C (void);
// 0x0000065C System.Void UnityEngine.EventSystems.EventSystem::OnApplicationFocus(System.Boolean)
extern void EventSystem_OnApplicationFocus_m85C0A5CBBCEC8D900365BDD4F3E3188ED0EE8DC9 (void);
// 0x0000065D System.Void UnityEngine.EventSystems.EventSystem::Update()
extern void EventSystem_Update_m9D0AC1A7236F0DA1CCA0A8FFE0D8D33D960D433C (void);
// 0x0000065E System.Void UnityEngine.EventSystems.EventSystem::ChangeEventModule(UnityEngine.EventSystems.BaseInputModule)
extern void EventSystem_ChangeEventModule_m18F27ADCD2CF6656D771CB0413B7B4D768D38181 (void);
// 0x0000065F System.String UnityEngine.EventSystems.EventSystem::ToString()
extern void EventSystem_ToString_m0C3906BF8A1C2D7BCC31B09224890BC89B2AF35B (void);
// 0x00000660 System.Void UnityEngine.EventSystems.EventSystem::.cctor()
extern void EventSystem__cctor_mE933C88969E443D3DEE106C6E747F97F40D3B48F (void);
// 0x00000661 System.Void UnityEngine.EventSystems.EventSystem/<>c__DisplayClass52_0::.ctor()
extern void U3CU3Ec__DisplayClass52_0__ctor_m92802E6FD95BD7427E6265625035CAF19A8B061B (void);
// 0x00000662 System.Void UnityEngine.EventSystems.EventSystem/<>c__DisplayClass52_0::<CreateUIToolkitPanelGameObject>b__0()
extern void U3CU3Ec__DisplayClass52_0_U3CCreateUIToolkitPanelGameObjectU3Eb__0_mF55A93A2665521B4BB521A1FABDC7B98D7F05999 (void);
// 0x00000663 System.Collections.Generic.List`1<UnityEngine.EventSystems.EventTrigger/Entry> UnityEngine.EventSystems.EventTrigger::get_delegates()
extern void EventTrigger_get_delegates_m0EF6EB8D0AB4964C9AB563D74387B1D5366B9004 (void);
// 0x00000664 System.Void UnityEngine.EventSystems.EventTrigger::set_delegates(System.Collections.Generic.List`1<UnityEngine.EventSystems.EventTrigger/Entry>)
extern void EventTrigger_set_delegates_m47AE262A9A8E4F2F2824F2C877597DC4CE2A979A (void);
// 0x00000665 System.Void UnityEngine.EventSystems.EventTrigger::.ctor()
extern void EventTrigger__ctor_m2A471D4099280D37183A1B668FF092B9517BA294 (void);
// 0x00000666 System.Collections.Generic.List`1<UnityEngine.EventSystems.EventTrigger/Entry> UnityEngine.EventSystems.EventTrigger::get_triggers()
extern void EventTrigger_get_triggers_m2361511923086BCD40339097448A70AFB22C4647 (void);
// 0x00000667 System.Void UnityEngine.EventSystems.EventTrigger::set_triggers(System.Collections.Generic.List`1<UnityEngine.EventSystems.EventTrigger/Entry>)
extern void EventTrigger_set_triggers_m5F861F79BBA48C26CFB83BEA7E25580B21BDA815 (void);
// 0x00000668 System.Void UnityEngine.EventSystems.EventTrigger::Execute(UnityEngine.EventSystems.EventTriggerType,UnityEngine.EventSystems.BaseEventData)
extern void EventTrigger_Execute_m8F637065284AB93B0D2C1090C63830AFD9CE25BE (void);
// 0x00000669 System.Void UnityEngine.EventSystems.EventTrigger::OnPointerEnter(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnPointerEnter_m78A0620B719E345A02F2A628EBC1D08ADAA5FD89 (void);
// 0x0000066A System.Void UnityEngine.EventSystems.EventTrigger::OnPointerExit(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnPointerExit_mF15D24467BCC9686CD9DC11C728632F7ED098BF4 (void);
// 0x0000066B System.Void UnityEngine.EventSystems.EventTrigger::OnDrag(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnDrag_mD4E2457101987E2E96C251EDBBAD8960BED20874 (void);
// 0x0000066C System.Void UnityEngine.EventSystems.EventTrigger::OnDrop(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnDrop_mF111804E0134C1C873156D4B22E8479CDDEC0C1B (void);
// 0x0000066D System.Void UnityEngine.EventSystems.EventTrigger::OnPointerDown(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnPointerDown_m91957FC65D1AE1C5FD6B0548682DEE1B4283ECC0 (void);
// 0x0000066E System.Void UnityEngine.EventSystems.EventTrigger::OnPointerUp(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnPointerUp_m63A37DEC73942B6C5863F79DED7A2BCDEF8B8DB6 (void);
// 0x0000066F System.Void UnityEngine.EventSystems.EventTrigger::OnPointerClick(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnPointerClick_m6006A8F9138007DF16AEA63968E865D8A2AF128E (void);
// 0x00000670 System.Void UnityEngine.EventSystems.EventTrigger::OnSelect(UnityEngine.EventSystems.BaseEventData)
extern void EventTrigger_OnSelect_m191AD9E9C686FABEEF036AAC0D89F27D7BACC8E4 (void);
// 0x00000671 System.Void UnityEngine.EventSystems.EventTrigger::OnDeselect(UnityEngine.EventSystems.BaseEventData)
extern void EventTrigger_OnDeselect_m647B65049C6C332711233F0B2F72C99E4AE2DE46 (void);
// 0x00000672 System.Void UnityEngine.EventSystems.EventTrigger::OnScroll(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnScroll_m45ED61FD7F6FAD70C71502A38D2479DEE50B1370 (void);
// 0x00000673 System.Void UnityEngine.EventSystems.EventTrigger::OnMove(UnityEngine.EventSystems.AxisEventData)
extern void EventTrigger_OnMove_mEE11502B46693D5F5C8E23380E0DF0D4B75EE9CF (void);
// 0x00000674 System.Void UnityEngine.EventSystems.EventTrigger::OnUpdateSelected(UnityEngine.EventSystems.BaseEventData)
extern void EventTrigger_OnUpdateSelected_mF5C79E9494D1F1F3D032FFB17B1D5B3701FB5BD7 (void);
// 0x00000675 System.Void UnityEngine.EventSystems.EventTrigger::OnInitializePotentialDrag(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnInitializePotentialDrag_mF57EC5149D92811696046CACFA2CD4422890AE78 (void);
// 0x00000676 System.Void UnityEngine.EventSystems.EventTrigger::OnBeginDrag(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnBeginDrag_m370891394066DA8891BFA458D335A4B878988E7B (void);
// 0x00000677 System.Void UnityEngine.EventSystems.EventTrigger::OnEndDrag(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnEndDrag_mFC87A35C4060855401A4C0C28612829D0894A8A8 (void);
// 0x00000678 System.Void UnityEngine.EventSystems.EventTrigger::OnSubmit(UnityEngine.EventSystems.BaseEventData)
extern void EventTrigger_OnSubmit_m2EC7EAB0AAD5AD0528511C8184A430FD91E95E0D (void);
// 0x00000679 System.Void UnityEngine.EventSystems.EventTrigger::OnCancel(UnityEngine.EventSystems.BaseEventData)
extern void EventTrigger_OnCancel_m17724FAA28975B06DDDE55D06716DE33A1788144 (void);
// 0x0000067A System.Void UnityEngine.EventSystems.EventTrigger/TriggerEvent::.ctor()
extern void TriggerEvent__ctor_mBC60D36344FFB96FBE826D229CE25D4C25E08440 (void);
// 0x0000067B System.Void UnityEngine.EventSystems.EventTrigger/Entry::.ctor()
extern void Entry__ctor_m7325965EB4BD264BE16F837B6AA2693ECEDBB5E8 (void);
// 0x0000067C T UnityEngine.EventSystems.ExecuteEvents::ValidateEventData(UnityEngine.EventSystems.BaseEventData)
// 0x0000067D System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IPointerMoveHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m316D0EE5A1936BFFD9999F4C145722DC6C121FF7 (void);
// 0x0000067E System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IPointerEnterHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m554281680E2DBC534055073ECCE46230E488A3E6 (void);
// 0x0000067F System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IPointerExitHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m3DD6C7687A440E55EEF8B7D115DEF950728295B6 (void);
// 0x00000680 System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IPointerDownHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m36FF8B992CDB75A825077B7A52AA7BE72318B37F (void);
// 0x00000681 System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IPointerUpHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_mD0811E5B0A4F7D5A88E7ACF0A845CA107485F579 (void);
// 0x00000682 System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IPointerClickHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m512ACDD06180A73819570FED3C2BEE0F0E2DA3F2 (void);
// 0x00000683 System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IInitializePotentialDragHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_mCD88FE48772FC6DA5E9FE9CAF910402F63090C35 (void);
// 0x00000684 System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IBeginDragHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m3F3FEE80AD62CF4207EDA55D6998B98DFF8FFB64 (void);
// 0x00000685 System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IDragHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_mBEB42D218E11F4B9834CAC70894631C305E6AF18 (void);
// 0x00000686 System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IEndDragHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m1A35D0185316601E2CE063420F4953C8D3D62D3A (void);
// 0x00000687 System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IDropHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m6DD01624C34CF22057ECF1B0C7E561006DA6D2F3 (void);
// 0x00000688 System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IScrollHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m08AB6D464ED66E7D539C957D84076F79D8ED5563 (void);
// 0x00000689 System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IUpdateSelectedHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_mF1F3202132B706B56AE43B19577758BCA4EAEB88 (void);
// 0x0000068A System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.ISelectHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_mBDDBAF4DEB956C013CD19E514088B6AC086783B2 (void);
// 0x0000068B System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IDeselectHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m070554B8CD391A49E8A51A4FC10C8CB8827E5627 (void);
// 0x0000068C System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IMoveHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_mBC94A654B65C6B14834E3CD0FF0472DB5445E2F2 (void);
// 0x0000068D System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.ISubmitHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m6CE7DBF76F4858C3014295BB2EBBAD768EF5992E (void);
// 0x0000068E System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.ICancelHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m30F76D861B01F5DE4671B93C23B57989889EC8AC (void);
// 0x0000068F UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IPointerMoveHandler> UnityEngine.EventSystems.ExecuteEvents::get_pointerMoveHandler()
extern void ExecuteEvents_get_pointerMoveHandler_m996E37A7026F03F8791EFBB69B72DE1FC4FA3A60 (void);
// 0x00000690 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IPointerEnterHandler> UnityEngine.EventSystems.ExecuteEvents::get_pointerEnterHandler()
extern void ExecuteEvents_get_pointerEnterHandler_m9F921E3357CE38A925DF20E9CD94B4C3AEE9AE48 (void);
// 0x00000691 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IPointerExitHandler> UnityEngine.EventSystems.ExecuteEvents::get_pointerExitHandler()
extern void ExecuteEvents_get_pointerExitHandler_m03735363884BC967C1B04246B51FE98886C9C6DE (void);
// 0x00000692 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IPointerDownHandler> UnityEngine.EventSystems.ExecuteEvents::get_pointerDownHandler()
extern void ExecuteEvents_get_pointerDownHandler_mA67CE33D32540939A273DB88D6456C7FE43C13EF (void);
// 0x00000693 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IPointerUpHandler> UnityEngine.EventSystems.ExecuteEvents::get_pointerUpHandler()
extern void ExecuteEvents_get_pointerUpHandler_m51B83B4AD7498D6F7A2CBD5F2331E91A37AE4CF2 (void);
// 0x00000694 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IPointerClickHandler> UnityEngine.EventSystems.ExecuteEvents::get_pointerClickHandler()
extern void ExecuteEvents_get_pointerClickHandler_m0017F9D1EAF7C02CDDB4C148C92D6685D88EA8D5 (void);
// 0x00000695 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IInitializePotentialDragHandler> UnityEngine.EventSystems.ExecuteEvents::get_initializePotentialDrag()
extern void ExecuteEvents_get_initializePotentialDrag_m16F4CD40448FB1B78F6683AA26A9CC574F48AFBD (void);
// 0x00000696 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IBeginDragHandler> UnityEngine.EventSystems.ExecuteEvents::get_beginDragHandler()
extern void ExecuteEvents_get_beginDragHandler_mB0BEAC09E4A8F31438B07FE68A5BF7267FF8C2FC (void);
// 0x00000697 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IDragHandler> UnityEngine.EventSystems.ExecuteEvents::get_dragHandler()
extern void ExecuteEvents_get_dragHandler_m9193926B9685C80C0560C2E105FF6150C4EAE507 (void);
// 0x00000698 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IEndDragHandler> UnityEngine.EventSystems.ExecuteEvents::get_endDragHandler()
extern void ExecuteEvents_get_endDragHandler_mE78FEEEAE114635E416FF1FE33C851E62B60555B (void);
// 0x00000699 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IDropHandler> UnityEngine.EventSystems.ExecuteEvents::get_dropHandler()
extern void ExecuteEvents_get_dropHandler_m8E00FA7361DE68780ACEB365E6B14206A2180D03 (void);
// 0x0000069A UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IScrollHandler> UnityEngine.EventSystems.ExecuteEvents::get_scrollHandler()
extern void ExecuteEvents_get_scrollHandler_m51E902070611D3F81AD5F1F5762AE2C48E84AFE2 (void);
// 0x0000069B UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IUpdateSelectedHandler> UnityEngine.EventSystems.ExecuteEvents::get_updateSelectedHandler()
extern void ExecuteEvents_get_updateSelectedHandler_m8AF7543437082AD4F5690AAA77F2623AE28C3D09 (void);
// 0x0000069C UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.ISelectHandler> UnityEngine.EventSystems.ExecuteEvents::get_selectHandler()
extern void ExecuteEvents_get_selectHandler_mCF588328D11715E24BC54DF464EF4F3D694B3939 (void);
// 0x0000069D UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IDeselectHandler> UnityEngine.EventSystems.ExecuteEvents::get_deselectHandler()
extern void ExecuteEvents_get_deselectHandler_m9CDD5F8B5269067CA38247DDD41B521A8FCEDFEF (void);
// 0x0000069E UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IMoveHandler> UnityEngine.EventSystems.ExecuteEvents::get_moveHandler()
extern void ExecuteEvents_get_moveHandler_mF717824AB0018BBED3C2DF3C67486E3B2B3836D2 (void);
// 0x0000069F UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.ISubmitHandler> UnityEngine.EventSystems.ExecuteEvents::get_submitHandler()
extern void ExecuteEvents_get_submitHandler_mDCAAA40F0F6AEA385B375C1839B4DC37E5FC4A7A (void);
// 0x000006A0 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.ICancelHandler> UnityEngine.EventSystems.ExecuteEvents::get_cancelHandler()
extern void ExecuteEvents_get_cancelHandler_mBCDFD10C95FC2BBC5DC5A512FEA1BBEECC2DAE12 (void);
// 0x000006A1 System.Void UnityEngine.EventSystems.ExecuteEvents::GetEventChain(UnityEngine.GameObject,System.Collections.Generic.IList`1<UnityEngine.Transform>)
extern void ExecuteEvents_GetEventChain_m4FAD69B97B2D0AADFCA3AE06CA80E680B60632ED (void);
// 0x000006A2 System.Boolean UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.GameObject,UnityEngine.EventSystems.BaseEventData,UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<T>)
// 0x000006A3 UnityEngine.GameObject UnityEngine.EventSystems.ExecuteEvents::ExecuteHierarchy(UnityEngine.GameObject,UnityEngine.EventSystems.BaseEventData,UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<T>)
// 0x000006A4 System.Boolean UnityEngine.EventSystems.ExecuteEvents::ShouldSendToComponent(UnityEngine.Component)
// 0x000006A5 System.Void UnityEngine.EventSystems.ExecuteEvents::GetEventList(UnityEngine.GameObject,System.Collections.Generic.IList`1<UnityEngine.EventSystems.IEventSystemHandler>)
// 0x000006A6 System.Boolean UnityEngine.EventSystems.ExecuteEvents::CanHandleEvent(UnityEngine.GameObject)
// 0x000006A7 UnityEngine.GameObject UnityEngine.EventSystems.ExecuteEvents::GetEventHandler(UnityEngine.GameObject)
// 0x000006A8 System.Void UnityEngine.EventSystems.ExecuteEvents::.cctor()
extern void ExecuteEvents__cctor_mFF9D727E7E8EEEE34D6861D20720411F1CACE9C5 (void);
// 0x000006A9 System.Void UnityEngine.EventSystems.ExecuteEvents/EventFunction`1::.ctor(System.Object,System.IntPtr)
// 0x000006AA System.Void UnityEngine.EventSystems.ExecuteEvents/EventFunction`1::Invoke(T1,UnityEngine.EventSystems.BaseEventData)
// 0x000006AB System.IAsyncResult UnityEngine.EventSystems.ExecuteEvents/EventFunction`1::BeginInvoke(T1,UnityEngine.EventSystems.BaseEventData,System.AsyncCallback,System.Object)
// 0x000006AC System.Void UnityEngine.EventSystems.ExecuteEvents/EventFunction`1::EndInvoke(System.IAsyncResult)
// 0x000006AD System.String UnityEngine.EventSystems.BaseInput::get_compositionString()
extern void BaseInput_get_compositionString_m2F5F37C4A3E1CBFB779113D038802AC2BA3E556E (void);
// 0x000006AE UnityEngine.IMECompositionMode UnityEngine.EventSystems.BaseInput::get_imeCompositionMode()
extern void BaseInput_get_imeCompositionMode_m61F7F9CF12191DE6328F900458CB1886AEDA2B08 (void);
// 0x000006AF System.Void UnityEngine.EventSystems.BaseInput::set_imeCompositionMode(UnityEngine.IMECompositionMode)
extern void BaseInput_set_imeCompositionMode_m10C9A03CA5BE2DD16C356603A1D03EE197B29085 (void);
// 0x000006B0 UnityEngine.Vector2 UnityEngine.EventSystems.BaseInput::get_compositionCursorPos()
extern void BaseInput_get_compositionCursorPos_m40F062B6C5FB3667DE689AA06AA0CA5DD52DBF7C (void);
// 0x000006B1 System.Void UnityEngine.EventSystems.BaseInput::set_compositionCursorPos(UnityEngine.Vector2)
extern void BaseInput_set_compositionCursorPos_m186F1B453469AC2FEE13F9B2144B1A59D4D7519E (void);
// 0x000006B2 System.Boolean UnityEngine.EventSystems.BaseInput::get_mousePresent()
extern void BaseInput_get_mousePresent_mCB00324CF55402907B52C63213CF397E53D03E71 (void);
// 0x000006B3 System.Boolean UnityEngine.EventSystems.BaseInput::GetMouseButtonDown(System.Int32)
extern void BaseInput_GetMouseButtonDown_m6276D605B7C48000F3D61BF56BE9E3B5F86398AF (void);
// 0x000006B4 System.Boolean UnityEngine.EventSystems.BaseInput::GetMouseButtonUp(System.Int32)
extern void BaseInput_GetMouseButtonUp_mBB470F97111BB7BCC1B543CD282F898C9033DAE4 (void);
// 0x000006B5 System.Boolean UnityEngine.EventSystems.BaseInput::GetMouseButton(System.Int32)
extern void BaseInput_GetMouseButton_mD6EAA726BE691C40052FEDBFF51AEAA1DACAAB57 (void);
// 0x000006B6 UnityEngine.Vector2 UnityEngine.EventSystems.BaseInput::get_mousePosition()
extern void BaseInput_get_mousePosition_mD75C96534C8B4EFF48A732F4826E6C9E09CB4540 (void);
// 0x000006B7 UnityEngine.Vector2 UnityEngine.EventSystems.BaseInput::get_mouseScrollDelta()
extern void BaseInput_get_mouseScrollDelta_mD764FCD7B05C6505AAB3161C3011A5EA51DEDC39 (void);
// 0x000006B8 System.Boolean UnityEngine.EventSystems.BaseInput::get_touchSupported()
extern void BaseInput_get_touchSupported_mA46B82A5BCB1A1BE47FB15BD4ACD522694DBDC1C (void);
// 0x000006B9 System.Int32 UnityEngine.EventSystems.BaseInput::get_touchCount()
extern void BaseInput_get_touchCount_mCD103B50B46B7938389AE38F81C34F173B9F94FD (void);
// 0x000006BA UnityEngine.Touch UnityEngine.EventSystems.BaseInput::GetTouch(System.Int32)
extern void BaseInput_GetTouch_m1FA092A2BD2276B8F94A3058B3D8A9E301DDCBE6 (void);
// 0x000006BB System.Single UnityEngine.EventSystems.BaseInput::GetAxisRaw(System.String)
extern void BaseInput_GetAxisRaw_m817F925099FC5D22086D616249C0CB5C7F21445B (void);
// 0x000006BC System.Boolean UnityEngine.EventSystems.BaseInput::GetButtonDown(System.String)
extern void BaseInput_GetButtonDown_m3B34561DB7A1E129F880B1E09CE8B844B1FF6FBC (void);
// 0x000006BD System.Void UnityEngine.EventSystems.BaseInput::.ctor()
extern void BaseInput__ctor_m7E497239A0A78CCAC04BE6EE9AA81D49D887787C (void);
// 0x000006BE System.Boolean UnityEngine.EventSystems.BaseInputModule::get_sendPointerHoverToParent()
extern void BaseInputModule_get_sendPointerHoverToParent_m3C22EF19BA6E95672ACD15F7E3FCD11277EBBF47 (void);
// 0x000006BF System.Void UnityEngine.EventSystems.BaseInputModule::set_sendPointerHoverToParent(System.Boolean)
extern void BaseInputModule_set_sendPointerHoverToParent_m1E97FE3C9AEECB53AFAB89429D6ABCFE7A9F1882 (void);
// 0x000006C0 UnityEngine.EventSystems.BaseInput UnityEngine.EventSystems.BaseInputModule::get_input()
extern void BaseInputModule_get_input_mCB3F78528AA14A7AD7E957870DBB0152B4BF13FB (void);
// 0x000006C1 UnityEngine.EventSystems.BaseInput UnityEngine.EventSystems.BaseInputModule::get_inputOverride()
extern void BaseInputModule_get_inputOverride_m92D66E309898C180BF887F6043CCE7AE63C6C44C (void);
// 0x000006C2 System.Void UnityEngine.EventSystems.BaseInputModule::set_inputOverride(UnityEngine.EventSystems.BaseInput)
extern void BaseInputModule_set_inputOverride_m876BAC421A4BC40FB5873FC386E361C4CFA53987 (void);
// 0x000006C3 UnityEngine.EventSystems.EventSystem UnityEngine.EventSystems.BaseInputModule::get_eventSystem()
extern void BaseInputModule_get_eventSystem_m341B2378F61A58D5432906B9EE1E12265E2FAB33 (void);
// 0x000006C4 System.Void UnityEngine.EventSystems.BaseInputModule::OnEnable()
extern void BaseInputModule_OnEnable_m2F440F226F94D4D79905CD403F08C3AEEE99D965 (void);
// 0x000006C5 System.Void UnityEngine.EventSystems.BaseInputModule::OnDisable()
extern void BaseInputModule_OnDisable_m370643AD83FFAD10B9E67301355F63B4FF7FB389 (void);
// 0x000006C6 System.Void UnityEngine.EventSystems.BaseInputModule::Process()
// 0x000006C7 UnityEngine.EventSystems.RaycastResult UnityEngine.EventSystems.BaseInputModule::FindFirstRaycast(System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
extern void BaseInputModule_FindFirstRaycast_mE07BDA14A7C9A8E3DFBFDAF449E5896597C9F6F5 (void);
// 0x000006C8 UnityEngine.EventSystems.MoveDirection UnityEngine.EventSystems.BaseInputModule::DetermineMoveDirection(System.Single,System.Single)
extern void BaseInputModule_DetermineMoveDirection_m8C99256812C74890B4F54BBCA5BE424A7D608E15 (void);
// 0x000006C9 UnityEngine.EventSystems.MoveDirection UnityEngine.EventSystems.BaseInputModule::DetermineMoveDirection(System.Single,System.Single,System.Single)
extern void BaseInputModule_DetermineMoveDirection_m6461EE20A0418E30EFA13CD293A2B0E7A95DBA54 (void);
// 0x000006CA UnityEngine.GameObject UnityEngine.EventSystems.BaseInputModule::FindCommonRoot(UnityEngine.GameObject,UnityEngine.GameObject)
extern void BaseInputModule_FindCommonRoot_mBCC0541CA6E2BCFF051B90FE34F4F00C28CDFA10 (void);
// 0x000006CB System.Void UnityEngine.EventSystems.BaseInputModule::HandlePointerExitAndEnter(UnityEngine.EventSystems.PointerEventData,UnityEngine.GameObject)
extern void BaseInputModule_HandlePointerExitAndEnter_m0815F06EAF8F937916E0656D66A69844CB211298 (void);
// 0x000006CC UnityEngine.EventSystems.AxisEventData UnityEngine.EventSystems.BaseInputModule::GetAxisEventData(System.Single,System.Single,System.Single)
extern void BaseInputModule_GetAxisEventData_m99FD46006BB2D8FD6D1E10F606886FE017955293 (void);
// 0x000006CD UnityEngine.EventSystems.BaseEventData UnityEngine.EventSystems.BaseInputModule::GetBaseEventData()
extern void BaseInputModule_GetBaseEventData_mF750E3A63EC1080B933A2FA2CC21D683A68ED433 (void);
// 0x000006CE System.Boolean UnityEngine.EventSystems.BaseInputModule::IsPointerOverGameObject(System.Int32)
extern void BaseInputModule_IsPointerOverGameObject_m1406F19FE6A3CAEECB2238427345E4CA32E1AD6F (void);
// 0x000006CF System.Boolean UnityEngine.EventSystems.BaseInputModule::ShouldActivateModule()
extern void BaseInputModule_ShouldActivateModule_m51B70F9097EF7FEB20B62D4D775F7FEA853185A1 (void);
// 0x000006D0 System.Void UnityEngine.EventSystems.BaseInputModule::DeactivateModule()
extern void BaseInputModule_DeactivateModule_mAE698307DADBE4DE8A26BD3DE5F3F7E3D75B385D (void);
// 0x000006D1 System.Void UnityEngine.EventSystems.BaseInputModule::ActivateModule()
extern void BaseInputModule_ActivateModule_m2C693E95727E13FDF06D54FA8762A040175AC3BA (void);
// 0x000006D2 System.Void UnityEngine.EventSystems.BaseInputModule::UpdateModule()
extern void BaseInputModule_UpdateModule_m201C2C266D80D7451D42E929A90EFC8C4B7358BE (void);
// 0x000006D3 System.Boolean UnityEngine.EventSystems.BaseInputModule::IsModuleSupported()
extern void BaseInputModule_IsModuleSupported_m60644A4C84A8B0FA66E204E20D149A0BCFAD27A2 (void);
// 0x000006D4 System.Int32 UnityEngine.EventSystems.BaseInputModule::ConvertUIToolkitPointerId(UnityEngine.EventSystems.PointerEventData)
extern void BaseInputModule_ConvertUIToolkitPointerId_m067C6EDDF29815FE295111E95A38F66860D1E441 (void);
// 0x000006D5 System.Void UnityEngine.EventSystems.BaseInputModule::.ctor()
extern void BaseInputModule__ctor_m88DDBBE7BC4BB7170F5F8F00A0C9E2EC6328B819 (void);
// 0x000006D6 System.Boolean UnityEngine.EventSystems.PointerInputModule::GetPointerData(System.Int32,UnityEngine.EventSystems.PointerEventData&,System.Boolean)
extern void PointerInputModule_GetPointerData_m8D1C52EE44136560312932072786A2B5AA2C8BE5 (void);
// 0x000006D7 System.Void UnityEngine.EventSystems.PointerInputModule::RemovePointerData(UnityEngine.EventSystems.PointerEventData)
extern void PointerInputModule_RemovePointerData_m012713A1B4511855549793D6BA2B7998134B1BE9 (void);
// 0x000006D8 UnityEngine.EventSystems.PointerEventData UnityEngine.EventSystems.PointerInputModule::GetTouchPointerEventData(UnityEngine.Touch,System.Boolean&,System.Boolean&)
extern void PointerInputModule_GetTouchPointerEventData_m55EBA8BD04214AAD8E98B9109D44610496A5B2E1 (void);
// 0x000006D9 System.Void UnityEngine.EventSystems.PointerInputModule::CopyFromTo(UnityEngine.EventSystems.PointerEventData,UnityEngine.EventSystems.PointerEventData)
extern void PointerInputModule_CopyFromTo_m4302FE47F12B3B8C59A3790BD0ADF2BFAAEA9BFD (void);
// 0x000006DA UnityEngine.EventSystems.PointerEventData/FramePressState UnityEngine.EventSystems.PointerInputModule::StateForMouseButton(System.Int32)
extern void PointerInputModule_StateForMouseButton_mED5B48F98F706160F97A26511FB82BD84DBAB0CF (void);
// 0x000006DB UnityEngine.EventSystems.PointerInputModule/MouseState UnityEngine.EventSystems.PointerInputModule::GetMousePointerEventData()
extern void PointerInputModule_GetMousePointerEventData_m77052AB014196BA4E66C8BBE27EC9AF739031EFE (void);
// 0x000006DC UnityEngine.EventSystems.PointerInputModule/MouseState UnityEngine.EventSystems.PointerInputModule::GetMousePointerEventData(System.Int32)
extern void PointerInputModule_GetMousePointerEventData_m8D8111399CF7077AEBE4836AC701DDDF3F5ADFC5 (void);
// 0x000006DD UnityEngine.EventSystems.PointerEventData UnityEngine.EventSystems.PointerInputModule::GetLastPointerEventData(System.Int32)
extern void PointerInputModule_GetLastPointerEventData_m6355023718EB2DCF6D9C226A57B63B70CCEECAB4 (void);
// 0x000006DE System.Boolean UnityEngine.EventSystems.PointerInputModule::ShouldStartDrag(UnityEngine.Vector2,UnityEngine.Vector2,System.Single,System.Boolean)
extern void PointerInputModule_ShouldStartDrag_m6260055DEAD5E28183E338BDA53C7F8A0521EC6B (void);
// 0x000006DF System.Void UnityEngine.EventSystems.PointerInputModule::ProcessMove(UnityEngine.EventSystems.PointerEventData)
extern void PointerInputModule_ProcessMove_m3555F333D82A446C2354D8855034323BF7C9208A (void);
// 0x000006E0 System.Void UnityEngine.EventSystems.PointerInputModule::ProcessDrag(UnityEngine.EventSystems.PointerEventData)
extern void PointerInputModule_ProcessDrag_m73FE39BFACC950DCA7FDD7BDC67F45484DC01207 (void);
// 0x000006E1 System.Boolean UnityEngine.EventSystems.PointerInputModule::IsPointerOverGameObject(System.Int32)
extern void PointerInputModule_IsPointerOverGameObject_mBDCC057426289D69D4C6E1EF7F6849C112171883 (void);
// 0x000006E2 System.Void UnityEngine.EventSystems.PointerInputModule::ClearSelection()
extern void PointerInputModule_ClearSelection_mC5852667E5B9CA97C2A4CAB3D7C907344511C1D2 (void);
// 0x000006E3 System.String UnityEngine.EventSystems.PointerInputModule::ToString()
extern void PointerInputModule_ToString_m9C5DB37AC45C9F27B017E3B52C5CFE22F91CAF9D (void);
// 0x000006E4 System.Void UnityEngine.EventSystems.PointerInputModule::DeselectIfSelectionChanged(UnityEngine.GameObject,UnityEngine.EventSystems.BaseEventData)
extern void PointerInputModule_DeselectIfSelectionChanged_m8F111DD2317E33C4F0498F651BC52BD5C984A95B (void);
// 0x000006E5 System.Void UnityEngine.EventSystems.PointerInputModule::.ctor()
extern void PointerInputModule__ctor_mBF074492478BFC24F87EF2C941D6C11A8ACDAF11 (void);
// 0x000006E6 UnityEngine.EventSystems.PointerInputModule/MouseButtonEventData UnityEngine.EventSystems.PointerInputModule/ButtonState::get_eventData()
extern void ButtonState_get_eventData_m4767730784143F1DCE06B6138658A31CBC5E155F (void);
// 0x000006E7 System.Void UnityEngine.EventSystems.PointerInputModule/ButtonState::set_eventData(UnityEngine.EventSystems.PointerInputModule/MouseButtonEventData)
extern void ButtonState_set_eventData_mA9D59CB9A1565A7D99569E87D88B90738FEF4E1F (void);
// 0x000006E8 UnityEngine.EventSystems.PointerEventData/InputButton UnityEngine.EventSystems.PointerInputModule/ButtonState::get_button()
extern void ButtonState_get_button_m2210A465432D0F990F2380B6357AD2FBA4A7540D (void);
// 0x000006E9 System.Void UnityEngine.EventSystems.PointerInputModule/ButtonState::set_button(UnityEngine.EventSystems.PointerEventData/InputButton)
extern void ButtonState_set_button_mFAE3F16E2B027BD6B854F18E7C7C2D6CDAB023DE (void);
// 0x000006EA System.Void UnityEngine.EventSystems.PointerInputModule/ButtonState::.ctor()
extern void ButtonState__ctor_m4D7C25C0E1FC598646FFBD436B9A2042DB41AC9E (void);
// 0x000006EB System.Boolean UnityEngine.EventSystems.PointerInputModule/MouseState::AnyPressesThisFrame()
extern void MouseState_AnyPressesThisFrame_m4887FF61D58D641496B95C83710C8A4E841970F3 (void);
// 0x000006EC System.Boolean UnityEngine.EventSystems.PointerInputModule/MouseState::AnyReleasesThisFrame()
extern void MouseState_AnyReleasesThisFrame_m4FBA37A12735418AD0970F11BC44850517B05E93 (void);
// 0x000006ED UnityEngine.EventSystems.PointerInputModule/ButtonState UnityEngine.EventSystems.PointerInputModule/MouseState::GetButtonState(UnityEngine.EventSystems.PointerEventData/InputButton)
extern void MouseState_GetButtonState_mD25E7D214B0499DBBE3B3E532CD7085C1A021E51 (void);
// 0x000006EE System.Void UnityEngine.EventSystems.PointerInputModule/MouseState::SetButtonState(UnityEngine.EventSystems.PointerEventData/InputButton,UnityEngine.EventSystems.PointerEventData/FramePressState,UnityEngine.EventSystems.PointerEventData)
extern void MouseState_SetButtonState_m72DA468C8D10E76923FA5F993BBDBCFFF57E4326 (void);
// 0x000006EF System.Void UnityEngine.EventSystems.PointerInputModule/MouseState::.ctor()
extern void MouseState__ctor_mF4A8041A86E50D91202770E73CE0DAF12BB207D9 (void);
// 0x000006F0 System.Boolean UnityEngine.EventSystems.PointerInputModule/MouseButtonEventData::PressedThisFrame()
extern void MouseButtonEventData_PressedThisFrame_mEE5DC95537AAEB346C57DCA85917E0701A44388D (void);
// 0x000006F1 System.Boolean UnityEngine.EventSystems.PointerInputModule/MouseButtonEventData::ReleasedThisFrame()
extern void MouseButtonEventData_ReleasedThisFrame_m5AD4F06D1CA6E0ACD6E84EEFAD4FB112098AFD51 (void);
// 0x000006F2 System.Void UnityEngine.EventSystems.PointerInputModule/MouseButtonEventData::.ctor()
extern void MouseButtonEventData__ctor_m9EDAC7F39F1D3CFBB93403DDE620A5147C4469A2 (void);
// 0x000006F3 System.Void UnityEngine.EventSystems.StandaloneInputModule::.ctor()
extern void StandaloneInputModule__ctor_m77BAC1DB71B81FFCD2791DE706BD4FE239F47C27 (void);
// 0x000006F4 UnityEngine.EventSystems.StandaloneInputModule/InputMode UnityEngine.EventSystems.StandaloneInputModule::get_inputMode()
extern void StandaloneInputModule_get_inputMode_m38D63EDD9DE39E7AFE1821BDE201625C292C66D9 (void);
// 0x000006F5 System.Boolean UnityEngine.EventSystems.StandaloneInputModule::get_allowActivationOnMobileDevice()
extern void StandaloneInputModule_get_allowActivationOnMobileDevice_m03E7DC8FCBE7B43A223EADABB454445C91664A1B (void);
// 0x000006F6 System.Void UnityEngine.EventSystems.StandaloneInputModule::set_allowActivationOnMobileDevice(System.Boolean)
extern void StandaloneInputModule_set_allowActivationOnMobileDevice_mFFFF3E19FBD199ED9BFAEC535E5BD11F5027FF25 (void);
// 0x000006F7 System.Boolean UnityEngine.EventSystems.StandaloneInputModule::get_forceModuleActive()
extern void StandaloneInputModule_get_forceModuleActive_m381A5525E48FD280EB91ECEEEF138E7603C004B8 (void);
// 0x000006F8 System.Void UnityEngine.EventSystems.StandaloneInputModule::set_forceModuleActive(System.Boolean)
extern void StandaloneInputModule_set_forceModuleActive_m4C3FD8550258266795D24863D8B531F2402500DD (void);
// 0x000006F9 System.Single UnityEngine.EventSystems.StandaloneInputModule::get_inputActionsPerSecond()
extern void StandaloneInputModule_get_inputActionsPerSecond_m584ABC794A3864BF91EEB27E62ED6E8081DEE0A5 (void);
// 0x000006FA System.Void UnityEngine.EventSystems.StandaloneInputModule::set_inputActionsPerSecond(System.Single)
extern void StandaloneInputModule_set_inputActionsPerSecond_mF367AFA55FF576533999F2DFB60514D7247228FF (void);
// 0x000006FB System.Single UnityEngine.EventSystems.StandaloneInputModule::get_repeatDelay()
extern void StandaloneInputModule_get_repeatDelay_mDB85393BD9AA45BF8C5B94F5E3A523F5480D1F6F (void);
// 0x000006FC System.Void UnityEngine.EventSystems.StandaloneInputModule::set_repeatDelay(System.Single)
extern void StandaloneInputModule_set_repeatDelay_m236DB6414CFAE01609187B97E955D95A32F0CB40 (void);
// 0x000006FD System.String UnityEngine.EventSystems.StandaloneInputModule::get_horizontalAxis()
extern void StandaloneInputModule_get_horizontalAxis_mDB47CA6F06F26837BBC4853877F69817590161F0 (void);
// 0x000006FE System.Void UnityEngine.EventSystems.StandaloneInputModule::set_horizontalAxis(System.String)
extern void StandaloneInputModule_set_horizontalAxis_mF71F2B0B425BD0455AF54F39EEEE43DD80DE27EC (void);
// 0x000006FF System.String UnityEngine.EventSystems.StandaloneInputModule::get_verticalAxis()
extern void StandaloneInputModule_get_verticalAxis_m5F00ECDA3B18F48BCBD6F9E7B4AD67A1F56CFAC2 (void);
// 0x00000700 System.Void UnityEngine.EventSystems.StandaloneInputModule::set_verticalAxis(System.String)
extern void StandaloneInputModule_set_verticalAxis_mB0FE6DC9517F0ABF0107F72FC04A322FD91C2AC0 (void);
// 0x00000701 System.String UnityEngine.EventSystems.StandaloneInputModule::get_submitButton()
extern void StandaloneInputModule_get_submitButton_mAF097B352341EB53A42F71052F3469F205243D40 (void);
// 0x00000702 System.Void UnityEngine.EventSystems.StandaloneInputModule::set_submitButton(System.String)
extern void StandaloneInputModule_set_submitButton_m571CB829C6D76AD062BA105D0903F08CEA0BCCC7 (void);
// 0x00000703 System.String UnityEngine.EventSystems.StandaloneInputModule::get_cancelButton()
extern void StandaloneInputModule_get_cancelButton_mE6F80897FDAA6D931803BF6C3A9E4A45877E5585 (void);
// 0x00000704 System.Void UnityEngine.EventSystems.StandaloneInputModule::set_cancelButton(System.String)
extern void StandaloneInputModule_set_cancelButton_m63A06532F16A21785B3BD5AD3B79509B4441B7EF (void);
// 0x00000705 System.Boolean UnityEngine.EventSystems.StandaloneInputModule::ShouldIgnoreEventsOnNoFocus()
extern void StandaloneInputModule_ShouldIgnoreEventsOnNoFocus_m423AA5752E528E3B32F105EE2B341FCF5E9F8285 (void);
// 0x00000706 System.Void UnityEngine.EventSystems.StandaloneInputModule::UpdateModule()
extern void StandaloneInputModule_UpdateModule_m8B42D289F6AB3EBE6071FB5B904A7449118EAA6B (void);
// 0x00000707 System.Void UnityEngine.EventSystems.StandaloneInputModule::ReleaseMouse(UnityEngine.EventSystems.PointerEventData,UnityEngine.GameObject)
extern void StandaloneInputModule_ReleaseMouse_mC5C3083C356ACD5CD420A58662D99A6CACC5FAF5 (void);
// 0x00000708 System.Boolean UnityEngine.EventSystems.StandaloneInputModule::ShouldActivateModule()
extern void StandaloneInputModule_ShouldActivateModule_m6E9E205A37636246BFE65CAC33E1EF703A4D99AF (void);
// 0x00000709 System.Void UnityEngine.EventSystems.StandaloneInputModule::ActivateModule()
extern void StandaloneInputModule_ActivateModule_m1F28B8DB0FC20082694221BE5B1B275E9B7224BB (void);
// 0x0000070A System.Void UnityEngine.EventSystems.StandaloneInputModule::DeactivateModule()
extern void StandaloneInputModule_DeactivateModule_m064C1EB615C0E0B0EDFC6F6F5079E55270DF1468 (void);
// 0x0000070B System.Void UnityEngine.EventSystems.StandaloneInputModule::Process()
extern void StandaloneInputModule_Process_mBD949CC45BBCAB5A0FAF5E24F3BB4C3B22FF3E81 (void);
// 0x0000070C System.Boolean UnityEngine.EventSystems.StandaloneInputModule::ProcessTouchEvents()
extern void StandaloneInputModule_ProcessTouchEvents_m042FC6B13874B1EE6699BBB51F02FE3A435A25F0 (void);
// 0x0000070D System.Void UnityEngine.EventSystems.StandaloneInputModule::ProcessTouchPress(UnityEngine.EventSystems.PointerEventData,System.Boolean,System.Boolean)
extern void StandaloneInputModule_ProcessTouchPress_mD72A0807626DA04E47313F9553249DD4A32625E3 (void);
// 0x0000070E System.Boolean UnityEngine.EventSystems.StandaloneInputModule::SendSubmitEventToSelectedObject()
extern void StandaloneInputModule_SendSubmitEventToSelectedObject_m7121ACC09ABA46FF5CDDEAE7B26507BE06A2953F (void);
// 0x0000070F UnityEngine.Vector2 UnityEngine.EventSystems.StandaloneInputModule::GetRawMoveVector()
extern void StandaloneInputModule_GetRawMoveVector_mFF583B1720780B7D8D2DD3248F947ED8D855610B (void);
// 0x00000710 System.Boolean UnityEngine.EventSystems.StandaloneInputModule::SendMoveEventToSelectedObject()
extern void StandaloneInputModule_SendMoveEventToSelectedObject_mC71D1E623B1DB82DC4E035277AC5FFA7CD64E981 (void);
// 0x00000711 System.Void UnityEngine.EventSystems.StandaloneInputModule::ProcessMouseEvent()
extern void StandaloneInputModule_ProcessMouseEvent_mCE1BA96E47D9A4448614CB9DAF5A406754F655DD (void);
// 0x00000712 System.Boolean UnityEngine.EventSystems.StandaloneInputModule::ForceAutoSelect()
extern void StandaloneInputModule_ForceAutoSelect_m8A0FD9795D64CAF49AED184D30FA5C7AB6439C75 (void);
// 0x00000713 System.Void UnityEngine.EventSystems.StandaloneInputModule::ProcessMouseEvent(System.Int32)
extern void StandaloneInputModule_ProcessMouseEvent_m8A8214EB9286BA31C18F515BCC3349DF740B2BBA (void);
// 0x00000714 System.Boolean UnityEngine.EventSystems.StandaloneInputModule::SendUpdateEventToSelectedObject()
extern void StandaloneInputModule_SendUpdateEventToSelectedObject_mE1C4AEB5B19378C2BF97DD3EAF4AA9C0EC5E7520 (void);
// 0x00000715 System.Void UnityEngine.EventSystems.StandaloneInputModule::ProcessMousePress(UnityEngine.EventSystems.PointerInputModule/MouseButtonEventData)
extern void StandaloneInputModule_ProcessMousePress_m24665E707FEF5C80719847D62A8A8AEABE27C6C5 (void);
// 0x00000716 UnityEngine.GameObject UnityEngine.EventSystems.StandaloneInputModule::GetCurrentFocusedGameObject()
extern void StandaloneInputModule_GetCurrentFocusedGameObject_m6E67A53E66DE554CCD13A943638815631A3E8E87 (void);
// 0x00000717 System.Void UnityEngine.EventSystems.TouchInputModule::.ctor()
extern void TouchInputModule__ctor_mCBE23B5A3A8CE1CD042A061D7E070B04A45E3075 (void);
// 0x00000718 System.Boolean UnityEngine.EventSystems.TouchInputModule::get_allowActivationOnStandalone()
extern void TouchInputModule_get_allowActivationOnStandalone_m2F9A65E10F7BE98D250CC3D6C9CABA3BCCE95995 (void);
// 0x00000719 System.Void UnityEngine.EventSystems.TouchInputModule::set_allowActivationOnStandalone(System.Boolean)
extern void TouchInputModule_set_allowActivationOnStandalone_m5AB9798D9B6071B37FC67E0D1A81A58A0A59D7AD (void);
// 0x0000071A System.Boolean UnityEngine.EventSystems.TouchInputModule::get_forceModuleActive()
extern void TouchInputModule_get_forceModuleActive_m7200F7B6C80EDD69987615B8356B6B2497461FCA (void);
// 0x0000071B System.Void UnityEngine.EventSystems.TouchInputModule::set_forceModuleActive(System.Boolean)
extern void TouchInputModule_set_forceModuleActive_m32676A04010774CA55055EE93A05ED6C6388D2C2 (void);
// 0x0000071C System.Void UnityEngine.EventSystems.TouchInputModule::UpdateModule()
extern void TouchInputModule_UpdateModule_mE6F4F74D770ACFEF3C46611C71CBE705342EA608 (void);
// 0x0000071D System.Boolean UnityEngine.EventSystems.TouchInputModule::IsModuleSupported()
extern void TouchInputModule_IsModuleSupported_m795B5298EC90DC063A96147CF3B3287EC27C9799 (void);
// 0x0000071E System.Boolean UnityEngine.EventSystems.TouchInputModule::ShouldActivateModule()
extern void TouchInputModule_ShouldActivateModule_m4B17231DE579430D27088D6592378FB7547ADBDC (void);
// 0x0000071F System.Boolean UnityEngine.EventSystems.TouchInputModule::UseFakeInput()
extern void TouchInputModule_UseFakeInput_m66A84384ADA044187F239B1CFC143C42E5E56774 (void);
// 0x00000720 System.Void UnityEngine.EventSystems.TouchInputModule::Process()
extern void TouchInputModule_Process_m3C0CB50AB7D9E92B519787F7742AE0976FB36841 (void);
// 0x00000721 System.Void UnityEngine.EventSystems.TouchInputModule::FakeTouches()
extern void TouchInputModule_FakeTouches_m264BF2C70234CD04B0162FE4CED673B1A77A84F9 (void);
// 0x00000722 System.Void UnityEngine.EventSystems.TouchInputModule::ProcessTouchEvents()
extern void TouchInputModule_ProcessTouchEvents_mBB28D85996F6280141E39A462BC35EF01373E514 (void);
// 0x00000723 System.Void UnityEngine.EventSystems.TouchInputModule::ProcessTouchPress(UnityEngine.EventSystems.PointerEventData,System.Boolean,System.Boolean)
extern void TouchInputModule_ProcessTouchPress_m1DC51E52E6B419F02626EB567A60411A0FCFA517 (void);
// 0x00000724 System.Void UnityEngine.EventSystems.TouchInputModule::DeactivateModule()
extern void TouchInputModule_DeactivateModule_m7CF377DBC376C3EC560523E76514E9F47CCC9DEE (void);
// 0x00000725 System.String UnityEngine.EventSystems.TouchInputModule::ToString()
extern void TouchInputModule_ToString_m1AD08DB012D85A33FC0EA3322D5AA5EB98CD1956 (void);
// 0x00000726 System.Void UnityEngine.EventSystems.RaycasterManager::AddRaycaster(UnityEngine.EventSystems.BaseRaycaster)
extern void RaycasterManager_AddRaycaster_mD2EE52F55FBDB3BEAAF583C4445D4D16B09B6350 (void);
// 0x00000727 System.Collections.Generic.List`1<UnityEngine.EventSystems.BaseRaycaster> UnityEngine.EventSystems.RaycasterManager::GetRaycasters()
extern void RaycasterManager_GetRaycasters_m876BA9CA8DB8E6D351DC4A97473753503B7017DE (void);
// 0x00000728 System.Void UnityEngine.EventSystems.RaycasterManager::RemoveRaycasters(UnityEngine.EventSystems.BaseRaycaster)
extern void RaycasterManager_RemoveRaycasters_m0800E0ACE007AD43B62D10C1029EC85E7DE28999 (void);
// 0x00000729 System.Void UnityEngine.EventSystems.RaycasterManager::.cctor()
extern void RaycasterManager__cctor_m06146026A557346F1469D15E855918E746125F90 (void);
// 0x0000072A System.Void UnityEngine.EventSystems.BaseRaycaster::Raycast(UnityEngine.EventSystems.PointerEventData,System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
// 0x0000072B UnityEngine.Camera UnityEngine.EventSystems.BaseRaycaster::get_eventCamera()
// 0x0000072C System.Int32 UnityEngine.EventSystems.BaseRaycaster::get_priority()
extern void BaseRaycaster_get_priority_m79C109ECC138B84A60F9CFA40242628A8B29C838 (void);
// 0x0000072D System.Int32 UnityEngine.EventSystems.BaseRaycaster::get_sortOrderPriority()
extern void BaseRaycaster_get_sortOrderPriority_m4E0BEBF85F720AE4B7C78E99CCD786779C3E7226 (void);
// 0x0000072E System.Int32 UnityEngine.EventSystems.BaseRaycaster::get_renderOrderPriority()
extern void BaseRaycaster_get_renderOrderPriority_m03C407856FF76393AB6EE26FA173131B8F36CA66 (void);
// 0x0000072F UnityEngine.EventSystems.BaseRaycaster UnityEngine.EventSystems.BaseRaycaster::get_rootRaycaster()
extern void BaseRaycaster_get_rootRaycaster_m63E20D85A8B9867AC196768924F8BE579668BF28 (void);
// 0x00000730 System.String UnityEngine.EventSystems.BaseRaycaster::ToString()
extern void BaseRaycaster_ToString_m12811CE16AB7E07C949B78CDE309C4B2E44B5377 (void);
// 0x00000731 System.Void UnityEngine.EventSystems.BaseRaycaster::OnEnable()
extern void BaseRaycaster_OnEnable_m87CCF1ACD4116BB8BC0D9DB427F5B07C6FDE3D96 (void);
// 0x00000732 System.Void UnityEngine.EventSystems.BaseRaycaster::OnDisable()
extern void BaseRaycaster_OnDisable_mC90A700D5F78DDAD0DD926983C2A8D7C50A5D880 (void);
// 0x00000733 System.Void UnityEngine.EventSystems.BaseRaycaster::OnCanvasHierarchyChanged()
extern void BaseRaycaster_OnCanvasHierarchyChanged_m20A82CFED659012D1F052C5026B8294B44D99BD7 (void);
// 0x00000734 System.Void UnityEngine.EventSystems.BaseRaycaster::OnTransformParentChanged()
extern void BaseRaycaster_OnTransformParentChanged_m121068CDDBC97032FF51C4ED944D4C126CB58F7F (void);
// 0x00000735 System.Void UnityEngine.EventSystems.BaseRaycaster::.ctor()
extern void BaseRaycaster__ctor_m1B6A963368E54C1E450BE15FAF1AE082142A1683 (void);
// 0x00000736 System.Void UnityEngine.EventSystems.Physics2DRaycaster::.ctor()
extern void Physics2DRaycaster__ctor_mF2F12F2AF9DDCA74EB09349D038A67F3D3F88CF9 (void);
// 0x00000737 System.Void UnityEngine.EventSystems.Physics2DRaycaster::Raycast(UnityEngine.EventSystems.PointerEventData,System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
extern void Physics2DRaycaster_Raycast_m9F6AA9C9DC7A34C01959F2053446D3FFCE567630 (void);
// 0x00000738 System.Void UnityEngine.EventSystems.PhysicsRaycaster::.ctor()
extern void PhysicsRaycaster__ctor_mB7D4BAC26DC219A10060B35498EE9D5F05AD0E80 (void);
// 0x00000739 UnityEngine.Camera UnityEngine.EventSystems.PhysicsRaycaster::get_eventCamera()
extern void PhysicsRaycaster_get_eventCamera_m95026618116D1781A906DDE4AF9C415F2374013C (void);
// 0x0000073A System.Int32 UnityEngine.EventSystems.PhysicsRaycaster::get_depth()
extern void PhysicsRaycaster_get_depth_mCC2E924588088DB1DCA160765C09734D3C4F7F60 (void);
// 0x0000073B System.Int32 UnityEngine.EventSystems.PhysicsRaycaster::get_finalEventMask()
extern void PhysicsRaycaster_get_finalEventMask_m20AD2327FE81B38A5853B23970A587EAA2ECCB1B (void);
// 0x0000073C UnityEngine.LayerMask UnityEngine.EventSystems.PhysicsRaycaster::get_eventMask()
extern void PhysicsRaycaster_get_eventMask_mA8FE3884CD425BD59BD22784F4D5219159426DB9 (void);
// 0x0000073D System.Void UnityEngine.EventSystems.PhysicsRaycaster::set_eventMask(UnityEngine.LayerMask)
extern void PhysicsRaycaster_set_eventMask_mD5110BE565C7E3F1738369519D44587452CA056D (void);
// 0x0000073E System.Int32 UnityEngine.EventSystems.PhysicsRaycaster::get_maxRayIntersections()
extern void PhysicsRaycaster_get_maxRayIntersections_mA06D0B5E291BCF94AE1EF4ED7B68890F39395911 (void);
// 0x0000073F System.Void UnityEngine.EventSystems.PhysicsRaycaster::set_maxRayIntersections(System.Int32)
extern void PhysicsRaycaster_set_maxRayIntersections_mECCF07932870A3B5C8875AE6204FC1ECB2CE01F7 (void);
// 0x00000740 System.Boolean UnityEngine.EventSystems.PhysicsRaycaster::ComputeRayAndDistance(UnityEngine.EventSystems.PointerEventData,UnityEngine.Ray&,System.Int32&,System.Single&)
extern void PhysicsRaycaster_ComputeRayAndDistance_mCFEFA9D83EC1E63393454E383FFFEF89E14C173B (void);
// 0x00000741 System.Void UnityEngine.EventSystems.PhysicsRaycaster::Raycast(UnityEngine.EventSystems.PointerEventData,System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
extern void PhysicsRaycaster_Raycast_mB29925EB33102E9BEAA76658F8A59CA666C78B1A (void);
// 0x00000742 System.Int32 UnityEngine.EventSystems.PhysicsRaycaster/RaycastHitComparer::Compare(UnityEngine.RaycastHit,UnityEngine.RaycastHit)
extern void RaycastHitComparer_Compare_mB5B88FE52375A12B781682C712FE58193F417A03 (void);
// 0x00000743 System.Void UnityEngine.EventSystems.PhysicsRaycaster/RaycastHitComparer::.ctor()
extern void RaycastHitComparer__ctor_mAB0536EE515BF2BD1B29BE3B39E8BA9E9CFE97C3 (void);
// 0x00000744 System.Void UnityEngine.EventSystems.PhysicsRaycaster/RaycastHitComparer::.cctor()
extern void RaycastHitComparer__cctor_m772D29066D594105261C78CDDB5724BE28A773FA (void);
// 0x00000745 UnityEngine.GameObject UnityEngine.EventSystems.RaycastResult::get_gameObject()
extern void RaycastResult_get_gameObject_m77014B442B9E2D10F2CC3AEEDC07AA95CDE1E2F1 (void);
// 0x00000746 System.Void UnityEngine.EventSystems.RaycastResult::set_gameObject(UnityEngine.GameObject)
extern void RaycastResult_set_gameObject_mCFEB66C0E3F01AC5E55040FE8BEB16E40427BD9E (void);
// 0x00000747 System.Boolean UnityEngine.EventSystems.RaycastResult::get_isValid()
extern void RaycastResult_get_isValid_m69957B97C041A9E3FAF4ECA82BB8099C9FA171CE (void);
// 0x00000748 System.Void UnityEngine.EventSystems.RaycastResult::Clear()
extern void RaycastResult_Clear_m0E9DA70AC69CF143CEA8428AFC5BA552F99643AE (void);
// 0x00000749 System.String UnityEngine.EventSystems.RaycastResult::ToString()
extern void RaycastResult_ToString_m0267000494B09783ABD507B9329ADB01FBBC5428 (void);
// 0x0000074A System.Void UnityEngine.EventSystems.UIBehaviour::Awake()
extern void UIBehaviour_Awake_mDF9D1A4867C8E730C59A7CAE97709CA9B8F3A0F2 (void);
// 0x0000074B System.Void UnityEngine.EventSystems.UIBehaviour::OnEnable()
extern void UIBehaviour_OnEnable_m8989ABF5C038905A68E5536BED2E6FFAF8767FFC (void);
// 0x0000074C System.Void UnityEngine.EventSystems.UIBehaviour::Start()
extern void UIBehaviour_Start_mB12643ED6D859CD3682B4BF5B9CA7F72E8A72B45 (void);
// 0x0000074D System.Void UnityEngine.EventSystems.UIBehaviour::OnDisable()
extern void UIBehaviour_OnDisable_m18D5A0B93F65FB50F4D6CE8197EC07F3452C5DDE (void);
// 0x0000074E System.Void UnityEngine.EventSystems.UIBehaviour::OnDestroy()
extern void UIBehaviour_OnDestroy_mF225CF9163823F19BE5E2B2735D35898A20D608B (void);
// 0x0000074F System.Boolean UnityEngine.EventSystems.UIBehaviour::IsActive()
extern void UIBehaviour_IsActive_m9E79A0650C81204AF9A861BBBA8685D9563AE9C4 (void);
// 0x00000750 System.Void UnityEngine.EventSystems.UIBehaviour::OnRectTransformDimensionsChange()
extern void UIBehaviour_OnRectTransformDimensionsChange_m86A6D20E0EBF41CDB89DD1E87F23624263B68159 (void);
// 0x00000751 System.Void UnityEngine.EventSystems.UIBehaviour::OnBeforeTransformParentChanged()
extern void UIBehaviour_OnBeforeTransformParentChanged_m980EF41E33A7541BD6C65AEC305B25A19C9CA30F (void);
// 0x00000752 System.Void UnityEngine.EventSystems.UIBehaviour::OnTransformParentChanged()
extern void UIBehaviour_OnTransformParentChanged_mAD56D3C6049A1746F00DC2643D1666F7DE921384 (void);
// 0x00000753 System.Void UnityEngine.EventSystems.UIBehaviour::OnDidApplyAnimationProperties()
extern void UIBehaviour_OnDidApplyAnimationProperties_mE011A7C92134E28AE2AF3A0EBFB2E4AB88ABE748 (void);
// 0x00000754 System.Void UnityEngine.EventSystems.UIBehaviour::OnCanvasGroupChanged()
extern void UIBehaviour_OnCanvasGroupChanged_m592FA8BF5238E712E73E2D99258EE0DB6D88D84B (void);
// 0x00000755 System.Void UnityEngine.EventSystems.UIBehaviour::OnCanvasHierarchyChanged()
extern void UIBehaviour_OnCanvasHierarchyChanged_mCAC018CB33FA00E857288B64E3722226638A1229 (void);
// 0x00000756 System.Boolean UnityEngine.EventSystems.UIBehaviour::IsDestroyed()
extern void UIBehaviour_IsDestroyed_m2E9FFA28686D1C82697FB467002541CC58A06BCA (void);
// 0x00000757 System.Void UnityEngine.EventSystems.UIBehaviour::.ctor()
extern void UIBehaviour__ctor_m24C66A65DDD996E779871C6655CF11B871F11337 (void);
// 0x00000758 System.Int32 UnityEditor.Rendering.BuiltIn.ShaderGraph.MaterialAccess::ReadMaterialRawRenderQueue(UnityEngine.Material)
extern void MaterialAccess_ReadMaterialRawRenderQueue_m6B9E0FEB4CBD15C741BE81BEEA4E9B17C1091416 (void);
// 0x00000759 System.Int32 UnityEditor.Rendering.Universal.MaterialAccess::ReadMaterialRawRenderQueue(UnityEngine.Material)
extern void MaterialAccess_ReadMaterialRawRenderQueue_m093C11796E1489030FD35E9EAE4005F397BFE6B2 (void);
static Il2CppMethodPointer s_methodPointers[1881] = 
{
	AnimationTriggers_get_normalTrigger_mDB8A7C5C4B69515C514BB138724E25F16FCED43F,
	AnimationTriggers_set_normalTrigger_m43C30CD216A826221653CF8648B1C1823EBBA8E6,
	AnimationTriggers_get_highlightedTrigger_m492093112EC52907A3B5ED518BAD366B0052EDCA,
	AnimationTriggers_set_highlightedTrigger_mCAD700865DD27254AFCA56FE85E2457ECF4CE6B7,
	AnimationTriggers_get_pressedTrigger_mFB9A652E90CCCB38FCF47EE464D20FACE41399B9,
	AnimationTriggers_set_pressedTrigger_m1AEC4AC3C6CF43AE7EFE2B8E9A7561A5C2F7A5A0,
	AnimationTriggers_get_selectedTrigger_m631840BD0D4ED252C62E11405B29826F9BC419E8,
	AnimationTriggers_set_selectedTrigger_m3AC876A19515E1901E0986781756F339A13E45A9,
	AnimationTriggers_get_disabledTrigger_mC91BD8165E64C82F9DCB7E0549ACB2D0537CE376,
	AnimationTriggers_set_disabledTrigger_m20289A9FDAF524362F32320D57EF4E5A323299C1,
	AnimationTriggers__ctor_mDF3C8571BACB06DACEE75D9E5899B53C1D429A02,
	Button__ctor_m0A1FC265F589989085C1909BC8D93E33A698D8E5,
	Button_get_onClick_m701712A7F7F000CC80D517C4510697E15722C35C,
	Button_set_onClick_m4CD77BD99635400BA18692D591BEA79A7ECC66C3,
	Button_Press_mEF76F32CD5C01C1D8B00B80BDFC0C6CEEEF2C993,
	Button_OnPointerClick_mB76B80D7374811C7BBE11DA188E2656904AE5422,
	Button_OnSubmit_m700E3D529DEE2FB6214BD698C61A3C7CDA08F0A8,
	Button_OnFinishSubmit_m72771C6FF84DA31AE09E936D2D7FB6771FE5A7D9,
	ButtonClickedEvent__ctor_m2B38CD66BDA4E63A19DB233BFA32C828A3D5290D,
	U3COnFinishSubmitU3Ed__9__ctor_m52988E24A7D4CE00B0F8A0F60A6EC20166027553,
	U3COnFinishSubmitU3Ed__9_System_IDisposable_Dispose_m15AFD67ECC7FD7739798F4F063F3978AA19D41EA,
	U3COnFinishSubmitU3Ed__9_MoveNext_m1D344B644399C92B28851F8630337135752BDE2A,
	U3COnFinishSubmitU3Ed__9_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m82819377766A051FA756675E7EDB47088418FD96,
	U3COnFinishSubmitU3Ed__9_System_Collections_IEnumerator_Reset_m3C1D75C11B17DE106053B97EC52822B74591061F,
	U3COnFinishSubmitU3Ed__9_System_Collections_IEnumerator_get_Current_m26114B1DB5CA45B24C00C1B5596D29F76A4AED57,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	CanvasUpdateRegistry__ctor_m2265E2D6AE72DCF25E4A8E52A03A390012CDB01C,
	CanvasUpdateRegistry_get_instance_m57BA2006B09FA35EA4CE228078E7EAF0E01509DE,
	CanvasUpdateRegistry_ObjectValidForUpdate_mFF8ACAA818FA7F73C5A6447C8E1E61631690660A,
	CanvasUpdateRegistry_CleanInvalidItems_mFDBE5D212F6B9649B6EB619AA8860DB72F3AA80E,
	CanvasUpdateRegistry_PerformUpdate_mA5CAEDD4452E5C8B58B688C08BC491AC2DAFD51A,
	CanvasUpdateRegistry_ParentCount_mA10504532DE021BBA642052EDB70F46BAD4A55D2,
	CanvasUpdateRegistry_SortLayoutList_m28074D05490A0F8B9D4E5699BEB357F92212141F,
	CanvasUpdateRegistry_RegisterCanvasElementForLayoutRebuild_mB9571A1C6F0E32E1A0B07C46A1E68366E2A598AB,
	CanvasUpdateRegistry_TryRegisterCanvasElementForLayoutRebuild_mCF214BCE7C81643D9684D93C2CC40FEC599E72EB,
	CanvasUpdateRegistry_InternalRegisterCanvasElementForLayoutRebuild_m609303A2651E3AC6B866A9ACDEAE0773F4CCAAC0,
	CanvasUpdateRegistry_RegisterCanvasElementForGraphicRebuild_mEBBD04C3B001E80801966E3347E70A35FCEBE8B1,
	CanvasUpdateRegistry_TryRegisterCanvasElementForGraphicRebuild_mFA63F8841FECC69E9EC84B9F4D7EAF4B0EBFE375,
	CanvasUpdateRegistry_InternalRegisterCanvasElementForGraphicRebuild_m6CA79E8E3D6217779BF91B50C8D4C9FCF7492B60,
	CanvasUpdateRegistry_UnRegisterCanvasElementForRebuild_m61F9979AB8AFBA924430757FE09967D7A335D916,
	CanvasUpdateRegistry_DisableCanvasElementForRebuild_mC1A68AC220C3755789E3CB51E8DBAC81CC61D62F,
	CanvasUpdateRegistry_InternalUnRegisterCanvasElementForLayoutRebuild_m2DA109CB4DE672A779EB3531D2E727D683E3A00A,
	CanvasUpdateRegistry_InternalUnRegisterCanvasElementForGraphicRebuild_m2A2FAEE11B508953630961D186E379ED890DA589,
	CanvasUpdateRegistry_InternalDisableCanvasElementForLayoutRebuild_m64780D6E94F424BEF771EC84E3F2A8D328B9CB6C,
	CanvasUpdateRegistry_InternalDisableCanvasElementForGraphicRebuild_m6AC0A40EDD8462EEA49F355BFA793AD565DB5D57,
	CanvasUpdateRegistry_IsRebuildingLayout_m3C037968252136E38CF1AF8716DC671CE13917EA,
	CanvasUpdateRegistry_IsRebuildingGraphics_m424672693DCCC18C324436EDD483753B8137A482,
	CanvasUpdateRegistry__cctor_m19922681B4E153B487D8E81BE3A583CACBF32858,
	ColorBlock_get_normalColor_m08A07A74ED743B4B0C1B5A5C35774F2D78F1F20E,
	ColorBlock_set_normalColor_m3EBF594F6FA2C6494ACA9FCB9B458807D85B96F8,
	ColorBlock_get_highlightedColor_m4D1A3D268CB00B351F56934F7F244DBC68855301,
	ColorBlock_set_highlightedColor_m04E97DF2CCE7CAC47120D8F486E18BF62F16FF86,
	ColorBlock_get_pressedColor_m5EDADBA10824D08BFB67D02099A9FC6A4235AC62,
	ColorBlock_set_pressedColor_m644C938090857AB07C57B25FE53F6DC2BB0DD5A8,
	ColorBlock_get_selectedColor_m41CD59090E997A5982EE5AB9D23811FEB35C82CF,
	ColorBlock_set_selectedColor_m76FEFB1148798B7A356C974CDEA3BA2E2E3C1D21,
	ColorBlock_get_disabledColor_m2E20FC772B592ADD71CE1336D29B3C3C1523669E,
	ColorBlock_set_disabledColor_m4D10D1F8525CCC7E8E200E3994AFB28ADABB1D8E,
	ColorBlock_get_colorMultiplier_m54C8F6B7E5ACF45D70F9EAAED78AB4606999C187,
	ColorBlock_set_colorMultiplier_m920A048B95541DB0E92AF4AF3894BE7CD2D37102,
	ColorBlock_get_fadeDuration_m506A0FCC2819DA313BE033640C8FEDC5331D1C39,
	ColorBlock_set_fadeDuration_m8519A304808384CE873377EC104969A6B9FBB6C5,
	ColorBlock__cctor_mE6D6008EFBF7B20ECDFC69AD0FBAAF745BBFEB7A,
	ColorBlock_Equals_m20D958BB28F6FDC12D612279AF6B50679C0C1E67,
	ColorBlock_Equals_m52DCE246EA23904A3EF0FCD3ADAB81BC20DC1BE5,
	ColorBlock_op_Equality_m5925207B6FDD0CE013BEB0269B4407B9C3A54276,
	ColorBlock_op_Inequality_m73B2B54AA18CB45290F99B1A870BC43E08209AC7,
	ColorBlock_GetHashCode_m3CCB4E1E5EE93B905650E24BD4753096082270D7,
	ClipperRegistry__ctor_m664370B6F6A28646681B08A723C4EEE7737599A4,
	ClipperRegistry_get_instance_m709E4407231F3C616FCE693389AE2BC0121FCE40,
	ClipperRegistry_Cull_mE2BBF0B75900B6780EDE22699476542FC5B62730,
	ClipperRegistry_Register_m4C47388806CA8A75538144365809137FB61C965B,
	ClipperRegistry_Unregister_mEEF92721B30BDF97F454512C32D1DF8E24834F42,
	ClipperRegistry_Disable_m4541BB1A762E730709A65D7CDA917CF0D56CA687,
	Clipping_FindCullAndClipWorldRect_mE367B99A2BEBA67F6B394B7E95346C9F6416C4B5,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	RectangularVertexClipper_GetCanvasRect_m9C9A5CAF396D20925E1394FA188E71D3B825B383,
	RectangularVertexClipper__ctor_m159190C771C2A7F406769365B902A228DE585C7A,
	DefaultControls_get_factory_m5E94C746BC7C05A928A9886519FC4FB32C2EB57D,
	DefaultControls_CreateUIElementRoot_m29E6F31D5BEA9AA602BFDFA423DB403DFE429683,
	DefaultControls_CreateUIObject_mBBA2C8A5C8BB80104251200395B2947A5CB45071,
	DefaultControls_SetDefaultTextValues_mE667D7E0A8BB03B6EBA7E3A5917A5F0B5DF1D0BB,
	DefaultControls_SetDefaultColorTransitionValues_mA11DBF31257A877F2C3CFE2FC555F77DE4AB27B5,
	DefaultControls_SetParentAndAlign_mA6632B61C5C5C33B4901129DC16919E8C5158952,
	DefaultControls_SetLayerRecursively_mE0BFC051766E26BC0118555582A6579179281CBA,
	DefaultControls_CreatePanel_m69F2B388CE41646797A582D4AF52CC91B45BB7C0,
	DefaultControls_CreateButton_m3551B134B8B79ADCE1DB85D5A77B4C9F32E43619,
	DefaultControls_CreateText_mA23D7B0D56561FA174752601AEFFEB04F26E7C3E,
	DefaultControls_CreateImage_m0D5C35201D8D12B1A42685CE23772F5C39864331,
	DefaultControls_CreateRawImage_m1CF70C988DE4276C35037BB56479E805EAAB567F,
	DefaultControls_CreateSlider_m46C7D78861271433489674E7B9A09D018E33911C,
	DefaultControls_CreateScrollbar_m78FC29513D3DAF700CB9205882F58F59B3F5620E,
	DefaultControls_CreateToggle_mE5D3F00385DD0F468F8218D520C0C0D300BE58F4,
	DefaultControls_CreateInputField_m0381BFDF0D84EC0A896C639EAB732F39A36B8ED2,
	DefaultControls_CreateDropdown_m94CE7639D609D6341FBCF0D49D6494A5901FFDBD,
	DefaultControls_CreateScrollView_m091D81394C468627D85DDAB8236665E837C89AA7,
	DefaultControls__cctor_m712ED7CCB7CEEE815F424F553E03BC3BA4F6E80B,
	NULL,
	DefaultRuntimeFactory_CreateGameObject_m0D5F91ACE140C39C3139BAF1437792D42CC0C389,
	DefaultRuntimeFactory__ctor_m5467830A8AA017398C392E147A4582857EFD0710,
	DefaultRuntimeFactory__cctor_m09225594AC1F1C4EE5EBF6E5FBC7C8760C34AF2D,
	Dropdown_get_template_m6714116D7DA3F457F184B004785B4F017D50987A,
	Dropdown_set_template_m13FE93E0ED2414A5D8D4595D3123DDFD726DB619,
	Dropdown_get_captionText_m0A8DEACA15F0DDFEE339462E03DF511B87389EF4,
	Dropdown_set_captionText_mD314CF798D1B85726553E124496A7EE226BB1830,
	Dropdown_get_captionImage_mA4C6EF8312F06B6190FC4E78583975145274168B,
	Dropdown_set_captionImage_mF6B9BCAF2C8C0018E2F94600F9C8DE2412F5F184,
	Dropdown_get_itemText_m8E98EB1B2B2F8D5C14F0D4A02E620E9240966681,
	Dropdown_set_itemText_m901981335866C0A856E31D7D1C87C7D8E76FBFAA,
	Dropdown_get_itemImage_mA30A3B51B8C9B6E364B57A3FB277B364B6E0EF1B,
	Dropdown_set_itemImage_m6F4BBC06449E2EAF073D495871BB29F4B35BD7FE,
	Dropdown_get_options_m30F757DBA22980CB77DADB8315207D5B87307816,
	Dropdown_set_options_mEC30A0E3E0819485B1EACF8624D0C1974857D368,
	Dropdown_get_onValueChanged_mAC49CE9A83E258FEC024662127057567275CAC12,
	Dropdown_set_onValueChanged_m59337E2E2975F5F4338C5B03C50347A23343C0E0,
	Dropdown_get_alphaFadeSpeed_m17C37664CEDBA2950ACDA7FCB1DFCBAD1A9C82E9,
	Dropdown_set_alphaFadeSpeed_m67E1A7B551D3592380C6EA34355B94C461790984,
	Dropdown_get_value_m386913162D5E273B762657FE5156DC567602BC3C,
	Dropdown_set_value_m0764A5E2023E34705ADD422689BF6C0074449FEE,
	Dropdown_SetValueWithoutNotify_m3D2B40BC16D305309D68D9FF093BF25FF66E4ABA,
	Dropdown_Set_m2F7DFBF09261A4C4CB1AFCF939907716191D8F07,
	Dropdown__ctor_m1AF791E4615DB8F00045A3713730CD45E66A7CD4,
	Dropdown_Awake_m1A9102FB62C5393F695E5A0FB44A0CFEC5B947FF,
	Dropdown_Start_m93BFFE8C88FF09265315FE8B145FE165467CBB35,
	Dropdown_OnDisable_mB9CBBE366F5F5EDA29C064DB5D7A6EA7C711C70E,
	Dropdown_RefreshShownValue_mA112A95E8653859FC2B6C2D0CC89660D36E8970E,
	Dropdown_AddOptions_mE535B30A30D77024D10AB2AB71CE3FD280CD0327,
	Dropdown_AddOptions_mCFB763400FA1BCA695C168E7FBCDE20C9B8E7839,
	Dropdown_AddOptions_mD4460EE082AB7BE36CB54DBB67BFEB4BC172707E,
	Dropdown_ClearOptions_m3EE71BFE47AB96BC7F731C4EE6BC728ED0E6EE56,
	Dropdown_SetupTemplate_m6F68B1CAC7C39B2C3415B46FD2CF8F91DCF48901,
	NULL,
	Dropdown_OnPointerClick_m3AE64082F83B272B4880935125784442E107939C,
	Dropdown_OnSubmit_m3535A89BE2130B54653DB2A6BA850F2055DA7F6D,
	Dropdown_OnCancel_m50A25AA76B6A92E72820E97C4C9DF2295B45FC2A,
	Dropdown_Show_m103EDF14CFC2B5284C92037B097F015DAB1340DC,
	Dropdown_CreateBlocker_mA27CE256509155DAC14FBB8549074ACFF5976DDB,
	Dropdown_DestroyBlocker_mE0B298F69E3343D0551E7B42B28312EEE28C553B,
	Dropdown_CreateDropdownList_mD6A55CE0786F7A418C6FC001798F660D1D2CFF95,
	Dropdown_DestroyDropdownList_mB8F81B723F9C08AF3D303D8CDB395B4474B1846C,
	Dropdown_CreateItem_m2E8E7B65A324DF3CB783D219F7ADA70E28CD8FAA,
	Dropdown_DestroyItem_mD48C6E656F3CE04FE1C26E1F92F599B1F0EAD778,
	Dropdown_AddItem_m16017A91D142FECFE69FB38FAA311636348B499C,
	Dropdown_AlphaFadeList_mF73F53EB84546666A4DB382173BEFEA23DFD9D64,
	Dropdown_AlphaFadeList_m5727C00B9A1FF385C5A4B65799E1CFAE49F29F86,
	Dropdown_SetAlpha_mE367D2B2798F4F7FC0281D772AB4DC7417A2077C,
	Dropdown_Hide_m49F29E7BC614DB6E04512F762399A9AACCDAFCB7,
	Dropdown_DelayedDestroyDropdownList_m5840A3EACBCDA1F7EB89E36A44EA502243E87F8F,
	Dropdown_ImmediateDestroyDropdownList_mAC289C54114CD256FE7F34B8D62EFDA947C00272,
	Dropdown_OnSelectItem_m17D380C68C04FE4125D32EA8494D8F98442150F9,
	Dropdown__cctor_m4A014C9379610C7598BED3E900FD22040E2F9C2C,
	DropdownItem_get_text_m29C926466BC0BE39A7EA282A627E1F8459C53E0D,
	DropdownItem_set_text_mE5F27F83326429B6056B686682BBC9911546DAA0,
	DropdownItem_get_image_m415346A4FB0E83932E4043D41B0AE837F2C3EE75,
	DropdownItem_set_image_mED01F92D19AA3B5C0CACBCE2D1C9A70AFC7049EA,
	DropdownItem_get_rectTransform_mAFF594D5FE8280F8E4CF8D246654C1EC04C892EB,
	DropdownItem_set_rectTransform_m62744FF037D3E7044EDA139CA6BB6FBB11E1061E,
	DropdownItem_get_toggle_m9E93C07903AF29C0D66C48B217575A65CD4CB471,
	DropdownItem_set_toggle_mD58F68764A433037C8F42483BE4F95973EBA3535,
	DropdownItem_OnPointerEnter_mB9464C1CE0EBF0A4F3A7979B37AEF2283E738A34,
	DropdownItem_OnCancel_mFEA3928E939D387662E21AD7496DD64FF40B9FC7,
	DropdownItem__ctor_mB55660FE9B66C2A5E7E8587450729BB691EDAC03,
	OptionData_get_text_m147C3EFE4B7D157914D2C6CF653B32CE2D987AF1,
	OptionData_set_text_mA6022A455FC38025B0CA97B4E3629DA10FDE259E,
	OptionData_get_image_m4E10E9C1338C69EF43C240AB6866AD99CA63451F,
	OptionData_set_image_mE503B098325797C5AA91F3BD71A182CAFF878C9D,
	OptionData__ctor_m6321993E5D83F3A7E52ADC14C9276508D1129166,
	OptionData__ctor_m0BB22D3B9A2443D8D51CE88AD6B4DAEAF11B59E6,
	OptionData__ctor_m59495D34418035A84F4985F134B7557294689252,
	OptionData__ctor_mFF7263F2503D3F2D1E395450A62CAAB48CA9AFDE,
	OptionDataList_get_options_m0400B4F545E0EF3D00D50B701720B5D2F732A00E,
	OptionDataList_set_options_mE730DD2A6EB4DEE150450E52C0C2869CE4573E1C,
	OptionDataList__ctor_mEDE3FBBEC8C69BAB71DC8A4EEBA4DD92A19D2E6E,
	DropdownEvent__ctor_m40067CAE88519F3B3B9991621A3EA5DC89682145,
	U3CU3Ec__DisplayClass63_0__ctor_mA6669AA99E56F2DEE6C1E1ECB173C7BE4DE1CD64,
	U3CU3Ec__DisplayClass63_0_U3CShowU3Eb__0_m2D40C4419DA54F2340E2A0BE7E7E6BD57113B71C,
	U3CDelayedDestroyDropdownListU3Ed__75__ctor_m80FA88C604962EB1BCF0453E39809E4AD856564F,
	U3CDelayedDestroyDropdownListU3Ed__75_System_IDisposable_Dispose_m86610E303C691865AD8CA51A944E0DD22CD76646,
	U3CDelayedDestroyDropdownListU3Ed__75_MoveNext_m4635FEBE76913C9F4A0D60DF2DEFBABE071481D4,
	U3CDelayedDestroyDropdownListU3Ed__75_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mD7843A1E586805C8BA4165718774F1579F775077,
	U3CDelayedDestroyDropdownListU3Ed__75_System_Collections_IEnumerator_Reset_mD5684D5117ECD0043294091F4CBB9EEC17957CC2,
	U3CDelayedDestroyDropdownListU3Ed__75_System_Collections_IEnumerator_get_Current_m746DC8D79704E5D1B78C1DC62CDECC7274409D13,
	FontData_get_defaultFontData_mE91EA0AE923A4988ECEF06F608BA8DE764541B6F,
	FontData_get_font_m449DE7A18F42B85D427608E88BC17B528D974D93,
	FontData_set_font_mDF16F5058F749DA9A80B7203BE1E007A21258089,
	FontData_get_fontSize_m6695DDD7FECD4BAC1147A15D26B7F16B78E2B2D3,
	FontData_set_fontSize_m00594E7340206777E0CF1F038943724B8DA9FD53,
	FontData_get_fontStyle_m7671598F11D5C2AE55AA46D28794C78D0D690EC3,
	FontData_set_fontStyle_m90E8DF52C663489F43FB185780D38A3E99A30C29,
	FontData_get_bestFit_m230FD8F27172E1A020BFDDC2D89932DFD01788FC,
	FontData_set_bestFit_m15B4E1EC2E3AA912718466F0C098BF0C22E7B46B,
	FontData_get_minSize_mD8AD04F4CF85C79BEA14710F3AD85228E3DC2D97,
	FontData_set_minSize_mAAC06D3C29D5210054B3DC3FDE58358648460F91,
	FontData_get_maxSize_mA8FDA877D8D459C0C97F1AE7FD8D5F7C27391872,
	FontData_set_maxSize_m3EC43E7AB5A4C022DE729371D8AACFC7D702B527,
	FontData_get_alignment_mC3C237BFE74D104BE4502D0D6BEF6D400AC509F4,
	FontData_set_alignment_m25795B35CBF298D966B5C9A73A4A58F075C17563,
	FontData_get_alignByGeometry_m193ADE84986D74A91F46B31C1F961BC9D688CDFF,
	FontData_set_alignByGeometry_m580D8D1B9D4396C648C9180BB891DAF561E37A2F,
	FontData_get_richText_m76956F1C2063841C77172F1CB404F3C6C81052A1,
	FontData_set_richText_mB37DCE83CBD25C93A3AA4AA9C0C3A7AE332753DC,
	FontData_get_horizontalOverflow_mEF56759973C6722FDE71032861BC0713628E5EA8,
	FontData_set_horizontalOverflow_m8B75EB2EB0241423F50E31C023729BDBAAA019E1,
	FontData_get_verticalOverflow_m306AE42FED4B302C133CC899B55D92FB86C1ED8F,
	FontData_set_verticalOverflow_m857D9882EC486696EE3898EB5BFFFE04053C9D17,
	FontData_get_lineSpacing_mE9627A4D01D54115F8AE42EC1F12CFBB86FAC5E0,
	FontData_set_lineSpacing_m034F2A307093DCAACE71D610550C3306C1389FB5,
	FontData_UnityEngine_ISerializationCallbackReceiver_OnBeforeSerialize_mCA5C2ADF6B05942D58C400752E8D175DAC008399,
	FontData_UnityEngine_ISerializationCallbackReceiver_OnAfterDeserialize_mAB5158604FD53556402CD7297F9797747088EC6F,
	FontData__ctor_m90225BC9FF97C82F911B775CD3EB54B0C95839C8,
	FontUpdateTracker_TrackText_mE52366E2C5DF0BA4E24F35D7DA246FBF32332007,
	FontUpdateTracker_RebuildForFont_mC9A828F534DBBCE1E70BFF4A5034C7B37F7D65EE,
	FontUpdateTracker_UntrackText_m813D712F66E05727FE0CEFAB4438EE7DF5483738,
	FontUpdateTracker__cctor_m82550106869CBCE1C5D8D7AC9F211AD71DBEE5C7,
	Graphic_get_defaultGraphicMaterial_mC3D98DC8F6E8826633B17BB4AC6E38DF20A74E78,
	Graphic_get_color_mA6639AC2B77A8F1B7F27656B69320E7A0FD4F315,
	Graphic_set_color_mC9B90A387A37946AF295D7BCDA1FBC1DBD2D4865,
	Graphic_get_raycastTarget_mA3E3A3A0C7A12EB550D0BCD5DC68F5A40C6D7844,
	Graphic_set_raycastTarget_mE3D3CBB94E605C13362A592F17420AEAAC771448,
	Graphic_get_raycastPadding_m44CC4DC7030C46D15519AAFA7523E9AD4DC462B7,
	Graphic_set_raycastPadding_m5EBFEDD522BD4E1EC0202FEA1D7A0273E25FD5E5,
	Graphic_get_useLegacyMeshGeneration_m2057231F53432FC95BA40EA485E85F5DAF21F423,
	Graphic_set_useLegacyMeshGeneration_m8069890AE2F389C73D944941BB8462C44EB32EC9,
	Graphic__ctor_m61FAEBEC21F22FE00B8CF39A8498AD31F62C0D6D,
	Graphic_SetAllDirty_mE93D6326AF09CED62858980A38F571F01A567E17,
	Graphic_SetLayoutDirty_m707188E6F05B8977FBA14C6269420EAE045A728B,
	Graphic_SetVerticesDirty_m8DBAF14DE97CB50DC54E768A2C120F8F4B3C647E,
	Graphic_SetMaterialDirty_m19E23BAD2FAF23CEF776F467AA8A453C3320473E,
	Graphic_SetRaycastDirty_m07F00097DD9C6278923A1CC204770A4141F4B400,
	Graphic_OnRectTransformDimensionsChange_m2A42F124936B2F377BE4A07BC9586C38CF15EB74,
	Graphic_OnBeforeTransformParentChanged_mFEE7DB7653CD70C7279F397DFF1A5C9B702B36BE,
	Graphic_OnTransformParentChanged_m5FAC5BEDE05D6969B7F7AD15C0A8C5715129EED7,
	Graphic_get_depth_m16A82C751AE0497941048A3715D48A1066939460,
	Graphic_get_rectTransform_mF4752E8934267D630810E84CE02CDFB81EB1FD6D,
	Graphic_get_canvas_mEA2161DF3BD736541DE41F9B814C4860FEB76419,
	Graphic_CacheCanvas_m3F8A1EE9BE3F17297B5E5B9EA02CCA8AF53E34DD,
	Graphic_get_canvasRenderer_m62AB727277A28728264860232642DA6EC20DEAB1,
	Graphic_get_defaultMaterial_m1F258214F9C1F431922BAA0028374FF6F3F81661,
	Graphic_get_material_m7E92B4A77B5454BCC2507952561F12EA88AB9240,
	Graphic_set_material_m49252B02E3CB2C0A17C1A74783F615E50C8801B5,
	Graphic_get_materialForRendering_m4B0017B2B59D2EF578D32ABFCF84A97A835B6B22,
	Graphic_get_mainTexture_mC38AAAD7BB2E9ED5CD1606FB0BB076CCB5F4B70D,
	Graphic_OnEnable_mD7544FBC0068D0C74181E6E66C7EC167B7C6309E,
	Graphic_OnDisable_m2DF81EFCEA05C2E6605C027DA3ABD79945C94F16,
	Graphic_OnDestroy_mDA1CEBC665EEC946C60519596C396477F2E348D9,
	Graphic_OnCanvasHierarchyChanged_m7062158DC1477AF8A5BC2B07755314ED7A184C5C,
	Graphic_OnCullingChanged_m50D153DBBF9C9F17AE177E6ED6D157D847120621,
	Graphic_Rebuild_mEA8B7052D925874A5C8A3F3733F5027CA946EFAD,
	Graphic_LayoutComplete_m42E63C813BCE631365012B856473439ABD49A726,
	Graphic_GraphicUpdateComplete_m02387ED9D65BF3C90D58BD5D2A9614736ABD7D5F,
	Graphic_UpdateMaterial_m0FE63FE57725F78FA05D9C85F8457B6CA06EF665,
	Graphic_UpdateGeometry_m29DD64EA8C3600E9B5A50DAAA8A79D63B9FC1BE5,
	Graphic_DoMeshGeneration_m9A226AB1660C68B8C2ED56845686600741CF7BB9,
	Graphic_DoLegacyMeshGeneration_m6B3FFD836E8904FE9ED48633DED556CB8CEC0156,
	Graphic_get_workerMesh_m31789D0370C0CCCFC9A160714835CAD44CEEB877,
	Graphic_OnFillVBO_m327876DCE662B10A36B5DD71A891F75599186FE4,
	Graphic_OnPopulateMesh_mA35BBAE4555A20A302AABD4EF1AB4F4C9D565160,
	Graphic_OnPopulateMesh_mDD8F1B97C1AB94FB2C61D82080DE06DBAE2C0EEF,
	Graphic_OnDidApplyAnimationProperties_m75AB831FC70C61BF140CFA69D337C48E8762B1CF,
	Graphic_SetNativeSize_m9D5D0610B602745DA5BED808B20A07214CC18991,
	Graphic_Raycast_mEEE1690786A5894545C42BF6143936237BFE61A0,
	Graphic_PixelAdjustPoint_mBC4AFC26628D498B9872314726561D72F6DD2F28,
	Graphic_GetPixelAdjustedRect_m70D7B527D04C0B88C23E7C6661A8FF1ECC4B4BA1,
	Graphic_CrossFadeColor_m6BF11EA2B9F62DF8D9421292EF974D7D548829C5,
	Graphic_CrossFadeColor_m0D1181CC2BF5CE521C14C85BE9CEB22EC0129D43,
	Graphic_CreateColorFromAlpha_mFFAB1C85CFC981F357FCBFE84DDCFC623E2C804A,
	Graphic_CrossFadeAlpha_mB3D045B48E9DDE6CE23F4368B875F1307765B192,
	Graphic_RegisterDirtyLayoutCallback_m870D9C225888AF117EAB7DCFBC5E629797D22B7E,
	Graphic_UnregisterDirtyLayoutCallback_m2284BC352FE69018BB15978CB3218C673F29AD9B,
	Graphic_RegisterDirtyVerticesCallback_m46034B2100B5D28BDBCCB34C1283B1B9B2DB9A9E,
	Graphic_UnregisterDirtyVerticesCallback_mA36A388BF7DDB2D71596D6F13CEFCA79B4199B5C,
	Graphic_RegisterDirtyMaterialCallback_m5EDBA1E08656A49997538A1C7DE29201FDE0A013,
	Graphic_UnregisterDirtyMaterialCallback_m62B9DB9B9021EC647E1B3D5122FE3693F8FC9BD2,
	Graphic__cctor_mF2A854B88E328E94B0091B2E9ACC67559BFD3514,
	Graphic_UnityEngine_UI_ICanvasElement_get_transform_m171A3F16EAE82D42EF768C3B091DC87174D5E768,
	GraphicRaycaster_get_sortOrderPriority_m0F064AFD3551ABC89DE649D406B032AFA6E3D83F,
	GraphicRaycaster_get_renderOrderPriority_m1E6278AF3B98742F9F5A293DAF89F75B06E7441D,
	GraphicRaycaster_get_ignoreReversedGraphics_mC501DBD2D4BD9594F4A5591AFD76AE307EA6BACE,
	GraphicRaycaster_set_ignoreReversedGraphics_m5CFA68408D296EDCC9230AF7CFB53589BE9F1CCB,
	GraphicRaycaster_get_blockingObjects_m54343002F72E2C27919DDF5F4088934891AC13FF,
	GraphicRaycaster_set_blockingObjects_m0CB3F62ABC27BDB348B09B6CF0E6AB4D42A6FBC7,
	GraphicRaycaster_get_blockingMask_mDD3BC80288E6B12D2480B40788BA3B69D6F863C5,
	GraphicRaycaster_set_blockingMask_mCE08DF88D4D4BFD17358C75DE9F0A8F68DB3BB00,
	GraphicRaycaster__ctor_m863917ADCD9732623EBDF53A0CEDDEEB6EA4C42A,
	GraphicRaycaster_get_canvas_mD4D82F397DA3E82EBA7052E93A20562C2263339F,
	GraphicRaycaster_Raycast_mCBF5513CAA3AB70569DA3BE50DCF8980819A6D7F,
	GraphicRaycaster_get_eventCamera_m2EF53324CF216839FA622884418FA77EFB9B3879,
	GraphicRaycaster_Raycast_m06B8EF9AC17F7B4FBDB687E3A2C748EF575CCFCC,
	GraphicRaycaster__cctor_mCE7CB78EE668443FB78303E46D3D62EE92814FBD,
	U3CU3Ec__cctor_m6A476FFBD4558E7BA60882D6696252685DD826F5,
	U3CU3Ec__ctor_mA1FCF997C2A1BC3278AFD9072B0CA4C4273F8F39,
	U3CU3Ec_U3CRaycastU3Eb__27_0_m81E2CE6D45AE93300AF014EA75EF4A4B2E4C059A,
	GraphicRegistry__ctor_m26893FC7AC6ED439CDD999168C66667E27C0B48F,
	GraphicRegistry_get_instance_mB6879C75347DA916BAECEF49280C8A32375BAC60,
	GraphicRegistry_RegisterGraphicForCanvas_m0C0DEF1D00EE4D074927B2592AA0E39EBBC5C935,
	GraphicRegistry_RegisterRaycastGraphicForCanvas_m10218EBBB9EBD098CB0E4954902E94C1862222A9,
	GraphicRegistry_UnregisterGraphicForCanvas_m31671D141DBAF5B11D8F005E90D6E826362FDC3B,
	GraphicRegistry_UnregisterRaycastGraphicForCanvas_mAB5A50A86219AE4AE5DD135C93AADC22989B5CD4,
	GraphicRegistry_DisableGraphicForCanvas_m9AFAD2245A25194017FDDF31DE9D6F6DD9B7A506,
	GraphicRegistry_DisableRaycastGraphicForCanvas_mA4F6606E0E337C952C61773DD6C6109BE27D2115,
	GraphicRegistry_GetGraphicsForCanvas_m72A429EAD15F1CFA7F84BE394A3ECA1A00BE7087,
	GraphicRegistry_GetRaycastableGraphicsForCanvas_mF0EABC1F1DDCAB05BA144A1C37F1EC0EB606E668,
	GraphicRegistry__cctor_m63428B4F697EE7B38C6A4F6C6C724E3A2B4FEC45,
	NULL,
	Image_get_sprite_mB2AA377708722E100574F6F75BC102513BB3BCB1,
	Image_set_sprite_mC0C248340BA27AAEE56855A3FAFA0D8CA12956DE,
	Image_DisableSpriteOptimizations_m94966D77FEEF830B1B97C44EAF74843EB94E7C25,
	Image_get_overrideSprite_mE3FDFDD768A99DA4F19356E1D3F158A29E7A3C65,
	Image_set_overrideSprite_m05036DA9D0E7A173E3A5D2A2156E8E0A50A7983E,
	Image_get_activeSprite_m0F639A03B26FD25CA1D8EEA006D0B0C322037034,
	Image_get_type_m7CE3AA14B38E1C50AC8362176AE842992DA8C639,
	Image_set_type_mECB8D34772AA393FFBC867B03D18EA0F1A8546BF,
	Image_get_preserveAspect_mCF10199F127659628F58CDC7C91E686816B34B5F,
	Image_set_preserveAspect_mF465AFD1313C0F002B37C8B86C75F98CB72A4098,
	Image_get_fillCenter_m4951647922C5C7B1A0243C9536F8CF5A8FDDDC6E,
	Image_set_fillCenter_m3A5E856A3F877649590F678ED6DDE38B64B14FE4,
	Image_get_fillMethod_mAFB1FAAFA913DB0EE050C4053DBBA6FAAD68A5F1,
	Image_set_fillMethod_m5361D29BA950BEFE72E7270AC3BFA0B00AE7E294,
	Image_get_fillAmount_mDEE52490D07124E21E7CB36718A5E3714D8B9788,
	Image_set_fillAmount_m8A9B55F47F966A3214EAC4ACBFE198776A98FAA7,
	Image_get_fillClockwise_mD18612EBF815BC5C238D1591039BF9F1D28DF2C0,
	Image_set_fillClockwise_mB5DBAFC66370F906EA2CC1D49D49FCC366B64646,
	Image_get_fillOrigin_mC9778E141C67C15EC865F6648E5B2545BCC30389,
	Image_set_fillOrigin_m2D89BA820DABB26123A33059CA266212E7970B4E,
	Image_get_eventAlphaThreshold_m19B026C80DB547E702E22A1053FBD0A1BFF2F51A,
	Image_set_eventAlphaThreshold_m999376263E8A9914F5D69E71B4650D76F283AB6D,
	Image_get_alphaHitTestMinimumThreshold_m5F6F90EEC3D06F719E9C360A6813A49CDD7EC4BA,
	Image_set_alphaHitTestMinimumThreshold_m007F9F1C5FD0331E1EDADF4EEE3CB16F6B43F843,
	Image_get_useSpriteMesh_m3157E0D7DB2F54EA7B13284F53FA9013F316F7F8,
	Image_set_useSpriteMesh_mFA81C2E108CEB33E5F92A9142B2C83B871C3A81B,
	Image__ctor_m8F922348981CDB74700D89D833FE39611FA4BC37,
	Image_get_defaultETC1GraphicMaterial_mCEFD3237CA0090EBED29A81983DC3FE78BAFBAB3,
	Image_get_mainTexture_m16CAAF3A2CBF5B3BBB19AC8BD99CE9187C47D3FD,
	Image_get_hasBorder_m9B09E5452FE8CF13958D7301B01A3A8124ADDDC0,
	Image_get_pixelsPerUnitMultiplier_m2B008CF7C16C195A24FDBC5CC7B34531E18F1A18,
	Image_set_pixelsPerUnitMultiplier_m05DA43C7FD5B7B162FCB1ED6FCA850FD41AF7DC1,
	Image_get_pixelsPerUnit_m319197FFB69E9E8661F46B0DF652F3B3F25D16D5,
	Image_get_multipliedPixelsPerUnit_m6F99237811BE288035A4133833611A446BEE6A8A,
	Image_get_material_m62CEA51BA237569FDB47573CDC125CC3E643A3E7,
	Image_set_material_mC1B5D07666D4CF7C4531F2E8424EB2B62A445D19,
	Image_OnBeforeSerialize_mF6D870DBB1C6826A6AFBD2F23D5181A2BE47994A,
	Image_OnAfterDeserialize_mAD5F5C236B40A266EED00C838164502E253957DD,
	Image_PreserveSpriteAspectRatio_mF56B000B224C2EF11A2EAB4BF465EEA158C5BE1D,
	Image_GetDrawingDimensions_mE33EF5C86703080A13063FAD318B6C114B80CB1B,
	Image_SetNativeSize_mC769A2A62A1F5ED648FC64918182CA40D5518817,
	Image_OnPopulateMesh_m5B662B655BB6DD663AFBF9DF440DF6C6C2EEF9EB,
	Image_TrackSprite_m77BFAC0425F494ED236E393B60E6BD26D5B6A5AA,
	Image_OnEnable_m35B953599A5E65EFEA059E93772D73ACA91BD073,
	Image_OnDisable_m453B2333D529FD5359E1F687BFE2D949207AA58C,
	Image_UpdateMaterial_m3EF2E1AA8D38FAA067FB5AF887B88855EBF1AE9C,
	Image_OnCanvasHierarchyChanged_m3B34FE2B1BDEE8A04854E9C1ADAC49934FC7EDA8,
	Image_GenerateSimpleSprite_m32C9150574E952AE9F5B846AD11A5F0BC8521CC9,
	Image_GenerateSprite_mE58FCD6A8B78A30794664E9DEA81A51C5CF6FD03,
	Image_GenerateSlicedSprite_mE27E793AAF0D0E30BD1B02A12C7FF08566132EF1,
	Image_GenerateTiledSprite_mD6AD2832573EB7AFDDDAC9D31C243AABEA7489B5,
	Image_AddQuad_m53D28C1CA949F7C8B1214D15298BDA5E21AFFD21,
	Image_AddQuad_m39CF7AAE0605E563F3D0C6CE62639E44BCAACA42,
	Image_GetAdjustedBorders_mF3AEDCD9810B2DE6038FF269245899F325366CF6,
	Image_GenerateFilledSprite_m3C13BE8BEBBF021D40B2A6AF6A4170055E621915,
	Image_RadialCut_m0D5FED1F2A3FFE1985A19E8C8AE990EDFA42C2E4,
	Image_RadialCut_m9F8E2FE769EE906D4327A856B6DE9ED73B1AE338,
	Image_CalculateLayoutInputHorizontal_m2B3C913A12F299D2ADBC79DCBC2FD533B24E1EC8,
	Image_CalculateLayoutInputVertical_mA3259ED5830198EF68B2FE1490491D6761C9CAF4,
	Image_get_minWidth_m55A550B01D2E2AA928D77B836B6DDD159EF8B9EA,
	Image_get_preferredWidth_m8AB595CC948924C3C0014873E4C32FC60CA7F27E,
	Image_get_flexibleWidth_m76B50FB439854C2E3850E4D1988029BFCD85EEB5,
	Image_get_minHeight_m40CDD49A5304B1E96FBA3325A9865F16C782CA4F,
	Image_get_preferredHeight_m3A6C0CA2FF3F09FD072ABA13D0553783DD5B0A5E,
	Image_get_flexibleHeight_mF47948629BAA50EC3FC818AD668411A0061EEE6C,
	Image_get_layoutPriority_m1D4FFA04DF71939657E16CDFFC81A5453ECE0C67,
	Image_IsRaycastLocationValid_mB71CF2A446BE3F4C6CF896E8BCA9A36BDF676D21,
	Image_MapCoordinate_m11D428E63DF2AEB1A5866A0AE778E5287F4776FF,
	Image_RebuildImage_m5BDCACEE109C4EF96B8F783BCB71FEA9A72E0E45,
	Image_TrackImage_m24AE9D703DB406780DA6975F648C587CA1F62EDC,
	Image_UnTrackImage_m59DCA4A9F6ABE55046D24006FCC7373FC0717A0C,
	Image_OnDidApplyAnimationProperties_mA079140EDEA8341023066DC950E94F38C61EEE27,
	Image__cctor_m67595BC3057DCFD5A6593929CA673CE415F5803C,
	NULL,
	NULL,
	NULL,
	InputField_get_input_m23129FACBD4CDCEA3FC9A977D7DA5BBD4BBB0B2B,
	InputField_get_compositionString_m5E9F323DE7B62EBB69AFC569C05ABC00F619FC4A,
	InputField__ctor_m06B9629E3C878D578A8B43C1A8835B526629D6E5,
	InputField_get_mesh_m89CB1A4155FF8E7C42D5D97178DD00A3A7D8888E,
	InputField_get_cachedInputTextGenerator_m42F16837E9BC49BB43F58163B827C4260303E48E,
	InputField_set_shouldHideMobileInput_mC3759A3E3DED19B9EC01E30CB810922772894C76,
	InputField_get_shouldHideMobileInput_mA752B065435F4062EFB931119C34FDB5B35157E2,
	InputField_set_shouldActivateOnSelect_m5F21C9511D040820CFF661E56145C25D147D17A5,
	InputField_get_shouldActivateOnSelect_m4DA84FAEB2FFB6F036A3821675730842FF86245F,
	InputField_get_text_m6E0796350FF559505E4DF17311803962699D6704,
	InputField_set_text_m28B1C806BBCAC44F3ACCDC3B550509CA0C7D257F,
	InputField_SetTextWithoutNotify_m2CD8DAC2A298CBABFCEC654A17294427DDD238A3,
	InputField_SetText_m66574324D7550D728E41F71DD704CDCDEADF9E66,
	InputField_get_isFocused_m19BD51E842077CA087824025F294C4078B2DAC50,
	InputField_get_caretBlinkRate_m5D6172BA3B84F25897444A1A469AA53FC5CE5613,
	InputField_set_caretBlinkRate_mCE440AA4049C7A1EDEDB63E5B0AE4005563C5226,
	InputField_get_caretWidth_m6D85BF105006F28ABF2940033BEED2E595C89E55,
	InputField_set_caretWidth_mD71B00146099D90D920F4F63A7032E8AEDD39915,
	InputField_get_textComponent_m319EF4B9B24056AF25327874A2455362FF7B7A85,
	InputField_set_textComponent_m09DF6BBF8544028D98D68D3F905AAAE17486D272,
	InputField_get_placeholder_m84C2F2E414B8A03B372C7CEB3C97A2AE72F3A39F,
	InputField_set_placeholder_m64F47B180F584EB1049CF8B501DAC3FCA9029F25,
	InputField_get_caretColor_m92C8BB7D9BD4B4DAE361494F85418F834EE87832,
	InputField_set_caretColor_mF9C606AA2F9F123CB6AD078DF616DE35061FF830,
	InputField_get_customCaretColor_mB1D8A9DE8CD1787B3614BAF3E50E27B2428C7215,
	InputField_set_customCaretColor_m7CA0470187246247EEC354FEB7053E4B4911DC13,
	InputField_get_selectionColor_m988C5ACE38195B9B6397352B5A226FF3867A6E54,
	InputField_set_selectionColor_m2B7800A90FCE0840800CC01EC2C17059634B015E,
	InputField_get_onEndEdit_m92C86FF7CA6108C4B14392CED20C9ED9D39AD9A3,
	InputField_set_onEndEdit_m0AA121171524CB10C4BE4692117839A97E6AAD08,
	InputField_get_onSubmit_m66A3BFEC3D3D5C261558043FD606D4FBCC7D478D,
	InputField_set_onSubmit_m1763F344243E5E3CF28F07872A80AAF809FC1988,
	InputField_get_onValueChange_mF6915B4F33F4B24A91D8E56DE20EFFAE25C59756,
	InputField_set_onValueChange_mA1AEDDDB12CEC499949DB0605A83D8F383212CEA,
	InputField_get_onValueChanged_mA9ABE178FE3EB05AEF3DC20C11349427C59916AE,
	InputField_set_onValueChanged_m2B2F8D1E8F5FE418CE0797F2534B61A1A45B8A85,
	InputField_get_onValidateInput_m370D93274B6040422092981DD3A34E4B88E96EBC,
	InputField_set_onValidateInput_m3A3FA74285B9BBA68325A91AA862201AF3A18CE4,
	InputField_get_characterLimit_m7FE26FC66741545B89BFFDCAD8E8B34EB1274403,
	InputField_set_characterLimit_m98A2187FF493DB170821C39A6D069731F3AFFF2B,
	InputField_get_contentType_m8C589B15987EB8852D5F4948A79084186935B19B,
	InputField_set_contentType_m5C3DDD7C14781E963BFFC88F7A8A537919F34C59,
	InputField_get_lineType_m6CEA63D8FCACAEC05D3499577ED0771EFFF33377,
	InputField_set_lineType_m06BE148366DF8F17E0F91C3CF094628C201B5FD8,
	InputField_get_inputType_mC324081499638BC8AAA45CC110536C016C707BD0,
	InputField_set_inputType_mB2A3B667DC710AD1F9E1C046659AC35720AB0313,
	InputField_get_touchScreenKeyboard_m99338FA7655276193EE1BA8FCB821C7F1928B3D8,
	InputField_get_keyboardType_mCF9432AC88C35E77546235909346C5689682E620,
	InputField_set_keyboardType_m9DD165B20CF12F93BD85140D8D1F54371FF4E9F3,
	InputField_get_characterValidation_m02AD706E70817147BAADD487DAC73D79547BCBBF,
	InputField_set_characterValidation_m9DE08B33714B9D97F570853ADB56C070C2DD4072,
	InputField_get_readOnly_m37800B8623CB744D99E5F5607C80AEBE6C7043B3,
	InputField_set_readOnly_mD70582D7F885929AD7CF28BF083623991C5F543F,
	InputField_get_multiLine_m4AF37C1E2560778A214C50E91C472430D8F777B6,
	InputField_get_asteriskChar_m2556CE9FA8ABF5C00552BA665299F71EAC7D55C5,
	InputField_set_asteriskChar_m26FC4CE6C8637E49ADE854769F6C777A6BEF5CB6,
	InputField_get_wasCanceled_m75E09A773352839E08B04B33F966ED3E849436E9,
	InputField_ClampPos_m8939841884C3CD51A6169F5DA05A85CC3C16A371,
	InputField_get_caretPositionInternal_mF01180C72008CCDD2A5371EE45B84D7745CB6BC0,
	InputField_set_caretPositionInternal_mA35B05D5FF035A060967C6E456610D659367C3EA,
	InputField_get_caretSelectPositionInternal_mBAE2F71F18603A0C4A6AA08F0BFE5831CBBBA461,
	InputField_set_caretSelectPositionInternal_mCA096AAD610587421E739BDD195A1680FD93A75A,
	InputField_get_hasSelection_m3E8EF152E7A7238C8F0631FFC16727800CF16B24,
	InputField_get_caretPosition_mC43674CCFF5BF7D047C2D4682B2CD7DE8A179EA7,
	InputField_set_caretPosition_mF502AA3301C39D4397C7BF809D1F3A18D0603BD7,
	InputField_get_selectionAnchorPosition_mF5CB19025C29DECEA0EBA8C6EC3D6D5687A1D65E,
	InputField_set_selectionAnchorPosition_mE57B85DBF03991E694729ED36283B44A8D7D1E68,
	InputField_get_selectionFocusPosition_m14D662A0A20FF6952E73CFAB7C1F21FD7CF4298A,
	InputField_set_selectionFocusPosition_mE9E0E491C5AC1B89B4F9272EC3B67617A4F7DFEB,
	InputField_Awake_m7253E5687FD0D44982BA34EA523894C0CBE927A6,
	InputField_OnEnable_m00FE61194E553F736B0C1AABC73A79EEDE81D9AF,
	InputField_OnDisable_mA79B9B02E48BE7F1AA6C94C6CECB7A6AB323AB8B,
	InputField_OnDestroy_m551000531722FAD0D2DEB4CA9A76EF25A7067EAA,
	InputField_CaretBlink_m030EE72571B48D2CD7E346D68B0F236C9BB25CB5,
	InputField_SetCaretVisible_m9DB05703AF6B427F53FB4948BB592CF061AA37AB,
	InputField_SetCaretActive_mC91972AACD936D757447E3F7967CE2DAD4B46D0E,
	InputField_UpdateCaretMaterial_mA2C86C0AFC38D35509A3BD66A10411AF7D13FFD4,
	InputField_OnFocus_m5EC2CB19FBDAA84FB317F5ADA86548D78B550F37,
	InputField_SelectAll_mC3A2CAB32B290BC43782A61452760BD127E729EA,
	InputField_MoveTextEnd_m1C20AF9DB90F79CD85C4DAB179DA4EDB4D971810,
	InputField_MoveTextStart_mE56A94C2D4AE751A3BE1035250880D9B592BF130,
	InputField_get_clipboard_m4ACB240747BB6AF77A3FEF28A63A5C2B2A049543,
	InputField_set_clipboard_mA8C4BC1DA5B1C12F8A7E7880E0F74185E2D8BCDB,
	InputField_TouchScreenKeyboardShouldBeUsed_m56104E5B7C58A89C552D4CF8FD7A1B1D93D7340A,
	InputField_InPlaceEditing_m1F71173373CC2A21034D23ECA0060FA4E5A89F11,
	InputField_InPlaceEditingChanged_mE02AC706260B93670AF1380BE4060F3AA4063C47,
	InputField_UpdateCaretFromKeyboard_mCFB186696BE23B347D7AA94DF50A13555C31F8B4,
	InputField_LateUpdate_mA1C1B81011E3D2F3D6F0769C0FE0D4B0A8E71020,
	InputField_ScreenToLocal_m3ABFAAAC443370A1621926D80EA665CF421CAF9E,
	InputField_GetUnclampedCharacterLineFromPosition_mDD25BDEA1097899537A5D7E8881F23D3D49327DC,
	InputField_GetCharacterIndexFromPosition_m9C0D9CBB43A1CCC47F7B4234379668E46AE3EB32,
	InputField_MayDrag_m72ED9A80A46F59B07697E415E1D691084BC133E6,
	InputField_OnBeginDrag_m3A945C4E07937EDA5E99447572F5F167F1143691,
	InputField_OnDrag_mEF28C06EFB5024C1E236C5A21E715B62CA87BE84,
	InputField_MouseDragOutsideRect_m464392D721204B540DC92E449B48BCB04BCFDABC,
	InputField_OnEndDrag_m0BAA34E5BDBC9A3E241F8BC7DBA8172DD5D9651B,
	InputField_OnPointerDown_m4A3A77DDBA95CB4E50A4BFDF0EDD59B5A9191BF2,
	InputField_KeyPressed_mD6FAC314D8211F43C4C041AE87B3290665A05D28,
	InputField_IsValidChar_mDFF88F1042D52286FDCD5D7302706C837265876D,
	InputField_ProcessEvent_mF905BEF5A4CFF9144159FA40DE2F9DFD4A967358,
	InputField_OnUpdateSelected_m36FFEE16138CDDCA30643962A4C5A41763FE2E55,
	InputField_GetSelectedString_mDF15471A4398D6D7B391105A8549F09DC03DA283,
	InputField_FindtNextWordBegin_m1152E725F12932E30E304F4F10A42B0733201A18,
	InputField_MoveRight_m0D51E23BE4EF55EA54DED277573263BB2A5B1D38,
	InputField_FindtPrevWordBegin_m54E76FA4BF8AE95109D2F78EA0814751837F5AF7,
	InputField_MoveLeft_mD7E3870F7E54009522CF9412764FD5FD9212BBAA,
	InputField_DetermineCharacterLine_mD80BD8A0F49EE45FA6E512796D3A4A15462D97BC,
	InputField_LineUpCharacterPosition_m6E5C0F57795B5CF3D588EFF099A65D90E60848A0,
	InputField_LineDownCharacterPosition_m3212B8EC92092E97AC60D072EFBD385FE72CA829,
	InputField_MoveDown_m365DDF603B2D68FD98B0240F3302886FF7CFF16E,
	InputField_MoveDown_m13622D37FC022939623A9DBC447E49F5D9F43C80,
	InputField_MoveUp_m4703516BEB5B1A3C4020895BABD0558427BE7895,
	InputField_MoveUp_m7F41FF9D5EA2BF64B36C1ACABB67169722C668DD,
	InputField_Delete_m12AD40195316F01879910401E6E0DCEC7F5A8132,
	InputField_ForwardSpace_m4CF251F5CE00CF4918EA0C2D322770A4B556D4E7,
	InputField_Backspace_m4BDCF533ECD04258884076830CB4F0907FCED3E6,
	InputField_Insert_m925B9FADD75785B8FDD886477F0B0CC1E0B4C718,
	InputField_UpdateTouchKeyboardFromEditChanges_m68C429349526101B885D038FFD0C2935151E0772,
	InputField_SendOnValueChangedAndUpdateLabel_mEB064D57921681BB49F55AA796E046A951DAA7BA,
	InputField_SendOnValueChanged_m52131907987E99A872F6007B599345A2ADD244AC,
	InputField_SendOnEndEdit_m79E2689DD75F72FDA8157EECD3F17391D187094B,
	InputField_SendOnSubmit_m933C160291FD9118A9EC7FD7AED5E805B998BA27,
	InputField_Append_m78F45E67DDB94E034940730969D199A971C7D1F1,
	InputField_Append_m22A6348E74FB83932286AC1CDD73322C05BBC63F,
	InputField_UpdateLabel_mDBE25D21A1021AE4563539586438B5EA89511D58,
	InputField_IsSelectionVisible_m2A7FD156812466D2D2397B57959BF91BACC52EB0,
	InputField_GetLineStartPosition_m6ABF6AFB8A9495D7A5446B577EB2ECA8770A9660,
	InputField_GetLineEndPosition_m690864C08F9250D76D718D5D54611C886AAA0A79,
	InputField_SetDrawRangeToContainCaretPosition_m0F3F4E0179627915136B2B2927CD234304E8432C,
	InputField_ForceLabelUpdate_m49441594294B33C5DC10D717198A476B523EE1C8,
	InputField_MarkGeometryAsDirty_m71DCE40033F96C4A842885A7601E3882FF0BD4F4,
	InputField_Rebuild_m4974AB56B494186177AB4BA6C2626BCB0EF93304,
	InputField_LayoutComplete_m7953946E63BF48E14CE1FF13D76FCAA832735C7F,
	InputField_GraphicUpdateComplete_m25B7375B32DC3384EF8684ADDAB6996359668DBF,
	InputField_UpdateGeometry_mABF2E288AF71AF5C8E608F30745D6BAE40A9CB4D,
	InputField_AssignPositioningIfNeeded_m114957547C208AD107279D1B6E8A855D18915E36,
	InputField_OnFillVBO_m84E1576406EFFC37D6EFDDD4604B393E281C5BA2,
	InputField_GenerateCaret_m401461627986E86804E31BE16332003BDCD9EF98,
	InputField_CreateCursorVerts_m2170881250E5F316805946E87EA1F1A794E6AB23,
	InputField_GenerateHighlight_mD1A67441901D78AE29E17A655791754A92EEC072,
	InputField_Validate_mBB63D4E37F8CD96C0F57270259DDE69E3BCB7656,
	InputField_ActivateInputField_m4986DE5488FE44D93DE1D906C140D6500134DF05,
	InputField_ActivateInputFieldInternal_m5B89A6BBCE9D7DD6F0A3DF4B6296533507170119,
	InputField_OnSelect_m723C2F0E81FAFF8264CFE4596CA2AF30B7D9E307,
	InputField_OnPointerClick_mCADA1FE2E0B6EA1F6A9B69DB3790E752243BA4F3,
	InputField_DeactivateInputField_m58D0B3BF095094A0963A9CE8BABF1979F7D1254D,
	InputField_OnDeselect_mA31D1383106BAF91CB638C04E508322FBEB2EFDC,
	InputField_OnSubmit_mFEBD3EF3B76741F19E84A12FBBF9B5BB60E5952C,
	InputField_EnforceContentType_mB8A7743C77E3EAE952426EF14BB5BE5B80E7488A,
	InputField_EnforceTextHOverflow_m7F0E61391D942F47B4AD128C0C8B9B204BBE14B8,
	InputField_SetToCustomIfContentTypeIsNot_m8E1B8AF7133B6B42F9E6BA3951AE2AA4D2AF1071,
	InputField_SetToCustom_m1D8B546B458993E86A24A05B868C57286E8C6BF4,
	InputField_DoStateTransition_m51CFACBDB11404C6F10D0BA3AACB394036CB35A8,
	InputField_CalculateLayoutInputHorizontal_m291256FA87BF5E7F0D7CD64205B58E6B7E88809B,
	InputField_CalculateLayoutInputVertical_m4102477D8FA249BA49FDF9C0CE5F45A42752B083,
	InputField_get_minWidth_mE316201A4474E22FA455CFD381C0A73B76CF5B06,
	InputField_get_preferredWidth_m13ACB831ECB400033C936A46342FF10E8A96D05B,
	InputField_get_flexibleWidth_mCCBC75043CD2BF11B0E38D71A00A5CE790DD9E8C,
	InputField_get_minHeight_mC742ED6E8E46602EE8C085F724AD5442A24DB1D7,
	InputField_get_preferredHeight_m7C3EAA7E8DC12397B9C83A72582C8FC219BA63DA,
	InputField_get_flexibleHeight_mE4CA2B68F90E91C6B884D87FF98D3CA062332A6D,
	InputField_get_layoutPriority_m88277B59E761DA55E6DF1AA803B0DC629ECDFE3C,
	InputField__cctor_m963ABF5968D8C97B8286CD633B0B0B4691ACEBBD,
	InputField_UnityEngine_UI_ICanvasElement_get_transform_m68143981855D6B92BF815F3058EA2F063A63D59A,
	OnValidateInput__ctor_mDC0454BF264F87154EF8694821905B5A6A587A29,
	OnValidateInput_Invoke_m6A7776E0E91552E39F207A90C7E33A4D4479F076,
	OnValidateInput_BeginInvoke_m2A003B257BC355C137B83FB37B3D9DD34821F9D2,
	OnValidateInput_EndInvoke_mE13A5F2C1260AD59F20BFBD7CCC9BE42F84EF6DA,
	SubmitEvent__ctor_mE8908589516FD77AA786BDACC7BEBC2182A87EE3,
	EndEditEvent__ctor_mEAA90FD69A3F6F34EF977AF11A424CEEFF441953,
	OnChangeEvent__ctor_m3D387EF9F415EC6E177649A23DAA137AB98F3E05,
	U3CCaretBlinkU3Ed__172__ctor_mD71554D61758324CCBD8F37F5CE8249169AA88F6,
	U3CCaretBlinkU3Ed__172_System_IDisposable_Dispose_m4B3174F229D803FBEC9FE749FE1A76E0A17A7AF1,
	U3CCaretBlinkU3Ed__172_MoveNext_m725171803230FB9AB7A1FD06EA915CE483335D82,
	U3CCaretBlinkU3Ed__172_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m6F0710FF54BBA7F57D031169B56C02C9D0503926,
	U3CCaretBlinkU3Ed__172_System_Collections_IEnumerator_Reset_m880C7F0BD8A9138228E0D9C61A53D0C7FF616BCA,
	U3CCaretBlinkU3Ed__172_System_Collections_IEnumerator_get_Current_m047B5A2A48DE0ADB8ADA21A1B9C70A81F7ADD9CE,
	U3CMouseDragOutsideRectU3Ed__194__ctor_m561BCE12F8D3972DD2E157255C57E2E7EF5A3EF5,
	U3CMouseDragOutsideRectU3Ed__194_System_IDisposable_Dispose_mB18C1AC7228F57FAFCEE8B7D6015C8AA079418F2,
	U3CMouseDragOutsideRectU3Ed__194_MoveNext_mBDBD60F4DA7ED5CD50DE5ED93C6ACA320B3AC444,
	U3CMouseDragOutsideRectU3Ed__194_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m97FAB502D17418D00041C80355446F3790E2027C,
	U3CMouseDragOutsideRectU3Ed__194_System_Collections_IEnumerator_Reset_mA0942EBCCC575616D5D28D9879334C5D68ECBD34,
	U3CMouseDragOutsideRectU3Ed__194_System_Collections_IEnumerator_get_Current_mCB19D1EFAE7DE8A8B81DF1B0C6CF552ED9E40BD3,
	AspectRatioFitter_get_aspectMode_m530AE9878F26D7C1166C2AC3C2B2547CED122B27,
	AspectRatioFitter_set_aspectMode_m1CDA777FF728BD01AB939C074D03F9C18675FB65,
	AspectRatioFitter_get_aspectRatio_m72A1972D15B7435EF895562EEF0AE8C689ED120E,
	AspectRatioFitter_set_aspectRatio_m4192E203648BE0ACA39D9C0540C982331CEA91D9,
	AspectRatioFitter_get_rectTransform_m20FD6C51C01C8BBC2C8223C255F9C28E00689496,
	AspectRatioFitter__ctor_m277805022C03480F2EDA97E7AA48D33839EBD102,
	AspectRatioFitter_OnEnable_m5B6FCCB531F87ABBAEFEB38AEDA1340E10EDEFDD,
	AspectRatioFitter_Start_mB88F08EC9C3453EAB41607D91825BD90C6391F64,
	AspectRatioFitter_OnDisable_m43DAB6B9ADAE9683A99395FCD7B769879A75477F,
	AspectRatioFitter_OnTransformParentChanged_mD5F9B727921A4416EB663B4152CCB499EFB8B111,
	AspectRatioFitter_Update_mE1F6FB785AB83C3416B67EEC58CDB74144583230,
	AspectRatioFitter_OnRectTransformDimensionsChange_mE94570689C2A5CCB2C2EB33F9C5F240E780A2784,
	AspectRatioFitter_UpdateRect_mFAB08DEB6F064E439934183C92038428ADA0F235,
	AspectRatioFitter_GetSizeDeltaToProduceSize_m467FB832F233366AC4B795E932F05740E6429A4D,
	AspectRatioFitter_GetParentSize_mA3CFC47B4F43532BCA0267F99911DC2CA1FFE9B0,
	AspectRatioFitter_SetLayoutHorizontal_m49115A35A48158B48CD198028034214F95793FAE,
	AspectRatioFitter_SetLayoutVertical_mAC5B9A89C0E8659BB590BD62608D22349B90D612,
	AspectRatioFitter_SetDirty_mCCB04E2ECBD43C874822C58BEEAC00AB7EA8A58A,
	AspectRatioFitter_IsComponentValidOnObject_m163BC9DE4258B1C308B850BC259704A3D285A3B0,
	AspectRatioFitter_IsAspectModeValid_m0311FF067288EAD9D2A81ED3A4151C406F0A30B7,
	AspectRatioFitter_DoesParentExists_m9475339C8EE94000A65B9F39AFB08A867940D925,
	CanvasScaler_get_uiScaleMode_m8E92609E011796E8CC23B1739F95CE7BE2631525,
	CanvasScaler_set_uiScaleMode_m064C83FFA35E2AED4E9FA7D5EC1AD19630D8FC2A,
	CanvasScaler_get_referencePixelsPerUnit_mE0A7FECC27003A4A2BE6AE6E70747FAC8C19A008,
	CanvasScaler_set_referencePixelsPerUnit_m8817BAEB73BE78DD7C87EAB7D2FE2983B2300628,
	CanvasScaler_get_scaleFactor_mB2BFA22B99AEC96F09886F490DA9EE2F825D3431,
	CanvasScaler_set_scaleFactor_mD53E8CAE41E8C1B0DF53CCF14D5941FF8EA3488B,
	CanvasScaler_get_referenceResolution_m79C03DD8CE6759B045928C5339A3C5E6220276B5,
	CanvasScaler_set_referenceResolution_m793679B8505AF9BBF64F45D80AFE39F3F99FAB8D,
	CanvasScaler_get_screenMatchMode_mA07ABCCF6AFE98C16651EBD5AB24BFF08B10F768,
	CanvasScaler_set_screenMatchMode_m926C437B408D2F2CA4900723BEEEE09504A6768F,
	CanvasScaler_get_matchWidthOrHeight_m9C40FBA943172874FD27F3F7B880E2D5D5862C9B,
	CanvasScaler_set_matchWidthOrHeight_m44635DC3E4424255C312814C325A48E37E6B6E30,
	CanvasScaler_get_physicalUnit_mD4B04FD2D68F8C3CA39550C056A7AFC836DEB6EA,
	CanvasScaler_set_physicalUnit_m6A759A32FFBEBC43A51C98621A3F505289670C5C,
	CanvasScaler_get_fallbackScreenDPI_m966C603918C0420EAB4C3048591DE408190FFAA2,
	CanvasScaler_set_fallbackScreenDPI_m01E7CB32B519FBC9F5A77F060EE0B2DF7D6895AC,
	CanvasScaler_get_defaultSpriteDPI_m2F1CDF6DE4F2B2E3DED10D50D6E674699120C50A,
	CanvasScaler_set_defaultSpriteDPI_m742DFE7A3315C0B33763D2E3FB2424BCFF35D3DE,
	CanvasScaler_get_dynamicPixelsPerUnit_m6DFC581EFFD626F6815BA8C9579DD736514626AB,
	CanvasScaler_set_dynamicPixelsPerUnit_m7A081D5FD963F751140DCF1E5190ED4E51308CA2,
	CanvasScaler__ctor_m0D60150B065E8CFBCB4BC324F364A0FF08762493,
	CanvasScaler_OnEnable_m9F50E6AF109CE6227FD9E523B0698925B89D29F8,
	CanvasScaler_Canvas_preWillRenderCanvases_mDBBF36EADD3DFBE62E1E5F14D0DC9BB86FC21E6A,
	CanvasScaler_OnDisable_mE0CE97F651B806DD2B2565203A00E97A6A781B2E,
	CanvasScaler_Handle_m0EF8A30C92B8A90A54D2B0BB06E7698E74AD5967,
	CanvasScaler_HandleWorldCanvas_m3E325EB0AC3221EA44B3D81360DFE63C36C13190,
	CanvasScaler_HandleConstantPixelSize_m7C504A9281A98E3473F0113CD74A9305AE4C5CD0,
	CanvasScaler_HandleScaleWithScreenSize_m3F436166B074013EDBEE38B7009C338650CF942C,
	CanvasScaler_HandleConstantPhysicalSize_m44CEBEFEE2AAD54993DA3A43047E86AE07B32DD7,
	CanvasScaler_SetScaleFactor_m195FFD8019696523653CA6CB1B8531ECE4020636,
	CanvasScaler_SetReferencePixelsPerUnit_m77B9E51B468EC9750355687AA6E25564D60BE9B5,
	ContentSizeFitter_get_horizontalFit_mA5FBF6AB42F551272B94A7B89A372B1AA1ADBC0D,
	ContentSizeFitter_set_horizontalFit_m7B0DB223B08B8D578F749DEC381349E7D66DCDE4,
	ContentSizeFitter_get_verticalFit_m3F2848F19A5F8F30F55E0B5D930EFEF4E5EFAFF5,
	ContentSizeFitter_set_verticalFit_m8F61CFD01D4C3D3DC253F30BA8FC2F44F8F927CF,
	ContentSizeFitter_get_rectTransform_m757AAC9852D5C462C083FDA80390813E4FF06467,
	ContentSizeFitter__ctor_m60693679801693DCDEC5BF0FD45590BD66F2434A,
	ContentSizeFitter_OnEnable_m31DA9C05A1B5FAB9BD1BE05C43192B427C156CD3,
	ContentSizeFitter_OnDisable_mA11B1667210796F7DEE199F2B78844A6CA0C720F,
	ContentSizeFitter_OnRectTransformDimensionsChange_m427809780F5D59796CDB386A8CD5B4DB985D7691,
	ContentSizeFitter_HandleSelfFittingAlongAxis_mA050224EA492DF6C8B339DC36FC3BB8ED5D09A85,
	ContentSizeFitter_SetLayoutHorizontal_m694E40D536D88366735B3838FA040EB2D2144320,
	ContentSizeFitter_SetLayoutVertical_mB58DDF80917329DFAE202DA73472AD39BF37E561,
	ContentSizeFitter_SetDirty_m5A4C67937A3C77E467881648D5B9D7AB4E8C5C59,
	GridLayoutGroup_get_startCorner_m0796B782C9F3981B6E97F83A6815102A5176657D,
	GridLayoutGroup_set_startCorner_mCE5A1E957B06BF34173119A5C62B832E279DA78A,
	GridLayoutGroup_get_startAxis_mADFB75A761550B3141256B0130655A6703FF3FF5,
	GridLayoutGroup_set_startAxis_m2C9BCD2A1CD3ECFDDF3B0A8B7EE28C48179A7739,
	GridLayoutGroup_get_cellSize_m30D8A051F44C8EE0C87B6D6CDDC00C2592A78B6D,
	GridLayoutGroup_set_cellSize_m0A3FF07694BDBF52D973597978FC87B0941BE5F9,
	GridLayoutGroup_get_spacing_m19BC15652BF18D051B0998C14F13DB83191F3E58,
	GridLayoutGroup_set_spacing_mA5550A683F7B4A7A1510B267B5D4CACEB8981306,
	GridLayoutGroup_get_constraint_mAEC0A95B4DF9F48E07B5403CC5F954AFDE503029,
	GridLayoutGroup_set_constraint_m632CB37D0D79A12DE81372EE819348CD1226B84A,
	GridLayoutGroup_get_constraintCount_m63AE4B7889A27D8CAA8EB04A40B1FE53D80CC318,
	GridLayoutGroup_set_constraintCount_m685F6D5254B6D77AF8BE070EF3DCA5F049B3D043,
	GridLayoutGroup__ctor_mBC2ADB7B7F092C83138425C82DEDBB6701F73F7D,
	GridLayoutGroup_CalculateLayoutInputHorizontal_mFDEDFB79ECF5C03713EE1C128362D3AC0D48ED8E,
	GridLayoutGroup_CalculateLayoutInputVertical_m41E33CD0EBF75155C0B842E9EDA2C66EB68AA9EA,
	GridLayoutGroup_SetLayoutHorizontal_m16F35F3DA5B7AED47787C0EBEC723723DC9034F0,
	GridLayoutGroup_SetLayoutVertical_mAF83C49C8BBA29EC4465B1BC2A8A39B0321FB038,
	GridLayoutGroup_SetCellsAlongAxis_m815D9BF1B794A46C96CFE3E069C49274FCB66739,
	HorizontalLayoutGroup__ctor_m811D870AB5F67030CD9A3C1FC02FFE69298131BC,
	HorizontalLayoutGroup_CalculateLayoutInputHorizontal_mB2C54B2F51CB18A490867DE302D6444C93ADC537,
	HorizontalLayoutGroup_CalculateLayoutInputVertical_m8739924AF17AA7FD9061BBDEBECFC3E2C946D27E,
	HorizontalLayoutGroup_SetLayoutHorizontal_mA4203F549D73128EB605594C74DA47CA07278A25,
	HorizontalLayoutGroup_SetLayoutVertical_m6B8A658837C88E6A29A9850725734F9C5CA67B82,
	HorizontalOrVerticalLayoutGroup_get_spacing_m916C9BF57D4AB0EF76E6BC4EC5E1EA54B7918782,
	HorizontalOrVerticalLayoutGroup_set_spacing_m90373F54D37DA8DFA90E102DC60EC33E542FD859,
	HorizontalOrVerticalLayoutGroup_get_childForceExpandWidth_m07A6B6378938DA69E365DCFB2794EEE7D71CC510,
	HorizontalOrVerticalLayoutGroup_set_childForceExpandWidth_m351827AA1A453ACD17C2EAC7B4DAB9C5DB1760E5,
	HorizontalOrVerticalLayoutGroup_get_childForceExpandHeight_mFCBB20057EDC1E7B2DFD56FB6ABFE9A462560741,
	HorizontalOrVerticalLayoutGroup_set_childForceExpandHeight_mA144CF421614F41813DE346AA9D1C64621C6C2E5,
	HorizontalOrVerticalLayoutGroup_get_childControlWidth_mBA38BDC393C180CFC30DA02478B493D6CCD92AB1,
	HorizontalOrVerticalLayoutGroup_set_childControlWidth_m0B9A78B8284E17C438645684984796AC0E2D1BD8,
	HorizontalOrVerticalLayoutGroup_get_childControlHeight_m867F7E1D52F29ED8F9E5F060089800295E186AA4,
	HorizontalOrVerticalLayoutGroup_set_childControlHeight_m8DD189C9B1F926641F4A2FD41F41F2097E4D7751,
	HorizontalOrVerticalLayoutGroup_get_childScaleWidth_mF5057406C963AB6CB70DC1B2B213A1F5F7C97E91,
	HorizontalOrVerticalLayoutGroup_set_childScaleWidth_m96A12D7E1C6BCDD510EC08FC470FA5F69B90922D,
	HorizontalOrVerticalLayoutGroup_get_childScaleHeight_mA5AD05DFD31E25C5C014C24B5B11DC5492A2E893,
	HorizontalOrVerticalLayoutGroup_set_childScaleHeight_m519A990CF97DE1C974DD1F48466763E4AEC648BC,
	HorizontalOrVerticalLayoutGroup_get_reverseArrangement_m245D8EC788EDA70DCB831FE62DAB8DB806BE7EA3,
	HorizontalOrVerticalLayoutGroup_set_reverseArrangement_m2AF5AC83D6FE8AE364C626C0518B2ECCEE9C0477,
	HorizontalOrVerticalLayoutGroup_CalcAlongAxis_m12CA995AB887ED06762B07E97953D456B316647A,
	HorizontalOrVerticalLayoutGroup_SetChildrenAlongAxis_m4D7B06435A66102659B2372B48D49B2117D57F09,
	HorizontalOrVerticalLayoutGroup_GetChildSizes_mE555CFCDBD0CD9913829BB56457F939A166BA383,
	HorizontalOrVerticalLayoutGroup__ctor_m778C23DD9F3973AFACD3C6CCEDABF81902665D3F,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	LayoutElement_get_ignoreLayout_m32A9F0BACBC8E6BAE46F35E570DF71E937924412,
	LayoutElement_set_ignoreLayout_mF3D4AF6214FD719979E4BA6A120494E7226FF18C,
	LayoutElement_CalculateLayoutInputHorizontal_mD6645A83B5E234C1EA5C764E48CAD4F3C135C4D7,
	LayoutElement_CalculateLayoutInputVertical_m1D25D380F32BD322135C80C41D407BD81C5D88F6,
	LayoutElement_get_minWidth_m6943ECF36A67019A485C4A7AFFC0BF7FD94480CE,
	LayoutElement_set_minWidth_mC140AB11DDA8F8FD299A5A7E3A9674FB21E827E4,
	LayoutElement_get_minHeight_mC1951830B9F43C57AC4A287E9AF3A62A0871E9C3,
	LayoutElement_set_minHeight_m8B794B9E92B440D9B88FEACD95492DC5257D628F,
	LayoutElement_get_preferredWidth_m214B11641CBD652E174F42133EF7CDC413CF6CE0,
	LayoutElement_set_preferredWidth_m9D8F8097227D2EBAC03BB0E2E6B0E0A6C8887BA6,
	LayoutElement_get_preferredHeight_mE630312564CC2A3E459C9C3E5FFDC2138D35EC88,
	LayoutElement_set_preferredHeight_m0F5874AD74B74F2A8F1CE86ED0477FEA9555433F,
	LayoutElement_get_flexibleWidth_m2E51EA4DC58A4740702314E253FCA8816A1B98A8,
	LayoutElement_set_flexibleWidth_m29E6E303E19AE180FD805D6E5481A00FC49E2983,
	LayoutElement_get_flexibleHeight_m8A7B16E85F304CAA03BF6417BE1D0F6C0212E2E4,
	LayoutElement_set_flexibleHeight_m39C426C07583BE074F9B71DA9ECA1216860A43D2,
	LayoutElement_get_layoutPriority_m20D5C7FC2019146C2FFD09CF1A3D908703763510,
	LayoutElement_set_layoutPriority_m8EAEC716134A0536F1E96F8C3AB0980D5416E2BD,
	LayoutElement__ctor_m31C173AFE1B1749B6957B578C9463044BA22624A,
	LayoutElement_OnEnable_mCD4984C5E35B4658AAB3224795209A92DAD65C6B,
	LayoutElement_OnTransformParentChanged_m7495A830D24B032BBCE6FC2F540CDCE8B713C330,
	LayoutElement_OnDisable_m5DBCC5762DB101EA70B19A24F8A41BCDE450AB87,
	LayoutElement_OnDidApplyAnimationProperties_m3D225CF42A2339702431CEB9F43DC769567E1535,
	LayoutElement_OnBeforeTransformParentChanged_mC3BA3EA166CF4AE74B9A00799DE1C2869A9261D6,
	LayoutElement_SetDirty_m9ECC494A5A6C3764AAB0D3E2C61C6050FC517879,
	LayoutGroup_get_padding_m91ABA3C588704717EDC82E72BA6D1B82711FE83C,
	LayoutGroup_set_padding_m9F415F3402E5E4AE684FD153493CE3E8D64D3EB7,
	LayoutGroup_get_childAlignment_m45C0D32DB91FD92852CA50278904034A26ADEFC1,
	LayoutGroup_set_childAlignment_mA97DF1F2CF43C0CD1B83CFE7883626AA86ABB0AF,
	LayoutGroup_get_rectTransform_mE9AD2CFD78229C631BF21260FDB40C2D0D895974,
	LayoutGroup_get_rectChildren_mEB00A4F0B86326AA9BE3D5E5DD7E4C9E3A032391,
	LayoutGroup_CalculateLayoutInputHorizontal_mAB313A3646FC94E9FA98E5C4EA19DBAA7F3754FD,
	NULL,
	LayoutGroup_get_minWidth_m3EFD1527249470CC4F71588466BFB17D4A632229,
	LayoutGroup_get_preferredWidth_mDE70B887487494986C9A5621C9F19488154EE2CA,
	LayoutGroup_get_flexibleWidth_mB4DCC3B208370CF2A2FE276A56D011922BC08609,
	LayoutGroup_get_minHeight_mE2FA1D3B4B40AAD5CD4493087C5B63C7BCAE9B3C,
	LayoutGroup_get_preferredHeight_m055B2270ECB1C9C0FCCCA396FD7E9F8EFBDBDBA8,
	LayoutGroup_get_flexibleHeight_m5F911708AAE2DDEF9ABF8EC7894F2B7A7264EB0A,
	LayoutGroup_get_layoutPriority_mC86CB36BF49A18F09F6577A9B298CB639F1FEC4A,
	NULL,
	NULL,
	LayoutGroup__ctor_m3F10CB94B64D503325A8EE097A94261C08AA2337,
	LayoutGroup_OnEnable_m49EF8F43626DCBD10EB37D7F95BDEF2817DECC72,
	LayoutGroup_OnDisable_mC10A4F2B949F44688E26D0F1499BE39B0655DB42,
	LayoutGroup_OnDidApplyAnimationProperties_m7E426AAB3C937005BF074ABCF5A1C9FB2D67BB95,
	LayoutGroup_GetTotalMinSize_mFBD1A44880D3390EFC7AF2441D556C9FAD49059A,
	LayoutGroup_GetTotalPreferredSize_mEFFC79C79FC70A3BDD06E46C6188827E0F7EABC3,
	LayoutGroup_GetTotalFlexibleSize_m0750BE35A8B466C0CB82460B0A490139B8BE1E2A,
	LayoutGroup_GetStartOffset_m3748EE96F01312488AD6B764B01171AB2F5E309B,
	LayoutGroup_GetAlignmentOnAxis_m14E9D80D22AFAE88909D806F5439BCB9EF194A45,
	LayoutGroup_SetLayoutInputForAxis_m3704D7673470CF7CF1F2B145F226C9C30C25E660,
	LayoutGroup_SetChildAlongAxis_m25F11D4F93E0D31E68F7227D74000FFB067A8FDC,
	LayoutGroup_SetChildAlongAxisWithScale_mDCF850DCCD115F9B2ED8AC9D5D7EF8EA0B42EA94,
	LayoutGroup_SetChildAlongAxis_mBE88585F9D066C2997499871D934C0A4E9AE871F,
	LayoutGroup_SetChildAlongAxisWithScale_mC1910181779269C2656D954DE36F384D19F11C22,
	LayoutGroup_get_isRootLayoutGroup_mFB0EC6A489F3847C38599F1187755B6E04301B04,
	LayoutGroup_OnRectTransformDimensionsChange_m32A8C9D736F6096B93235870A9623D63C2CBCA74,
	LayoutGroup_OnTransformChildrenChanged_mF55AB48380641070CF0F92AC633357266D14A04A,
	NULL,
	LayoutGroup_SetDirty_m32F20D8BB5C4B4DF350AF5F35A5917660FF9CE60,
	LayoutGroup_DelayedSetDirty_m67C0D880E25888F274BE8AE9D3F4C28EA4A22D0C,
	U3CDelayedSetDirtyU3Ed__56__ctor_mF6AE811754CADB1402BABF82639E38DB56C9AFCB,
	U3CDelayedSetDirtyU3Ed__56_System_IDisposable_Dispose_m347957DDD38BB5EFEE268E592550D258E5189F75,
	U3CDelayedSetDirtyU3Ed__56_MoveNext_mE69F0D45357F390412D5833F35A0C4B4F3E47420,
	U3CDelayedSetDirtyU3Ed__56_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m581E5D52D9508F8B755213FC2BFFC15412352F79,
	U3CDelayedSetDirtyU3Ed__56_System_Collections_IEnumerator_Reset_m7C5E44C5235E8C18D0066EF7464A6165F6D4B1C0,
	U3CDelayedSetDirtyU3Ed__56_System_Collections_IEnumerator_get_Current_m83BB521EA7AF720756B95AA6D637557DFCDCA2A3,
	LayoutRebuilder_Initialize_m3186A381CF387FC04A9D52BF6ED9982B0150E562,
	LayoutRebuilder_Clear_m2BCF887531F7BA60FB962F7153564A055A136AA1,
	LayoutRebuilder__cctor_m5AE721B6C2738FA3FD23CF5103CEF96E6AEA578B,
	LayoutRebuilder_ReapplyDrivenProperties_m2FAE70C6B03F93BDF9484BC4674FA80D956BE45F,
	LayoutRebuilder_get_transform_m885E49969AFEF977B384D517212E68ABFDDB6555,
	LayoutRebuilder_IsDestroyed_mEB8D2E6A0E61BD035965F28D30FB5BB41AAB2149,
	LayoutRebuilder_StripDisabledBehavioursFromList_mB6E476924D6DDDA8050F40300A58696303F0753A,
	LayoutRebuilder_ForceRebuildLayoutImmediate_mCCA094579654469919EFA4B5AA5D9AF93CD67B4A,
	LayoutRebuilder_Rebuild_mE0477A991681D208BF504CCAABFE01D7FCD8E137,
	LayoutRebuilder_PerformLayoutControl_mA6EB813FBAC300966A6357D248FAADD947C92D4B,
	LayoutRebuilder_PerformLayoutCalculation_m0733192A11C335EEF72298A2321937CDA97A1C34,
	LayoutRebuilder_MarkLayoutForRebuild_m37F415D59609E9D18D49423D9C33E7EA6D859EBD,
	LayoutRebuilder_ValidController_m28AC31CE8158B1D2D9656A99ACE3F259F5212C70,
	LayoutRebuilder_MarkLayoutRootForRebuild_m72542D06667BE02C021D13ADC4C77094614552FF,
	LayoutRebuilder_LayoutComplete_mB93ADFB170DD29029D271710D946FE0B08665380,
	LayoutRebuilder_GraphicUpdateComplete_m177178144B034919E062EB9C205AB65CB437BC6D,
	LayoutRebuilder_GetHashCode_m408B8FD9884FA8F7F967F1E8C7015055B8F780D3,
	LayoutRebuilder_Equals_mD6E988174B451D9E832E3FC8B1EBBA0DD1FFB92E,
	LayoutRebuilder_ToString_m7F8066428103BE4A1E0A71F45B1D0E725E377A58,
	LayoutRebuilder__ctor_m685B1B7449046E3467525550996AFB6A4565219E,
	U3CU3Ec__cctor_m0D6AD1DB52B49A72650F253F02B465D02C18BE04,
	U3CU3Ec__ctor_mD28F0F8B5399F1C60A8E4575F9DCDC847D2CAA23,
	U3CU3Ec_U3C_cctorU3Eb__5_0_mD2D37BAA0BED9121AC22FDFC48D7CA35BF400E14,
	U3CU3Ec_U3C_cctorU3Eb__5_1_mE8F9670037E944B0EB22487F1640407057B8A290,
	U3CU3Ec_U3CStripDisabledBehavioursFromListU3Eb__10_0_m03CF501571C52837064AFBD196238DB52B64BC5E,
	U3CU3Ec_U3CRebuildU3Eb__12_0_mDB44431ACB66295B4B09C0132E9EF267DB0090F1,
	U3CU3Ec_U3CRebuildU3Eb__12_1_m08B6A90656111D084CCF7AF3B07D50C03B95BF9F,
	U3CU3Ec_U3CRebuildU3Eb__12_2_m516829AF584D4F446B08587F777088C704548C40,
	U3CU3Ec_U3CRebuildU3Eb__12_3_mDEE0C1EB02D33044B945FF479F81E7A3DD85684B,
	LayoutUtility_GetMinSize_mE0421687F579243D5252F065A737268EF736374C,
	LayoutUtility_GetPreferredSize_mCAFD360B8490CD02AF5F99E93E09D8625BD85F52,
	LayoutUtility_GetFlexibleSize_m2D6400EB342AE2E811DAFFF0CD2AA2F8AA5DD655,
	LayoutUtility_GetMinWidth_m920875D5D911EF3FAC615C045D9178630697A0F3,
	LayoutUtility_GetPreferredWidth_mFF51E72881BE14E8C59521A71188E458475D4052,
	LayoutUtility_GetFlexibleWidth_mFE4684C5AC223E1D8E4369AA3460461A3964D9BE,
	LayoutUtility_GetMinHeight_mB428914EB41682FC709CDBB27A0CB42D42EC4D9E,
	LayoutUtility_GetPreferredHeight_m3E8CDE02CC980080BBD4BBA1D6BFDFD42F7CF706,
	LayoutUtility_GetFlexibleHeight_m13C0A91CEB1B4DE827C4B9E5230D4AA73FFC23DC,
	LayoutUtility_GetLayoutProperty_m3A5BD03879B0B223BE78DDD6AB7595BDF14CF7A7,
	LayoutUtility_GetLayoutProperty_mEE37FED419E8D6C3B799296DC6712D312AA5261F,
	U3CU3Ec__cctor_m0CA720C96E971F17E2E861D8AFE6982FD1F59F44,
	U3CU3Ec__ctor_m5E4858F8F2E57AAC48D706CFDE697DB16DE163D3,
	U3CU3Ec_U3CGetMinWidthU3Eb__3_0_mB230985725E48B130593DCE9618576ABD38544E9,
	U3CU3Ec_U3CGetPreferredWidthU3Eb__4_0_mB8A573FB7B4D32CBC78F6AF30C42FDD204D18862,
	U3CU3Ec_U3CGetPreferredWidthU3Eb__4_1_m21A4B6CC6110B2FE507ECD670D1C701BC9E1C9F9,
	U3CU3Ec_U3CGetFlexibleWidthU3Eb__5_0_mDAFF6CD37904716095CE8E674BB7D2586ED17A95,
	U3CU3Ec_U3CGetMinHeightU3Eb__6_0_m92D133D332D83DAECA59B06DD94CE6390C617162,
	U3CU3Ec_U3CGetPreferredHeightU3Eb__7_0_m869A0C6EBD3699CA96970C944D80A94779D58FEA,
	U3CU3Ec_U3CGetPreferredHeightU3Eb__7_1_m6851C73E5D55417BF6A9A29D3DD22EA033D40EEB,
	U3CU3Ec_U3CGetFlexibleHeightU3Eb__8_0_m55A0D46B9D7CD1002AE7F803E496E6F1A98F3E24,
	VerticalLayoutGroup__ctor_m2EF3851AD1D83E3ADBB5053D1FAEF84A773E1D5B,
	VerticalLayoutGroup_CalculateLayoutInputHorizontal_mF9483E90B39BDCE71C90F9B27CBF76F2A10E4D28,
	VerticalLayoutGroup_CalculateLayoutInputVertical_m360446A9D17C1B798BBB0B777EA1BEEE297807BA,
	VerticalLayoutGroup_SetLayoutHorizontal_mD074FE8C9B3187AA23AF6578E8C81B23404D58B2,
	VerticalLayoutGroup_SetLayoutVertical_m27D87A8FEBBBD9226B95F250A076B3AB7BAA155F,
	Mask_get_rectTransform_m4D1933DACBE7B0F93B1B83F1B3B0A09F65B24209,
	Mask_get_showMaskGraphic_m87FD20C72F514AB305E05A5B104B180D9B35601B,
	Mask_set_showMaskGraphic_m9F288D22259CFD781D5A4D9B9747C2A2895E7D67,
	Mask_get_graphic_mDC288968F569C492F1E18F82229ECB7AA3804AD2,
	Mask__ctor_mB4AF8A6FD9496A1E8EEB7631D43F8A0548134DB9,
	Mask_MaskEnabled_m330C9AE8B8A642ECF3C4E88687E9F297969B6351,
	Mask_OnSiblingGraphicEnabledDisabled_m38D50E90213834C6E06D449F364C7A802964FC74,
	Mask_OnEnable_m928342074FD21B3A58E1370F681DC762BD64B095,
	Mask_OnDisable_m7B533EC440BB28CB80AB8AE914BFA501FAB3ADA5,
	Mask_IsRaycastLocationValid_mE12C460DF4AF0C65082DBBA6F46A2259687A2534,
	Mask_GetModifiedMaterial_m5D7DE1884428D7EBC6A7AA6376650E4FB966B1F4,
	MaskableGraphic_get_onCullStateChanged_m8452945E93AF20B975D85E61999B51039CAF6538,
	MaskableGraphic_set_onCullStateChanged_m4284F81D75D8F8293FE2FB5FC236FDF63579BBF7,
	MaskableGraphic_get_maskable_m34B87CD87CFF73FF4E09D892ADB316E412F22660,
	MaskableGraphic_set_maskable_mC2486FDC0636C83AC3BDBFF11E6E85CC27F15689,
	MaskableGraphic_get_isMaskingGraphic_m8C4270841AF6071FD5AC4EB7225AF259053DF55E,
	MaskableGraphic_set_isMaskingGraphic_m350EDFCF390CF594B939BBEE3A0D634F2EA48A78,
	MaskableGraphic_GetModifiedMaterial_mBE4C5B18ED4221E0A6C026C750B6A04E9B35312A,
	MaskableGraphic_Cull_mF6948476960E33BD174FD3723101650E3C344CC7,
	MaskableGraphic_UpdateCull_mAC0798E6376F7B103BB36929AC4DD69729E30E86,
	MaskableGraphic_SetClipRect_m19317C49A4CC99A991A3F0135756DB94020930C2,
	MaskableGraphic_SetClipSoftness_mF11957AB91E1BA19B6008ACEF95C5F9AD930CAE4,
	MaskableGraphic_OnEnable_m4BF46ECE5E57E2EE11ED4CE41AD50DADF141C9BC,
	MaskableGraphic_OnDisable_m9123E729FA7BE001037CDE14E8A75B69AD68E16C,
	MaskableGraphic_OnTransformParentChanged_mE5ABE137F670FBA7E6FCD2A67616E4A8097AD876,
	MaskableGraphic_ParentMaskStateChanged_m1353B87D25271925B6ED342FDC06B05F7EAD3992,
	MaskableGraphic_OnCanvasHierarchyChanged_mB30092A7276A921F711E466E9CE85C04ED982E77,
	MaskableGraphic_get_rootCanvasRect_mB7F5E772A53CBCCF920CD924E84634CD8155F6D8,
	MaskableGraphic_UpdateClipParent_mEFEEC27574B12503C1D8B694BA61C7166828F6A2,
	MaskableGraphic_RecalculateClipping_mFDD980F0A3AC1BEFF0BC9EDE95EF063AA9C282F7,
	MaskableGraphic_RecalculateMasking_m76F4A84B87AD4938F8A68B022A5A2BB4B5F343AF,
	MaskableGraphic__ctor_mD2E256F950AAAE0E2445971361B5C54D2066E4C2,
	MaskableGraphic_UnityEngine_UI_IClippable_get_gameObject_m17FD7D774DA4D9D0F2E23240D9E17FF5C7DC4A44,
	CullStateChangedEvent__ctor_m885AD59B4D0D6075AB6DFA71AD69A7BB48640CE4,
	MaskUtilities_Notify2DMaskStateChanged_mBD5C9FCE2AC1327C599BF0D7390BFD86FAE06937,
	MaskUtilities_NotifyStencilStateChanged_m112CACEF914385BC2F96F4D66D4038AF1E0FCD6B,
	MaskUtilities_FindRootSortOverrideCanvas_mCB7DABA799F6C5BDF659D4CA60BA2FE8141A65AA,
	MaskUtilities_GetStencilDepth_m782D2795F76F569F4FB261C5BFB6D9EF241C0EE9,
	MaskUtilities_IsDescendantOrSelf_mBCC8B1428F599BAF1EAFA16E9586639A11B87C23,
	MaskUtilities_GetRectMaskForClippable_m7AEB8F89DFD994A487EED33DDD8C59E5A784245C,
	MaskUtilities_GetRectMasksForClip_mDEC4D04BA24F5C4C5828A4E8A677BE4F3CC6FAAF,
	MaskUtilities__ctor_m32B6A8721369418CAA95A8EF5D65E0B8CD89DA82,
	NULL,
	Misc_Destroy_mA812AD936D10BCABA81E04C6C4C190034995214F,
	Misc_DestroyImmediate_m7E53D180A6459C9577D115A345D59C26FC05F919,
	MultipleDisplayUtilities_GetRelativeMousePositionForDrag_m3C283E331437CB72CF86C5C98B9E61D2317B8F4A,
	MultipleDisplayUtilities_RelativeMouseAtScaled_mE3B0EE3E697B4316CE8588D05F3A75E47A75A855,
	Navigation_get_mode_m3B574F1549B3806753EC33228EB3FF3031F4E809,
	Navigation_set_mode_m0BEF999F733332AD994CF3CA4AC17B2A47531207,
	Navigation_get_wrapAround_mA24021791B1C67F665065B5A415434837CEA86DD,
	Navigation_set_wrapAround_m9D808EC49EE5F3AFA7F0D13E86FF9F72AA20A081,
	Navigation_get_selectOnUp_mD24FC0BAB97E5DBB28C9C7209BAC2ACC9419B183,
	Navigation_set_selectOnUp_mCB04000FDFC05D3BAC497602E4BA346A536152E5,
	Navigation_get_selectOnDown_m1D36E990CDB38C4BB78745587668F94BBE8A1285,
	Navigation_set_selectOnDown_m0EBBAB8C51107F75F63FFBC3DF88D9010E6A44BB,
	Navigation_get_selectOnLeft_mA4F7DA341D7C660A7E15520B34847B0757C65F81,
	Navigation_set_selectOnLeft_mA4E7480D7CBDA9A5ECA93BAFCD1CF1976A994FCB,
	Navigation_get_selectOnRight_m7A781F4050AE064DC0473E68AA6D07CFFF0A8FF9,
	Navigation_set_selectOnRight_mD0B38024BB628CDC801EA93E9FF7C438ECE2055B,
	Navigation_get_defaultNavigation_m142FA3A8F52EE3DD355FFE30061771FB9A86671E,
	Navigation_Equals_mE25B4E3D0AB85C1469B99971E6AB16E2039E6B4D,
	RawImage__ctor_mB9515043B2286A9012B98913D023EA0ACEF57401,
	RawImage_get_mainTexture_mDA4701244E31799D8897FBB6E0A1FA41EF5B81E9,
	RawImage_get_texture_m84CCFDF78F6886F73EBE5A7C78D6E9C3CA903813,
	RawImage_set_texture_mC016318C95CC17A826D57DD219DBCB6DFD295C02,
	RawImage_get_uvRect_m83D2C4632C6AE437D1DC775904AC2FA8CB83D823,
	RawImage_set_uvRect_m9DF6BBBC6AC46F7F3290A220ED6F076CAB4BC52F,
	RawImage_SetNativeSize_m02ACAE096422EE2D5E17FCF89CC7BBB74A64FD6A,
	RawImage_OnPopulateMesh_mA85FE8B6123F6B3D013E8DEFB9DE3CAAF0C08F6D,
	RawImage_OnDidApplyAnimationProperties_m571F0CB106D9060554503E87FCA700A6B6C997A6,
	RectMask2D_get_padding_m37CA7BF6DA7386AB4D9A6449CAC48ED6BC4B7777,
	RectMask2D_set_padding_m2E8CADD2DC7A40E78586118453CFE2D8795C997A,
	RectMask2D_get_softness_m2638D596B2600278FF2D3225B14038624DA19E34,
	RectMask2D_set_softness_m2857F567959455CA644277BC644A2EE0984089D4,
	RectMask2D_get_Canvas_m689A6760F58FD683B7A5EA6A92691AAA521D4634,
	RectMask2D_get_canvasRect_m81DEFAC3250A9F3FE4B97981335E406B43CFF4F4,
	RectMask2D_get_rectTransform_m6EF34408BB7A5763A590F36D65DE7974E6C996DD,
	RectMask2D__ctor_mC7257CF022267C2E98E8F04CFC28CA37CF8C64FD,
	RectMask2D_OnEnable_m2C52D2F840A9E7462488AB028C21803D3BE14A51,
	RectMask2D_OnDisable_m2CF7F93D68B6ADC28322024E7A9AD4102832F4CC,
	RectMask2D_OnDestroy_m950120AD49BDAFF20E783C22AF863741897015BF,
	RectMask2D_IsRaycastLocationValid_m9ADA1029D511D9A62CFC1B576F396EDD0A31E4FF,
	RectMask2D_get_rootCanvasRect_mC644AE792D28558B8260E23A87C8E6645D33224A,
	RectMask2D_PerformClipping_mD89C9AEAC139EA7AFBB189608D02ABB87F3D7AB0,
	RectMask2D_UpdateClipSoftness_m84A9BCB92DEB1654703D0084C5A3F0BCD2E1BFF2,
	RectMask2D_AddClippable_m90A9698CD91A2A08EBE86AB60B05E76AFA38EAA4,
	RectMask2D_RemoveClippable_m2247DBCAD9B09980191AB791A7CB83FF9C355C2D,
	RectMask2D_OnTransformParentChanged_m593E595A4C1293CEFB17764B55C96E2EC41E4648,
	RectMask2D_OnCanvasHierarchyChanged_m232F0056ED310EAB18C3BA314A666ABF13B4353B,
	Scrollbar_get_handleRect_mEC95A981B744C4DB961D8B5DF6D2B81132CBB238,
	Scrollbar_set_handleRect_m2B621325A0EEA1EDCB71402FCBC7DBEB9C2BD4B0,
	Scrollbar_get_direction_m1950D7EE42DDD0E3DBEABCDD59DD7E0FEC164C4C,
	Scrollbar_set_direction_m1C307CE73857CD7D3FBB160FE66875CA6BA6A3C6,
	Scrollbar__ctor_m65C96C26AB7CBC074ACDC19557E1982155CA30A4,
	Scrollbar_get_value_mC2F43475C89766DA596FFAA019CA59F94CC89A35,
	Scrollbar_set_value_m8F7815DB02D4A69B33B091FC5F674609F070D804,
	Scrollbar_SetValueWithoutNotify_m6E2A4BE4DA16EBA596D2E6E40E4AC2DAC8B6C162,
	Scrollbar_get_size_mD88FDA836274F40EC8A97237C72B7E3C4906DB5F,
	Scrollbar_set_size_m5376982465D6013425FAB0CA8EFC620C3E1458FB,
	Scrollbar_get_numberOfSteps_mC3CEFF66E82BEF0473A82581CA7ACE08AA93B999,
	Scrollbar_set_numberOfSteps_m59EA2D1FDFB3D5E91CC5630254E319605B67E095,
	Scrollbar_get_onValueChanged_m14356CECC1A2BA96576EB73279AF2ECF28B26D6A,
	Scrollbar_set_onValueChanged_m4167C1B411C38C2BCF9967840102723367B35AAF,
	Scrollbar_get_stepSize_m76926AD1E9F264A61B9BF098BC90F1E1335FA7A5,
	Scrollbar_Rebuild_mB6BEE134B0B018A07FD5DE27A353DC4F8834EE85,
	Scrollbar_LayoutComplete_m62E02A6865F74A44F1301CC085D1D4CA4CC90797,
	Scrollbar_GraphicUpdateComplete_mD1DB8FC7C34AC5454CDF41D39483122DA7118876,
	Scrollbar_OnEnable_m80353998984F644C00DFC51861A9ACE4134D2C86,
	Scrollbar_OnDisable_mB78DB94C4093312BBBE28F78FE21B16F8485D2B5,
	Scrollbar_Update_m758EF18E62B3A8D6F319D5CEC9ACDFB005CD1AC3,
	Scrollbar_UpdateCachedReferences_m63BD63A223E31DF89731186F8204993FE707F0AE,
	Scrollbar_Set_m9A15F05D06D200A038C20B1F1C6A4DFA5B17D0A4,
	Scrollbar_OnRectTransformDimensionsChange_m06E846A58CBE1B1006AA3453784789F1A56B8CC6,
	Scrollbar_get_axis_m7C529809A9A4246CAA1F7417AC3418270B7D7ADB,
	Scrollbar_get_reverseValue_mDEEB7F6EC4FD16FD6B1F6806335463FDBC417571,
	Scrollbar_UpdateVisuals_m262B64133E8C98F2B1FF1A075AEACF0F8CBFF72C,
	Scrollbar_UpdateDrag_mD7B02B0A326AF4BB20B66423F3EAEC8FD4BCC787,
	Scrollbar_DoUpdateDrag_mC0C9D56DA7F9AAF3E8941206448DEF1FF2E4BC3E,
	Scrollbar_MayDrag_m19259CC2C45110C1951E59E7E0F8CB207DD69430,
	Scrollbar_OnBeginDrag_m9B628433953BE38D64DB2AE5A3A14A82CDD789CE,
	Scrollbar_OnDrag_m79EAA59922BB2ED61C042ACCCCF9EE14B0990675,
	Scrollbar_OnPointerDown_m8A4C9EDFECF2503F92F57D70C8D71842A3165A27,
	Scrollbar_ClickRepeat_mB3CD100CB06D4687F163B47B1BE806F5519FD8C8,
	Scrollbar_ClickRepeat_m9805A27D61BE928E0A8CC8B6CF6D7DD0A2256830,
	Scrollbar_OnPointerUp_m957C480C8DE9E46E381A800B4B60B07FF12F64B7,
	Scrollbar_OnMove_m17725BD4A3BB30209D66B1938BDF15172F05AD51,
	Scrollbar_FindSelectableOnLeft_m4D775883935EA4A06A67C452C47971BDA90FEFE9,
	Scrollbar_FindSelectableOnRight_mD77EA6CD469357D8E014C5075301A5752A0CA052,
	Scrollbar_FindSelectableOnUp_m44369416317D6AF92FC5CD29CF3B4D4CB44D247D,
	Scrollbar_FindSelectableOnDown_mA0C3C3970272025DE78D382CCDB96721B4EBDD6D,
	Scrollbar_OnInitializePotentialDrag_m7B2840ACB1D2A6D3DA0F03DF9677D2DCF790E065,
	Scrollbar_SetDirection_mA62DC964AA698D058BC84FA1DCAFA46BCA6A8182,
	Scrollbar_UnityEngine_UI_ICanvasElement_get_transform_m402A9522ECD918080DBBE778E8BEF58415E41B44,
	ScrollEvent__ctor_m8875FD9430D9657557F83634E0BDAC8A4C280C10,
	U3CClickRepeatU3Ed__58__ctor_mFE0A3748E0675C23476EE9B999A3DA9A648D07EB,
	U3CClickRepeatU3Ed__58_System_IDisposable_Dispose_mF65B6B047023720C4031343ADBFBA21A23455068,
	U3CClickRepeatU3Ed__58_MoveNext_mB17FA8F05D7A43F4D54188D618BE2C575FC51EFD,
	U3CClickRepeatU3Ed__58_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m72A0A35EF0BD3D37716605AD12258D2CEF3E283B,
	U3CClickRepeatU3Ed__58_System_Collections_IEnumerator_Reset_m5B78E0B6896A6F359FF829520E88FB0EF9E747C0,
	U3CClickRepeatU3Ed__58_System_Collections_IEnumerator_get_Current_m217C077410A6847D0936C68956158E8BE9925873,
	ScrollRect_get_content_m7878BCA28A96B7FBA02DC466A1ED2C9E191C6996,
	ScrollRect_set_content_m01BF6FE0205985CBD16C6D3BB4B6F345B3AF484E,
	ScrollRect_get_horizontal_mDA4358EF29CE64E6B346D6CC5D70E08F00D3D05B,
	ScrollRect_set_horizontal_m99C076AF2B2B596C87435E1465EF0B104281B150,
	ScrollRect_get_vertical_m43F2C650302CB71D53A0A373934CA9F9921CC38B,
	ScrollRect_set_vertical_m972088E788E72690AAE139E7C0F8F634C325E7CE,
	ScrollRect_get_movementType_m0672A0BA382BC5479398DE95C551530FE5B38621,
	ScrollRect_set_movementType_m2A900C10E6C005FD6866EFF1DA2DF78AA957534A,
	ScrollRect_get_elasticity_mF0DE000D57AA94F2A5D9E1C48EC6F6514C1F4565,
	ScrollRect_set_elasticity_mCA1500D31E9A8DE62FA03EA3E1276BFFB7F6094B,
	ScrollRect_get_inertia_m10C8837B3E43787E1FA94C71683D19638FCEFFBF,
	ScrollRect_set_inertia_m8A17589561A5E7A2F5F543B8F2F6149458C68AC2,
	ScrollRect_get_decelerationRate_mDE7178B7D5AEA48B258A328ED352C7A8AF9065AF,
	ScrollRect_set_decelerationRate_m7DB02F71AC6E7C519ADB3FA88F9B46EF187FCD61,
	ScrollRect_get_scrollSensitivity_m36A71A35CCAE99F83DE336A51520BB2657686E4C,
	ScrollRect_set_scrollSensitivity_m07A6D8B94625BC52775BED72633CCBEA41E27E1D,
	ScrollRect_get_viewport_m85092216DD476F77E78F5CE50F9C4E70063ECCF9,
	ScrollRect_set_viewport_m53D91C0869950B18953E163E9A3CE5E7AFB0A262,
	ScrollRect_get_horizontalScrollbar_mDE0EC3FD5C1AC8FDB4D8E8EF4B093A77218DF534,
	ScrollRect_set_horizontalScrollbar_m38777B9083CABE5B05EE674DF59867247613F6CA,
	ScrollRect_get_verticalScrollbar_mCEB62CC858B43CE7FB07D287CAFC1363668E78C6,
	ScrollRect_set_verticalScrollbar_m3A3503567D1ED44E21A452FE51B12691E084426C,
	ScrollRect_get_horizontalScrollbarVisibility_m3BB3586EBE511EEB0946353153D4818D5207A91C,
	ScrollRect_set_horizontalScrollbarVisibility_mA00C9BDAC3704BEEE76986BCD1D2DFB7F2E2D818,
	ScrollRect_get_verticalScrollbarVisibility_m8F8691067DFB8070BDB2A15D40C6E98E858B1E77,
	ScrollRect_set_verticalScrollbarVisibility_m40A791E57B3FD37CEB97D2FD29639C4EC5B49ABF,
	ScrollRect_get_horizontalScrollbarSpacing_mA61BE48D8F60FA41696D3854501BD6931297DFB6,
	ScrollRect_set_horizontalScrollbarSpacing_mF3FDBF169F96C109BCC75EE62AAC265D23E30D63,
	ScrollRect_get_verticalScrollbarSpacing_mB3FB9008708D488CCC4EE2753B4EE74953CBEB7C,
	ScrollRect_set_verticalScrollbarSpacing_m27BECB09BC4EE6BC91EAABEF50657182A637C1E7,
	ScrollRect_get_onValueChanged_mA6AF3832A97E82D31BB8C20BCD6E87A300E56C05,
	ScrollRect_set_onValueChanged_mB3D669EB2351EDDEBEF2D0F85FBE6279BE905288,
	ScrollRect_get_viewRect_m3E97A12D75F8D1CBE409EFD5D550141B0DA326C3,
	ScrollRect_get_velocity_m8F7DDB02F52BFF2503F079C216FC5C89AA4875DC,
	ScrollRect_set_velocity_mBC8D4BC0A0184FCC3AEB359AE68E9130E811AFC2,
	ScrollRect_get_rectTransform_mB34A69B7E6E21FFF066786508974D89B5A6D4E4C,
	ScrollRect__ctor_m71A7660A30496E9D4937AE250FBAB722BF0747C7,
	ScrollRect_Rebuild_mC15C5A090517F09F981F12DFD46BCCAE96FF9660,
	ScrollRect_LayoutComplete_mA3AB518DD92641DF7F01CE8108EBFC4C0424A115,
	ScrollRect_GraphicUpdateComplete_mF50A0A85D39C499126C7305CCCF055360091EE22,
	ScrollRect_UpdateCachedData_m5E25EF1E36AB04D01FEE66C8E0CD30C0E6CCA933,
	ScrollRect_OnEnable_m5A4AE9FF349A1F5C9780F2DC17CEF3304B795AE9,
	ScrollRect_OnDisable_m0C287FAF83174051A941BA2F90F4D0E38B3ECFDC,
	ScrollRect_IsActive_mBACF2D3F35080C325C5D6A54CF86D17C19FF9A70,
	ScrollRect_EnsureLayoutHasRebuilt_mDEA99980960C5429B17B200EFB3B2EB13B01956A,
	ScrollRect_StopMovement_mA278F4EBDE715F61F9D38F88E71E364E82870851,
	ScrollRect_OnScroll_m86BA4041DE7B1B13101BCC01D90752143A5A28F6,
	ScrollRect_OnInitializePotentialDrag_m35BB18E5EB6B50B7CC4B44171433E1493A5F8A10,
	ScrollRect_OnBeginDrag_m6B0948CCD12A89B43E4F2596E3C7220A6D426868,
	ScrollRect_OnEndDrag_m7CB3145874E1930FEBD50874DF31280FC35B480B,
	ScrollRect_OnDrag_m1BA80F29441E3761A294E32C7CCE52C35F1B6E5C,
	ScrollRect_SetContentAnchoredPosition_m4C8EC3F85A2B1011985E7583AFDC15A69FF90ACE,
	ScrollRect_LateUpdate_m7E003F1E2C34057F6B802003E77AABF54526C0EE,
	ScrollRect_UpdatePrevData_m4BF4AF6ACB7DC3E4A3F7DA8F468B784D1320ED8D,
	ScrollRect_UpdateScrollbars_m9D6268FD19434213F7BCE166722A9B36346C755B,
	ScrollRect_get_normalizedPosition_m4B05A9E790891D503C2B65953728278C7FF8CB58,
	ScrollRect_set_normalizedPosition_m8CFC50007450856E3B1FEB9E61A6311FBC0E709E,
	ScrollRect_get_horizontalNormalizedPosition_mC2C3A7F67E27AA7470A81042AD2B0AD0B5F1AF93,
	ScrollRect_set_horizontalNormalizedPosition_m9B268C9AE7891FC73623DC7BE6B9900640C029B6,
	ScrollRect_get_verticalNormalizedPosition_m4FE766F04272C1805FDE2A4B72D80F6190841FA1,
	ScrollRect_set_verticalNormalizedPosition_m4AF461113925E6710BF04F46A49CF1F856F7738C,
	ScrollRect_SetHorizontalNormalizedPosition_m3F43FC307A146E534DC3F73F4DE38386AAC10405,
	ScrollRect_SetVerticalNormalizedPosition_m4E9F3559FA6369389C1B70D3E94AA35AEC7903E5,
	ScrollRect_SetNormalizedPosition_m99C3731F06EEEF281E68D5D448914B1A3C5636FB,
	ScrollRect_RubberDelta_m5A4BE5FAAA0C39B318A422F236C898D1008AE248,
	ScrollRect_OnRectTransformDimensionsChange_mD41D649A067BFD8DC067FC612C04E48518D691BF,
	ScrollRect_get_hScrollingNeeded_m426A4490F146A56FF76349CBBA4B587EDA5F78DB,
	ScrollRect_get_vScrollingNeeded_m96BA5B252797DF209A1784D1DE3C09AAFEFB25B2,
	ScrollRect_CalculateLayoutInputHorizontal_mEC706200EAB973A2333279BA6C2EE7F6DAA884A6,
	ScrollRect_CalculateLayoutInputVertical_mF708C890C569C942921A2ED809FC0294E13CC9A4,
	ScrollRect_get_minWidth_m3824272990612610DDDCA8D35C23EDC0E97A6751,
	ScrollRect_get_preferredWidth_m16914F16D3F8F1102428267D62CCBF5E8B1EF131,
	ScrollRect_get_flexibleWidth_m6C7F8AC0595D6B5179BF02EAFEF3126731B162D6,
	ScrollRect_get_minHeight_m3D973E3759C8D35899E2F62CFA7677834E6050B4,
	ScrollRect_get_preferredHeight_m90993A52773D1214E648E8DC937D89317F6D4F72,
	ScrollRect_get_flexibleHeight_m91767E81456CA1069B6BBEFCD140BE65962C421F,
	ScrollRect_get_layoutPriority_m19C83DF0ACE68769627C6FB8E09F92FDF63E80E9,
	ScrollRect_SetLayoutHorizontal_m26167C6091ECF4AFB6A4747575592C2923CA4EE5,
	ScrollRect_SetLayoutVertical_mAC8DF5F2CEB21C69D993846A3AF307C6217B83C8,
	ScrollRect_UpdateScrollbarVisibility_mC4E22621A76C4FED36EFA5421BA4006DCB4E5140,
	ScrollRect_UpdateOneScrollbarVisibility_mB2A129E7AE74E39D6080389679DFDB99D1A65FD7,
	ScrollRect_UpdateScrollbarLayout_m41BFD2C6E126A96E99A6892EB88249D2F44530D2,
	ScrollRect_UpdateBounds_m71C0450FC4E45F3A60CAEC0D3ABE21702364BA92,
	ScrollRect_AdjustBounds_mF4ADDB84F572E72668E1FA1E699F84A4A89E9F96,
	ScrollRect_GetBounds_m867D453097CBE1F32BF2F9D74F88255542F692A2,
	ScrollRect_InternalGetBounds_m678E51D17A614402FEA0D24741A37EBE45B31817,
	ScrollRect_CalculateOffset_mAFCC1C71DF0F848130BBF11C914E2333B8E5155D,
	ScrollRect_InternalCalculateOffset_m47D8A586D3069AA701718AB516A5F2FECC8AE1C0,
	ScrollRect_SetDirty_mAE263F4AB8A126B60FECCB4A20A6DE1C0A7EB8FE,
	ScrollRect_SetDirtyCaching_m8E5F2F8A20AE671802C2ABA400E9125CF60FF19F,
	ScrollRect_UnityEngine_UI_ICanvasElement_get_transform_m92CB3091979234EDC51D449A75CC22C2F9223AD8,
	ScrollRectEvent__ctor_m1A1148AF5CFAEA289C3F017565F6B1261CDB95AC,
	Selectable_get_allSelectablesArray_m1071647E8ED4DDE7162EE56B3D730468D09454B3,
	Selectable_get_allSelectableCount_m2C8D64447141260C734038679940C8D9DB39A6CA,
	Selectable_get_allSelectables_m0B3507A121322D32AC9E8EE45424F84B3653D8AF,
	Selectable_AllSelectablesNoAlloc_m1583EDE9D566FA98A92F1AFC543519E3A8BE56BC,
	Selectable_get_navigation_mA0E5FC6B1D19C2DCABA5C82EC33C49CF7F17103E,
	Selectable_set_navigation_m706D254813B084B60F07980607D7AE43AC44AFEF,
	Selectable_get_transition_mBDC7F9FCA36E707B6D77E2F33FCEFA344A3E5005,
	Selectable_set_transition_m67F9584736EB6891A314C9804489368C430F0F59,
	Selectable_get_colors_mB53E365D02351D4B64084295C4B2A7AF2DEC4750,
	Selectable_set_colors_m0A49ED3ACD6647B7E5A2DA10B3D417E8FE1BE55A,
	Selectable_get_spriteState_m7388F8F08AB8A03CB56516A7C9713733A737629A,
	Selectable_set_spriteState_mE0E2CDA8757045FE0D35BC4D9E827857F64E19ED,
	Selectable_get_animationTriggers_m58213BBD3E4D5B7C8A25F1DAC51F2B06176A08DA,
	Selectable_set_animationTriggers_m564A90FBE85D0F3A5055AEA255E753EF58C2B1D8,
	Selectable_get_targetGraphic_m659A2940226EC644AAFC2D5CCC326ABEE6384388,
	Selectable_set_targetGraphic_m23DB0DF4E5F2DABD50C662C708B4555162171FB9,
	Selectable_get_interactable_m17DD0484DC62DCB4467109488D7A599BC85EC112,
	Selectable_set_interactable_m8DD581C1AD99B2EFA8B3EE9AF69EDDF26688B492,
	Selectable_get_isPointerInside_mB31AB05760CDC4A72B7E5D7B86061C9829BE5DF0,
	Selectable_set_isPointerInside_mF82515A016E440225E31092AC6CB63EA09D71D4D,
	Selectable_get_isPointerDown_m61C9ECC7F52547B6638CD046CD7FF61A7FA1F778,
	Selectable_set_isPointerDown_m02FB181F4C59A8477243C9971AA17CD77A86A70C,
	Selectable_get_hasSelection_m7F81F2A77E32862AE18BB0459A0732275EFFA11A,
	Selectable_set_hasSelection_m9EBB907C29E5BB0DAB3066EFCC728595B125D235,
	Selectable__ctor_m340EDFEA07F025166175C3ECB1BD2EEDD81C8638,
	Selectable_get_image_m88664022F6BC90E7B8D4BFCBA7FE24B48E90C639,
	Selectable_set_image_mE9DDDBE46C5A435F9788E88EEF0187B5E09A30A8,
	Selectable_get_animator_mE0AB180AF3936F681535220F4344FF3016C96C34,
	Selectable_Awake_m55439376D9E09A622C61C4BD7DA413E1E0EFD469,
	Selectable_OnCanvasGroupChanged_mC30124BB26D8462F8E163F33A57388B443A1BBA0,
	Selectable_IsInteractable_mEF8BE44216120C4200B619E9BEE7ABF608D5246D,
	Selectable_OnDidApplyAnimationProperties_m62471EC7970DF938373D7E63BB1D4DFB74EA7330,
	Selectable_OnEnable_mBE48F9440061AFFCEA53B103F7C7A059AC115FA7,
	Selectable_OnTransformParentChanged_mC802FD6123F88D70845E1FDE93FD38D38315EB27,
	Selectable_OnSetProperty_m9070CBEB5C95931EFC0DA7BCA038461CDF835010,
	Selectable_OnDisable_m293DB718E1101FC77E655E4A2C4F2DE1DBD4663C,
	Selectable_OnApplicationFocus_mE3ADCB53E6FD825F59B51BD0390F0C81AAD8E8F4,
	Selectable_get_currentSelectionState_mD8AC0B7BF3C5AFB574C57BDC81274F621978FABC,
	Selectable_InstantClearState_m8D5BD204B502945CC1AB73A0C45CF8DE199A041B,
	Selectable_DoStateTransition_mE74A03CC2A2DBCA9C07559B168FA6A77FFE57942,
	Selectable_FindSelectable_m332211FC94618A05817C0C62A9C36C60F787179E,
	Selectable_GetPointOnRectEdge_m3E2D149816CB643503988036FEA4E25F914788C2,
	Selectable_Navigate_mF67643CAEFF8AFFB80A1EC743CF6B2C1121556C5,
	Selectable_FindSelectableOnLeft_m1DB05BA9AB4FBED7AAD646526926BCC9BC99E134,
	Selectable_FindSelectableOnRight_m9F76D3B04DD85E9A2C6DC3F1041DE0C9200F307E,
	Selectable_FindSelectableOnUp_m3B25FCB3C7EBEA5A777325A7ECB7985A4B7345CC,
	Selectable_FindSelectableOnDown_mF1715CEA701C504DA775E4A22373881031F851B3,
	Selectable_OnMove_m0801D5433615BD3163659A17B1DB2B23886AF05A,
	Selectable_StartColorTween_m13B3BCF55A09B8C4CD56C25018C93E97F2B51097,
	Selectable_DoSpriteSwap_mDE447BE74A0240AE366AA9C0D9701B2E4689ECD5,
	Selectable_TriggerAnimation_mDA4462FAF2B2DE28945F4AD30E9F8904F4AC4D8E,
	Selectable_IsHighlighted_m889908FCD27411E02267021F8A1B0C72525EF96F,
	Selectable_IsPressed_m2B38EC61FF57A3C4161EDAA8DB4CA5757A3196FA,
	Selectable_EvaluateAndTransitionToSelectionState_mD0648A10DDF70A60B8B707507CC1DBF6A148F9B2,
	Selectable_OnPointerDown_m4425D3C7641AAD2430A7E666F35047E2F3B623D3,
	Selectable_OnPointerUp_mF7B6987EE86DD7079DDA835339A17BCFC6E7A4C9,
	Selectable_OnPointerEnter_m4AEEEAFB92045B8D8794C65890965E9CC8870860,
	Selectable_OnPointerExit_mA288BF802AD6844F51CE19C120DF5CCEBF487929,
	Selectable_OnSelect_m50BA6D8F185CEA3211F9DEFE68AB6439AF685242,
	Selectable_OnDeselect_m43A2F451FC100ACAFA88D67331CD4537994B8262,
	Selectable_Select_mE52B485BB3714E96666F913358BAB9D57588F9A7,
	Selectable__cctor_m6D5E8673B9C3F2CE492ECCF88960CBC03C9D8E51,
	SetPropertyUtility_SetColor_m05C71F5D62DDB2E51E35EDACC0060205B2BA7237,
	NULL,
	NULL,
	Slider_get_fillRect_m35EE2868F52084F9543158A2EAD99476E5C13D9A,
	Slider_set_fillRect_m2CB86D7C94EA17486DACA010B643F9FE308B6AA3,
	Slider_get_handleRect_mF6564572F3D7074E01D17661BD012F5987D328D9,
	Slider_set_handleRect_m572400ADF8F03B8931302F709BB638745CAD5111,
	Slider_get_direction_mEB650B873607C3D4E49EC4AB25EE9CE2554B33D5,
	Slider_set_direction_mD219E6B22DA729C74E1594C8571B926C4A96871D,
	Slider_get_minValue_m4443221B443E357866F07B062CE39944134C794C,
	Slider_set_minValue_mC4D1F7709276A9A418F9284A04799FF767DEDC4F,
	Slider_get_maxValue_mB34C0C9337F5D00ECB2915E8008BCAEB8E7C5FB6,
	Slider_set_maxValue_m43F3BF47C6D7063D80C578FD9B95AD88494203BE,
	Slider_get_wholeNumbers_mF1A52AF2845985E1FC462236783B3E5BE83F9928,
	Slider_set_wholeNumbers_m8A76CC011B30B0281F47F8ED085DDE62EACA0EC5,
	Slider_get_value_m92843A0FEE9FBF1FC5228C7F677E74642D860010,
	Slider_set_value_mA6DC34301E7F76E7FD9C964D61A7B06C95A05D0C,
	Slider_SetValueWithoutNotify_mD60D03926D6D1CBA6F162DE01296B239CF9A03BA,
	Slider_get_normalizedValue_mC839197322275EF1318B6E49B7573FDB30F74D83,
	Slider_set_normalizedValue_mD8E0F3B3EC5CA862BCD1B2AB42DC1CDFCC381A1C,
	Slider_get_onValueChanged_m4DA3FD0F8D7BB838F442C07F7796EEE584D0D4F6,
	Slider_set_onValueChanged_mBFB4D238D7D0B4C686BF47E944A4F873A82939C9,
	Slider_get_stepSize_m55FF421B05B5995454F93AF1D3A5313A6C58977D,
	Slider__ctor_m205FDE3F1A59F98FE8E0E138FA96C107F79BDDB0,
	Slider_Rebuild_mD7FD3AE545912A90D82A84164779FAD30448BDE0,
	Slider_LayoutComplete_mD2E60699C63B82C9164232EA8A2669B5436A2DA5,
	Slider_GraphicUpdateComplete_m2BFE85324EE12F00974D6034CCEBD058911DBC6D,
	Slider_OnEnable_m7B8D2AD29196D07E85830E4D17E01EB7D2151E8A,
	Slider_OnDisable_m3FCB26AAD286DAC967219251AF81A676436A3D39,
	Slider_Update_m522C74C2E16CB8923FFBB2F67A39DC92812A2283,
	Slider_OnDidApplyAnimationProperties_m09393E7CF5C36A5C28AFDF3B767BB8F7B8B75FBC,
	Slider_UpdateCachedReferences_m377F41A1442EBDA6661A3E7E40E92B6D4CD4F5AE,
	Slider_ClampValue_m78647872AACF7C1DADF80CE1355C4FA72E17F91E,
	Slider_Set_m8407F7245321EAA46ED3E5F6CC9B2F04B9A2FDD5,
	Slider_OnRectTransformDimensionsChange_mAD826A7F943BB26DA36F11310D286422ADA5E69A,
	Slider_get_axis_m1EBD05C9A3C34B1859FEA0192B4569AD45EC7DED,
	Slider_get_reverseValue_mE0B463C7174C203F870866456E0EF2AD39D8E834,
	Slider_UpdateVisuals_mF0D5A86EE4352DBFE092CA49479F1AAD9212B00E,
	Slider_UpdateDrag_m704D10BF17D39858193BDD4E946558C520DAB304,
	Slider_MayDrag_mBC1025F6079EF65A36594E8BC2C0647A7F809576,
	Slider_OnPointerDown_m37122B2271F5C26BA2A36ABB70D07B8620A0961F,
	Slider_OnDrag_mC19612CC7EA3D02F3D338ECD6C534B7E402A3856,
	Slider_OnMove_m3FAB8435346C2D8DBA59AB5CC59D569B06CC1500,
	Slider_FindSelectableOnLeft_mB3F6A127C5B758ED1CB9E850FEE3BBE0D4CF3F85,
	Slider_FindSelectableOnRight_m109193687A0ADDDF1BA1AEA2E6B49A1399AF18D4,
	Slider_FindSelectableOnUp_m3523976BA934C07123A7E28CCE8302CAF321115A,
	Slider_FindSelectableOnDown_mC50638D5F0EE1A5D2E9322F0C7F88ED33F6161F1,
	Slider_OnInitializePotentialDrag_m509A0273020AF65D2DA0DB25EC35FDB748F75DC9,
	Slider_SetDirection_m84FCDE9EB319203D0C5C4069A1BFC40447760101,
	Slider_UnityEngine_UI_ICanvasElement_get_transform_mA7875ACE1B6F89DDBF76529E25C1E122F027C33E,
	SliderEvent__ctor_m5FD31BB6BB3FAF583C0A555FCF3733EAD6A6C319,
	SpriteState_get_highlightedSprite_m5D24B628AB2E4DEBF67E094CCA059BDADAB952BB,
	SpriteState_set_highlightedSprite_mEECDB7C62DE0C6A0B2A7D5D7ADF54EB8CDDB20B0,
	SpriteState_get_pressedSprite_m89052B1818D1659DA7E594F218485F1DEB8128BD,
	SpriteState_set_pressedSprite_mD01568B87B1BC1374CCFB5CD190D7CD62A6FDAA3,
	SpriteState_get_selectedSprite_m5316836E91F7EB454E953CADD439FF69AA198BA5,
	SpriteState_set_selectedSprite_m902ACABEC203C0A2408B4ECD7B74C10DFE7BB340,
	SpriteState_get_disabledSprite_m6BE5A2231E20BE1600328082B4EFE53EE7F3E12C,
	SpriteState_set_disabledSprite_m624499C245DC34D314FF0326FE5ADCF35DA28E27,
	SpriteState_Equals_mAF58D9F36662F5A8196071690175AAFCC4506653,
	StencilMaterial_Add_m84AA68A912ABDADC5187B9E9BC0E4FE6DB4E2220,
	StencilMaterial_Add_m4FBC1C2732C3B161EE38767ABE2020105E0BF7F4,
	StencilMaterial_LogWarningWhenNotInBatchmode_mDA6F8CA72D4AAD9C9B480AD2AB4FEFE0C73CD8E3,
	StencilMaterial_Add_m7BF719F0507970D16D11F47019761391ACE55766,
	StencilMaterial_Remove_m828D3D85F213AD5B3E4FE6A230981E9115007412,
	StencilMaterial_ClearAll_mB1977688C5675CB7C32AD21537795223742B7084,
	StencilMaterial__cctor_m18A5D42EF758C1549A3DA3C6871A47042E5E547B,
	MatEntry__ctor_mEB63E7AA0A179AF5EE93EE6DCAC4E91BFAEF2CBA,
	Text__ctor_mE28BC6E42B4715F23401A9379C9681867A0631C1,
	Text_get_cachedTextGenerator_mFC242539F7380F54696D431B126B69DC4EFC821E,
	Text_get_cachedTextGeneratorForLayout_m409B96DB358F900C531F543CE351B02B0974A077,
	Text_get_mainTexture_m8EF8E897193467EF8B839C99B5F388AA3241315D,
	Text_FontTextureChanged_mD716EBECCAFA43F8D01D90FF9F869C69E484A763,
	Text_get_font_mBF98ED39D5C5081AF14A64170EC3391D206CCAFD,
	Text_set_font_mA0D2999281A72029A5BC7294A886C5674F07DC5F,
	Text_get_text_mE71474D219ECCE472FD9A08679168E859577A3D1,
	Text_set_text_m6872BDD62D0904C075F06A19CF5AD96A2B2FE23F,
	Text_get_supportRichText_mE5B61670099BB2611BB60D84ADB72C9A54BAC68B,
	Text_set_supportRichText_mB4DB141150AEBCCADEFFF4EC7A799F85FD075265,
	Text_get_resizeTextForBestFit_mA4EEC57C4C188C1598187D1E11A83B950883B011,
	Text_set_resizeTextForBestFit_m1376BB9FDBAC5571E0F24564E22391AC8EB89A35,
	Text_get_resizeTextMinSize_mAB17F2DA673C7A3860E6EA0746BFC0C919D5A659,
	Text_set_resizeTextMinSize_m1DC5160514ED872A8C572024A94D7EA9D6357655,
	Text_get_resizeTextMaxSize_m7B61DCEEA4D801C4B8149674B27DBE99098A38E3,
	Text_set_resizeTextMaxSize_m25EB2C9302AA9354237A2F56BB3E019192C6015B,
	Text_get_alignment_m01C4D0437DF8A2E05BE4489779A8BEF231A2F2CC,
	Text_set_alignment_m9FAD6C1C270FA28C610AB1E07414FBF96403157A,
	Text_get_alignByGeometry_m68F41E942D6BC7AF8F134B3CCDF039A8D3D49DC3,
	Text_set_alignByGeometry_mB427C41097943370E11579A3DA822A3295836CE2,
	Text_get_fontSize_m837C0618E78D0FDA972D11DDE3015DC888E93993,
	Text_set_fontSize_m426338B0A2CDA58609028FFD471EF5F2C9F364D4,
	Text_get_horizontalOverflow_mC909085F76EF49D62A70A8E503C5BC14C30176F1,
	Text_set_horizontalOverflow_m10AAFBA65FD7F4B1934B5D628B3E70D75D02FFD6,
	Text_get_verticalOverflow_mEC72BD123A8B12278F6F7B89D29EB9D93D0A97FD,
	Text_set_verticalOverflow_m72A544DEAE0EBFCCBDE8174DF4C10C903DA8444F,
	Text_get_lineSpacing_m124405CE023E0E23D9040BAA84318408248DF9CF,
	Text_set_lineSpacing_m36CE565189BAF89DB1DA1E0DE5786521D4763D0E,
	Text_get_fontStyle_m7684B5FFE1DC8237FB573A012B482DDB04E3BA47,
	Text_set_fontStyle_m5ABEF66BFC88E7E0A950E2817E4978FF472F6C1D,
	Text_get_pixelsPerUnit_mC48AE94D40662DE114A72B870DF77BF7B418925E,
	Text_OnEnable_m183EE6D534BE840F16D23DD36A0C1619AFC905F8,
	Text_OnDisable_m94F10EBC54572DCD1D3DB7B6C7CBEC8CBE8AF60E,
	Text_UpdateGeometry_mEAEFCA5F05F983DC984FA1497A905A4B2DCF132F,
	Text_AssignDefaultFont_m475A3C848C9F8ADFBD5438E936E81B618FB4B398,
	Text_AssignDefaultFontIfNecessary_mF5167C211C87E6DD62978C938F6521B287F371CF,
	Text_GetGenerationSettings_m620E0E5AFB30E3331A0371EB2361F587BB0A1E0F,
	Text_GetTextAnchorPivot_mD0734509B028EC6E42800FD73A6CB8476EDF0150,
	Text_OnPopulateMesh_m6505569424B120C338EAF6840893E38530185ECE,
	Text_CalculateLayoutInputHorizontal_m42B464C2F7C1AE5A0B1311FC5E6BECE1C6EEAC5C,
	Text_CalculateLayoutInputVertical_m7A76D597BFFF1C68C3FEA03E26EE440B9A67E532,
	Text_get_minWidth_m8C6D60E991BAABD25859D3C04AAB6107BAD4F139,
	Text_get_preferredWidth_m1624ADC4EB2193885E4EA35D44E6A80C12A436BC,
	Text_get_flexibleWidth_m97C2D396445B82CD45260F21CD15CF6F6B279A4A,
	Text_get_minHeight_mB6B7E5A4426313C18A7F2CD28F3A7B5CE2DAA6F9,
	Text_get_preferredHeight_mF95F444557BFB576AB0E1E876146E03174DA058C,
	Text_get_flexibleHeight_mC82DCE442BB670E3AC683BA1C660810FB4936FC8,
	Text_get_layoutPriority_m99DD053FCD9F30FFCA40937B2DFBF796B67CBD12,
	Toggle_get_group_mE182279EECC97BECAFFA919AA08E4D5B6E9C83FF,
	Toggle_set_group_mEE85FE3AB2ACFF9056DA613239DBACECA588507B,
	Toggle__ctor_mA84E212B567F21B617B480F90BC335B602523400,
	Toggle_Rebuild_m101F36A2CD0C4ABD7BAF41262493A0D6ED0B0D3E,
	Toggle_LayoutComplete_mD0D33BD5078F2E190A61E306A4CF88E45F80C473,
	Toggle_GraphicUpdateComplete_mE1636C76DF59E2B1483BB62FF0982EAAEE1185EA,
	Toggle_OnDestroy_mCC155BA7A5FE311B49536F9C904AC74EC6282E68,
	Toggle_OnEnable_mA9EF315CBA63011213BBB13A9CA1EB84147DAF0D,
	Toggle_OnDisable_mB32FFD1AAE48A56205E782BC041A5EC86B66B536,
	Toggle_OnDidApplyAnimationProperties_m1D3922CE86EA2AFB38F3204935BC15DCD534BFB3,
	Toggle_SetToggleGroup_mDD819C46310559ADC2346EAEE7BE3BEEF51BB1B1,
	Toggle_get_isOn_m89A609E936CD67F460E336CA8E03C4047BFB6619,
	Toggle_set_isOn_m61D6AB073668E87530A9F49D990A3B3631D2061F,
	Toggle_SetIsOnWithoutNotify_mF5B19F1767B9EFF02335E41D3D2DC678642170C2,
	Toggle_Set_mA2CCB1FBC23519004E2F47CA0F53CA6E1B368DDE,
	Toggle_PlayEffect_m728310FF62E7251958CC8D4016C2435AAC9DF0A2,
	Toggle_Start_m3E085820286E51F69BD848C1EA1FCA7DFD07E3E7,
	Toggle_InternalToggle_mD36F2575F4B2E26641C0E24A73B277E0C8BF25A1,
	Toggle_OnPointerClick_m2D0D693EE40BDC56482DA6982C3CB42DBACD98E3,
	Toggle_OnSubmit_mCD303693EDD107D676D55CABA07BA43F9328C9B2,
	Toggle_UnityEngine_UI_ICanvasElement_get_transform_mD7C00596C9A48C3A7C40E285DFFF9C2B255221C2,
	ToggleEvent__ctor_m8983544B67193810F8BAA820B2C408251CBEF145,
	ToggleGroup_get_allowSwitchOff_mA6724BF0B3965330FE892FB9E144D761ACFA7364,
	ToggleGroup_set_allowSwitchOff_m30C71C353E740F9B3F9641689A4ABA4AB8BAC9C3,
	ToggleGroup__ctor_mED87CABB1682380A925DCC8FA41C739ED6ADF3EE,
	ToggleGroup_Start_mA5D0C8F6437723E98C53149716EA28C7984BDDA7,
	ToggleGroup_OnEnable_m5679531D85D1CAC371A71AC5B1E980248A01F038,
	ToggleGroup_ValidateToggleIsInGroup_mA9CAD4C4345BE7AE18351AB4F31D1574A900280C,
	ToggleGroup_NotifyToggleOn_m0676292BE46CBE477DAF139D9DABCE5DB72F7F45,
	ToggleGroup_UnregisterToggle_m6A07803166E901CCDE4F23FCED1BD76CBB002307,
	ToggleGroup_RegisterToggle_mADE82548BE13A13E9FDD00F488471D3416A97214,
	ToggleGroup_EnsureValidState_m5A8B88CF91EEB8F7E7DECB87261EAFF5A556778B,
	ToggleGroup_AnyTogglesOn_mCE714D4DBDD9CF56D41C830719FCFC24008C1700,
	ToggleGroup_ActiveToggles_m04CAF25D2C9DE5F310090D63B9841963954BF2BF,
	ToggleGroup_GetFirstActiveToggle_m07251AA447A7F06B082B685CD44F5C0465A323BA,
	ToggleGroup_SetAllTogglesOff_m770745001C6B4553805F3E333084F5DFCB08B78F,
	U3CU3Ec__cctor_m878A0225FF0D038AD88F4E89CB4DACC057132A26,
	U3CU3Ec__ctor_m71A650578043739A4182051BA48B2792FA8C287F,
	U3CU3Ec_U3CAnyTogglesOnU3Eb__13_0_m060E207CF61E772B8A8C9B5262EA8867E086B397,
	U3CU3Ec_U3CActiveTogglesU3Eb__14_0_m9567251B779C881881B16EB6ADEF9D7E71CD3B0D,
	ReflectionMethodsCache__ctor_m2BBCC7AC457DD7CB3836B01B5307F8B6285CADB3,
	ReflectionMethodsCache_get_Singleton_m77EFD7AC0043333E09987BD601113B810453C42B,
	Raycast3DCallback__ctor_m8F06E2216CD1CCB88B9B94197226CE3F1EC67310,
	Raycast3DCallback_Invoke_m9CDA4EB17B5A46853DEBC894E610B5C8FCE23415,
	Raycast3DCallback_BeginInvoke_m2FED0375CEC6BC3E6545ED6A19E88D7913AB2E6F,
	Raycast3DCallback_EndInvoke_m4DB350E572F75C4D0C92DE38EC9B8B0368464871,
	RaycastAllCallback__ctor_m971EC206409480AB580913F8E1E7E9850DC0DB03,
	RaycastAllCallback_Invoke_mB30319766AF5F0D5145A6C0AFFEA829A31A5D4B7,
	RaycastAllCallback_BeginInvoke_mFD486859C455F0E5198BC58E3505CD12ACDAC0AA,
	RaycastAllCallback_EndInvoke_mBF07366FEF9002D0A44A4E8982BA201699C864CE,
	GetRaycastNonAllocCallback__ctor_mBF3B05A56B530A13FFE0C8F66A12A94230598787,
	GetRaycastNonAllocCallback_Invoke_m36411365E9622819DAB93D0BB0F169FEE99F07D9,
	GetRaycastNonAllocCallback_BeginInvoke_m381F75A2BBE062F5DFB3B910D3B3066CA512D024,
	GetRaycastNonAllocCallback_EndInvoke_m0A8CB6C1DBFAD95A2E3AC7686E161E1D6057F52D,
	Raycast2DCallback__ctor_m4C15F69C429322DFC4BDA9A9E99A500D4C9718BB,
	Raycast2DCallback_Invoke_m36A82ED39B674FC0D8D80D62948B729CC244C366,
	Raycast2DCallback_BeginInvoke_m2135AC8F9004783AB5F6E92DFA11B187CBBC3DE8,
	Raycast2DCallback_EndInvoke_mC51CF38067DEC9BBB94782FF1BB129A19EC602C4,
	GetRayIntersectionAllCallback__ctor_mF6F153CE75C4728D934A766700346C408088ECFF,
	GetRayIntersectionAllCallback_Invoke_m917AA4108EBDC724AFEF39BFD06A586B7461F497,
	GetRayIntersectionAllCallback_BeginInvoke_m9C824E08C6261803AAE7A1B39D7525A4B748679E,
	GetRayIntersectionAllCallback_EndInvoke_mE9CE6394D3F2C7C56DE578882666ADBFFC729965,
	GetRayIntersectionAllNonAllocCallback__ctor_mAF9F997ABE4C3EECD5A402BAB7CB30B19CC50F9C,
	GetRayIntersectionAllNonAllocCallback_Invoke_mFAA36E9AF362DC72204EEF53B28DBFC3367D09A7,
	GetRayIntersectionAllNonAllocCallback_BeginInvoke_mE93D1099CC919A75041D25C692B4BA8FB1F66061,
	GetRayIntersectionAllNonAllocCallback_EndInvoke_m0C4A807380DA32E16F797AF910C2A69C06D1352C,
	VertexHelper__ctor_mE8DE438637116EA7AF8180E10E7641FD00DB64A5,
	VertexHelper__ctor_mE42FAE63F4A3200C38ACFDD9C3F601FDC7E258F8,
	VertexHelper_InitializeListIfRequired_mC7180B010A6DCC7C1115A33D29B8E00B92DB2542,
	VertexHelper_Dispose_mAA41704ED960A368DA8BFB8D1506A3969A033653,
	VertexHelper_Clear_mB19E51AD5AF1C04CB2C6E6A272D032D651EC40F5,
	VertexHelper_get_currentVertCount_m45BFEBD6FCB7DF3BF9F76946D6002BDC58B173A4,
	VertexHelper_get_currentIndexCount_mF409C3D4A6786E64AC4E8EC0D6D97E27597A900C,
	VertexHelper_PopulateUIVertex_m48FF05C38D56529E18A360D629F4842BE5D050BE,
	VertexHelper_SetUIVertex_m539A518867E7872E0893715AD372DC9A06334FD9,
	VertexHelper_FillMesh_m524F00287F0A0C7683E2CC7768A77B5755544A0E,
	VertexHelper_AddVert_mC7596EEC59384AB7BFD12CA6F8350ACDC5BF5E56,
	VertexHelper_AddVert_m5765AC8F13C86709B2EFEC613D492963BE1E1198,
	VertexHelper_AddVert_m2187D76DC2CE7E9AF69280424660739858901287,
	VertexHelper_AddVert_mB65D778E8E3C6916CDFF5382208890882C3031BA,
	VertexHelper_AddTriangle_mBA2504734E550C672A33168BE119D76D92C788A4,
	VertexHelper_AddUIVertexQuad_m6AC21081F2A5A48D22BC3497E527D0A9AB8278B0,
	VertexHelper_AddUIVertexStream_m213E27491ADDA2C603D40730E34F3AA6C5E7757D,
	VertexHelper_AddUIVertexTriangleStream_m29A217271BF2B3D3D60B7CBDA4114C7BB40C2841,
	VertexHelper_GetUIVertexStream_m87D56EB5559CCCA150F68B1DD660FF4154CACBCE,
	VertexHelper__cctor_mEED5FDE0E235482F4F4A551E114358266128E0CC,
	NULL,
	BaseVertexEffect__ctor_m9458015A3EDD3D42F821F8608D0E595B85A70B6C,
	BaseMeshEffect_get_graphic_mE8226BAC46FDB49681BEAD2DE8A4EE3CEC18FF04,
	BaseMeshEffect_OnEnable_m74592558CD0F70DC35EEFCBC1E23F84493CD77F7,
	BaseMeshEffect_OnDisable_mE005F7A15BFE7127D274717C3C482561481D3603,
	BaseMeshEffect_OnDidApplyAnimationProperties_m981407A626B008820D9554F3778DAA8E7959451E,
	BaseMeshEffect_ModifyMesh_mD98C4CF227E0EF63BD031824AABC5F3C1AB7BDEC,
	NULL,
	BaseMeshEffect__ctor_mFFF23FD89B32150DAC512C556A1CCF563D062427,
	NULL,
	NULL,
	NULL,
	Outline__ctor_m1E8EF7C85B52E0DE3D67506C8F7C118A1E2B3552,
	Outline_ModifyMesh_mC6D402BD2D65E27A163B68676F3102AF03BFC4C9,
	PositionAsUV1__ctor_mE24D2DE5032BCAE8B065B8D4CAA90BA3256EB382,
	PositionAsUV1_ModifyMesh_mFE5C4211D991E7A292A29DB85BFBAF3C31282F90,
	Shadow__ctor_mDE7F89B477692F7FF0CCE6B8CE01A63D9942291E,
	Shadow_get_effectColor_m6E7751BB8792C85BE9DAD0D133D787317D9CF59B,
	Shadow_set_effectColor_mCCC5DB6B7D09C5DEE0C677DEB3B9B0C578F05AF1,
	Shadow_get_effectDistance_mA87EB50066AFEBC13C69D27376E50033930FA58F,
	Shadow_set_effectDistance_m5E7B565C41CF2A8C84EC98319ACBF5C8E1FE47DA,
	Shadow_get_useGraphicAlpha_mD2A88F78B7B2E25905D1750788B0DFA3082AC616,
	Shadow_set_useGraphicAlpha_m70CCAE5D643B2373A5ADC8BD04031D3CBF0AF722,
	Shadow_ApplyShadowZeroAlloc_m010AE345D731FC53595A62CF8D0B401C2D6F4B58,
	Shadow_ApplyShadow_mB615BBD368431C63B1407CAFD7DD32BE023E543E,
	Shadow_ModifyMesh_m7201FBFE56F97B440215E92064BFC59F00ACA9C6,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	ColorTween_get_startColor_m9E33FB5C5F76BCF49A3B20201CD8006DBFB46012,
	ColorTween_set_startColor_mD22349343421BD44F0C31E537718ED53BE4850DA,
	ColorTween_get_targetColor_m240A7018BDC3B44AB44BA674AA16C39960BC23FF,
	ColorTween_set_targetColor_m7D8E74B32AC3A9C17C3192096003B12A1500D749,
	ColorTween_get_tweenMode_m06B83FB6E45A807F83FDD762A8241D478FD13F8B,
	ColorTween_set_tweenMode_m105EEB49F6632D6D105C63DA9919385233A5D4DE,
	ColorTween_get_duration_m40D8F08C13FF2FE7583746934C6A017A93398548,
	ColorTween_set_duration_m1C278AB5A90B5C108CEB4870CAC90A9A9EAC19CB,
	ColorTween_get_ignoreTimeScale_mEDB15A4ADE3A0B9487D240964A7571247F974708,
	ColorTween_set_ignoreTimeScale_m060FF3CED06F73EA1F555A37999D61DC58F99927,
	ColorTween_TweenValue_mF5CBA9BDE7F73E47F9CF26DC4EC2419694049860,
	ColorTween_AddOnChangedCallback_mAC2856A154604B4B6721DAC185B819A98D6F7438,
	ColorTween_GetIgnoreTimescale_m679C83012235779A37DCCD0AA75CD6B0DAE5BCFA,
	ColorTween_GetDuration_mC40D6776769FDB79C7ADC42D59F059A2A9AE2F66,
	ColorTween_ValidTarget_m1D7A682CE00048FAF1A3BDD55EB76F44C9122B4D,
	ColorTweenCallback__ctor_mFEB49A6A1ABACFE2351A63060F786B762E2DC6B9,
	FloatTween_get_startValue_mCA121483CCF4C8F10991BB3306E3F2769EBB3A3C,
	FloatTween_set_startValue_m43B55D74B7B34D9C32439D6004F306BFA18E4A1A,
	FloatTween_get_targetValue_m6EFBD9EAB206F145959832269DC24C4B68FEE6B1,
	FloatTween_set_targetValue_m4AE44CE862797E898CDE00A1B7D6A33CE0AFDCFB,
	FloatTween_get_duration_mB1496D38A618FF8282205FD3AA14CA9C6D76454D,
	FloatTween_set_duration_m40E10A7B796B4B54FFB8DA3889B09557BEC98456,
	FloatTween_get_ignoreTimeScale_m6F6BDCBD59C19E68572370F9FE3D7373B4212B3B,
	FloatTween_set_ignoreTimeScale_m09041A4110040F9C86D24E1B4DED6E6B7FB206A8,
	FloatTween_TweenValue_mE51344369BDDA58E9C3AEC62E1B1C1AC0349278E,
	FloatTween_AddOnChangedCallback_m13B1FFCAD78C7E690E70704311B20D5BB67D8224,
	FloatTween_GetIgnoreTimescale_mA2463285D4524B70A46776FC60C4F939B3BCD045,
	FloatTween_GetDuration_m3E981D91F15C36ED6F241117665E703F2BD2A6D4,
	FloatTween_ValidTarget_m36EABC84C8FEFF79EBAC8E9C3C7A394F1377E311,
	FloatTweenCallback__ctor_m3BD06E1999E88B4BAC7627A04B37300331CA210A,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	PanelEventHandler_get_panel_mA34094B6004584B051A7E9554DCF7CE3C18E2642,
	PanelEventHandler_set_panel_m30302AED739E083827B25651029CB2F1563D2988,
	PanelEventHandler_get_selectableGameObject_m327CAA6DDDE5191CF001B5FED18EC8857E6915FC,
	PanelEventHandler_get_eventSystem_m4AC951AFE51C13E82DF39BD27DDD6BE9258535A2,
	PanelEventHandler_OnEnable_m75610BA601D59B6BCB212DB140580859B2C7B777,
	PanelEventHandler_OnDisable_m7174BFEA2A756C36F810433F9D285D9D0B464CE4,
	PanelEventHandler_RegisterCallbacks_mDA52FF8A14161DC03A7B09826079F60AEDBAC565,
	PanelEventHandler_UnregisterCallbacks_m93894C7D3D238507B771066CC0025C98816D309C,
	PanelEventHandler_OnPanelDestroyed_m1E7871C24E171C75D64BA6F6FB8F70EF7B345366,
	PanelEventHandler_OnElementFocus_m5EF528DB20E06FC6EBECE22E71F90B47660041F1,
	PanelEventHandler_OnElementBlur_m7FB60FF1D38D571180F0FB9B740DE531E9F43A24,
	PanelEventHandler_OnSelect_m01E0EBF7AF99013F9D7B0EE96F52CEA3B2C6FB68,
	PanelEventHandler_OnDeselect_m6AF499D5E0F1F162B5BCEA063D4D285E086AF663,
	PanelEventHandler_OnPointerMove_m753962E17CA7F9176FF96F765527BB093ED1F058,
	PanelEventHandler_OnPointerUp_mC03E88905E10E8730E8211810EC98927A3B89F96,
	PanelEventHandler_OnPointerDown_mB46E8626C4F1D143AA495ABAF6B5D57301D3C303,
	PanelEventHandler_OnPointerExit_m2A57890B6822CBB0D51D61FEBA91B32FE269B1B4,
	PanelEventHandler_OnPointerEnter_m0627B36F32B2C7D59783CF07C7781AA66F202C70,
	PanelEventHandler_OnSubmit_m56C7D96593E7DC7B561AE24B741647431C75E84D,
	PanelEventHandler_OnCancel_mAC960731F19FB4522FD960CD51790361A9F26C8A,
	PanelEventHandler_OnMove_m3103CB2983C10B1E721004FDE9EAAF9E8C598DF4,
	PanelEventHandler_OnScroll_mE4812293B72E54A268D49C31845DF17687E68DA4,
	PanelEventHandler_SendEvent_m380CCD38E3E7949B65EE3001067AA9548B19B9F5,
	PanelEventHandler_SendEvent_m8A731185591EB81DC398B72D4C081970A89D421B,
	PanelEventHandler_Update_mB47B3B1C74E2FE6EC56B7A6861D71DACD2FFC733,
	PanelEventHandler_LateUpdate_mF537C32BA3237501B31627DEFCED28C934DDAF14,
	PanelEventHandler_ProcessImguiEvents_mFD6515767C5083020530A3F81371BFC94029A31F,
	PanelEventHandler_ProcessKeyboardEvent_m16DDFA49BD3081FEDA4FB3B22AA6DB78A19086F1,
	PanelEventHandler_ProcessTabEvent_m53F9BFFBF8D1E45FE3CD57EC3815C7130C1363AE,
	PanelEventHandler_SendTabEvent_mA2058FFF2B3B3C64CD86EC20B30A9C753DE4AEA7,
	PanelEventHandler_SendKeyUpEvent_mF261A0CE2897E82529220A72DBE069DE97EC601D,
	PanelEventHandler_SendKeyDownEvent_mB5DA98F3B07ED56ABF2E694744BE6EAE3ED81452,
	PanelEventHandler_ReadPointerData_m655D52851C00124DBA14106CDBE322B7AE2F9372,
	PanelEventHandler__ctor_mF90AF37F849E48687B1A1D3730E952A379A62C5B,
	PointerEvent_get_pointerId_mD4E22379BC076C3D75E103BC55ACFBA81BEF59BE,
	PointerEvent_set_pointerId_m1BFCE40A5AF978254069B94292CADC4B39CB4E6B,
	PointerEvent_get_pointerType_m6AB451260BF46DEFEFF3607498093DE56F8CF537,
	PointerEvent_set_pointerType_m1BD8CE6C878A3FFB6441A60302634515525E1050,
	PointerEvent_get_isPrimary_m5AF6EA62872F5E02DF4E88BCB078CAEDDB0813A6,
	PointerEvent_set_isPrimary_m90DD30E4F4B1641C8F800C4EF04DF078F7F37D2E,
	PointerEvent_get_button_m72275A3B433F9433FAAC939B5776E908CBAC488C,
	PointerEvent_set_button_mBD5A4ADBC9FB28B3D78019091D0279C18AC5F248,
	PointerEvent_get_pressedButtons_m809CC87D0F8B424423079C5DA3E4EFC87E829F02,
	PointerEvent_set_pressedButtons_m0B5199481431978AC07CFEAE090907BA5E70FA68,
	PointerEvent_get_position_m6CAC16F2273B6222BB18583B11B85BE3ECA8BB45,
	PointerEvent_set_position_m24E0958379E88BDD173E563CC00B2523E77EE051,
	PointerEvent_get_localPosition_m06C5B58432C1E806B885F67BA0FB8C90EAD71793,
	PointerEvent_set_localPosition_m759E75018F6729AA6744C93A57907ACEB390727C,
	PointerEvent_get_deltaPosition_m185F5E48BD0879D48BADC520D64DDD68183B83D2,
	PointerEvent_set_deltaPosition_m12E7B298A9EEDC1D623E72EA99758204F16B4A11,
	PointerEvent_get_deltaTime_mD95C5D61E308ACD9D91FD202D274C2DF94780940,
	PointerEvent_set_deltaTime_mEECBC843D749F429B1F72559BB488BE17BBFC3E0,
	PointerEvent_get_clickCount_m1E9AE0EF81D8BC131012E0DEE2C4E169C8B1EE06,
	PointerEvent_set_clickCount_m87C44B61E5E2154178CD4D4CD931C2C463971B89,
	PointerEvent_get_pressure_mA7FA9AFBE607289D1A785889E0E2C8CEB705EDB2,
	PointerEvent_set_pressure_m1D036CF601B6EEB97DBDB8DB75F0923D39303FD9,
	PointerEvent_get_tangentialPressure_m585887790F2A05742888E412B19E0331C4402320,
	PointerEvent_set_tangentialPressure_m7ADB233CDA686FCB10A995F2A6826EE5F54AB36D,
	PointerEvent_get_altitudeAngle_mFDE6773840B002EC90E34041817D96BB8F27A3C4,
	PointerEvent_set_altitudeAngle_m8B963C51BB5DB8A14A943F4B1BEC39B175ABABEB,
	PointerEvent_get_azimuthAngle_mDB91EA27BE4126C4582A66DF75CB8012DE16254B,
	PointerEvent_set_azimuthAngle_m404D73D4BAF6C658A52B29DD2C1D5FBEDC174139,
	PointerEvent_get_twist_mDE5D41083F1E9237B3B852B4E8EA778E2C5D2AE7,
	PointerEvent_set_twist_mCA0ECFFE48E1771A1540212CABB34326C7AD6B5D,
	PointerEvent_get_radius_m2C6907BE1B20DE289E3C166F45FBBCEEAB095F32,
	PointerEvent_set_radius_m387840E4830548F1B1DA865A5A062062D86590EC,
	PointerEvent_get_radiusVariance_mFED4A22BC0C0667DDC74F6046046A5DA315F4CA2,
	PointerEvent_set_radiusVariance_m2627A414E6EFAE8132E2B4FBAC008D830CF0458D,
	PointerEvent_get_modifiers_m31E21D875E7EF1A47DB29878AA76698B0047BD6D,
	PointerEvent_set_modifiers_mB339D7800998DB09F5D8B47B7DDD365897FD61C5,
	PointerEvent_get_shiftKey_mB459C1F6FA17DA9FF904A67473A19A1B22970631,
	PointerEvent_get_ctrlKey_m6EEB9C3A61C998C00946B424121C7BB32CDA6BED,
	PointerEvent_get_commandKey_m750005DB9507733FAEE22D4DE58F28C11FD15DB3,
	PointerEvent_get_altKey_m6306F34C315A6BF2B2B95448657A812817AE2B4E,
	PointerEvent_get_actionKey_mED4C6D96CBEE2F84F52354EFB3540A5759A47CA0,
	PointerEvent_Read_mE5A2B332E857E3264562FF872625FB5ACE2E3248,
	PointerEvent_SetPosition_mBFFE588EBFBDB353A634B4D6D544291073916B88,
	PointerEvent__ctor_mE689E41BEA012A2914C799FECBCE48F7A58FCF73,
	PointerEvent_U3CReadU3Eg__InRangeU7C82_0_mC8BFB779E097CC745E370BFF83CDC1296C0DB045,
	PanelRaycaster_get_panel_m9D8D3E52B0D7A2E4F71B997CC95FB8C808395B85,
	PanelRaycaster_set_panel_m840C66DD38B96603B01E8FAA09C74CA1A67E602C,
	PanelRaycaster_RegisterCallbacks_m840C71BFC5351078CB6BE82C8510F596DC55616D,
	PanelRaycaster_UnregisterCallbacks_mD26ACD360F0C27CFB33A824ADE371742853D66F6,
	PanelRaycaster_OnPanelDestroyed_mF761BC7FD349DB95EBBD8C8D55B404300E5D8AF2,
	PanelRaycaster_get_selectableGameObject_m26B496BDA7A92AD0C66B4209171B56321308A628,
	PanelRaycaster_get_sortOrderPriority_mBFB2EAC6C4F13CAA1E1723216A0B624B7652EA54,
	PanelRaycaster_get_renderOrderPriority_m5E21F65FA1954268DBE3862EB754B20A8B48BE8F,
	PanelRaycaster_Raycast_mFD63FF3E65B14E412D6CD21A3A9455416CE5F895,
	PanelRaycaster_get_eventCamera_m5CDBA1FA81F8BB62020925C81617830897793A2B,
	PanelRaycaster_ConvertFloatBitsToInt_m1B874D1D187BFEE0E217A8D74D21FF4A2F13D717,
	PanelRaycaster__ctor_m1F8C36B6C6A4A92394FFB160E6A084F8FA833F6C,
	AxisEventData_get_moveVector_m7979B5CF62B6B3B0C5F2DA8B328C499ED80ECC41,
	AxisEventData_set_moveVector_mC744F8B3519A6EE5E60482E8FB39641181C62914,
	AxisEventData_get_moveDir_mC8E219BB19708AC67C202C860DF2E6D08C29B8B9,
	AxisEventData_set_moveDir_mD82A8AEB52FEFAC48CA064BB77A381B9A3E1B24B,
	AxisEventData__ctor_mD9AFBD293F84F7032BAC2BDCB47FF5A780418CC5,
	AbstractEventData_Reset_mC3FF13B6FB1012E8FAB00250AE8CD2E1975EF6AC,
	AbstractEventData_Use_m5DBA1B649A757E09ACB14C3632998231C03795B8,
	AbstractEventData_get_used_m0C95B1F392BD74E99F3AD87963647AA060EE5DDF,
	AbstractEventData__ctor_m3D5B26D1C8BC7ACDDF16F505CF7AE273B54584FC,
	BaseEventData__ctor_mE51C4DB618D8661AB2527EC5DE4D563D2284F558,
	BaseEventData_get_currentInputModule_mA46B583FC6DAA697F2DAA91A73D14B3E914AF1A5,
	BaseEventData_get_selectedObject_m0642DE5E08D7CCC49C67D66B296EEE060E357CE1,
	BaseEventData_set_selectedObject_mF3EE53D700B0EA9444D1D7FAF0FB234B4D88A884,
	PointerEventData_get_pointerEnter_m6CE76D5C0C36C4666CDDE348B57885C52D495A4B,
	PointerEventData_set_pointerEnter_m2DA660C24CBDE9B83DF2B2D09D9AF0E94A770D17,
	PointerEventData_get_lastPress_m46720C62503214A44EE947679A8BA307BC2AEEDC,
	PointerEventData_set_lastPress_m0B9EDFBA95B410FBD8CA2A82306ED3EA6696AE64,
	PointerEventData_get_rawPointerPress_m8B7A6235A116E26EDDBBDB24473BE0F9634C7B71,
	PointerEventData_set_rawPointerPress_mEEC4E3C7CD00F1DDCD3DA98DA5837E71BB8455E3,
	PointerEventData_get_pointerDrag_m36BF08A32216845A8095C5F74DFE6C9959A11E96,
	PointerEventData_set_pointerDrag_m0E8D72362B07962843671C39ADC8F4D5E4915010,
	PointerEventData_get_pointerClick_m2AFE23543BC381EC734E85ADB16DD63BA2017FEB,
	PointerEventData_set_pointerClick_m8FA5D91C9556A722BAE8ADBBB5353C79854D74C0,
	PointerEventData_get_pointerCurrentRaycast_m1C6B7D707CEE9C6574DD443289D90102EDC7A2C4,
	PointerEventData_set_pointerCurrentRaycast_m52E1E9E89BACACFA6E8F105191654C7E24A98667,
	PointerEventData_get_pointerPressRaycast_mEB1B974F5543F78162984E2924EF908E18CE3B5D,
	PointerEventData_set_pointerPressRaycast_m55CA127474B4CBCA795A9C872B7630AAF766F852,
	PointerEventData_get_eligibleForClick_m4B01A1640C694FD7421BDFB19CF763BC85672C8E,
	PointerEventData_set_eligibleForClick_m360125CB3E348F3CF64C39F163467A842E479C21,
	PointerEventData_get_pointerId_m81DDB468147FE75C1474C9C6C35753BB53A21275,
	PointerEventData_set_pointerId_m5B5FF54AB1DE7BD4454022A7C0535C618049BD9B,
	PointerEventData_get_position_m5BE71C28EB72EFB8435749E4E6E839213AEF458C,
	PointerEventData_set_position_m66E8DFE693F550372E6B085C6E2F887FDB092FAA,
	PointerEventData_get_delta_m7DC87C01EAE1D10282C37842ED215FDBFE2C1C5B,
	PointerEventData_set_delta_mD200AF7CCAEAD92D947091902AF864CB4ACE0F1D,
	PointerEventData_get_pressPosition_m8A6788DA6BF81481E4EBCBA2ED1838F786EBAE63,
	PointerEventData_set_pressPosition_m85544FBAB798DABE70067508294A6C4841A95379,
	PointerEventData_get_worldPosition_m296F53ACF7665D00DE12A18E1A91E3FFDEB42101,
	PointerEventData_set_worldPosition_m917BBBF297B2D89BB6836985D466A93B863899FA,
	PointerEventData_get_worldNormal_m5C5939C06E4AAC48C134A59A9C8F03A6D6CD8884,
	PointerEventData_set_worldNormal_mA342C6737631C9C902EFDF1F816AF5C6BE6B0EC7,
	PointerEventData_get_clickTime_m5ABE0298E8CEF28B6BD7E750E940756CD78AB96E,
	PointerEventData_set_clickTime_m93D27EB35F490AC9100369A23002F09148F85996,
	PointerEventData_get_clickCount_m3977011C09DB9F904B1AAC3708B821B8D6AC0F9F,
	PointerEventData_set_clickCount_m0A87C2C367987492F310786DC9C3DF1616EA4D49,
	PointerEventData_get_scrollDelta_m38C419C3E84811D17D1A42973AF7B3A457B316EA,
	PointerEventData_set_scrollDelta_m58007CAE9A9B333B82C36B9E5431FBD926CB556C,
	PointerEventData_get_useDragThreshold_m3ED1F39E71630C9AB1F340C92F8FA39AA489E1C5,
	PointerEventData_set_useDragThreshold_m63FE2034E4B240F1A0A902B1EB893B3DBA2D848B,
	PointerEventData_get_dragging_mE0AD837F228E3830D4A74657AD3D47F53F6C87E9,
	PointerEventData_set_dragging_m43982B3F95F05986F40A736914CFBC45D2A9BB8E,
	PointerEventData_get_button_mA8CBDAF2E16927E6952BC60040D56630BCC95B0B,
	PointerEventData_set_button_m77DA0291BA43CB813FE83752D826AF3982C81601,
	PointerEventData_get_pressure_m0745482FB0BD942F9615009C647765E3000F12C3,
	PointerEventData_set_pressure_m4471D0EEC22789490EA12FE6521A620CF60A37CA,
	PointerEventData_get_tangentialPressure_m76ED73E8545F01660D6196DCEBAA6C63DDDE374C,
	PointerEventData_set_tangentialPressure_m66792087B044033F0FF0FA4B2BA316233755EEF4,
	PointerEventData_get_altitudeAngle_m3D72F9EF9FF2238B1FE2E6B5870F8B0DD14B90FE,
	PointerEventData_set_altitudeAngle_m20F2AF2ADB0A20BF20C4B9A6AFE2566A0F4C8BD1,
	PointerEventData_get_azimuthAngle_mBFF5F23355EEAB911D8FF55965CCFF9CB3DD3F42,
	PointerEventData_set_azimuthAngle_mBE64BAD91A9A47E9D9163E25E9E0D1E677B0FC1B,
	PointerEventData_get_twist_m15A76D34614115A290B8FA90799752FBE00580B7,
	PointerEventData_set_twist_mE49469F4F730BA43906F2167E7ADDB9CB2F946E4,
	PointerEventData_get_radius_mA89C671E5F8CA0D0684113CF05E7FAF2961BF7D0,
	PointerEventData_set_radius_mB2F29A6E8A14D1DE1162ECAB3398B539FEF83ABE,
	PointerEventData_get_radiusVariance_m5A3BC7FD6B455570A6535911E0F72F88B0F598BB,
	PointerEventData_set_radiusVariance_m62367BD7EE689AFF5BB5394D984E4AF026A2D15E,
	PointerEventData_get_fullyExited_m8A648782FBCC4F948B2D6DEC3B35AFF59A7C794C,
	PointerEventData_set_fullyExited_mDC23BED1E8A933E25E955A25109494A5D9F25C74,
	PointerEventData_get_reentered_m8B88B2F3A8C9FBBE878B458560F5BFF2D7DD142B,
	PointerEventData_set_reentered_mE363C3D307806C3FF87DF730C14E82AF68A96D8A,
	PointerEventData__ctor_m63837790B68893F0022CCEFEF26ADD55A975F71C,
	PointerEventData_IsPointerMoving_m281B3698E618D116F3D1E7473BADFAE5B67C834E,
	PointerEventData_IsScrolling_mFB78E050A248CDF5221482334808B82500D0A564,
	PointerEventData_get_enterEventCamera_m2EBF9CB2E5C1B169F6B6BB066C9CF5B99A7476CF,
	PointerEventData_get_pressEventCamera_m8D6A377D5CA730307D9F8ABB8656FFB8FCD56AE3,
	PointerEventData_get_pointerPress_mEE815DDB67E40AA587090BCCE0E3CABA6405C50A,
	PointerEventData_set_pointerPress_m51241AAA6E5F87ADEBBB8DB7D4452CE45200BEE8,
	PointerEventData_ToString_m49B5681669B6866A981884B774BC48E87D64B48D,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	EventSystem_get_current_mC87C69FB418563DC2A571A10E2F9DB59A6785016,
	EventSystem_set_current_mCAAA4D0C90542AF31D363CC4ACE4D615D5D28233,
	EventSystem_get_sendNavigationEvents_m8BA21E58E633B2C5B477E49DAABAD3C97A8158AF,
	EventSystem_set_sendNavigationEvents_m9309FBEDCBAA85162A202AADF3FDBB7A47D52D30,
	EventSystem_get_pixelDragThreshold_m2F7B0D1B5ACC63EB507FD7CCFE74F2B2804FF2E3,
	EventSystem_set_pixelDragThreshold_m2D2A087B9A9992D7B624CDB98A6E30BE9D10EF63,
	EventSystem_get_currentInputModule_m30559FCECCCE1AAD97D801968B8BD1C483FBF7AC,
	EventSystem_get_firstSelectedGameObject_m15FB056EE7A99D8DD5891D40A6E3EF18719F0553,
	EventSystem_set_firstSelectedGameObject_m626D151EC4AC93DE63E18689FDC13A03DCFB5AAE,
	EventSystem_get_currentSelectedGameObject_mD606FFACF3E72755298A523CBB709535CF08C98A,
	EventSystem_get_lastSelectedGameObject_m494BAB623DA90318F7B37C2FFEAD1D8E17FBE735,
	EventSystem_get_isFocused_mB0BB5BE03F7203A06D2F351ACD28BA177079104A,
	EventSystem__ctor_mEEF6F5A0BCA90CC9AD827AA3F2522783B71C6E50,
	EventSystem_UpdateModules_m2D91F02D546D50094DDB25BF0228A987E2EAFF91,
	EventSystem_get_alreadySelecting_m3DB9F620A5E2976EBF1362F95C05C12031BACCC4,
	EventSystem_SetSelectedGameObject_m9675415B7B3FE13B35E2CCB220F0C8AF04ECA173,
	EventSystem_get_baseEventDataCache_mF9AFC01C9D2B055F0816F6EEA2CC0011F1D82B7F,
	EventSystem_SetSelectedGameObject_m91382EAC4D552C672CC07BE7EB1481F156045280,
	EventSystem_RaycastComparer_mBF2582FBEDA9A1B604EE4281C61CB5E3DF676795,
	EventSystem_RaycastAll_mE93CC75909438D20D17A0EF98348A064FBFEA528,
	EventSystem_IsPointerOverGameObject_mC89BFEA46B0DA67F914B9B90356E63BFBE11EB38,
	EventSystem_IsPointerOverGameObject_m238732B4FDEA343976D798FF04DB34C3221243C2,
	EventSystem_get_isUIToolkitActiveEventSystem_m6FF1DA7E38D73742C5AEBF93C611723B9CC93FDE,
	EventSystem_get_sendUIToolkitEvents_m7E11CCC27DFE797BC4DFAEAE2D1C94BF845B08C9,
	EventSystem_get_createUIToolkitPanelGameObjectsOnStart_mD617E1B0EA52D750421DE03A8F131CF2F5831712,
	EventSystem_SetUITookitEventSystemOverride_m31B7776BD35EFB75371E2B860CF6E34FCDCD6A59,
	EventSystem_CreateUIToolkitPanelGameObject_mFE582264FE41E29CA6BBCCA384E1B238671D3B4B,
	EventSystem_Start_m392BF40F247855AA4D87C74F2CB5F9AC175F5556,
	EventSystem_OnDestroy_m2DDC6C240ED981710CB6D91F143A9FF6A3230D14,
	EventSystem_OnEnable_m4A1E4BD3E26E6DD1150AF17B8A4E14DA9FDA2D9C,
	EventSystem_OnDisable_m7667186DBAD79874E4B7CE04A5F0291C35FBE240,
	EventSystem_TickModules_mD3F159C0C33396BEB5789B633065005DE771028C,
	EventSystem_OnApplicationFocus_m85C0A5CBBCEC8D900365BDD4F3E3188ED0EE8DC9,
	EventSystem_Update_m9D0AC1A7236F0DA1CCA0A8FFE0D8D33D960D433C,
	EventSystem_ChangeEventModule_m18F27ADCD2CF6656D771CB0413B7B4D768D38181,
	EventSystem_ToString_m0C3906BF8A1C2D7BCC31B09224890BC89B2AF35B,
	EventSystem__cctor_mE933C88969E443D3DEE106C6E747F97F40D3B48F,
	U3CU3Ec__DisplayClass52_0__ctor_m92802E6FD95BD7427E6265625035CAF19A8B061B,
	U3CU3Ec__DisplayClass52_0_U3CCreateUIToolkitPanelGameObjectU3Eb__0_mF55A93A2665521B4BB521A1FABDC7B98D7F05999,
	EventTrigger_get_delegates_m0EF6EB8D0AB4964C9AB563D74387B1D5366B9004,
	EventTrigger_set_delegates_m47AE262A9A8E4F2F2824F2C877597DC4CE2A979A,
	EventTrigger__ctor_m2A471D4099280D37183A1B668FF092B9517BA294,
	EventTrigger_get_triggers_m2361511923086BCD40339097448A70AFB22C4647,
	EventTrigger_set_triggers_m5F861F79BBA48C26CFB83BEA7E25580B21BDA815,
	EventTrigger_Execute_m8F637065284AB93B0D2C1090C63830AFD9CE25BE,
	EventTrigger_OnPointerEnter_m78A0620B719E345A02F2A628EBC1D08ADAA5FD89,
	EventTrigger_OnPointerExit_mF15D24467BCC9686CD9DC11C728632F7ED098BF4,
	EventTrigger_OnDrag_mD4E2457101987E2E96C251EDBBAD8960BED20874,
	EventTrigger_OnDrop_mF111804E0134C1C873156D4B22E8479CDDEC0C1B,
	EventTrigger_OnPointerDown_m91957FC65D1AE1C5FD6B0548682DEE1B4283ECC0,
	EventTrigger_OnPointerUp_m63A37DEC73942B6C5863F79DED7A2BCDEF8B8DB6,
	EventTrigger_OnPointerClick_m6006A8F9138007DF16AEA63968E865D8A2AF128E,
	EventTrigger_OnSelect_m191AD9E9C686FABEEF036AAC0D89F27D7BACC8E4,
	EventTrigger_OnDeselect_m647B65049C6C332711233F0B2F72C99E4AE2DE46,
	EventTrigger_OnScroll_m45ED61FD7F6FAD70C71502A38D2479DEE50B1370,
	EventTrigger_OnMove_mEE11502B46693D5F5C8E23380E0DF0D4B75EE9CF,
	EventTrigger_OnUpdateSelected_mF5C79E9494D1F1F3D032FFB17B1D5B3701FB5BD7,
	EventTrigger_OnInitializePotentialDrag_mF57EC5149D92811696046CACFA2CD4422890AE78,
	EventTrigger_OnBeginDrag_m370891394066DA8891BFA458D335A4B878988E7B,
	EventTrigger_OnEndDrag_mFC87A35C4060855401A4C0C28612829D0894A8A8,
	EventTrigger_OnSubmit_m2EC7EAB0AAD5AD0528511C8184A430FD91E95E0D,
	EventTrigger_OnCancel_m17724FAA28975B06DDDE55D06716DE33A1788144,
	TriggerEvent__ctor_mBC60D36344FFB96FBE826D229CE25D4C25E08440,
	Entry__ctor_m7325965EB4BD264BE16F837B6AA2693ECEDBB5E8,
	NULL,
	ExecuteEvents_Execute_m316D0EE5A1936BFFD9999F4C145722DC6C121FF7,
	ExecuteEvents_Execute_m554281680E2DBC534055073ECCE46230E488A3E6,
	ExecuteEvents_Execute_m3DD6C7687A440E55EEF8B7D115DEF950728295B6,
	ExecuteEvents_Execute_m36FF8B992CDB75A825077B7A52AA7BE72318B37F,
	ExecuteEvents_Execute_mD0811E5B0A4F7D5A88E7ACF0A845CA107485F579,
	ExecuteEvents_Execute_m512ACDD06180A73819570FED3C2BEE0F0E2DA3F2,
	ExecuteEvents_Execute_mCD88FE48772FC6DA5E9FE9CAF910402F63090C35,
	ExecuteEvents_Execute_m3F3FEE80AD62CF4207EDA55D6998B98DFF8FFB64,
	ExecuteEvents_Execute_mBEB42D218E11F4B9834CAC70894631C305E6AF18,
	ExecuteEvents_Execute_m1A35D0185316601E2CE063420F4953C8D3D62D3A,
	ExecuteEvents_Execute_m6DD01624C34CF22057ECF1B0C7E561006DA6D2F3,
	ExecuteEvents_Execute_m08AB6D464ED66E7D539C957D84076F79D8ED5563,
	ExecuteEvents_Execute_mF1F3202132B706B56AE43B19577758BCA4EAEB88,
	ExecuteEvents_Execute_mBDDBAF4DEB956C013CD19E514088B6AC086783B2,
	ExecuteEvents_Execute_m070554B8CD391A49E8A51A4FC10C8CB8827E5627,
	ExecuteEvents_Execute_mBC94A654B65C6B14834E3CD0FF0472DB5445E2F2,
	ExecuteEvents_Execute_m6CE7DBF76F4858C3014295BB2EBBAD768EF5992E,
	ExecuteEvents_Execute_m30F76D861B01F5DE4671B93C23B57989889EC8AC,
	ExecuteEvents_get_pointerMoveHandler_m996E37A7026F03F8791EFBB69B72DE1FC4FA3A60,
	ExecuteEvents_get_pointerEnterHandler_m9F921E3357CE38A925DF20E9CD94B4C3AEE9AE48,
	ExecuteEvents_get_pointerExitHandler_m03735363884BC967C1B04246B51FE98886C9C6DE,
	ExecuteEvents_get_pointerDownHandler_mA67CE33D32540939A273DB88D6456C7FE43C13EF,
	ExecuteEvents_get_pointerUpHandler_m51B83B4AD7498D6F7A2CBD5F2331E91A37AE4CF2,
	ExecuteEvents_get_pointerClickHandler_m0017F9D1EAF7C02CDDB4C148C92D6685D88EA8D5,
	ExecuteEvents_get_initializePotentialDrag_m16F4CD40448FB1B78F6683AA26A9CC574F48AFBD,
	ExecuteEvents_get_beginDragHandler_mB0BEAC09E4A8F31438B07FE68A5BF7267FF8C2FC,
	ExecuteEvents_get_dragHandler_m9193926B9685C80C0560C2E105FF6150C4EAE507,
	ExecuteEvents_get_endDragHandler_mE78FEEEAE114635E416FF1FE33C851E62B60555B,
	ExecuteEvents_get_dropHandler_m8E00FA7361DE68780ACEB365E6B14206A2180D03,
	ExecuteEvents_get_scrollHandler_m51E902070611D3F81AD5F1F5762AE2C48E84AFE2,
	ExecuteEvents_get_updateSelectedHandler_m8AF7543437082AD4F5690AAA77F2623AE28C3D09,
	ExecuteEvents_get_selectHandler_mCF588328D11715E24BC54DF464EF4F3D694B3939,
	ExecuteEvents_get_deselectHandler_m9CDD5F8B5269067CA38247DDD41B521A8FCEDFEF,
	ExecuteEvents_get_moveHandler_mF717824AB0018BBED3C2DF3C67486E3B2B3836D2,
	ExecuteEvents_get_submitHandler_mDCAAA40F0F6AEA385B375C1839B4DC37E5FC4A7A,
	ExecuteEvents_get_cancelHandler_mBCDFD10C95FC2BBC5DC5A512FEA1BBEECC2DAE12,
	ExecuteEvents_GetEventChain_m4FAD69B97B2D0AADFCA3AE06CA80E680B60632ED,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	ExecuteEvents__cctor_mFF9D727E7E8EEEE34D6861D20720411F1CACE9C5,
	NULL,
	NULL,
	NULL,
	NULL,
	BaseInput_get_compositionString_m2F5F37C4A3E1CBFB779113D038802AC2BA3E556E,
	BaseInput_get_imeCompositionMode_m61F7F9CF12191DE6328F900458CB1886AEDA2B08,
	BaseInput_set_imeCompositionMode_m10C9A03CA5BE2DD16C356603A1D03EE197B29085,
	BaseInput_get_compositionCursorPos_m40F062B6C5FB3667DE689AA06AA0CA5DD52DBF7C,
	BaseInput_set_compositionCursorPos_m186F1B453469AC2FEE13F9B2144B1A59D4D7519E,
	BaseInput_get_mousePresent_mCB00324CF55402907B52C63213CF397E53D03E71,
	BaseInput_GetMouseButtonDown_m6276D605B7C48000F3D61BF56BE9E3B5F86398AF,
	BaseInput_GetMouseButtonUp_mBB470F97111BB7BCC1B543CD282F898C9033DAE4,
	BaseInput_GetMouseButton_mD6EAA726BE691C40052FEDBFF51AEAA1DACAAB57,
	BaseInput_get_mousePosition_mD75C96534C8B4EFF48A732F4826E6C9E09CB4540,
	BaseInput_get_mouseScrollDelta_mD764FCD7B05C6505AAB3161C3011A5EA51DEDC39,
	BaseInput_get_touchSupported_mA46B82A5BCB1A1BE47FB15BD4ACD522694DBDC1C,
	BaseInput_get_touchCount_mCD103B50B46B7938389AE38F81C34F173B9F94FD,
	BaseInput_GetTouch_m1FA092A2BD2276B8F94A3058B3D8A9E301DDCBE6,
	BaseInput_GetAxisRaw_m817F925099FC5D22086D616249C0CB5C7F21445B,
	BaseInput_GetButtonDown_m3B34561DB7A1E129F880B1E09CE8B844B1FF6FBC,
	BaseInput__ctor_m7E497239A0A78CCAC04BE6EE9AA81D49D887787C,
	BaseInputModule_get_sendPointerHoverToParent_m3C22EF19BA6E95672ACD15F7E3FCD11277EBBF47,
	BaseInputModule_set_sendPointerHoverToParent_m1E97FE3C9AEECB53AFAB89429D6ABCFE7A9F1882,
	BaseInputModule_get_input_mCB3F78528AA14A7AD7E957870DBB0152B4BF13FB,
	BaseInputModule_get_inputOverride_m92D66E309898C180BF887F6043CCE7AE63C6C44C,
	BaseInputModule_set_inputOverride_m876BAC421A4BC40FB5873FC386E361C4CFA53987,
	BaseInputModule_get_eventSystem_m341B2378F61A58D5432906B9EE1E12265E2FAB33,
	BaseInputModule_OnEnable_m2F440F226F94D4D79905CD403F08C3AEEE99D965,
	BaseInputModule_OnDisable_m370643AD83FFAD10B9E67301355F63B4FF7FB389,
	NULL,
	BaseInputModule_FindFirstRaycast_mE07BDA14A7C9A8E3DFBFDAF449E5896597C9F6F5,
	BaseInputModule_DetermineMoveDirection_m8C99256812C74890B4F54BBCA5BE424A7D608E15,
	BaseInputModule_DetermineMoveDirection_m6461EE20A0418E30EFA13CD293A2B0E7A95DBA54,
	BaseInputModule_FindCommonRoot_mBCC0541CA6E2BCFF051B90FE34F4F00C28CDFA10,
	BaseInputModule_HandlePointerExitAndEnter_m0815F06EAF8F937916E0656D66A69844CB211298,
	BaseInputModule_GetAxisEventData_m99FD46006BB2D8FD6D1E10F606886FE017955293,
	BaseInputModule_GetBaseEventData_mF750E3A63EC1080B933A2FA2CC21D683A68ED433,
	BaseInputModule_IsPointerOverGameObject_m1406F19FE6A3CAEECB2238427345E4CA32E1AD6F,
	BaseInputModule_ShouldActivateModule_m51B70F9097EF7FEB20B62D4D775F7FEA853185A1,
	BaseInputModule_DeactivateModule_mAE698307DADBE4DE8A26BD3DE5F3F7E3D75B385D,
	BaseInputModule_ActivateModule_m2C693E95727E13FDF06D54FA8762A040175AC3BA,
	BaseInputModule_UpdateModule_m201C2C266D80D7451D42E929A90EFC8C4B7358BE,
	BaseInputModule_IsModuleSupported_m60644A4C84A8B0FA66E204E20D149A0BCFAD27A2,
	BaseInputModule_ConvertUIToolkitPointerId_m067C6EDDF29815FE295111E95A38F66860D1E441,
	BaseInputModule__ctor_m88DDBBE7BC4BB7170F5F8F00A0C9E2EC6328B819,
	PointerInputModule_GetPointerData_m8D1C52EE44136560312932072786A2B5AA2C8BE5,
	PointerInputModule_RemovePointerData_m012713A1B4511855549793D6BA2B7998134B1BE9,
	PointerInputModule_GetTouchPointerEventData_m55EBA8BD04214AAD8E98B9109D44610496A5B2E1,
	PointerInputModule_CopyFromTo_m4302FE47F12B3B8C59A3790BD0ADF2BFAAEA9BFD,
	PointerInputModule_StateForMouseButton_mED5B48F98F706160F97A26511FB82BD84DBAB0CF,
	PointerInputModule_GetMousePointerEventData_m77052AB014196BA4E66C8BBE27EC9AF739031EFE,
	PointerInputModule_GetMousePointerEventData_m8D8111399CF7077AEBE4836AC701DDDF3F5ADFC5,
	PointerInputModule_GetLastPointerEventData_m6355023718EB2DCF6D9C226A57B63B70CCEECAB4,
	PointerInputModule_ShouldStartDrag_m6260055DEAD5E28183E338BDA53C7F8A0521EC6B,
	PointerInputModule_ProcessMove_m3555F333D82A446C2354D8855034323BF7C9208A,
	PointerInputModule_ProcessDrag_m73FE39BFACC950DCA7FDD7BDC67F45484DC01207,
	PointerInputModule_IsPointerOverGameObject_mBDCC057426289D69D4C6E1EF7F6849C112171883,
	PointerInputModule_ClearSelection_mC5852667E5B9CA97C2A4CAB3D7C907344511C1D2,
	PointerInputModule_ToString_m9C5DB37AC45C9F27B017E3B52C5CFE22F91CAF9D,
	PointerInputModule_DeselectIfSelectionChanged_m8F111DD2317E33C4F0498F651BC52BD5C984A95B,
	PointerInputModule__ctor_mBF074492478BFC24F87EF2C941D6C11A8ACDAF11,
	ButtonState_get_eventData_m4767730784143F1DCE06B6138658A31CBC5E155F,
	ButtonState_set_eventData_mA9D59CB9A1565A7D99569E87D88B90738FEF4E1F,
	ButtonState_get_button_m2210A465432D0F990F2380B6357AD2FBA4A7540D,
	ButtonState_set_button_mFAE3F16E2B027BD6B854F18E7C7C2D6CDAB023DE,
	ButtonState__ctor_m4D7C25C0E1FC598646FFBD436B9A2042DB41AC9E,
	MouseState_AnyPressesThisFrame_m4887FF61D58D641496B95C83710C8A4E841970F3,
	MouseState_AnyReleasesThisFrame_m4FBA37A12735418AD0970F11BC44850517B05E93,
	MouseState_GetButtonState_mD25E7D214B0499DBBE3B3E532CD7085C1A021E51,
	MouseState_SetButtonState_m72DA468C8D10E76923FA5F993BBDBCFFF57E4326,
	MouseState__ctor_mF4A8041A86E50D91202770E73CE0DAF12BB207D9,
	MouseButtonEventData_PressedThisFrame_mEE5DC95537AAEB346C57DCA85917E0701A44388D,
	MouseButtonEventData_ReleasedThisFrame_m5AD4F06D1CA6E0ACD6E84EEFAD4FB112098AFD51,
	MouseButtonEventData__ctor_m9EDAC7F39F1D3CFBB93403DDE620A5147C4469A2,
	StandaloneInputModule__ctor_m77BAC1DB71B81FFCD2791DE706BD4FE239F47C27,
	StandaloneInputModule_get_inputMode_m38D63EDD9DE39E7AFE1821BDE201625C292C66D9,
	StandaloneInputModule_get_allowActivationOnMobileDevice_m03E7DC8FCBE7B43A223EADABB454445C91664A1B,
	StandaloneInputModule_set_allowActivationOnMobileDevice_mFFFF3E19FBD199ED9BFAEC535E5BD11F5027FF25,
	StandaloneInputModule_get_forceModuleActive_m381A5525E48FD280EB91ECEEEF138E7603C004B8,
	StandaloneInputModule_set_forceModuleActive_m4C3FD8550258266795D24863D8B531F2402500DD,
	StandaloneInputModule_get_inputActionsPerSecond_m584ABC794A3864BF91EEB27E62ED6E8081DEE0A5,
	StandaloneInputModule_set_inputActionsPerSecond_mF367AFA55FF576533999F2DFB60514D7247228FF,
	StandaloneInputModule_get_repeatDelay_mDB85393BD9AA45BF8C5B94F5E3A523F5480D1F6F,
	StandaloneInputModule_set_repeatDelay_m236DB6414CFAE01609187B97E955D95A32F0CB40,
	StandaloneInputModule_get_horizontalAxis_mDB47CA6F06F26837BBC4853877F69817590161F0,
	StandaloneInputModule_set_horizontalAxis_mF71F2B0B425BD0455AF54F39EEEE43DD80DE27EC,
	StandaloneInputModule_get_verticalAxis_m5F00ECDA3B18F48BCBD6F9E7B4AD67A1F56CFAC2,
	StandaloneInputModule_set_verticalAxis_mB0FE6DC9517F0ABF0107F72FC04A322FD91C2AC0,
	StandaloneInputModule_get_submitButton_mAF097B352341EB53A42F71052F3469F205243D40,
	StandaloneInputModule_set_submitButton_m571CB829C6D76AD062BA105D0903F08CEA0BCCC7,
	StandaloneInputModule_get_cancelButton_mE6F80897FDAA6D931803BF6C3A9E4A45877E5585,
	StandaloneInputModule_set_cancelButton_m63A06532F16A21785B3BD5AD3B79509B4441B7EF,
	StandaloneInputModule_ShouldIgnoreEventsOnNoFocus_m423AA5752E528E3B32F105EE2B341FCF5E9F8285,
	StandaloneInputModule_UpdateModule_m8B42D289F6AB3EBE6071FB5B904A7449118EAA6B,
	StandaloneInputModule_ReleaseMouse_mC5C3083C356ACD5CD420A58662D99A6CACC5FAF5,
	StandaloneInputModule_ShouldActivateModule_m6E9E205A37636246BFE65CAC33E1EF703A4D99AF,
	StandaloneInputModule_ActivateModule_m1F28B8DB0FC20082694221BE5B1B275E9B7224BB,
	StandaloneInputModule_DeactivateModule_m064C1EB615C0E0B0EDFC6F6F5079E55270DF1468,
	StandaloneInputModule_Process_mBD949CC45BBCAB5A0FAF5E24F3BB4C3B22FF3E81,
	StandaloneInputModule_ProcessTouchEvents_m042FC6B13874B1EE6699BBB51F02FE3A435A25F0,
	StandaloneInputModule_ProcessTouchPress_mD72A0807626DA04E47313F9553249DD4A32625E3,
	StandaloneInputModule_SendSubmitEventToSelectedObject_m7121ACC09ABA46FF5CDDEAE7B26507BE06A2953F,
	StandaloneInputModule_GetRawMoveVector_mFF583B1720780B7D8D2DD3248F947ED8D855610B,
	StandaloneInputModule_SendMoveEventToSelectedObject_mC71D1E623B1DB82DC4E035277AC5FFA7CD64E981,
	StandaloneInputModule_ProcessMouseEvent_mCE1BA96E47D9A4448614CB9DAF5A406754F655DD,
	StandaloneInputModule_ForceAutoSelect_m8A0FD9795D64CAF49AED184D30FA5C7AB6439C75,
	StandaloneInputModule_ProcessMouseEvent_m8A8214EB9286BA31C18F515BCC3349DF740B2BBA,
	StandaloneInputModule_SendUpdateEventToSelectedObject_mE1C4AEB5B19378C2BF97DD3EAF4AA9C0EC5E7520,
	StandaloneInputModule_ProcessMousePress_m24665E707FEF5C80719847D62A8A8AEABE27C6C5,
	StandaloneInputModule_GetCurrentFocusedGameObject_m6E67A53E66DE554CCD13A943638815631A3E8E87,
	TouchInputModule__ctor_mCBE23B5A3A8CE1CD042A061D7E070B04A45E3075,
	TouchInputModule_get_allowActivationOnStandalone_m2F9A65E10F7BE98D250CC3D6C9CABA3BCCE95995,
	TouchInputModule_set_allowActivationOnStandalone_m5AB9798D9B6071B37FC67E0D1A81A58A0A59D7AD,
	TouchInputModule_get_forceModuleActive_m7200F7B6C80EDD69987615B8356B6B2497461FCA,
	TouchInputModule_set_forceModuleActive_m32676A04010774CA55055EE93A05ED6C6388D2C2,
	TouchInputModule_UpdateModule_mE6F4F74D770ACFEF3C46611C71CBE705342EA608,
	TouchInputModule_IsModuleSupported_m795B5298EC90DC063A96147CF3B3287EC27C9799,
	TouchInputModule_ShouldActivateModule_m4B17231DE579430D27088D6592378FB7547ADBDC,
	TouchInputModule_UseFakeInput_m66A84384ADA044187F239B1CFC143C42E5E56774,
	TouchInputModule_Process_m3C0CB50AB7D9E92B519787F7742AE0976FB36841,
	TouchInputModule_FakeTouches_m264BF2C70234CD04B0162FE4CED673B1A77A84F9,
	TouchInputModule_ProcessTouchEvents_mBB28D85996F6280141E39A462BC35EF01373E514,
	TouchInputModule_ProcessTouchPress_m1DC51E52E6B419F02626EB567A60411A0FCFA517,
	TouchInputModule_DeactivateModule_m7CF377DBC376C3EC560523E76514E9F47CCC9DEE,
	TouchInputModule_ToString_m1AD08DB012D85A33FC0EA3322D5AA5EB98CD1956,
	RaycasterManager_AddRaycaster_mD2EE52F55FBDB3BEAAF583C4445D4D16B09B6350,
	RaycasterManager_GetRaycasters_m876BA9CA8DB8E6D351DC4A97473753503B7017DE,
	RaycasterManager_RemoveRaycasters_m0800E0ACE007AD43B62D10C1029EC85E7DE28999,
	RaycasterManager__cctor_m06146026A557346F1469D15E855918E746125F90,
	NULL,
	NULL,
	BaseRaycaster_get_priority_m79C109ECC138B84A60F9CFA40242628A8B29C838,
	BaseRaycaster_get_sortOrderPriority_m4E0BEBF85F720AE4B7C78E99CCD786779C3E7226,
	BaseRaycaster_get_renderOrderPriority_m03C407856FF76393AB6EE26FA173131B8F36CA66,
	BaseRaycaster_get_rootRaycaster_m63E20D85A8B9867AC196768924F8BE579668BF28,
	BaseRaycaster_ToString_m12811CE16AB7E07C949B78CDE309C4B2E44B5377,
	BaseRaycaster_OnEnable_m87CCF1ACD4116BB8BC0D9DB427F5B07C6FDE3D96,
	BaseRaycaster_OnDisable_mC90A700D5F78DDAD0DD926983C2A8D7C50A5D880,
	BaseRaycaster_OnCanvasHierarchyChanged_m20A82CFED659012D1F052C5026B8294B44D99BD7,
	BaseRaycaster_OnTransformParentChanged_m121068CDDBC97032FF51C4ED944D4C126CB58F7F,
	BaseRaycaster__ctor_m1B6A963368E54C1E450BE15FAF1AE082142A1683,
	Physics2DRaycaster__ctor_mF2F12F2AF9DDCA74EB09349D038A67F3D3F88CF9,
	Physics2DRaycaster_Raycast_m9F6AA9C9DC7A34C01959F2053446D3FFCE567630,
	PhysicsRaycaster__ctor_mB7D4BAC26DC219A10060B35498EE9D5F05AD0E80,
	PhysicsRaycaster_get_eventCamera_m95026618116D1781A906DDE4AF9C415F2374013C,
	PhysicsRaycaster_get_depth_mCC2E924588088DB1DCA160765C09734D3C4F7F60,
	PhysicsRaycaster_get_finalEventMask_m20AD2327FE81B38A5853B23970A587EAA2ECCB1B,
	PhysicsRaycaster_get_eventMask_mA8FE3884CD425BD59BD22784F4D5219159426DB9,
	PhysicsRaycaster_set_eventMask_mD5110BE565C7E3F1738369519D44587452CA056D,
	PhysicsRaycaster_get_maxRayIntersections_mA06D0B5E291BCF94AE1EF4ED7B68890F39395911,
	PhysicsRaycaster_set_maxRayIntersections_mECCF07932870A3B5C8875AE6204FC1ECB2CE01F7,
	PhysicsRaycaster_ComputeRayAndDistance_mCFEFA9D83EC1E63393454E383FFFEF89E14C173B,
	PhysicsRaycaster_Raycast_mB29925EB33102E9BEAA76658F8A59CA666C78B1A,
	RaycastHitComparer_Compare_mB5B88FE52375A12B781682C712FE58193F417A03,
	RaycastHitComparer__ctor_mAB0536EE515BF2BD1B29BE3B39E8BA9E9CFE97C3,
	RaycastHitComparer__cctor_m772D29066D594105261C78CDDB5724BE28A773FA,
	RaycastResult_get_gameObject_m77014B442B9E2D10F2CC3AEEDC07AA95CDE1E2F1,
	RaycastResult_set_gameObject_mCFEB66C0E3F01AC5E55040FE8BEB16E40427BD9E,
	RaycastResult_get_isValid_m69957B97C041A9E3FAF4ECA82BB8099C9FA171CE,
	RaycastResult_Clear_m0E9DA70AC69CF143CEA8428AFC5BA552F99643AE,
	RaycastResult_ToString_m0267000494B09783ABD507B9329ADB01FBBC5428,
	UIBehaviour_Awake_mDF9D1A4867C8E730C59A7CAE97709CA9B8F3A0F2,
	UIBehaviour_OnEnable_m8989ABF5C038905A68E5536BED2E6FFAF8767FFC,
	UIBehaviour_Start_mB12643ED6D859CD3682B4BF5B9CA7F72E8A72B45,
	UIBehaviour_OnDisable_m18D5A0B93F65FB50F4D6CE8197EC07F3452C5DDE,
	UIBehaviour_OnDestroy_mF225CF9163823F19BE5E2B2735D35898A20D608B,
	UIBehaviour_IsActive_m9E79A0650C81204AF9A861BBBA8685D9563AE9C4,
	UIBehaviour_OnRectTransformDimensionsChange_m86A6D20E0EBF41CDB89DD1E87F23624263B68159,
	UIBehaviour_OnBeforeTransformParentChanged_m980EF41E33A7541BD6C65AEC305B25A19C9CA30F,
	UIBehaviour_OnTransformParentChanged_mAD56D3C6049A1746F00DC2643D1666F7DE921384,
	UIBehaviour_OnDidApplyAnimationProperties_mE011A7C92134E28AE2AF3A0EBFB2E4AB88ABE748,
	UIBehaviour_OnCanvasGroupChanged_m592FA8BF5238E712E73E2D99258EE0DB6D88D84B,
	UIBehaviour_OnCanvasHierarchyChanged_mCAC018CB33FA00E857288B64E3722226638A1229,
	UIBehaviour_IsDestroyed_m2E9FFA28686D1C82697FB467002541CC58A06BCA,
	UIBehaviour__ctor_m24C66A65DDD996E779871C6655CF11B871F11337,
	MaterialAccess_ReadMaterialRawRenderQueue_m6B9E0FEB4CBD15C741BE81BEEA4E9B17C1091416,
	MaterialAccess_ReadMaterialRawRenderQueue_m093C11796E1489030FD35E9EAE4005F397BFE6B2,
};
extern void ColorBlock_get_normalColor_m08A07A74ED743B4B0C1B5A5C35774F2D78F1F20E_AdjustorThunk (void);
extern void ColorBlock_set_normalColor_m3EBF594F6FA2C6494ACA9FCB9B458807D85B96F8_AdjustorThunk (void);
extern void ColorBlock_get_highlightedColor_m4D1A3D268CB00B351F56934F7F244DBC68855301_AdjustorThunk (void);
extern void ColorBlock_set_highlightedColor_m04E97DF2CCE7CAC47120D8F486E18BF62F16FF86_AdjustorThunk (void);
extern void ColorBlock_get_pressedColor_m5EDADBA10824D08BFB67D02099A9FC6A4235AC62_AdjustorThunk (void);
extern void ColorBlock_set_pressedColor_m644C938090857AB07C57B25FE53F6DC2BB0DD5A8_AdjustorThunk (void);
extern void ColorBlock_get_selectedColor_m41CD59090E997A5982EE5AB9D23811FEB35C82CF_AdjustorThunk (void);
extern void ColorBlock_set_selectedColor_m76FEFB1148798B7A356C974CDEA3BA2E2E3C1D21_AdjustorThunk (void);
extern void ColorBlock_get_disabledColor_m2E20FC772B592ADD71CE1336D29B3C3C1523669E_AdjustorThunk (void);
extern void ColorBlock_set_disabledColor_m4D10D1F8525CCC7E8E200E3994AFB28ADABB1D8E_AdjustorThunk (void);
extern void ColorBlock_get_colorMultiplier_m54C8F6B7E5ACF45D70F9EAAED78AB4606999C187_AdjustorThunk (void);
extern void ColorBlock_set_colorMultiplier_m920A048B95541DB0E92AF4AF3894BE7CD2D37102_AdjustorThunk (void);
extern void ColorBlock_get_fadeDuration_m506A0FCC2819DA313BE033640C8FEDC5331D1C39_AdjustorThunk (void);
extern void ColorBlock_set_fadeDuration_m8519A304808384CE873377EC104969A6B9FBB6C5_AdjustorThunk (void);
extern void ColorBlock_Equals_m20D958BB28F6FDC12D612279AF6B50679C0C1E67_AdjustorThunk (void);
extern void ColorBlock_Equals_m52DCE246EA23904A3EF0FCD3ADAB81BC20DC1BE5_AdjustorThunk (void);
extern void ColorBlock_GetHashCode_m3CCB4E1E5EE93B905650E24BD4753096082270D7_AdjustorThunk (void);
extern void Navigation_get_mode_m3B574F1549B3806753EC33228EB3FF3031F4E809_AdjustorThunk (void);
extern void Navigation_set_mode_m0BEF999F733332AD994CF3CA4AC17B2A47531207_AdjustorThunk (void);
extern void Navigation_get_wrapAround_mA24021791B1C67F665065B5A415434837CEA86DD_AdjustorThunk (void);
extern void Navigation_set_wrapAround_m9D808EC49EE5F3AFA7F0D13E86FF9F72AA20A081_AdjustorThunk (void);
extern void Navigation_get_selectOnUp_mD24FC0BAB97E5DBB28C9C7209BAC2ACC9419B183_AdjustorThunk (void);
extern void Navigation_set_selectOnUp_mCB04000FDFC05D3BAC497602E4BA346A536152E5_AdjustorThunk (void);
extern void Navigation_get_selectOnDown_m1D36E990CDB38C4BB78745587668F94BBE8A1285_AdjustorThunk (void);
extern void Navigation_set_selectOnDown_m0EBBAB8C51107F75F63FFBC3DF88D9010E6A44BB_AdjustorThunk (void);
extern void Navigation_get_selectOnLeft_mA4F7DA341D7C660A7E15520B34847B0757C65F81_AdjustorThunk (void);
extern void Navigation_set_selectOnLeft_mA4E7480D7CBDA9A5ECA93BAFCD1CF1976A994FCB_AdjustorThunk (void);
extern void Navigation_get_selectOnRight_m7A781F4050AE064DC0473E68AA6D07CFFF0A8FF9_AdjustorThunk (void);
extern void Navigation_set_selectOnRight_mD0B38024BB628CDC801EA93E9FF7C438ECE2055B_AdjustorThunk (void);
extern void Navigation_Equals_mE25B4E3D0AB85C1469B99971E6AB16E2039E6B4D_AdjustorThunk (void);
extern void SpriteState_get_highlightedSprite_m5D24B628AB2E4DEBF67E094CCA059BDADAB952BB_AdjustorThunk (void);
extern void SpriteState_set_highlightedSprite_mEECDB7C62DE0C6A0B2A7D5D7ADF54EB8CDDB20B0_AdjustorThunk (void);
extern void SpriteState_get_pressedSprite_m89052B1818D1659DA7E594F218485F1DEB8128BD_AdjustorThunk (void);
extern void SpriteState_set_pressedSprite_mD01568B87B1BC1374CCFB5CD190D7CD62A6FDAA3_AdjustorThunk (void);
extern void SpriteState_get_selectedSprite_m5316836E91F7EB454E953CADD439FF69AA198BA5_AdjustorThunk (void);
extern void SpriteState_set_selectedSprite_m902ACABEC203C0A2408B4ECD7B74C10DFE7BB340_AdjustorThunk (void);
extern void SpriteState_get_disabledSprite_m6BE5A2231E20BE1600328082B4EFE53EE7F3E12C_AdjustorThunk (void);
extern void SpriteState_set_disabledSprite_m624499C245DC34D314FF0326FE5ADCF35DA28E27_AdjustorThunk (void);
extern void SpriteState_Equals_mAF58D9F36662F5A8196071690175AAFCC4506653_AdjustorThunk (void);
extern void ColorTween_get_startColor_m9E33FB5C5F76BCF49A3B20201CD8006DBFB46012_AdjustorThunk (void);
extern void ColorTween_set_startColor_mD22349343421BD44F0C31E537718ED53BE4850DA_AdjustorThunk (void);
extern void ColorTween_get_targetColor_m240A7018BDC3B44AB44BA674AA16C39960BC23FF_AdjustorThunk (void);
extern void ColorTween_set_targetColor_m7D8E74B32AC3A9C17C3192096003B12A1500D749_AdjustorThunk (void);
extern void ColorTween_get_tweenMode_m06B83FB6E45A807F83FDD762A8241D478FD13F8B_AdjustorThunk (void);
extern void ColorTween_set_tweenMode_m105EEB49F6632D6D105C63DA9919385233A5D4DE_AdjustorThunk (void);
extern void ColorTween_get_duration_m40D8F08C13FF2FE7583746934C6A017A93398548_AdjustorThunk (void);
extern void ColorTween_set_duration_m1C278AB5A90B5C108CEB4870CAC90A9A9EAC19CB_AdjustorThunk (void);
extern void ColorTween_get_ignoreTimeScale_mEDB15A4ADE3A0B9487D240964A7571247F974708_AdjustorThunk (void);
extern void ColorTween_set_ignoreTimeScale_m060FF3CED06F73EA1F555A37999D61DC58F99927_AdjustorThunk (void);
extern void ColorTween_TweenValue_mF5CBA9BDE7F73E47F9CF26DC4EC2419694049860_AdjustorThunk (void);
extern void ColorTween_AddOnChangedCallback_mAC2856A154604B4B6721DAC185B819A98D6F7438_AdjustorThunk (void);
extern void ColorTween_GetIgnoreTimescale_m679C83012235779A37DCCD0AA75CD6B0DAE5BCFA_AdjustorThunk (void);
extern void ColorTween_GetDuration_mC40D6776769FDB79C7ADC42D59F059A2A9AE2F66_AdjustorThunk (void);
extern void ColorTween_ValidTarget_m1D7A682CE00048FAF1A3BDD55EB76F44C9122B4D_AdjustorThunk (void);
extern void FloatTween_get_startValue_mCA121483CCF4C8F10991BB3306E3F2769EBB3A3C_AdjustorThunk (void);
extern void FloatTween_set_startValue_m43B55D74B7B34D9C32439D6004F306BFA18E4A1A_AdjustorThunk (void);
extern void FloatTween_get_targetValue_m6EFBD9EAB206F145959832269DC24C4B68FEE6B1_AdjustorThunk (void);
extern void FloatTween_set_targetValue_m4AE44CE862797E898CDE00A1B7D6A33CE0AFDCFB_AdjustorThunk (void);
extern void FloatTween_get_duration_mB1496D38A618FF8282205FD3AA14CA9C6D76454D_AdjustorThunk (void);
extern void FloatTween_set_duration_m40E10A7B796B4B54FFB8DA3889B09557BEC98456_AdjustorThunk (void);
extern void FloatTween_get_ignoreTimeScale_m6F6BDCBD59C19E68572370F9FE3D7373B4212B3B_AdjustorThunk (void);
extern void FloatTween_set_ignoreTimeScale_m09041A4110040F9C86D24E1B4DED6E6B7FB206A8_AdjustorThunk (void);
extern void FloatTween_TweenValue_mE51344369BDDA58E9C3AEC62E1B1C1AC0349278E_AdjustorThunk (void);
extern void FloatTween_AddOnChangedCallback_m13B1FFCAD78C7E690E70704311B20D5BB67D8224_AdjustorThunk (void);
extern void FloatTween_GetIgnoreTimescale_mA2463285D4524B70A46776FC60C4F939B3BCD045_AdjustorThunk (void);
extern void FloatTween_GetDuration_m3E981D91F15C36ED6F241117665E703F2BD2A6D4_AdjustorThunk (void);
extern void FloatTween_ValidTarget_m36EABC84C8FEFF79EBAC8E9C3C7A394F1377E311_AdjustorThunk (void);
extern void RaycastResult_get_gameObject_m77014B442B9E2D10F2CC3AEEDC07AA95CDE1E2F1_AdjustorThunk (void);
extern void RaycastResult_set_gameObject_mCFEB66C0E3F01AC5E55040FE8BEB16E40427BD9E_AdjustorThunk (void);
extern void RaycastResult_get_isValid_m69957B97C041A9E3FAF4ECA82BB8099C9FA171CE_AdjustorThunk (void);
extern void RaycastResult_Clear_m0E9DA70AC69CF143CEA8428AFC5BA552F99643AE_AdjustorThunk (void);
extern void RaycastResult_ToString_m0267000494B09783ABD507B9329ADB01FBBC5428_AdjustorThunk (void);
static Il2CppTokenAdjustorThunkPair s_adjustorThunks[72] = 
{
	{ 0x06000035, ColorBlock_get_normalColor_m08A07A74ED743B4B0C1B5A5C35774F2D78F1F20E_AdjustorThunk },
	{ 0x06000036, ColorBlock_set_normalColor_m3EBF594F6FA2C6494ACA9FCB9B458807D85B96F8_AdjustorThunk },
	{ 0x06000037, ColorBlock_get_highlightedColor_m4D1A3D268CB00B351F56934F7F244DBC68855301_AdjustorThunk },
	{ 0x06000038, ColorBlock_set_highlightedColor_m04E97DF2CCE7CAC47120D8F486E18BF62F16FF86_AdjustorThunk },
	{ 0x06000039, ColorBlock_get_pressedColor_m5EDADBA10824D08BFB67D02099A9FC6A4235AC62_AdjustorThunk },
	{ 0x0600003A, ColorBlock_set_pressedColor_m644C938090857AB07C57B25FE53F6DC2BB0DD5A8_AdjustorThunk },
	{ 0x0600003B, ColorBlock_get_selectedColor_m41CD59090E997A5982EE5AB9D23811FEB35C82CF_AdjustorThunk },
	{ 0x0600003C, ColorBlock_set_selectedColor_m76FEFB1148798B7A356C974CDEA3BA2E2E3C1D21_AdjustorThunk },
	{ 0x0600003D, ColorBlock_get_disabledColor_m2E20FC772B592ADD71CE1336D29B3C3C1523669E_AdjustorThunk },
	{ 0x0600003E, ColorBlock_set_disabledColor_m4D10D1F8525CCC7E8E200E3994AFB28ADABB1D8E_AdjustorThunk },
	{ 0x0600003F, ColorBlock_get_colorMultiplier_m54C8F6B7E5ACF45D70F9EAAED78AB4606999C187_AdjustorThunk },
	{ 0x06000040, ColorBlock_set_colorMultiplier_m920A048B95541DB0E92AF4AF3894BE7CD2D37102_AdjustorThunk },
	{ 0x06000041, ColorBlock_get_fadeDuration_m506A0FCC2819DA313BE033640C8FEDC5331D1C39_AdjustorThunk },
	{ 0x06000042, ColorBlock_set_fadeDuration_m8519A304808384CE873377EC104969A6B9FBB6C5_AdjustorThunk },
	{ 0x06000044, ColorBlock_Equals_m20D958BB28F6FDC12D612279AF6B50679C0C1E67_AdjustorThunk },
	{ 0x06000045, ColorBlock_Equals_m52DCE246EA23904A3EF0FCD3ADAB81BC20DC1BE5_AdjustorThunk },
	{ 0x06000048, ColorBlock_GetHashCode_m3CCB4E1E5EE93B905650E24BD4753096082270D7_AdjustorThunk },
	{ 0x06000360, Navigation_get_mode_m3B574F1549B3806753EC33228EB3FF3031F4E809_AdjustorThunk },
	{ 0x06000361, Navigation_set_mode_m0BEF999F733332AD994CF3CA4AC17B2A47531207_AdjustorThunk },
	{ 0x06000362, Navigation_get_wrapAround_mA24021791B1C67F665065B5A415434837CEA86DD_AdjustorThunk },
	{ 0x06000363, Navigation_set_wrapAround_m9D808EC49EE5F3AFA7F0D13E86FF9F72AA20A081_AdjustorThunk },
	{ 0x06000364, Navigation_get_selectOnUp_mD24FC0BAB97E5DBB28C9C7209BAC2ACC9419B183_AdjustorThunk },
	{ 0x06000365, Navigation_set_selectOnUp_mCB04000FDFC05D3BAC497602E4BA346A536152E5_AdjustorThunk },
	{ 0x06000366, Navigation_get_selectOnDown_m1D36E990CDB38C4BB78745587668F94BBE8A1285_AdjustorThunk },
	{ 0x06000367, Navigation_set_selectOnDown_m0EBBAB8C51107F75F63FFBC3DF88D9010E6A44BB_AdjustorThunk },
	{ 0x06000368, Navigation_get_selectOnLeft_mA4F7DA341D7C660A7E15520B34847B0757C65F81_AdjustorThunk },
	{ 0x06000369, Navigation_set_selectOnLeft_mA4E7480D7CBDA9A5ECA93BAFCD1CF1976A994FCB_AdjustorThunk },
	{ 0x0600036A, Navigation_get_selectOnRight_m7A781F4050AE064DC0473E68AA6D07CFFF0A8FF9_AdjustorThunk },
	{ 0x0600036B, Navigation_set_selectOnRight_mD0B38024BB628CDC801EA93E9FF7C438ECE2055B_AdjustorThunk },
	{ 0x0600036D, Navigation_Equals_mE25B4E3D0AB85C1469B99971E6AB16E2039E6B4D_AdjustorThunk },
	{ 0x0600048A, SpriteState_get_highlightedSprite_m5D24B628AB2E4DEBF67E094CCA059BDADAB952BB_AdjustorThunk },
	{ 0x0600048B, SpriteState_set_highlightedSprite_mEECDB7C62DE0C6A0B2A7D5D7ADF54EB8CDDB20B0_AdjustorThunk },
	{ 0x0600048C, SpriteState_get_pressedSprite_m89052B1818D1659DA7E594F218485F1DEB8128BD_AdjustorThunk },
	{ 0x0600048D, SpriteState_set_pressedSprite_mD01568B87B1BC1374CCFB5CD190D7CD62A6FDAA3_AdjustorThunk },
	{ 0x0600048E, SpriteState_get_selectedSprite_m5316836E91F7EB454E953CADD439FF69AA198BA5_AdjustorThunk },
	{ 0x0600048F, SpriteState_set_selectedSprite_m902ACABEC203C0A2408B4ECD7B74C10DFE7BB340_AdjustorThunk },
	{ 0x06000490, SpriteState_get_disabledSprite_m6BE5A2231E20BE1600328082B4EFE53EE7F3E12C_AdjustorThunk },
	{ 0x06000491, SpriteState_set_disabledSprite_m624499C245DC34D314FF0326FE5ADCF35DA28E27_AdjustorThunk },
	{ 0x06000492, SpriteState_Equals_mAF58D9F36662F5A8196071690175AAFCC4506653_AdjustorThunk },
	{ 0x06000557, ColorTween_get_startColor_m9E33FB5C5F76BCF49A3B20201CD8006DBFB46012_AdjustorThunk },
	{ 0x06000558, ColorTween_set_startColor_mD22349343421BD44F0C31E537718ED53BE4850DA_AdjustorThunk },
	{ 0x06000559, ColorTween_get_targetColor_m240A7018BDC3B44AB44BA674AA16C39960BC23FF_AdjustorThunk },
	{ 0x0600055A, ColorTween_set_targetColor_m7D8E74B32AC3A9C17C3192096003B12A1500D749_AdjustorThunk },
	{ 0x0600055B, ColorTween_get_tweenMode_m06B83FB6E45A807F83FDD762A8241D478FD13F8B_AdjustorThunk },
	{ 0x0600055C, ColorTween_set_tweenMode_m105EEB49F6632D6D105C63DA9919385233A5D4DE_AdjustorThunk },
	{ 0x0600055D, ColorTween_get_duration_m40D8F08C13FF2FE7583746934C6A017A93398548_AdjustorThunk },
	{ 0x0600055E, ColorTween_set_duration_m1C278AB5A90B5C108CEB4870CAC90A9A9EAC19CB_AdjustorThunk },
	{ 0x0600055F, ColorTween_get_ignoreTimeScale_mEDB15A4ADE3A0B9487D240964A7571247F974708_AdjustorThunk },
	{ 0x06000560, ColorTween_set_ignoreTimeScale_m060FF3CED06F73EA1F555A37999D61DC58F99927_AdjustorThunk },
	{ 0x06000561, ColorTween_TweenValue_mF5CBA9BDE7F73E47F9CF26DC4EC2419694049860_AdjustorThunk },
	{ 0x06000562, ColorTween_AddOnChangedCallback_mAC2856A154604B4B6721DAC185B819A98D6F7438_AdjustorThunk },
	{ 0x06000563, ColorTween_GetIgnoreTimescale_m679C83012235779A37DCCD0AA75CD6B0DAE5BCFA_AdjustorThunk },
	{ 0x06000564, ColorTween_GetDuration_mC40D6776769FDB79C7ADC42D59F059A2A9AE2F66_AdjustorThunk },
	{ 0x06000565, ColorTween_ValidTarget_m1D7A682CE00048FAF1A3BDD55EB76F44C9122B4D_AdjustorThunk },
	{ 0x06000567, FloatTween_get_startValue_mCA121483CCF4C8F10991BB3306E3F2769EBB3A3C_AdjustorThunk },
	{ 0x06000568, FloatTween_set_startValue_m43B55D74B7B34D9C32439D6004F306BFA18E4A1A_AdjustorThunk },
	{ 0x06000569, FloatTween_get_targetValue_m6EFBD9EAB206F145959832269DC24C4B68FEE6B1_AdjustorThunk },
	{ 0x0600056A, FloatTween_set_targetValue_m4AE44CE862797E898CDE00A1B7D6A33CE0AFDCFB_AdjustorThunk },
	{ 0x0600056B, FloatTween_get_duration_mB1496D38A618FF8282205FD3AA14CA9C6D76454D_AdjustorThunk },
	{ 0x0600056C, FloatTween_set_duration_m40E10A7B796B4B54FFB8DA3889B09557BEC98456_AdjustorThunk },
	{ 0x0600056D, FloatTween_get_ignoreTimeScale_m6F6BDCBD59C19E68572370F9FE3D7373B4212B3B_AdjustorThunk },
	{ 0x0600056E, FloatTween_set_ignoreTimeScale_m09041A4110040F9C86D24E1B4DED6E6B7FB206A8_AdjustorThunk },
	{ 0x0600056F, FloatTween_TweenValue_mE51344369BDDA58E9C3AEC62E1B1C1AC0349278E_AdjustorThunk },
	{ 0x06000570, FloatTween_AddOnChangedCallback_m13B1FFCAD78C7E690E70704311B20D5BB67D8224_AdjustorThunk },
	{ 0x06000571, FloatTween_GetIgnoreTimescale_mA2463285D4524B70A46776FC60C4F939B3BCD045_AdjustorThunk },
	{ 0x06000572, FloatTween_GetDuration_m3E981D91F15C36ED6F241117665E703F2BD2A6D4_AdjustorThunk },
	{ 0x06000573, FloatTween_ValidTarget_m36EABC84C8FEFF79EBAC8E9C3C7A394F1377E311_AdjustorThunk },
	{ 0x06000745, RaycastResult_get_gameObject_m77014B442B9E2D10F2CC3AEEDC07AA95CDE1E2F1_AdjustorThunk },
	{ 0x06000746, RaycastResult_set_gameObject_mCFEB66C0E3F01AC5E55040FE8BEB16E40427BD9E_AdjustorThunk },
	{ 0x06000747, RaycastResult_get_isValid_m69957B97C041A9E3FAF4ECA82BB8099C9FA171CE_AdjustorThunk },
	{ 0x06000748, RaycastResult_Clear_m0E9DA70AC69CF143CEA8428AFC5BA552F99643AE_AdjustorThunk },
	{ 0x06000749, RaycastResult_ToString_m0267000494B09783ABD507B9329ADB01FBBC5428_AdjustorThunk },
};
static const int32_t s_InvokerIndices[1881] = 
{
	6623,
	5326,
	6623,
	5326,
	6623,
	5326,
	6623,
	5326,
	6623,
	5326,
	6754,
	6754,
	6623,
	5326,
	6754,
	5326,
	5326,
	6623,
	6754,
	5295,
	6754,
	6519,
	6623,
	6754,
	6623,
	0,
	0,
	0,
	0,
	0,
	6754,
	12169,
	3740,
	6754,
	6754,
	10933,
	9468,
	11342,
	10805,
	3740,
	11342,
	10805,
	3740,
	11342,
	11342,
	5326,
	5326,
	5326,
	5326,
	12135,
	12135,
	12219,
	6521,
	5224,
	6521,
	5224,
	6521,
	5224,
	6521,
	5224,
	6521,
	5224,
	6683,
	5381,
	6683,
	5381,
	12219,
	3740,
	3646,
	9223,
	9223,
	6591,
	6754,
	12169,
	6754,
	11342,
	11342,
	11342,
	9617,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2293,
	6754,
	12169,
	8617,
	8610,
	11342,
	11342,
	9968,
	9961,
	11063,
	11063,
	11063,
	11063,
	11063,
	11063,
	11063,
	11063,
	11063,
	11063,
	11063,
	12219,
	0,
	2274,
	6754,
	12219,
	6623,
	5326,
	6623,
	5326,
	6623,
	5326,
	6623,
	5326,
	6623,
	5326,
	6623,
	5326,
	6623,
	5326,
	6683,
	5381,
	6591,
	5295,
	5295,
	2588,
	6754,
	6754,
	6754,
	6754,
	6754,
	5326,
	5326,
	5326,
	6754,
	5326,
	0,
	5326,
	5326,
	5326,
	6754,
	4719,
	5326,
	4719,
	5326,
	4719,
	5326,
	880,
	2980,
	1534,
	5381,
	6754,
	4724,
	6754,
	5326,
	12219,
	6623,
	5326,
	6623,
	5326,
	6623,
	5326,
	6623,
	5326,
	5326,
	5326,
	6754,
	6623,
	5326,
	6623,
	5326,
	6754,
	5326,
	5326,
	2925,
	6623,
	5326,
	6754,
	6754,
	6754,
	5221,
	5295,
	6754,
	6519,
	6623,
	6754,
	6623,
	12169,
	6623,
	5326,
	6591,
	5295,
	6591,
	5295,
	6519,
	5221,
	6591,
	5295,
	6591,
	5295,
	6591,
	5295,
	6519,
	5221,
	6519,
	5221,
	6591,
	5295,
	6591,
	5295,
	6683,
	5381,
	6754,
	6754,
	6754,
	11342,
	11342,
	11342,
	12219,
	12169,
	6521,
	5224,
	6519,
	5221,
	6746,
	5439,
	6519,
	5221,
	6754,
	6754,
	6754,
	6754,
	6754,
	6754,
	6754,
	6754,
	6754,
	6591,
	6623,
	6623,
	6754,
	6623,
	6623,
	6623,
	5326,
	6623,
	6623,
	6754,
	6754,
	6754,
	6754,
	6754,
	5295,
	6754,
	6754,
	6754,
	6754,
	6754,
	6754,
	12169,
	5326,
	5326,
	5326,
	6754,
	6754,
	1847,
	4920,
	6649,
	948,
	470,
	10841,
	1532,
	5326,
	5326,
	5326,
	5326,
	5326,
	5326,
	12219,
	6623,
	6591,
	6591,
	6519,
	5221,
	6591,
	5295,
	6603,
	5307,
	6754,
	6623,
	2925,
	6623,
	7708,
	12219,
	12219,
	6754,
	2047,
	6754,
	12169,
	9968,
	9968,
	9968,
	9968,
	9968,
	9968,
	11046,
	11046,
	12219,
	0,
	6623,
	5326,
	6754,
	6623,
	5326,
	6623,
	6591,
	5295,
	6519,
	5221,
	6519,
	5221,
	6591,
	5295,
	6683,
	5381,
	6519,
	5221,
	6591,
	5295,
	6683,
	5381,
	6683,
	5381,
	6519,
	5221,
	6754,
	12169,
	6623,
	6519,
	6683,
	5381,
	6683,
	6683,
	6623,
	5326,
	6754,
	6754,
	2364,
	4933,
	6754,
	5326,
	6754,
	6754,
	6754,
	6754,
	6754,
	2906,
	2906,
	5326,
	5326,
	8183,
	7250,
	2335,
	2906,
	7319,
	7715,
	6754,
	6754,
	6683,
	6683,
	6683,
	6683,
	6683,
	6683,
	6591,
	1847,
	2329,
	11342,
	11342,
	11342,
	6754,
	12219,
	0,
	0,
	0,
	6623,
	6623,
	6754,
	6623,
	6623,
	5221,
	6519,
	5221,
	6519,
	6623,
	5326,
	5326,
	2906,
	6519,
	6683,
	5381,
	6591,
	5295,
	6623,
	5326,
	6623,
	5326,
	6521,
	5224,
	6519,
	5221,
	6521,
	5224,
	6623,
	5326,
	6623,
	5326,
	6623,
	5326,
	6623,
	5326,
	6623,
	5326,
	6591,
	5295,
	6591,
	5295,
	6591,
	5295,
	6591,
	5295,
	6623,
	6591,
	5295,
	6591,
	5295,
	6519,
	5221,
	6519,
	6737,
	5430,
	6519,
	5210,
	6591,
	5295,
	6591,
	5295,
	6519,
	6591,
	5295,
	6591,
	5295,
	6591,
	5295,
	6754,
	6754,
	6754,
	6754,
	6623,
	6754,
	6754,
	6754,
	6754,
	6754,
	5221,
	5221,
	12169,
	11342,
	6519,
	6519,
	6519,
	6754,
	6754,
	4920,
	2114,
	4504,
	3740,
	5326,
	5326,
	4719,
	5326,
	5326,
	4429,
	3850,
	5326,
	5326,
	6623,
	6591,
	2372,
	6591,
	2372,
	2024,
	2021,
	2021,
	5221,
	2372,
	5221,
	2372,
	6754,
	6754,
	6754,
	5430,
	6754,
	6754,
	6754,
	6754,
	6754,
	5326,
	5430,
	6754,
	6519,
	9467,
	9467,
	5295,
	6754,
	6754,
	5295,
	6754,
	6754,
	6754,
	6754,
	5326,
	2941,
	6754,
	2941,
	1314,
	6754,
	6754,
	5326,
	5326,
	6754,
	5326,
	5326,
	6754,
	6754,
	5326,
	6754,
	2588,
	6754,
	6754,
	6683,
	6683,
	6683,
	6683,
	6683,
	6683,
	6591,
	12219,
	6623,
	2920,
	1314,
	442,
	4902,
	6754,
	6754,
	6754,
	5295,
	6754,
	6519,
	6623,
	6754,
	6623,
	5295,
	6754,
	6519,
	6623,
	6754,
	6623,
	6591,
	5295,
	6683,
	5381,
	6623,
	6754,
	6754,
	6754,
	6754,
	6754,
	6754,
	6754,
	6754,
	2306,
	6742,
	6754,
	6754,
	6754,
	6519,
	6519,
	6519,
	6591,
	5295,
	6683,
	5381,
	6683,
	5381,
	6742,
	5435,
	6591,
	5295,
	6683,
	5381,
	6591,
	5295,
	6683,
	5381,
	6683,
	5381,
	6683,
	5381,
	6754,
	6754,
	6754,
	6754,
	6754,
	6754,
	6754,
	6754,
	6754,
	5381,
	5381,
	6591,
	5295,
	6591,
	5295,
	6623,
	6754,
	6754,
	6754,
	6754,
	5295,
	6754,
	6754,
	6754,
	6591,
	5295,
	6591,
	5295,
	6742,
	5435,
	6742,
	5435,
	6591,
	5295,
	6591,
	5295,
	6754,
	6754,
	6754,
	6754,
	6754,
	5295,
	6754,
	6754,
	6754,
	6754,
	6754,
	6683,
	5381,
	6519,
	5221,
	6519,
	5221,
	6519,
	5221,
	6519,
	5221,
	6519,
	5221,
	6519,
	5221,
	6519,
	5221,
	2588,
	2588,
	161,
	6754,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	6519,
	5221,
	6754,
	6754,
	6683,
	5381,
	6683,
	5381,
	6683,
	5381,
	6683,
	5381,
	6683,
	5381,
	6683,
	5381,
	6591,
	5295,
	6754,
	6754,
	6754,
	6754,
	6754,
	6754,
	6754,
	6623,
	5326,
	6591,
	5295,
	6623,
	6623,
	6754,
	0,
	6683,
	6683,
	6683,
	6683,
	6683,
	6683,
	6591,
	0,
	0,
	6754,
	6754,
	6754,
	6754,
	4825,
	4825,
	4825,
	2298,
	4825,
	1079,
	1471,
	1028,
	1028,
	507,
	6519,
	6754,
	6754,
	0,
	6754,
	4719,
	5295,
	6754,
	6519,
	6623,
	6754,
	6623,
	5326,
	6754,
	12219,
	11342,
	6623,
	6519,
	11342,
	11342,
	5295,
	2925,
	2925,
	11342,
	9276,
	11342,
	6754,
	6754,
	6591,
	3740,
	6623,
	6754,
	12219,
	6754,
	6623,
	5326,
	3740,
	5326,
	5326,
	5326,
	5326,
	9650,
	9650,
	9650,
	11145,
	11145,
	11145,
	11145,
	11145,
	11145,
	8655,
	8079,
	12219,
	6754,
	4826,
	4826,
	4826,
	4826,
	4826,
	4826,
	4826,
	4826,
	6754,
	6754,
	6754,
	6754,
	6754,
	6623,
	6519,
	5221,
	6623,
	6754,
	6519,
	6754,
	6754,
	6754,
	1847,
	4719,
	6623,
	5326,
	6519,
	5221,
	6519,
	5221,
	4719,
	2960,
	5221,
	2960,
	5435,
	6754,
	6754,
	6754,
	6754,
	6754,
	6649,
	6754,
	6754,
	6754,
	6754,
	6623,
	6754,
	11342,
	11342,
	11046,
	9468,
	9276,
	11046,
	9968,
	6754,
	0,
	11342,
	11342,
	9268,
	11316,
	6591,
	5295,
	6519,
	5221,
	6623,
	5326,
	6623,
	5326,
	6623,
	5326,
	6623,
	5326,
	12168,
	3739,
	6754,
	6623,
	6623,
	5326,
	6649,
	5350,
	6754,
	5326,
	6754,
	6746,
	5439,
	6743,
	5436,
	6623,
	6649,
	6623,
	6754,
	6754,
	6754,
	6754,
	1847,
	6649,
	6754,
	6754,
	5326,
	5326,
	6754,
	6754,
	6623,
	5326,
	6591,
	5295,
	6754,
	6683,
	5381,
	5381,
	6683,
	5381,
	6591,
	5295,
	6623,
	5326,
	6683,
	5295,
	6754,
	6754,
	6754,
	6754,
	6754,
	6754,
	2978,
	6754,
	6591,
	6519,
	6754,
	5326,
	3014,
	3740,
	5326,
	5326,
	5326,
	4719,
	2282,
	5326,
	5326,
	6623,
	6623,
	6623,
	6623,
	5326,
	2588,
	6623,
	6754,
	5295,
	6754,
	6519,
	6623,
	6754,
	6623,
	6623,
	5326,
	6519,
	5221,
	6519,
	5221,
	6591,
	5295,
	6683,
	5381,
	6519,
	5221,
	6683,
	5381,
	6683,
	5381,
	6623,
	5326,
	6623,
	5326,
	6623,
	5326,
	6591,
	5295,
	6591,
	5295,
	6683,
	5381,
	6683,
	5381,
	6623,
	5326,
	6623,
	6742,
	5435,
	6623,
	6754,
	5295,
	6754,
	6754,
	6754,
	6754,
	6754,
	6519,
	6754,
	6754,
	5326,
	5326,
	5326,
	5326,
	5326,
	5435,
	6754,
	6754,
	5435,
	6742,
	5435,
	6683,
	5381,
	6683,
	5381,
	5381,
	5381,
	2979,
	9656,
	6754,
	6519,
	6519,
	6754,
	6754,
	6683,
	6683,
	6683,
	6683,
	6683,
	6683,
	6591,
	6754,
	6754,
	6754,
	8141,
	6754,
	6754,
	8102,
	6518,
	9165,
	4920,
	7199,
	6754,
	6754,
	6623,
	6754,
	12169,
	12161,
	12169,
	10933,
	6622,
	5325,
	6591,
	5295,
	6523,
	5226,
	6687,
	5386,
	6623,
	5326,
	6623,
	5326,
	6519,
	5221,
	6519,
	5221,
	6519,
	5221,
	6519,
	5221,
	6754,
	6623,
	5326,
	6623,
	6754,
	6754,
	6519,
	6754,
	6754,
	6754,
	6754,
	6754,
	5221,
	6591,
	6754,
	2588,
	4733,
	9755,
	2925,
	6623,
	6623,
	6623,
	6623,
	5326,
	2381,
	5326,
	5326,
	6519,
	6519,
	6754,
	5326,
	5326,
	5326,
	5326,
	5326,
	5326,
	6754,
	12219,
	9195,
	0,
	0,
	6623,
	5326,
	6623,
	5326,
	6591,
	5295,
	6683,
	5381,
	6683,
	5381,
	6519,
	5221,
	6683,
	5381,
	5381,
	6683,
	5381,
	6623,
	5326,
	6683,
	6754,
	5295,
	6754,
	6754,
	6754,
	6754,
	6754,
	6754,
	6754,
	4827,
	2978,
	6754,
	6591,
	6519,
	6754,
	2925,
	3740,
	5326,
	5326,
	5326,
	6623,
	6623,
	6623,
	6623,
	5326,
	2588,
	6623,
	6754,
	6623,
	5326,
	6623,
	5326,
	6623,
	5326,
	6623,
	5326,
	3800,
	9564,
	7481,
	9968,
	7105,
	11342,
	12219,
	12219,
	6754,
	6754,
	6623,
	6623,
	6623,
	6754,
	6623,
	5326,
	6623,
	5326,
	6519,
	5221,
	6519,
	5221,
	6591,
	5295,
	6591,
	5295,
	6591,
	5295,
	6519,
	5221,
	6591,
	5295,
	6591,
	5295,
	6591,
	5295,
	6683,
	5381,
	6591,
	5295,
	6683,
	6754,
	6754,
	6754,
	6754,
	6754,
	4867,
	11307,
	5326,
	6754,
	6754,
	6683,
	6683,
	6683,
	6683,
	6683,
	6683,
	6591,
	6623,
	5326,
	6754,
	5295,
	6754,
	6754,
	6754,
	6754,
	6754,
	6754,
	2906,
	6519,
	5221,
	5221,
	2372,
	5221,
	6754,
	6754,
	5326,
	5326,
	6623,
	6754,
	6519,
	5221,
	6754,
	6754,
	6754,
	5326,
	2906,
	5326,
	5326,
	6754,
	6519,
	6623,
	6623,
	5221,
	12219,
	6754,
	3740,
	3740,
	6754,
	12169,
	2920,
	577,
	222,
	1693,
	2920,
	1288,
	448,
	4719,
	2920,
	859,
	223,
	4429,
	2920,
	899,
	224,
	4773,
	2920,
	1288,
	448,
	4719,
	2920,
	859,
	223,
	4429,
	6754,
	5326,
	6754,
	6754,
	6754,
	6591,
	6591,
	2360,
	2995,
	5326,
	115,
	288,
	1552,
	5429,
	1413,
	5326,
	2925,
	5326,
	5326,
	12219,
	0,
	6754,
	6623,
	6754,
	6754,
	6754,
	5326,
	0,
	6754,
	0,
	0,
	0,
	6754,
	5326,
	6754,
	5326,
	6754,
	6521,
	5224,
	6742,
	5435,
	6519,
	5221,
	253,
	253,
	5326,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	6521,
	5224,
	6521,
	5224,
	6591,
	5295,
	6683,
	5381,
	6519,
	5221,
	5381,
	5326,
	6519,
	6683,
	6519,
	6754,
	6683,
	5381,
	6683,
	5381,
	6683,
	5381,
	6519,
	5221,
	5381,
	5326,
	6519,
	6683,
	6519,
	6754,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	6623,
	5326,
	6623,
	6623,
	6754,
	6754,
	6754,
	6754,
	6754,
	5326,
	5326,
	5326,
	5326,
	5326,
	5326,
	5326,
	5326,
	5326,
	5326,
	5326,
	5326,
	5326,
	2925,
	2925,
	6754,
	6754,
	5221,
	5326,
	5326,
	2917,
	5326,
	5326,
	1180,
	6754,
	6591,
	5295,
	6623,
	5326,
	6519,
	5221,
	6591,
	5295,
	6591,
	5295,
	6744,
	5437,
	6744,
	5437,
	6744,
	5437,
	6683,
	5381,
	6591,
	5295,
	6683,
	5381,
	6683,
	5381,
	6683,
	5381,
	6683,
	5381,
	6683,
	5381,
	6742,
	5435,
	6742,
	5435,
	6591,
	5295,
	6519,
	6519,
	6519,
	6519,
	6519,
	1486,
	3021,
	6754,
	8391,
	6623,
	5326,
	6754,
	6754,
	6754,
	6623,
	6591,
	6591,
	2925,
	6623,
	10937,
	6754,
	6742,
	5435,
	6591,
	5295,
	5326,
	6754,
	6754,
	6519,
	6754,
	5326,
	6623,
	6623,
	5326,
	6623,
	5326,
	6623,
	5326,
	6623,
	5326,
	6623,
	5326,
	6623,
	5326,
	6648,
	5349,
	6648,
	5349,
	6519,
	5221,
	6591,
	5295,
	6742,
	5435,
	6742,
	5435,
	6742,
	5435,
	6744,
	5437,
	6744,
	5437,
	6683,
	5381,
	6591,
	5295,
	6742,
	5435,
	6519,
	5221,
	6519,
	5221,
	6591,
	5295,
	6683,
	5381,
	6683,
	5381,
	6683,
	5381,
	6683,
	5381,
	6683,
	5381,
	6742,
	5435,
	6742,
	5435,
	6519,
	5221,
	6519,
	5221,
	5326,
	6519,
	6519,
	6623,
	6623,
	6623,
	5326,
	6623,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	12169,
	11342,
	6519,
	5221,
	6591,
	5295,
	6623,
	6623,
	5326,
	6623,
	6623,
	6519,
	6754,
	6754,
	6519,
	2925,
	6623,
	5326,
	9474,
	2925,
	6519,
	3708,
	6519,
	6519,
	6519,
	8920,
	5326,
	6754,
	6754,
	6754,
	6754,
	6754,
	5221,
	6754,
	5326,
	6623,
	12219,
	6754,
	6754,
	6623,
	5326,
	6754,
	6623,
	5326,
	2655,
	5326,
	5326,
	5326,
	5326,
	5326,
	5326,
	5326,
	5326,
	5326,
	5326,
	5326,
	5326,
	5326,
	5326,
	5326,
	5326,
	5326,
	6754,
	6754,
	0,
	9968,
	9968,
	9968,
	9968,
	9968,
	9968,
	9968,
	9968,
	9968,
	9968,
	9968,
	9968,
	9968,
	9968,
	9968,
	9968,
	9968,
	9968,
	12169,
	12169,
	12169,
	12169,
	12169,
	12169,
	12169,
	12169,
	12169,
	12169,
	12169,
	12169,
	12169,
	12169,
	12169,
	12169,
	12169,
	12169,
	9968,
	0,
	0,
	0,
	0,
	0,
	0,
	12219,
	0,
	0,
	0,
	0,
	6623,
	6591,
	5295,
	6742,
	5435,
	6519,
	3708,
	3708,
	3708,
	6742,
	6742,
	6519,
	6591,
	4886,
	4826,
	3740,
	6754,
	6519,
	5221,
	6623,
	6623,
	5326,
	6623,
	6754,
	6754,
	0,
	11097,
	9478,
	8533,
	9569,
	2925,
	1289,
	6623,
	3708,
	6519,
	6754,
	6754,
	6754,
	6519,
	4429,
	6754,
	1135,
	5326,
	1290,
	2925,
	4403,
	6623,
	4712,
	4712,
	7819,
	5326,
	5326,
	3708,
	6754,
	6623,
	2925,
	6754,
	6623,
	5326,
	6591,
	5295,
	6754,
	6519,
	6519,
	4712,
	1415,
	6754,
	6519,
	6519,
	6754,
	6754,
	6591,
	6519,
	5221,
	6519,
	5221,
	6683,
	5381,
	6683,
	5381,
	6623,
	5326,
	6623,
	5326,
	6623,
	5326,
	6623,
	5326,
	6519,
	6754,
	2925,
	6519,
	6754,
	6754,
	6754,
	6519,
	1451,
	6519,
	6742,
	6519,
	6754,
	6519,
	5295,
	6519,
	5326,
	6623,
	6754,
	6519,
	5221,
	6519,
	5221,
	6754,
	6519,
	6519,
	6519,
	6754,
	6754,
	6754,
	1451,
	6754,
	6623,
	11342,
	12169,
	11342,
	12219,
	0,
	0,
	6591,
	6591,
	6591,
	6623,
	6623,
	6754,
	6754,
	6754,
	6754,
	6754,
	6754,
	2925,
	6754,
	6623,
	6591,
	6591,
	6603,
	5307,
	6591,
	5295,
	565,
	2925,
	2054,
	6754,
	12219,
	6623,
	5326,
	6519,
	6754,
	6623,
	6754,
	6754,
	6754,
	6754,
	6754,
	6519,
	6754,
	6754,
	6754,
	6754,
	6754,
	6754,
	6519,
	6754,
	10933,
	10933,
};
static const Il2CppTokenRangePair s_rgctxIndices[14] = 
{
	{ 0x02000087, { 11, 27 } },
	{ 0x0200008E, { 38, 7 } },
	{ 0x0200008F, { 45, 5 } },
	{ 0x0600008E, { 0, 3 } },
	{ 0x060002F1, { 3, 2 } },
	{ 0x06000458, { 5, 4 } },
	{ 0x06000459, { 9, 2 } },
	{ 0x0600067C, { 50, 2 } },
	{ 0x060006A2, { 52, 5 } },
	{ 0x060006A3, { 57, 1 } },
	{ 0x060006A4, { 58, 1 } },
	{ 0x060006A5, { 59, 1 } },
	{ 0x060006A6, { 60, 1 } },
	{ 0x060006A7, { 61, 1 } },
};
extern const uint32_t g_rgctx_GameObject_GetComponent_TisT_tDCDB222928733797E8A881B5E6860AECE6D2C87B_m4A9D4F24F342D6ED79FC709ACEEA1F5DB66ECE68;
extern const uint32_t g_rgctx_T_tDCDB222928733797E8A881B5E6860AECE6D2C87B;
extern const uint32_t g_rgctx_GameObject_AddComponent_TisT_tDCDB222928733797E8A881B5E6860AECE6D2C87B_mA3F5345F1762DBB8509064C972E1634189F75AB6;
extern const uint32_t g_rgctx_T_t4CE5249EE868EADA2EF337B748A959CE36EDC68C;
extern const Il2CppRGCTXConstrainedData g_rgctx_T_t4CE5249EE868EADA2EF337B748A959CE36EDC68C_Object_Equals_m07105C4585D3FE204F2A80D58523D001DC43F63B;
extern const uint32_t g_rgctx_EqualityComparer_1_get_Default_m3E4622851CCB9DA5DC1CEB3289DDBE10F5424603;
extern const uint32_t g_rgctx_EqualityComparer_1_tBBA6C41BC096CA6655CB0E0ECD1E295787CD837C;
extern const uint32_t g_rgctx_EqualityComparer_1_tBBA6C41BC096CA6655CB0E0ECD1E295787CD837C;
extern const uint32_t g_rgctx_EqualityComparer_1_Equals_m6F4573F4EA78FD68AFF236B0A106A95AA0BB7BBA;
extern const uint32_t g_rgctx_T_tAD0C781C6CA5D4906775F4DB23C0757A642BE3CC;
extern const Il2CppRGCTXConstrainedData g_rgctx_T_tAD0C781C6CA5D4906775F4DB23C0757A642BE3CC_Object_Equals_m07105C4585D3FE204F2A80D58523D001DC43F63B;
extern const uint32_t g_rgctx_IndexedSet_1_Add_mD20EC572DE14037FD7A9FE5DD175094403539AA1;
extern const uint32_t g_rgctx_List_1_t2D02B439A60142305D30BD294433449D8922C8C6;
extern const uint32_t g_rgctx_List_1_Add_m8D4D0140F1E49FA04DA28F07F993A26C5EDE7C88;
extern const uint32_t g_rgctx_List_1_get_Count_m0DC4CD1127534421D09FEA705DE80F6694752412;
extern const uint32_t g_rgctx_Dictionary_2_t47F9FA6433A13FDC91FE9527F27DE9E61ED763C6;
extern const uint32_t g_rgctx_Dictionary_2_Add_m3A38D2FC6C96C849FC10E687D72097305ABFF096;
extern const uint32_t g_rgctx_IndexedSet_1_EnableItem_mC8D13DF12750C15FBCEF80C2B1D03466FA4502C2;
extern const uint32_t g_rgctx_Dictionary_2_ContainsKey_m5DC4DD0C23CCA8B57FCFB320720E5DD6C285E362;
extern const uint32_t g_rgctx_IndexedSet_1_DisableItem_m9040FC7F6E07351B87855B597A94D8EEF7452170;
extern const uint32_t g_rgctx_Dictionary_2_TryGetValue_m61E88BDD99D44D8ED0D0005AC6BD763FD4F6AD3A;
extern const uint32_t g_rgctx_IndexedSet_1_Swap_mD3B9A95183A1DCC547EB9470165257DA74A23E1B;
extern const uint32_t g_rgctx_IndexedSet_1_RemoveAt_m93460241D6FE2C5A76BCF5ED7E138C6A3A2098F6;
extern const uint32_t g_rgctx_IndexedSet_1_GetEnumerator_m4F29E52D3658BED5203041BAEB69CC34711A4C2D;
extern const uint32_t g_rgctx_List_1_Clear_mAB6EF3ED221BAADA6E88D0E217FE2A41541E4B34;
extern const uint32_t g_rgctx_Dictionary_2_Clear_m4FF43671D9D1BD0E0CD0B70F8B1D6D857B0FF449;
extern const uint32_t g_rgctx_List_1_CopyTo_m2C75509C4BFDE2430579C027C9999F0870B2B59D;
extern const uint32_t g_rgctx_List_1_get_Item_mC6651E26E5A9883DB3DD16C72E206325C717F93E;
extern const uint32_t g_rgctx_List_1_RemoveAt_m97C070EC37AF2B92EBC68E0EF8B2F0E4D556F1F3;
extern const uint32_t g_rgctx_Dictionary_2_Remove_m1D7F2A69EDBA5BFAD35F9E7C416B0073A98516CC;
extern const uint32_t g_rgctx_List_1_set_Item_m140B60FAA886CF2400F87C32F9A7D045AAB98B32;
extern const uint32_t g_rgctx_Dictionary_2_set_Item_m33F1EE8B7595E01E9CE2E6D041640A01B2B50988;
extern const uint32_t g_rgctx_Predicate_1_tA2EDE53213BCD07C8FE4C3A0110189780F365E88;
extern const uint32_t g_rgctx_Predicate_1_Invoke_mD18C22C930F67CBD3C1DA61D885594BD3B2F561C;
extern const uint32_t g_rgctx_IndexedSet_1_Remove_mA0884D2F7B5BF67DDEC2434A3C6950A9B7CDF784;
extern const uint32_t g_rgctx_List_1_Sort_mA6609F95F5F8AE75DCE485B9059573B94E3BB6A9;
extern const uint32_t g_rgctx_List_1__ctor_mD37D3EB3894802797A15134D2B5A16F58D3ACFD8;
extern const uint32_t g_rgctx_Dictionary_2__ctor_mCF27B5F0486A62F3B2C2F515946616955DF00FE6;
extern const uint32_t g_rgctx_U3CStartU3Ed__2_t34E76D7E9AFCC508842E5758DE2CAFEE5E3B0DB4;
extern const uint32_t g_rgctx_U3CStartU3Ed__2__ctor_m66854530A2219382341C781A18D794C811A02705;
extern const uint32_t g_rgctx_TweenRunner_1_StopTween_m9B63AE5A4006FC35334F581AE9D2B31345B40C1B;
extern const uint32_t g_rgctx_T_tDD41B39C2629C5EB98444C2FDDAFD12366A424ED;
extern const Il2CppRGCTXConstrainedData g_rgctx_T_tDD41B39C2629C5EB98444C2FDDAFD12366A424ED_ITweenValue_TweenValue_m2C736D23475DD9895C07A345BD3B41CD0A96486D;
extern const uint32_t g_rgctx_TweenRunner_1_Start_m3C1186007278CF3B2081B3E7B0636E780DCBAF07;
extern const uint32_t g_rgctx_TweenRunner_1_t93A997920D7FA94D4C40C3554D50391D6CA04EBB;
extern const uint32_t g_rgctx_T_tD5818FCC55D7393F6B75BFE81A5252965161FCDF;
extern const Il2CppRGCTXConstrainedData g_rgctx_T_tD5818FCC55D7393F6B75BFE81A5252965161FCDF_ITweenValue_ValidTarget_m740605403325DF395B81749DB73275C2CA9B2DA9;
extern const Il2CppRGCTXConstrainedData g_rgctx_T_tD5818FCC55D7393F6B75BFE81A5252965161FCDF_ITweenValue_get_ignoreTimeScale_m13D8C5499B95314B248A92C936CE08E1580F9332;
extern const Il2CppRGCTXConstrainedData g_rgctx_T_tD5818FCC55D7393F6B75BFE81A5252965161FCDF_ITweenValue_get_duration_mB900628EB167B01368D3F5E1B6790AA5F8E0501A;
extern const Il2CppRGCTXConstrainedData g_rgctx_T_tD5818FCC55D7393F6B75BFE81A5252965161FCDF_ITweenValue_TweenValue_m2C736D23475DD9895C07A345BD3B41CD0A96486D;
extern const uint32_t g_rgctx_T_t58E37477D59675354F05DF74854CDE6C83341AC0;
extern const uint32_t g_rgctx_T_t58E37477D59675354F05DF74854CDE6C83341AC0;
extern const uint32_t g_rgctx_ExecuteEvents_GetEventList_TisT_tD2D65B1E49BADA45153C291D66E3D03F695D0EF3_mCA6E5D0B1E3D1D3F9FE2E9EB346D1DE8E20D2C2D;
extern const uint32_t g_rgctx_T_tD2D65B1E49BADA45153C291D66E3D03F695D0EF3;
extern const uint32_t g_rgctx_T_tD2D65B1E49BADA45153C291D66E3D03F695D0EF3;
extern const uint32_t g_rgctx_EventFunction_1_t22CB52A9851B399DC428B842E24E65952F3CEE08;
extern const uint32_t g_rgctx_EventFunction_1_Invoke_m06CD6B5F492CB3D17CF986E50B042AC8423D6566;
extern const uint32_t g_rgctx_ExecuteEvents_Execute_TisT_tA38065E18CDAB29F8D4D45B3D81509DFFE58A55D_m9AD6EDD5C3C4681CFF2D5481545F40CCEF708CB6;
extern const uint32_t g_rgctx_T_t3D7CB97D1CD271643D41497DBCD44565829B30BB;
extern const uint32_t g_rgctx_ExecuteEvents_ShouldSendToComponent_TisT_t02FD379FA294C29488ED497ADADDDE5C474B8875_m3FF7985681EFF3C08C818438428725D0D421BE46;
extern const uint32_t g_rgctx_ExecuteEvents_GetEventList_TisT_tA0E8C0350401F48FF3B7EBBEB7545D889BC028F8_mB695606F30CF787AC875F65414D59FA63865709E;
extern const uint32_t g_rgctx_ExecuteEvents_CanHandleEvent_TisT_t972CBEB03C4BD4F4E3B581D83A5C518ACCA216ED_mA0E3EB65CFD909872401B0296F3393AF7269BD0F;
static const Il2CppRGCTXDefinition s_rgctxValues[62] = 
{
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_GameObject_GetComponent_TisT_tDCDB222928733797E8A881B5E6860AECE6D2C87B_m4A9D4F24F342D6ED79FC709ACEEA1F5DB66ECE68 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_tDCDB222928733797E8A881B5E6860AECE6D2C87B },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_GameObject_AddComponent_TisT_tDCDB222928733797E8A881B5E6860AECE6D2C87B_mA3F5345F1762DBB8509064C972E1634189F75AB6 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_t4CE5249EE868EADA2EF337B748A959CE36EDC68C },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_T_t4CE5249EE868EADA2EF337B748A959CE36EDC68C_Object_Equals_m07105C4585D3FE204F2A80D58523D001DC43F63B },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_EqualityComparer_1_get_Default_m3E4622851CCB9DA5DC1CEB3289DDBE10F5424603 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_EqualityComparer_1_tBBA6C41BC096CA6655CB0E0ECD1E295787CD837C },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_EqualityComparer_1_tBBA6C41BC096CA6655CB0E0ECD1E295787CD837C },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_EqualityComparer_1_Equals_m6F4573F4EA78FD68AFF236B0A106A95AA0BB7BBA },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_tAD0C781C6CA5D4906775F4DB23C0757A642BE3CC },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_T_tAD0C781C6CA5D4906775F4DB23C0757A642BE3CC_Object_Equals_m07105C4585D3FE204F2A80D58523D001DC43F63B },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_IndexedSet_1_Add_mD20EC572DE14037FD7A9FE5DD175094403539AA1 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_List_1_t2D02B439A60142305D30BD294433449D8922C8C6 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Add_m8D4D0140F1E49FA04DA28F07F993A26C5EDE7C88 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_get_Count_m0DC4CD1127534421D09FEA705DE80F6694752412 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Dictionary_2_t47F9FA6433A13FDC91FE9527F27DE9E61ED763C6 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Dictionary_2_Add_m3A38D2FC6C96C849FC10E687D72097305ABFF096 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_IndexedSet_1_EnableItem_mC8D13DF12750C15FBCEF80C2B1D03466FA4502C2 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Dictionary_2_ContainsKey_m5DC4DD0C23CCA8B57FCFB320720E5DD6C285E362 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_IndexedSet_1_DisableItem_m9040FC7F6E07351B87855B597A94D8EEF7452170 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Dictionary_2_TryGetValue_m61E88BDD99D44D8ED0D0005AC6BD763FD4F6AD3A },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_IndexedSet_1_Swap_mD3B9A95183A1DCC547EB9470165257DA74A23E1B },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_IndexedSet_1_RemoveAt_m93460241D6FE2C5A76BCF5ED7E138C6A3A2098F6 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_IndexedSet_1_GetEnumerator_m4F29E52D3658BED5203041BAEB69CC34711A4C2D },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Clear_mAB6EF3ED221BAADA6E88D0E217FE2A41541E4B34 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Dictionary_2_Clear_m4FF43671D9D1BD0E0CD0B70F8B1D6D857B0FF449 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_CopyTo_m2C75509C4BFDE2430579C027C9999F0870B2B59D },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_get_Item_mC6651E26E5A9883DB3DD16C72E206325C717F93E },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_RemoveAt_m97C070EC37AF2B92EBC68E0EF8B2F0E4D556F1F3 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Dictionary_2_Remove_m1D7F2A69EDBA5BFAD35F9E7C416B0073A98516CC },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_set_Item_m140B60FAA886CF2400F87C32F9A7D045AAB98B32 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Dictionary_2_set_Item_m33F1EE8B7595E01E9CE2E6D041640A01B2B50988 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Predicate_1_tA2EDE53213BCD07C8FE4C3A0110189780F365E88 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Predicate_1_Invoke_mD18C22C930F67CBD3C1DA61D885594BD3B2F561C },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_IndexedSet_1_Remove_mA0884D2F7B5BF67DDEC2434A3C6950A9B7CDF784 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1_Sort_mA6609F95F5F8AE75DCE485B9059573B94E3BB6A9 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_List_1__ctor_mD37D3EB3894802797A15134D2B5A16F58D3ACFD8 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Dictionary_2__ctor_mCF27B5F0486A62F3B2C2F515946616955DF00FE6 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_U3CStartU3Ed__2_t34E76D7E9AFCC508842E5758DE2CAFEE5E3B0DB4 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_U3CStartU3Ed__2__ctor_m66854530A2219382341C781A18D794C811A02705 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_TweenRunner_1_StopTween_m9B63AE5A4006FC35334F581AE9D2B31345B40C1B },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_tDD41B39C2629C5EB98444C2FDDAFD12366A424ED },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_T_tDD41B39C2629C5EB98444C2FDDAFD12366A424ED_ITweenValue_TweenValue_m2C736D23475DD9895C07A345BD3B41CD0A96486D },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_TweenRunner_1_Start_m3C1186007278CF3B2081B3E7B0636E780DCBAF07 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TweenRunner_1_t93A997920D7FA94D4C40C3554D50391D6CA04EBB },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_tD5818FCC55D7393F6B75BFE81A5252965161FCDF },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_T_tD5818FCC55D7393F6B75BFE81A5252965161FCDF_ITweenValue_ValidTarget_m740605403325DF395B81749DB73275C2CA9B2DA9 },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_T_tD5818FCC55D7393F6B75BFE81A5252965161FCDF_ITweenValue_get_ignoreTimeScale_m13D8C5499B95314B248A92C936CE08E1580F9332 },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_T_tD5818FCC55D7393F6B75BFE81A5252965161FCDF_ITweenValue_get_duration_mB900628EB167B01368D3F5E1B6790AA5F8E0501A },
	{ (Il2CppRGCTXDataType)5, (const void *)&g_rgctx_T_tD5818FCC55D7393F6B75BFE81A5252965161FCDF_ITweenValue_TweenValue_m2C736D23475DD9895C07A345BD3B41CD0A96486D },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_t58E37477D59675354F05DF74854CDE6C83341AC0 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_T_t58E37477D59675354F05DF74854CDE6C83341AC0 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ExecuteEvents_GetEventList_TisT_tD2D65B1E49BADA45153C291D66E3D03F695D0EF3_mCA6E5D0B1E3D1D3F9FE2E9EB346D1DE8E20D2C2D },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_tD2D65B1E49BADA45153C291D66E3D03F695D0EF3 },
	{ (Il2CppRGCTXDataType)1, (const void *)&g_rgctx_T_tD2D65B1E49BADA45153C291D66E3D03F695D0EF3 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_EventFunction_1_t22CB52A9851B399DC428B842E24E65952F3CEE08 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_EventFunction_1_Invoke_m06CD6B5F492CB3D17CF986E50B042AC8423D6566 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ExecuteEvents_Execute_TisT_tA38065E18CDAB29F8D4D45B3D81509DFFE58A55D_m9AD6EDD5C3C4681CFF2D5481545F40CCEF708CB6 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_t3D7CB97D1CD271643D41497DBCD44565829B30BB },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ExecuteEvents_ShouldSendToComponent_TisT_t02FD379FA294C29488ED497ADADDDE5C474B8875_m3FF7985681EFF3C08C818438428725D0D421BE46 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ExecuteEvents_GetEventList_TisT_tA0E8C0350401F48FF3B7EBBEB7545D889BC028F8_mB695606F30CF787AC875F65414D59FA63865709E },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_ExecuteEvents_CanHandleEvent_TisT_t972CBEB03C4BD4F4E3B581D83A5C518ACCA216ED_mA0E3EB65CFD909872401B0296F3393AF7269BD0F },
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_UnityEngine_UI_CodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_UI_CodeGenModule = 
{
	"UnityEngine.UI.dll",
	1881,
	s_methodPointers,
	72,
	s_adjustorThunks,
	s_InvokerIndices,
	0,
	NULL,
	14,
	s_rgctxIndices,
	62,
	s_rgctxValues,
	NULL,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
