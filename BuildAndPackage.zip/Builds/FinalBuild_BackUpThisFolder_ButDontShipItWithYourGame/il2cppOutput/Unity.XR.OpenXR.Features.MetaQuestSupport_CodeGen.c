﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





// 0x00000001 System.Void UnityEngine.XR.OpenXR.Features.MetaQuestSupport.MetaQuestFeature::.ctor()
extern void MetaQuestFeature__ctor_m5252F2B3583ED0398B5E04ECE2892C240D4F4E63 (void);
static Il2CppMethodPointer s_methodPointers[1] = 
{
	MetaQuestFeature__ctor_m5252F2B3583ED0398B5E04ECE2892C240D4F4E63,
};
static const int32_t s_InvokerIndices[1] = 
{
	6754,
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_Unity_XR_OpenXR_Features_MetaQuestSupport_CodeGenModule;
const Il2CppCodeGenModule g_Unity_XR_OpenXR_Features_MetaQuestSupport_CodeGenModule = 
{
	"Unity.XR.OpenXR.Features.MetaQuestSupport.dll",
	1,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
	NULL, // module initializer,
	NULL,
	NULL,
	NULL,
};
